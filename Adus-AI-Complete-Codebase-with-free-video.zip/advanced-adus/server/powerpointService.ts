import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { invokeLLM, selectChatModel } from "./_core/llm";
import { storagePut } from "./storage";
import { getRecord, saveRecord } from "./workspaceStore";
import {
  MAX_DATA_URL_CHARS,
  MAX_PICTURE_DATA_URL_CHARS,
  MAX_PICTURES,
  MAX_OUTLINE_ENTRIES,
  MAX_PPTX_BYTES,
  POWERPOINT_DRAFT_KIND,
  POWERPOINT_KIND,
  POWERPOINT_TASK_KIND,
  powerpointDraftSchema,
  powerpointGenerationRequestSchema,
  powerpointOutlineEntrySchema,
  powerpointPictureSchema,
  powerpointSourceSchema,
  type PowerPointAttachment,
  type PowerPointDraft,
  type PowerPointGenerationRequest,
  type PowerPointOutline,
  type PowerPointOutlineEntry,
  type PowerPointPicture,
  type PowerPointSource,
  type PowerPointTaskRecord,
  type PowerPointTaskState,
  safeTaskUrl,
} from "../shared/powerpoint";

const execFileAsync = promisify(execFile);
const API_BASE = "https://api.manus.ai";
const PPTX_MIME =
  "application/vnd.openxmlformats-officedocument.presentationml.presentation";
const MAX_ZIP_ENTRIES = 80;
const MAX_XML_BYTES = 512 * 1024;
const MAX_ARTIFACT_BYTES = 50 * 1024 * 1024;
const MAX_PICTURE_BYTES = 8 * 1024 * 1024;
const TASK_FETCH_TIMEOUT_MS = 30_000;
const ARTIFACT_FETCH_TIMEOUT_MS = 60_000;

export type ManusReadiness = {
  available: boolean;
  credentialEnv: "MANUS_API_KEY";
  message: string;
};

let readinessCache: {
  key: string;
  expiresAt: number;
  result: ManusReadiness;
} | null = null;

export function getManusReadiness(): ManusReadiness {
  return {
    available: false,
    credentialEnv: "MANUS_API_KEY",
    message: process.env.MANUS_API_KEY?.trim()
      ? "Checking the Manus API connection…"
      : "Full PowerPoint generation is not connected. An administrator needs to configure a valid presentation-service credential; editable outlines are available now.",
  };
}

/** Lightweight auth check, cached briefly so the tab does not hammer user.me. */
export async function checkManusReadiness(): Promise<ManusReadiness> {
  const key = process.env.MANUS_API_KEY?.trim() ?? "";
  if (!key) return getManusReadiness();
  const now = Date.now();
  if (readinessCache?.key === key && readinessCache.expiresAt > now)
    return readinessCache.result;
  let result: ManusReadiness;
  try {
    await apiRequest<{ user?: unknown }>(
      "/v2/user.me",
      { method: "GET" },
      key,
      10_000
    );
    result = {
      available: true,
      credentialEnv: "MANUS_API_KEY",
      message: "Slides generation is connected.",
    };
  } catch (error) {
    result = {
      available: false,
      credentialEnv: "MANUS_API_KEY",
      message:
        "The configured MANUS_API_KEY was rejected by Manus. Replace it in server project secrets, then re-check the connection.",
    };
    console.warn("[PowerPoint] Manus readiness check failed", error);
  }
  readinessCache = { key, expiresAt: now + 30_000, result };
  return result;
}

function requireManusApiKey(): string {
  const key = process.env.MANUS_API_KEY?.trim();
  if (!key) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message:
        "PowerPoint generation is ready but not connected. Set MANUS_API_KEY on the server, then retry.",
    });
  }
  return key;
}

async function requireAuthenticatedManusApiKey(): Promise<string> {
  const key = requireManusApiKey();
  const readiness = await checkManusReadiness();
  if (!readiness.available) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: readiness.message,
    });
  }
  return key;
}

export function decodePptxDataUrl(dataUrl: string): Buffer {
  if (dataUrl.length > MAX_DATA_URL_CHARS) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "The PPTX upload is too large.",
    });
  }
  const match = /^data:([^;,]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl);
  if (!match || match[1].toLowerCase() !== PPTX_MIME) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Upload a valid PowerPoint .pptx file.",
    });
  }
  const encoded = match[2].replace(/\s+/g, "");
  const bytes = Buffer.from(encoded, "base64");
  if (
    !bytes.length ||
    bytes.length > MAX_PPTX_BYTES ||
    bytes.subarray(0, 2).toString() !== "PK"
  ) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message:
        "The uploaded file is not a valid PowerPoint ZIP package or exceeds 20 MB.",
    });
  }
  return bytes;
}

export function validatePowerPointSource(source: PowerPointSource): Buffer {
  const parsed = powerpointSourceSchema.parse(source);
  if (!/\.pptx$/i.test(parsed.filename)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Upload a .pptx file.",
    });
  }
  return decodePptxDataUrl(parsed.dataUrl);
}

function decodeXmlText(text: string): string {
  return text
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) =>
      String.fromCodePoint(parseInt(code, 16))
    )
    .replace(/&#(\d+);/g, (_, code: string) =>
      String.fromCodePoint(Number(code))
    )
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
}

function slideNumber(name: string): number {
  return Number(/slide(\d+)\.xml$/i.exec(name)?.[1] ?? 0);
}

/**
 * Reads only slide XML text from the local PPTX ZIP for a preview. It never
 * executes or forwards extracted package files and is bounded by entry/byte
 * limits. The original ZIP is still sent to Manus Slides for actual editing.
 */
export async function extractPptxOutline(
  bytes: Buffer
): Promise<PowerPointOutlineEntry[]> {
  if (
    !bytes.length ||
    bytes.length > MAX_PPTX_BYTES ||
    bytes.subarray(0, 2).toString() !== "PK"
  )
    return [];
  const directory = await mkdtemp(join(tmpdir(), "adus-pptx-"));
  const archivePath = join(directory, "source.pptx");
  try {
    await writeFile(archivePath, bytes, { mode: 0o600 });
    const listing = await execFileAsync("unzip", ["-Z1", archivePath], {
      timeout: 10_000,
      maxBuffer: 500_000,
    });
    const entries = String(listing.stdout)
      .split(/\r?\n/)
      .map(name => name.trim())
      .filter(name => /^ppt\/slides\/slide\d+\.xml$/i.test(name))
      .sort((a, b) => slideNumber(a) - slideNumber(b))
      .slice(0, MAX_ZIP_ENTRIES);
    const result: PowerPointOutlineEntry[] = [];
    for (const name of entries) {
      const extracted = await execFileAsync(
        "unzip",
        ["-p", archivePath, name],
        {
          timeout: 10_000,
          maxBuffer: MAX_XML_BYTES,
        }
      );
      const xml = String(extracted.stdout).slice(0, MAX_XML_BYTES);
      const text = Array.from(
        xml.matchAll(/<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>/gi)
      )
        .map(match =>
          decodeXmlText(match[1] ?? "")
            .replace(/\s+/g, " ")
            .trim()
        )
        .filter(Boolean);
      if (!text.length) continue;
      const title = text[0].slice(0, 160) || `Slide ${result.length + 1}`;
      result.push(
        powerpointOutlineEntrySchema.parse({
          id: `slide-${result.length + 1}`,
          title,
          summary: text.slice(1).join(" ").slice(0, 600),
          bullets: text.slice(1, 6).map(value => value.slice(0, 240)),
          sourceFacts: [],
        })
      );
    }
    return result.slice(0, MAX_OUTLINE_ENTRIES);
  } catch {
    return [];
  } finally {
    await rm(directory, { recursive: true, force: true }).catch(
      () => undefined
    );
  }
}

async function apiRequest<T>(
  path: string,
  init: RequestInit,
  key: string,
  timeoutMs = TASK_FETCH_TIMEOUT_MS
): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    signal: init.signal ?? AbortSignal.timeout(timeoutMs),
    headers: {
      Accept: "application/json",
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      "x-manus-api-key": key,
      ...(init.headers ?? {}),
    },
  });
  const raw = await response.text();
  let body: any = {};
  try {
    body = raw ? JSON.parse(raw) : {};
  } catch {
    body = { error: { message: raw.slice(0, 500) } };
  }
  if (!response.ok || body.ok === false) {
    throw new Error(
      body.error?.message || `Manus API request failed (${response.status}).`
    );
  }
  return body as T;
}

export async function resolveSlidesSkillId(
  key = requireManusApiKey()
): Promise<string> {
  const response = await apiRequest<{
    data?: Array<{ id?: string; name?: string; description?: string }>;
  }>("/v2/skill.list", { method: "GET" }, key);
  const skill = (response.data ?? []).find(item => {
    const haystack =
      `${item.name ?? ""} ${item.description ?? ""} ${item.id ?? ""}`.toLowerCase();
    return /slides?|powerpoint|presentation|pptx/.test(haystack);
  });
  if (!skill?.id) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message:
        "No Slides skill is available for this Manus account. Refresh skill access and try again.",
    });
  }
  return skill.id;
}

async function uploadPptx(
  bytes: Buffer,
  filename: string,
  key: string
): Promise<string> {
  const created = await apiRequest<{
    file?: { id?: string };
    upload_url?: string;
  }>(
    "/v2/file.upload",
    { method: "POST", body: JSON.stringify({ filename }) },
    key
  );
  if (!created.file?.id || !created.upload_url)
    throw new Error("Manus returned an incomplete file upload reservation.");
  const upload = await fetch(created.upload_url, {
    method: "PUT",
    headers: { "Content-Type": PPTX_MIME },
    body: bytes as any,
    signal: AbortSignal.timeout(TASK_FETCH_TIMEOUT_MS),
  });
  if (!upload.ok)
    throw new Error(`Manus file upload failed (${upload.status}).`);
  return created.file.id;
}

function decodePictureDataUrl(picture: PowerPointPicture): Buffer {
  const parsed = powerpointPictureSchema.parse(picture);
  const prefix = `data:${parsed.mimeType};base64,`;
  if (!parsed.dataUrl.toLowerCase().startsWith(prefix.toLowerCase()))
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `The picture ${parsed.filename} is not a valid base64 image.`,
    });
  const encoded = parsed.dataUrl.slice(prefix.length).replace(/\s+/g, "");
  if (!/^[A-Za-z0-9+/=]+$/.test(encoded))
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `The picture ${parsed.filename} is not a valid base64 image.`,
    });
  const bytes = Buffer.from(encoded, "base64");
  if (!bytes.length || bytes.length > MAX_PICTURE_BYTES)
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Each picture must be a valid image no larger than 8 MB.",
    });
  return bytes;
}

async function uploadPicture(
  picture: PowerPointPicture,
  key: string
): Promise<string> {
  const parsed = powerpointPictureSchema.parse(picture);
  const bytes = decodePictureDataUrl(parsed);
  const created = await apiRequest<{
    file?: { id?: string };
    upload_url?: string;
  }>(
    "/v2/file.upload",
    { method: "POST", body: JSON.stringify({ filename: parsed.filename }) },
    key
  );
  if (!created.file?.id || !created.upload_url)
    throw new Error("Manus returned an incomplete picture upload reservation.");
  const upload = await fetch(created.upload_url, {
    method: "PUT",
    headers: { "Content-Type": parsed.mimeType },
    body: bytes as any,
    signal: AbortSignal.timeout(TASK_FETCH_TIMEOUT_MS),
  });
  if (!upload.ok)
    throw new Error(`Manus picture upload failed (${upload.status}).`);
  return created.file.id;
}

export function promptProhibitsPictures(prompt: string): boolean {
  return (
    /\b(no|without|don't|do not|avoid|exclude|omit|text[- ]only|picture[- ]free|image[- ]free)\b[\s\w-]{0,32}\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b/i.test(
      prompt
    ) ||
    /\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b[\s\w-]{0,24}\b(no|not|none|without|excluded|omitted)\b/i.test(
      prompt
    ) ||
    /(?:sin|sans|sem|ohne|bez|بدون|من دون|لا|画像なし|画像は不要|이미지 없이|不要图片|无图片)[\s\w-]{0,10}(?:pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?|imágenes?|fotos?|bilder|صور|画像|イメージ|사진|이미지|图片)/i.test(
      prompt
    )
  );
}

export function promptRequestsPictures(prompt: string): boolean {
  return (
    /\b(add|include|use|find|search(?: for)?|source|generate|create|illustrate|visuali[sz]e|show|with)\b[\s\w-]{0,48}\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b/i.test(
      prompt
    ) ||
    /\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b[\s\w-]{0,24}\b(for|in|throughout|on|of)\b/i.test(
      prompt
    ) ||
    /(?:ajouter|inclure|utiliser|chercher|générer|créer|avec des|incluir imágenes|com imagens|mit bildern|صور|画像|이미지|图片)/i.test(
      prompt
    )
  );
}

export function picturesPermitted(prompt: string, allowPictures: boolean): boolean {
  if (promptProhibitsPictures(prompt)) return false;
  return allowPictures || promptRequestsPictures(prompt);
}

function canUsePictures(request: PowerPointGenerationRequest): boolean {
  return picturesPermitted(request.prompt, request.allowPictures);
}

function sourceFactsForPrompt(draft: PowerPointDraft): string {
  const facts = [
    ...draft.sourceFacts,
    ...draft.outline.flatMap(item => item.sourceFacts),
  ].filter(Boolean);
  return facts.length
    ? facts.map((fact, index) => `${index + 1}. ${fact}`).join("\n")
    : "No source facts were supplied.";
}

export function deckTaskPrompt(
  draft: PowerPointDraft,
  sourceFilename?: string,
  pictureFilenames: string[] = []
): string {
  const outline = draft.outline
    .map((item, index) => {
      const bullets = item.bullets.length
        ? `\nBullets: ${item.bullets.join(" | ")}`
        : "";
      const facts = item.sourceFacts.length
        ? `\nFacts: ${item.sourceFacts.join(" | ")}`
        : "";
      return `${index + 1}. ${item.title}\nSummary: ${item.summary}${bullets}${facts}`;
    })
    .join("\n\n");
  return [
    `Create or edit a native, editable PowerPoint deck using the Slides skill.`,
    `User request (preserve this intent exactly): ${draft.prompt || draft.topic}`,
    `Topic: ${draft.topic}`,
    `Audience: ${draft.audience}`,
    `Language: ${draft.language}`,
    `Visual direction: ${draft.style}`,
    `Requested slide count: ${draft.slideCount}`,
    draft.effectsPrompt
      ? `Requested animations/effects (pass to Slides as a request, not a guarantee): ${draft.effectsPrompt}`
      : "No animations or effects were requested.",
    sourceFilename
      ? `Edit the attached existing PowerPoint file: ${sourceFilename}. Preserve useful existing content while applying this reviewed outline.`
      : "Create a new deck from the reviewed outline.",
    "Use only the supplied source facts for factual claims. Do not fabricate statistics, citations, quotes, or authorities. If a fact is not supplied, express it as a framing statement or omit it.",
    draft.allowPictures && pictureFilenames.length
      ? `The user permitted pictures. Use these attached user pictures where helpful: ${pictureFilenames.join(", ")}. You may also search for or generate additional pictures only when needed to fulfill the user's explicit picture request; do not add unrelated imagery.`
      : draft.allowPictures
        ? "The user permitted pictures. Search for or generate pictures only when needed to fulfill the user's explicit picture request; do not add unrelated imagery."
        : "Pictures are not permitted for this request. Do not search for, generate, or add pictures; use text, shapes, diagrams, and data supplied by the user only.",
    "Create original, audience-specific wording with a clear story, varied sentence lengths and concrete examples. Use bespoke layouts, generous whitespace, charts only from supplied data, diagrams, restrained colors, consistent alignment and readable type. Avoid repetitive bullet-only slides. Pass requested effects to Slides as an instruction, but do not promise unsupported animations or effects. Do not promise that the deck is undetectable or make AI-detector claims.",
    `Source facts:\n${sourceFactsForPrompt(draft)}`,
    `Reviewed outline:\n${outline}`,
    "Return the exported editable PPTX as the task output attachment.",
  ].join("\n\n");
}

export type CreatePowerPointTaskInput = {
  draft: PowerPointDraft;
  source?: PowerPointSource;
  pictures?: PowerPointPicture[];
};

export async function createPowerPointTask(
  userId: number,
  input: CreatePowerPointTaskInput
): Promise<PowerPointTaskRecord> {
  const key = await requireAuthenticatedManusApiKey();
  const draft = powerpointDraftSchema.parse(input.draft);
  const source = input.source
    ? powerpointSourceSchema.parse(input.source)
    : undefined;
  const bytes = source ? validatePowerPointSource(source) : undefined;
  const requestedPictures = (input.pictures ?? []).map(item =>
    powerpointPictureSchema.parse(item)
  );
  const pictures = canUsePictures({
    prompt: draft.prompt || draft.topic,
    slideCount: draft.slideCount,
    effectsPrompt: draft.effectsPrompt,
    allowPictures: draft.allowPictures,
    pictures: requestedPictures,
  })
    ? requestedPictures.slice(0, MAX_PICTURES)
    : [];
  const skillId = await resolveSlidesSkillId(key);
  const fileId =
    bytes && source ? await uploadPptx(bytes, source.filename, key) : undefined;
  const pictureFileIds = await Promise.all(
    pictures.map(picture => uploadPicture(picture, key))
  );
  const message: any = {
    content: [
      {
        type: "text",
        text: deckTaskPrompt(
          {
            ...draft,
            allowPictures: picturesPermitted(
              draft.prompt || draft.topic,
              draft.allowPictures
            ),
          },
          source?.filename,
          pictures.map(picture => picture.filename)
        ),
      },
      ...(fileId
        ? [
            {
              type: "file",
              file_id: fileId,
              filename: source?.filename,
              mime_type: PPTX_MIME,
            },
        ]
        : []),
      ...pictures.map((picture, index) => ({
        type: "file",
        file_id: pictureFileIds[index],
        filename: picture.filename,
        mime_type: picture.mimeType,
      })),
    ],
    force_skills: [skillId],
  };
  const created = await apiRequest<{
    task_id?: string;
    task?: { id?: string; url?: string };
    task_url?: string;
    url?: string;
  }>(
    "/v2/task.create",
    {
      method: "POST",
      body: JSON.stringify({
        message,
        title: draft.title,
        agent_profile: "standard",
        share_visibility: "private",
      }),
    },
    key
  );
  const taskId = created.task_id ?? created.task?.id;
  if (!taskId)
    throw new Error("Manus returned no task ID for the PowerPoint request.");
  const recordId = randomUUID();
  const record: PowerPointTaskRecord = {
    recordId,
    taskId,
    taskUrl:
      created.task_url ??
      created.url ??
      created.task?.url ??
      safeTaskUrl(taskId),
    title: draft.title,
    draft,
    sourceFilename: source?.filename,
    sourceFileId: fileId,
    pictureFilenames: pictures.map(picture => picture.filename),
    pictureFileIds,
    skillId,
    state: "queued",
    statusMessage: "Task created. Slides is preparing the editable deck.",
    updatedAt: Date.now(),
  };
  const saved = await saveRecord(
    userId,
    POWERPOINT_TASK_KIND,
    record,
    recordId
  );
  return saved.payload as PowerPointTaskRecord;
}

function textFromResponse(
  response: Awaited<ReturnType<typeof invokeLLM>>
): string {
  const content = response.choices?.[0]?.message?.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content))
    return content
      .filter(part => part.type === "text")
      .map(part => (part.type === "text" ? part.text : ""))
      .join("\n");
  return "";
}

const outlineJsonSchema = {
  type: "object",
  properties: {
    title: { type: "string" },
    topic: { type: "string" },
    audience: { type: "string" },
    language: { type: "string" },
    style: { type: "string" },
    slideCount: { type: "integer" },
    sourceFacts: { type: "array", items: { type: "string" } },
    outline: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "string" },
          title: { type: "string" },
          summary: { type: "string" },
          bullets: { type: "array", items: { type: "string" } },
          sourceFacts: { type: "array", items: { type: "string" } },
        },
        required: ["id", "title", "summary", "bullets", "sourceFacts"],
        additionalProperties: false,
      },
    },
  },
  required: [
    "title",
    "topic",
    "audience",
    "language",
    "style",
    "slideCount",
    "sourceFacts",
    "outline",
  ],
  additionalProperties: false,
} as const;

function preferredOutlineModel() {
  return selectChatModel({ mode: "fast" });
}

function draftPrompt(input: {
  topic: string;
  audience: string;
  language: string;
  style: string;
  slideCount: number;
  sourceOutline: PowerPointOutlineEntry[];
  sourceFacts?: string[];
  instruction?: string;
  draft?: PowerPointDraft;
  prompt?: string;
  effectsPrompt?: string;
}): string {
  return [
    "Create a concise, professional PowerPoint brief and editable slide outline.",
    "Never invent statistics, citations, quotes, named authorities, or source facts. Only place supplied facts in sourceFacts. Leave sourceFacts empty when none are supplied.",
    input.prompt ? `User's exact presentation request:\n${input.prompt}` : "",
    `Topic: ${input.topic}`,
    `Audience: ${input.audience}`,
    `Language: ${input.language}`,
    `Style: ${input.style}`,
    `Slide count: ${input.slideCount}`,
    input.effectsPrompt
      ? `Requested animations/effects (describe as a preference only): ${input.effectsPrompt}`
      : "",
    `Supplied source facts: ${(input.sourceFacts ?? []).join(" | ") || "none"}`,
    input.sourceOutline.length
      ? `Existing PPTX text preview to preserve where useful:\n${input.sourceOutline.map(item => `${item.title}: ${item.summary}`).join("\n")}`
      : "No existing PPTX outline was supplied.",
    input.draft
      ? `Current reviewed draft:\n${JSON.stringify(input.draft)}`
      : "",
    input.instruction ? `Revision request:\n${input.instruction}` : "",
    "Use an opening, a clear narrative arc, and a close. Keep each summary concrete and short. Use neutral framing when evidence is absent.",
  ]
    .filter(Boolean)
    .join("\n\n");
}

function normalizeDraft(
  raw: unknown,
  fallback: {
    topic: string;
    audience: string;
    language: string;
    style: string;
    slideCount: number;
    prompt?: string;
    effectsPrompt?: string;
    allowPictures?: boolean;
  }
): PowerPointDraft {
  const candidate = raw as Record<string, any>;
  const outline = Array.isArray(candidate?.outline) ? candidate.outline : [];
  const normalized = outline.slice(0, MAX_OUTLINE_ENTRIES).map((item, index) =>
    powerpointOutlineEntrySchema.parse({
      id: String(item?.id || `slide-${index + 1}`)
        .replace(/[^a-z0-9_-]/gi, "-")
        .slice(0, 48),
      title: String(item?.title || `Slide ${index + 1}`).slice(0, 160),
      summary: String(item?.summary || "").slice(0, 600),
      bullets: Array.isArray(item?.bullets)
        ? item.bullets.map(String).slice(0, 5)
        : [],
      sourceFacts: Array.isArray(item?.sourceFacts)
        ? item.sourceFacts.map(String).slice(0, 8)
        : [],
    })
  );
  if (normalized.length !== fallback.slideCount)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message:
        "The outline was incomplete. Your brief is kept; try generating it again.",
    });
  const requestedCount = fallback.slideCount;
  return powerpointDraftSchema.parse({
    title: String(candidate?.title || fallback.topic).slice(0, 200),
    topic: String(candidate?.topic || fallback.topic).slice(0, 240),
    audience: String(candidate?.audience || fallback.audience).slice(0, 240),
    language: fallback.language,
    style: fallback.style,
    slideCount: Math.min(12, Math.max(4, requestedCount)),
    outline: normalized.slice(0, Math.min(12, Math.max(4, requestedCount))),
    sourceFacts: Array.isArray(candidate?.sourceFacts)
      ? candidate.sourceFacts.map(String).slice(0, 40)
      : [],
    prompt: fallback.prompt ?? "",
    effectsPrompt: fallback.effectsPrompt ?? "",
    allowPictures: Boolean(fallback.allowPictures),
    pictureFilenames: [],
  });
}

export async function generatePowerPointDraft(input: {
  topic: string;
  audience: string;
  language: string;
  style: string;
  slideCount: number;
  source?: PowerPointSource;
  sourceFacts?: string[];
  prompt?: string;
  effectsPrompt?: string;
  allowPictures?: boolean;
}): Promise<{
  draft: PowerPointDraft;
  sourceOutline: PowerPointOutlineEntry[];
}> {
  const parsedSource = input.source
    ? powerpointSourceSchema.parse(input.source)
    : undefined;
  const sourceBytes = parsedSource
    ? validatePowerPointSource(parsedSource)
    : undefined;
  const sourceOutline = sourceBytes
    ? await extractPptxOutline(sourceBytes)
    : [];
  const model = await preferredOutlineModel();
  const response = await invokeLLM(
    {
      model,
      reasoning: { effort: "low" },
      maxCompletionTokens: 5000,
      signal: AbortSignal.timeout(60000),
      messages: [
        {
          role: "system",
          content:
            "Return JSON only. You are a careful presentation editor. Do not fabricate facts.",
        },
        { role: "user", content: draftPrompt({ ...input, sourceOutline }) },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "powerpoint_outline",
          strict: true,
          schema: outlineJsonSchema,
        },
      },
    },
    true
  );
  const content = textFromResponse(response);
  if (!content)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "The outline editor returned no draft.",
    });
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "The outline editor returned unreadable JSON.",
    });
  }
  return {
    draft: normalizeDraft(parsed, input),
    sourceOutline,
  };
}

export async function generatePowerPointTaskFromRequest(
  userId: number,
  request: PowerPointGenerationRequest
): Promise<PowerPointTaskRecord> {
  const parsed = powerpointGenerationRequestSchema.parse(request);
  const prompt = parsed.prompt.trim();
  const draftResult = await generatePowerPointDraft({
    topic: prompt.slice(0, 240),
    audience: "The audience described in the user's request",
    language: "English",
    style: "Executive clarity",
    slideCount: parsed.slideCount,
    sourceFacts: [],
    prompt,
    effectsPrompt: parsed.effectsPrompt,
    allowPictures: picturesPermitted(prompt, parsed.allowPictures),
  });
  return createPowerPointTask(userId, {
    draft: draftResult.draft,
    pictures: parsed.pictures,
  });
}

export async function revisePowerPointDraft(input: {
  draft: PowerPointDraft;
  instruction: string;
}): Promise<PowerPointDraft> {
  const draft = powerpointDraftSchema.parse(input.draft);
  const instruction = input.instruction.trim();
  if (!instruction)
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Describe the outline change you want.",
    });
  const model = await preferredOutlineModel();
  const response = await invokeLLM(
    {
      model,
      reasoning: { effort: "low" },
      maxCompletionTokens: 5000,
      signal: AbortSignal.timeout(60000),
      messages: [
        {
          role: "system",
          content:
            "Return JSON only. Revise the outline, preserve supplied source facts exactly, and never invent evidence.",
        },
        {
          role: "user",
          content: draftPrompt({
            ...draft,
            sourceOutline: [],
            sourceFacts: draft.sourceFacts,
            instruction,
            draft,
          }),
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "powerpoint_revised_outline",
          strict: true,
          schema: outlineJsonSchema,
        },
      },
    },
    true
  );
  const content = textFromResponse(response);
  if (!content)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "The outline editor returned no revision.",
    });
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "The outline editor returned unreadable JSON.",
    });
  }
  return normalizeDraft(parsed, draft);
}

function statusFromDetail(
  detail: any,
  messages: any[]
): {
  state: PowerPointTaskState;
  message: string;
  waitingForEventType?: string;
  waitingForEventId?: string;
} {
  const task = detail?.task ?? detail ?? {};
  const statusUpdate =
    messages.find(item => item?.type === "status_update")?.status_update ?? {};
  const agentStatus = String(
    task.agent_status ?? task.status ?? statusUpdate.agent_status ?? ""
  ).toLowerCase();
  const detailStatus = task.status_detail ?? statusUpdate.status_detail ?? {};
  if (agentStatus === "error" || task.error_message)
    return {
      state: "failed",
      message: task.error_message ?? "The Slides task failed.",
    };
  if (agentStatus === "waiting") {
    const waitingType = String(detailStatus.waiting_for_event_type ?? "");
    const input = /messageaskuser|cascadeaskuser/i.test(waitingType)
      ? "waiting_input"
      : "waiting_action";
    return {
      state: input,
      message:
        detailStatus.waiting_description ??
        "The task is waiting for input or an action.",
      waitingForEventType: waitingType,
      waitingForEventId: detailStatus.waiting_for_event_id,
    };
  }
  if (["running", "queued", "pending"].includes(agentStatus))
    return { state: "running", message: "Slides is working on the deck." };
  if (["completed", "success", "succeeded"].includes(agentStatus))
    return { state: "completed", message: "Slides completed the task." };
  if (agentStatus === "stopped") {
    if (task.has_running_background_jobs === false)
      return { state: "completed", message: "Slides completed the task." };
    return {
      state: "unknown",
      message:
        "Slides stopped its main run, but background work status is not yet confirmed.",
    };
  }
  return {
    state: "unknown",
    message: "The task status is not yet known; polling will continue.",
  };
}

export function parseTaskState(detail: unknown, messages: unknown[] = []) {
  return statusFromDetail(detail, Array.isArray(messages) ? messages : []);
}

function isAllowedArtifactUrl(value: string): boolean {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return false;
    const allowed = (
      process.env.MANUS_ARTIFACT_HOSTS ?? "private.manuscdn.com,.manuscdn.com"
    )
      .split(",")
      .map(host => host.trim().toLowerCase())
      .filter(Boolean);
    const hostname = url.hostname.toLowerCase();
    return allowed.some(host =>
      host.startsWith(".") ? hostname.endsWith(host) : hostname === host
    );
  } catch {
    return false;
  }
}
export { isAllowedArtifactUrl };

function attachmentsFromMessages(messages: any[]): PowerPointAttachment[] {
  const attachments: PowerPointAttachment[] = [];
  for (const event of messages) {
    const candidates = [
      ...(Array.isArray(event?.assistant_message?.attachments)
        ? event.assistant_message.attachments
        : []),
      ...(Array.isArray(event?.attachments) ? event.attachments : []),
    ];
    for (const attachment of candidates) {
      if (attachment && typeof attachment === "object")
        attachments.push(attachment as PowerPointAttachment);
    }
  }
  return attachments;
}

function findPptxAttachment(messages: any[]): PowerPointAttachment | undefined {
  return attachmentsFromMessages(messages).find(
    item =>
      Boolean(item.url) &&
      (item.content_type === PPTX_MIME ||
        /\.pptx(?:$|[?#])/i.test(item.filename ?? "") ||
        /pptx/i.test(item.url ?? ""))
  );
}

async function downloadArtifact(
  attachment: PowerPointAttachment
): Promise<Buffer> {
  const url = attachment.url ?? "";
  if (!isAllowedArtifactUrl(url))
    throw new Error(
      "The Slides output URL is not on the allowed Manus artifact host."
    );
  const response = await fetch(url, {
    signal: AbortSignal.timeout(ARTIFACT_FETCH_TIMEOUT_MS),
  });
  if (!response.ok)
    throw new Error(
      `The Slides output could not be downloaded (${response.status}).`
    );
  const length = Number(response.headers.get("content-length") ?? 0);
  if (length > MAX_ARTIFACT_BYTES)
    throw new Error("The PPTX output is larger than the workspace limit.");
  const bytes = Buffer.from(await response.arrayBuffer());
  if (
    !bytes.length ||
    bytes.length > MAX_ARTIFACT_BYTES ||
    bytes.subarray(0, 2).toString() !== "PK"
  )
    throw new Error("The Slides output was not a valid PPTX ZIP package.");
  return bytes;
}

async function sendManusMessage(
  taskId: string,
  content: string,
  skillId?: string
) {
  const key = await requireAuthenticatedManusApiKey();
  return apiRequest<{ task_id?: string }>(
    "/v2/task.sendMessage",
    {
      method: "POST",
      body: JSON.stringify({
        task_id: taskId,
        message: { content, ...(skillId ? { force_skills: [skillId] } : {}) },
      }),
    },
    key
  );
}

export async function sendPowerPointMessage(
  userId: number,
  taskRecordId: string,
  content: string
): Promise<PowerPointTaskRecord> {
  const stored = await getRecord(userId, POWERPOINT_TASK_KIND, taskRecordId);
  if (!stored)
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "That PowerPoint task was not found in your workspace.",
    });
  const record = stored.payload as PowerPointTaskRecord;
  if (!content.trim())
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Write a message before sending it to the task.",
    });
  await sendManusMessage(record.taskId, content.trim(), record.skillId);
  const next = {
    ...record,
    state: "running" as const,
    statusMessage: "Follow-up sent to the Slides task.",
    updatedAt: Date.now(),
  };
  const saved = await saveRecord(userId, POWERPOINT_TASK_KIND, next, stored.id);
  return saved.payload as PowerPointTaskRecord;
}

export async function pollPowerPointTask(
  userId: number,
  taskRecordId: string
): Promise<PowerPointTaskRecord> {
  const stored = await getRecord(userId, POWERPOINT_TASK_KIND, taskRecordId);
  if (!stored)
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "That PowerPoint task was not found in your workspace.",
    });
  const record = stored.payload as PowerPointTaskRecord;
  if (record.output) return record;
  const key = await requireAuthenticatedManusApiKey();
  const detail = await apiRequest<{ task?: any }>(
    `/v2/task.detail?task_id=${encodeURIComponent(record.taskId)}`,
    { method: "GET" },
    key
  );
  const messagesResponse = await apiRequest<{
    messages?: any[];
    has_more?: boolean;
    next_cursor?: string;
  }>(
    `/v2/task.listMessages?task_id=${encodeURIComponent(record.taskId)}&order=desc&limit=200&slides_format=pptx`,
    { method: "GET" },
    key
  );
  const messages = [...(messagesResponse.messages ?? [])];
  let cursor = messagesResponse.next_cursor;
  for (
    let page = 0;
    page < 4 && cursor && !findPptxAttachment(messages);
    page++
  ) {
    const nextPage = await apiRequest<{
      messages?: any[];
      has_more?: boolean;
      next_cursor?: string;
    }>(
      `/v2/task.listMessages?task_id=${encodeURIComponent(record.taskId)}&order=desc&limit=200&slides_format=pptx&cursor=${encodeURIComponent(cursor)}`,
      { method: "GET" },
      key
    );
    messages.push(...(nextPage.messages ?? []));
    cursor = nextPage.has_more ? nextPage.next_cursor : undefined;
  }
  const parsed = statusFromDetail(detail, messages);
  let next: PowerPointTaskRecord = {
    ...record,
    state: parsed.state,
    statusMessage: parsed.message,
    waitingForEventType: parsed.waitingForEventType,
    waitingForEventId: parsed.waitingForEventId,
    updatedAt: Date.now(),
  };
  if (parsed.state === "completed" && !record.output) {
    const attachment = findPptxAttachment(messages);
    if (attachment?.url) {
      try {
        const bytes = await downloadArtifact(attachment);
        const storedFile = await storagePut(
          `powerpoint/${userId}/${randomUUID()}.pptx`,
          bytes,
          PPTX_MIME
        );
        const output = {
          filename:
            attachment.filename?.replace(/[\\/\x00-\x1f]/g, "-") ||
            `${record.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase() || "presentation"}.pptx`,
          url: storedFile.url,
          key: storedFile.key,
          bytes: bytes.length,
          createdAt: Date.now(),
        };
        await saveRecord(
          userId,
          POWERPOINT_KIND,
          { taskRecordId, taskId: record.taskId, ...output },
          undefined
        );
        next = {
          ...next,
          output,
          statusMessage: "Editable PPTX saved to your workspace.",
        };
      } catch (error) {
        next = {
          ...next,
          state: "failed",
          statusMessage:
            error instanceof Error
              ? error.message
              : "The completed PPTX could not be saved.",
        };
      }
    } else {
      next = {
        ...next,
        statusMessage:
          "Slides completed, but no PPTX attachment was returned. Open the task to inspect its result.",
      };
    }
  }
  const saved = await saveRecord(userId, POWERPOINT_TASK_KIND, next, stored.id);
  return saved.payload as PowerPointTaskRecord;
}

export const powerpointServiceContracts = {
  PPTX_MIME,
  MAX_PPTX_BYTES,
  MAX_DATA_URL_CHARS,
  POWERPOINT_DRAFT_KIND,
  POWERPOINT_KIND,
  POWERPOINT_TASK_KIND,
};
