import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const home = readFileSync(
  new URL("../client/src/pages/Home.tsx", import.meta.url),
  "utf8"
);
const auth = readFileSync(
  new URL("../client/src/_core/hooks/useAuth.ts", import.meta.url),
  "utf8"
);
const entry = readFileSync(
  new URL("../client/src/main.tsx", import.meta.url),
  "utf8"
);

describe("October 12 parent UI integration", () => {
  it("keeps the stop-answer action separate from ending a call and muting the microphone", () => {
    expect(home).toContain('aria-label="Stop answer and listen"');
    expect(home).toContain("voiceControllerRef.current?.interrupt()");
    expect(home).toContain('aria-label="End voice call"');
    expect(home).toContain("toggleVoiceMute");
  });
  it("contains long messages and dedicates the mobile width to the chat", () => {
    expect(home).toContain("adus-chat-workspace");
    expect(home).toContain("adus-chat-shell");
    expect(home).toContain("adus-chat-messages");
    expect(home).toContain("[overflow-wrap:anywhere]");
    expect(home).not.toContain("max-w-[88%]");
  });
  it("does not write optional browser identity caches in render", () => {
    const memo = auth.slice(
      auth.indexOf("const state = useMemo"),
      auth.indexOf("useEffect(() =>", auth.indexOf("const state = useMemo"))
    );
    expect(memo).not.toContain("localStorage");
    expect(auth).toContain("Identity comes from the server");
  });
  it("does not report handled query errors twice", () => {
    expect(entry).toContain("if (!event.query.meta?.handledError)");
  });
});
