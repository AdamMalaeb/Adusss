import { randomUUID } from "node:crypto";
import sharp from "sharp";
import { z } from "zod";
import { attachmentSchema } from "./attachments";
import { generateImage } from "./_core/imageGeneration";
import { protectedProcedure, router } from "./_core/trpc";
import { saveRecord, listRecords, getRecord } from "./workspaceStore";
import { storagePut } from "./storage";
import { TRPCError } from "@trpc/server";

const MAX_BATCH = 5;
const MAX_RESIZE_INPUT_BYTES = 8 * 1024 * 1024;
const MAX_INPUT_PIXELS = 40_000_000;
const MAX_OUTPUT_PIXELS = 16_000_000;
const MAX_DIMENSION = 4096;
const IMAGE_HISTORY_KIND = "images";

const batchIndexSchema = z
  .number()
  .int()
  .min(0)
  .max(MAX_BATCH - 1);
const countSchema = z.number().int().min(1).max(MAX_BATCH);

const generateInputSchema = z.object({
  prompt: z.string().trim().min(1).max(12_000),
  index: batchIndexSchema,
  count: countSchema,
  reference: attachmentSchema.optional(),
});

const resizeInputSchema = z
  .object({
    file: attachmentSchema,
    width: z.number().int().min(1).max(MAX_DIMENSION),
    height: z.number().int().min(1).max(MAX_DIMENSION),
    fit: z.enum(["contain", "cover"]).default("contain"),
    format: z.enum(["png", "jpeg", "webp"]).default("png"),
  })
  .refine(value => value.width * value.height <= MAX_OUTPUT_PIXELS, {
    message: "The output cannot exceed 16 megapixels.",
    path: ["width"],
  });

function badRequest(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}

function decodeDataUrl(dataUrl: string, declaredMimeType: string): Buffer {
  const match = /^data:([^;,]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl);
  if (!match) badRequest("The attachment must be a base64 data URL.");
  const dataUrlMimeType = match[1].toLowerCase();
  if (
    !dataUrlMimeType.startsWith("image/") ||
    !declaredMimeType.toLowerCase().startsWith("image/")
  ) {
    badRequest("Only image attachments are supported here.");
  }
  if (dataUrlMimeType !== declaredMimeType.toLowerCase()) {
    badRequest("The attachment MIME type does not match its data URL.");
  }
  const buffer = Buffer.from(match[2].replace(/\s/g, ""), "base64");
  if (!buffer.length) badRequest("The image attachment is empty.");
  return buffer;
}

function validateBatchIndex(index: number, count: number) {
  if (index >= count) {
    badRequest(
      "The image index must be smaller than the requested batch count."
    );
  }
}

function generationPrompt(
  prompt: string,
  index: number,
  count: number,
  editing: boolean
): string {
  const ordinal = index + 1;
  const operation = editing
    ? "Edit the provided reference image"
    : "Create the finished image";
  return `${operation} as one complete, standalone image for item ${ordinal} of ${count}.\n\nUser request:\n${prompt}\n\nThis is an individual result, not a contact sheet or collage. Make this ordinal meaningfully distinct from the other items while keeping the user's subject and intent intact. Return a complete image that can be used on its own; never place multiple options, panels, frames, thumbnails, or variations in one canvas. ${editing ? "Preserve the reference identity, composition, lighting, perspective, product shape, color palette, and every untargeted detail. Change only what the request targets." : "Preserve any explicitly requested identity or product details and follow the requested composition."} Avoid watermarks, borders, UI chrome, placeholder art, and explanatory text unless the user explicitly asks for text in the image.`;
}

async function persistImageRecord(userId: number, payload: unknown) {
  try {
    await saveRecord(userId, IMAGE_HISTORY_KIND, payload);
  } catch (error) {
    // History is useful but should never turn a successfully generated image into a failed task.
    console.warn("[Images] Could not persist image history", error);
  }
}

export const imagesRouter = router({
  generateOne: protectedProcedure
    .input(generateInputSchema)
    .mutation(async ({ input, ctx }) => {
      validateBatchIndex(input.index, input.count);

      let originalImages:
        | Array<{ b64Json: string; mimeType: string }>
        | undefined;
      if (input.reference) {
        const buffer = decodeDataUrl(
          input.reference.dataUrl,
          input.reference.mimeType
        );
        originalImages = [
          {
            b64Json: buffer.toString("base64"),
            mimeType: input.reference.mimeType,
          },
        ];
      }

      const result = await generateImage({
        prompt: generationPrompt(
          input.prompt,
          input.index,
          input.count,
          Boolean(originalImages)
        ),
        originalImages,
        quality: "medium",
      });
      if (!result.url) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "The image service returned no image URL.",
        });
      }

      await persistImageRecord(ctx.user.id, {
        url: result.url,
        index: input.index,
        count: input.count,
        prompt: input.prompt,
        edited: Boolean(originalImages),
        createdAt: Date.now(),
      });
      return { url: result.url, index: input.index };
    }),

  resize: protectedProcedure
    .input(resizeInputSchema)
    .mutation(async ({ input, ctx }) => {
      const source = decodeDataUrl(input.file.dataUrl, input.file.mimeType);
      if (source.byteLength > MAX_RESIZE_INPUT_BYTES) {
        badRequest("The source image must be 8 MB or smaller.");
      }

      let metadata: { width?: number; height?: number };
      try {
        metadata = await sharp(source, {
          limitInputPixels: MAX_INPUT_PIXELS,
        }).metadata();
      } catch {
        badRequest("The attachment is not a readable image.");
      }
      const sourceWidth = metadata.width ?? 0;
      const sourceHeight = metadata.height ?? 0;
      if (
        !sourceWidth ||
        !sourceHeight ||
        sourceWidth * sourceHeight > MAX_INPUT_PIXELS
      ) {
        badRequest("The source image exceeds the 40 megapixel limit.");
      }

      const background =
        input.format === "jpeg"
          ? { r: 245, g: 245, b: 245, alpha: 1 }
          : { r: 0, g: 0, b: 0, alpha: 0 };
      let pipeline = sharp(source, {
        limitInputPixels: MAX_INPUT_PIXELS,
      }).resize({
        width: input.width,
        height: input.height,
        fit: input.fit,
        position: "centre",
        background,
      });
      if (input.format === "jpeg")
        pipeline = pipeline.jpeg({ quality: 92, mozjpeg: true });
      else if (input.format === "webp")
        pipeline = pipeline.webp({ quality: 92 });
      else pipeline = pipeline.png();

      let output: Buffer;
      try {
        output = await pipeline.toBuffer();
      } catch {
        badRequest("The image could not be resized with those settings.");
      }

      const extension = input.format === "jpeg" ? "jpg" : input.format;
      const stored = await storagePut(
        `images/resized/${ctx.user.id}/${randomUUID()}.${extension}`,
        output,
        input.format === "jpeg" ? "image/jpeg" : `image/${input.format}`
      );
      await persistImageRecord(ctx.user.id, {
        url: stored.url,
        key: stored.key,
        resized: true,
        createdAt: Date.now(),
      });
      return {
        url: stored.url,
        key: stored.key,
        width: input.width,
        height: input.height,
        format: input.format,
      };
    }),

  list: protectedProcedure.query(({ ctx }) =>
    listRecords(ctx.user.id, IMAGE_HISTORY_KIND)
  ),
  get: protectedProcedure
    .input(z.object({ id: z.string().trim().min(1).max(64) }))
    .query(({ input, ctx }) =>
      getRecord(ctx.user.id, IMAGE_HISTORY_KIND, input.id)
    ),
  history: router({
    list: protectedProcedure.query(({ ctx }) =>
      listRecords(ctx.user.id, IMAGE_HISTORY_KIND)
    ),
    get: protectedProcedure
      .input(z.object({ id: z.string().trim().min(1).max(64) }))
      .query(({ input, ctx }) =>
        getRecord(ctx.user.id, IMAGE_HISTORY_KIND, input.id)
      ),
  }),
});

export const imageRouter = imagesRouter;
export default imagesRouter;
