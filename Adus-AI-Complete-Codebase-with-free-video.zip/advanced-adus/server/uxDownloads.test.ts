import { beforeEach, describe, expect, it, vi } from "vitest";
import express from "express";

const mocks = vi.hoisted(() => ({ signed: vi.fn() }));
vi.mock("./storage", () => ({ storageGetSignedUrl: mocks.signed }));
vi.mock("./workspaceStore", () => ({
  listRecords: vi.fn(),
  getRecord: vi.fn(),
}));

import {
  registerMediaDownloads,
  signMediaTicket,
} from "./mediaDownloads";

const fixtures = [
  {
    name: "PNG",
    extension: "png",
    bytes: Buffer.from("89504e470d0a1a0a0000000d49484452", "hex"),
    type: "image/png",
  },
  {
    name: "PDF",
    extension: "pdf",
    bytes: Buffer.from("255044462d312e370a312030206f626a0a", "hex"),
    type: "application/pdf",
  },
  {
    name: "MP4",
    extension: "mp4",
    bytes: Buffer.from("000000186674797069736f6d00000200", "hex"),
    type: "video/mp4",
  },
] as const;

beforeEach(() => {
  vi.clearAllMocks();
  mocks.signed.mockResolvedValue("https://storage.test/object");
});

describe("deployed media attachment downloads", () => {
  it.each(fixtures)(
    "serves actual split $name bytes with a corrected attachment filename",
    async fixture => {
      const app = express();
      registerMediaDownloads(app);
      const server = app.listen(0);
      const originalFetch = globalThis.fetch;
      const chunks = [
        fixture.bytes.subarray(0, 1),
        fixture.bytes.subarray(1, 5),
        fixture.bytes.subarray(5),
      ];
      vi.spyOn(globalThis, "fetch").mockImplementation(async (input, init) => {
        if (String(input) === "https://storage.test/object") {
          const stream = new ReadableStream<Uint8Array>({
            start(controller) {
              for (const chunk of chunks) controller.enqueue(chunk);
              controller.close();
            },
          });
          return new Response(stream, {
            headers: { "content-type": "application/octet-stream" },
          });
        }
        return originalFetch(input, init);
      });
      try {
        const ticket = signMediaTicket("owned/object", `lesson.${fixture.extension}`);
        const response = await originalFetch(
          `http://127.0.0.1:${(server.address() as { port: number }).port}/api/media-download?ticket=${encodeURIComponent(ticket)}`
        );
        expect(response.status).toBe(200);
        expect(response.headers.get("content-type")).toBe(fixture.type);
        expect(response.headers.get("content-disposition")).toContain(
          `lesson.${fixture.extension}`
        );
        expect(Buffer.from(await response.arrayBuffer())).toEqual(fixture.bytes);
      } finally {
        server.close();
      }
    },
    15000
  );
});
