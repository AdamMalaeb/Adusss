import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import { protectedProcedure, router } from "./_core/trpc";
import {
  compareAndSwapRecord,
  getRecord,
  listRecords,
  saveRecord,
} from "./workspaceStore";
import {
  decryptCredentials,
  encryptCredentials,
  normalizeEmail,
  publicMailbox,
  safeDeliveryError,
  sendSingleMessage,
  transportForCredentials,
  verifySmtpCredentials,
  type SmtpCredentials,
} from "./communicationsEmail";
import { searchPublicContacts } from "./communicationsContacts";

export const COMMUNICATIONS_MAILBOX_KIND = "communicationsMailbox";
export const COMMUNICATIONS_DRAFT_KIND = "communicationsDraft";
export const COMMUNICATIONS_CAMPAIGN_KIND = "communicationsCampaign";
export const COMMUNICATIONS_MAILBOX_ID = "mailbox";
const MAX_RECIPIENTS = 50;
const campaignLocks = new Set<string>();

type MailboxRecord = {
  type: "mailbox";
  status: "connected" | "disconnected";
  encryptedCredentials?: string;
  host?: string;
  port?: number;
  email?: string;
  username?: string;
  secure?: boolean;
  verifiedAt?: number;
  verifiedAliases: string[];
  lastError?: string;
};

type DraftRecord = {
  type: "draft";
  title: string;
  objective: string;
  companyName?: string;
  recipientEmail?: string;
  recipientName?: string;
  subject: string;
  body: string;
  sources: Array<{ url: string; title: string }>;
  createdAt: number;
};

type RecipientRecord = {
  id: string;
  email: string;
  name?: string;
  sourceURL?: string;
  evidence?: string;
  status: "pending" | "sending" | "sent" | "failed";
  sentAt?: number;
  error?: string;
};

type CampaignRecord = {
  type: "campaign";
  title: string;
  from: string;
  subject: string;
  text: string;
  draftId?: string;
  recipients: RecipientRecord[];
  status: "review" | "sending" | "completed" | "partial" | "failed";
  createdAt: number;
  updatedAt: number;
};

const smtpInput = z.object({
  host: z.string().trim().min(1).max(253),
  port: z.number().int().min(1).max(65535),
  email: z.string().trim().min(3).max(320),
  username: z.string().trim().min(1).max(320),
  password: z.string().min(1).max(2048),
  secure: z.boolean().default(true),
});
const recipientInput = z.object({
  email: z.string().trim().min(3).max(320),
  name: z.string().trim().max(160).optional(),
  sourceURL: z.string().trim().url().max(2048).optional(),
  evidence: z.string().trim().max(500).optional(),
});
const draftContentInput = z.object({
  title: z.string().trim().min(1).max(160),
  objective: z.string().trim().min(3).max(4000),
  companyName: z.string().trim().max(160).optional(),
  recipientEmail: z.string().trim().max(320).optional(),
  recipientName: z.string().trim().max(160).optional(),
  subject: z.string().trim().min(1).max(240),
  body: z.string().trim().min(1).max(30_000),
  sources: z
    .array(
      z.object({ url: z.string().url().max(2048), title: z.string().max(240) })
    )
    .max(25)
    .default([]),
});
const draftSaveInput = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1).max(160),
  objective: z.string().trim().min(3).max(4000),
  companyName: z.string().trim().max(160).optional(),
  recipientEmail: z.string().trim().max(320).optional(),
  recipientName: z.string().trim().max(160).optional(),
  subject: z.string().trim().min(1).max(240),
  body: z.string().trim().min(1).max(30_000),
  sources: z
    .array(
      z.object({ url: z.string().url().max(2048), title: z.string().max(240) })
    )
    .max(25)
    .default([]),
});

function badRequest(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}
function conflict(message: string): never {
  throw new TRPCError({ code: "CONFLICT", message });
}
function serviceError(message: string): never {
  throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}
function asMailbox(value: unknown): MailboxRecord | undefined {
  if (!value || typeof value !== "object") return undefined;
  const record = value as Partial<MailboxRecord>;
  if (record.type !== "mailbox") return undefined;
  return {
    type: "mailbox",
    status: record.status === "connected" ? "connected" : "disconnected",
    encryptedCredentials: record.encryptedCredentials,
    host: record.host,
    port: record.port,
    email: record.email,
    username: record.username,
    secure: record.secure,
    verifiedAt: record.verifiedAt,
    verifiedAliases: Array.isArray(record.verifiedAliases)
      ? record.verifiedAliases
      : [],
    lastError: record.lastError,
  };
}
async function mailboxFor(userId: number) {
  const record = await getRecord(
    userId,
    COMMUNICATIONS_MAILBOX_KIND,
    `mailbox-${userId}`
  );
  return asMailbox(record?.payload);
}
function publicMailboxRecord(record?: MailboxRecord) {
  return publicMailbox(
    record ?? {
      status: "disconnected",
      verifiedAliases: [],
    }
  );
}
function requireSenderAllowed(sender: string, mailbox: MailboxRecord) {
  const normalized = normalizeEmail(sender);
  const allowed = [mailbox.email, ...mailbox.verifiedAliases]
    .filter((value): value is string => Boolean(value))
    .map(normalizeEmail);
  if (!allowed.includes(normalized)) {
    badRequest(
      "Sender must exactly match the connected mailbox or a verified alias."
    );
  }
  return normalized;
}
function readDraft(record: { id: string; payload: unknown }) {
  const payload = record.payload as Partial<DraftRecord>;
  if (
    payload.type !== "draft" ||
    typeof payload.subject !== "string" ||
    typeof payload.body !== "string"
  )
    return null;
  return { id: record.id, ...payload } as DraftRecord & { id: string };
}
function readCampaign(record: { id: string; payload: unknown }) {
  const payload = record.payload as Partial<CampaignRecord>;
  if (
    payload.type !== "campaign" ||
    typeof payload.from !== "string" ||
    typeof payload.subject !== "string" ||
    typeof payload.text !== "string" ||
    !Array.isArray(payload.recipients)
  )
    return null;
  return { id: record.id, ...payload } as CampaignRecord & { id: string };
}
function publicCampaign(campaign: CampaignRecord & { id: string }) {
  return {
    ...campaign,
    recipients: campaign.recipients.map(
      ({ email, name, sourceURL, evidence, id, status, sentAt, error }) => ({
        id,
        email,
        name,
        sourceURL,
        evidence,
        status,
        sentAt,
        error,
      })
    ),
  };
}
function publicDraft(draft: DraftRecord & { id: string }) {
  return { ...draft };
}

const draftResponseFormat = {
  type: "json_schema" as const,
  json_schema: {
    name: "professional_email_draft",
    strict: true,
    schema: {
      type: "object",
      properties: {
        subject: { type: "string", minLength: 1, maxLength: 240 },
        body: { type: "string", minLength: 1, maxLength: 30000 },
      },
      required: ["subject", "body"],
      additionalProperties: false,
    },
  },
};

export const communicationsRouter = router({
  mailbox: router({
    status: protectedProcedure.query(async ({ ctx }) =>
      publicMailboxRecord(await mailboxFor(ctx.user.id))
    ),
    connect: protectedProcedure
      .input(smtpInput)
      .mutation(async ({ ctx, input }) => {
        let credentials: SmtpCredentials;
        try {
          credentials = await verifySmtpCredentials(input);
        } catch (error) {
          console.error(
            "[Communications] SMTP verify failed",
            safeDeliveryError(error)
          );
          throw new TRPCError({
            code: "PRECONDITION_FAILED",
            message:
              "Mailbox verification failed. Check the public host, port, mailbox and app-password, then try again.",
          });
        }
        const record: MailboxRecord = {
          type: "mailbox",
          status: "connected",
          encryptedCredentials: encryptCredentials(credentials),
          host: credentials.host,
          port: credentials.port,
          email: credentials.email,
          username: credentials.username,
          secure: credentials.secure,
          verifiedAt: Date.now(),
          verifiedAliases: [],
        };
        await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_MAILBOX_KIND,
          record,
          `mailbox-${ctx.user.id}`
        );
        return publicMailboxRecord(record);
      }),
    verify: protectedProcedure.mutation(async ({ ctx }) => {
      const existing = await mailboxFor(ctx.user.id);
      if (!existing?.encryptedCredentials) return publicMailboxRecord(existing);
      try {
        const credentials = decryptCredentials(existing.encryptedCredentials);
        await verifySmtpCredentials(credentials);
        const updated: MailboxRecord = {
          ...existing,
          status: "connected",
          verifiedAt: Date.now(),
          lastError: undefined,
        };
        await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_MAILBOX_KIND,
          updated,
          `mailbox-${ctx.user.id}`
        );
        return publicMailboxRecord(updated);
      } catch (error) {
        const updated: MailboxRecord = {
          ...existing,
          status: "disconnected",
          lastError: safeDeliveryError(error),
        };
        await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_MAILBOX_KIND,
          updated,
          `mailbox-${ctx.user.id}`
        );
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message:
            "Mailbox verification failed. Reconnect with the current app-password.",
        });
      }
    }),
    disconnect: protectedProcedure
      .input(z.object({ confirmed: z.literal(true) }))
      .mutation(async ({ ctx }) => {
        const existing = await mailboxFor(ctx.user.id);
        const disconnected: MailboxRecord = {
          type: "mailbox",
          status: "disconnected",
          host: existing?.host,
          port: existing?.port,
          email: existing?.email,
          username: existing?.username,
          secure: existing?.secure,
          verifiedAliases: [],
        };
        // Overwrite the same per-user record without encryptedCredentials: credentials are deleted, not merely hidden.
        await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_MAILBOX_KIND,
          disconnected,
          `mailbox-${ctx.user.id}`
        );
        return publicMailboxRecord(disconnected);
      }),
  }),
  contacts: router({
    search: protectedProcedure
      .input(z.object({ companyName: z.string().trim().min(2).max(160) }))
      .mutation(async ({ input }) => {
        try {
          return await searchPublicContacts(input.companyName);
        } catch {
          throw new TRPCError({
            code: "BAD_GATEWAY",
            message:
              "Public contact search could not be verified. No contact was invented.",
          });
        }
      }),
  }),
  drafts: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const records = await listRecords(
        ctx.user.id,
        COMMUNICATIONS_DRAFT_KIND,
        100
      );
      return records
        .map(readDraft)
        .filter((draft): draft is DraftRecord & { id: string } =>
          Boolean(draft)
        )
        .map(publicDraft);
    }),
    save: protectedProcedure
      .input(draftSaveInput)
      .mutation(async ({ ctx, input }) => {
        const id = input.id ?? randomUUID();
        const draft: DraftRecord = {
          type: "draft",
          title: input.title,
          objective: input.objective,
          companyName: input.companyName,
          recipientEmail: input.recipientEmail
            ? normalizeEmail(input.recipientEmail)
            : undefined,
          recipientName: input.recipientName,
          subject: input.subject,
          body: input.body,
          sources: input.sources,
          createdAt: Date.now(),
        };
        const saved = await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_DRAFT_KIND,
          draft,
          id
        );
        return publicDraft({ id: saved.id, ...draft });
      }),
    generate: protectedProcedure
      .input(
        z.object({
          title: z
            .string()
            .trim()
            .min(1)
            .max(160)
            .default("Professional email"),
          objective: z.string().trim().min(3).max(4000),
          companyName: z.string().trim().max(160).optional(),
          recipientEmail: z.string().trim().max(320).optional(),
          recipientName: z.string().trim().max(160).optional(),
          context: z.string().trim().max(6000).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        let research:
          | Awaited<ReturnType<typeof searchPublicContacts>>
          | undefined;
        if (!input.recipientEmail) {
          if (!input.companyName)
            badRequest(
              "Enter a recipient or company name for public contact research."
            );
          try {
            research = await searchPublicContacts(input.companyName);
          } catch {
            throw new TRPCError({
              code: "BAD_GATEWAY",
              message:
                "Company research could not be verified. Enter an exact recipient instead.",
            });
          }
        }
        const researchContext = research
          ? `Verified public research for review only:\n${research.contacts.map(contact => `- ${contact.email} (source: ${contact.sourceURL})`).join("\n") || "No exact address found."}`
          : "An exact recipient was supplied by the user.";
        let response;
        try {
          response = await invokeLLM({
            model: "gpt-5-mini",
            maxCompletionTokens: 1200,
            reasoning: { effort: "minimal" },
            messages: [
              {
                role: "system",
                content:
                  "Write a concise, credible professional email. Do not claim facts not in the brief. Output JSON only with subject and body. Never invent email addresses.",
              },
              {
                role: "user",
                content: `Objective: ${input.objective}\nCompany: ${input.companyName ?? "Not provided"}\nRecipient: ${input.recipientName ?? "Not provided"}\nContext: ${input.context ?? ""}\n${researchContext}`,
              },
            ],
            response_format: draftResponseFormat,
          });
        } catch {
          throw new TRPCError({
            code: "SERVICE_UNAVAILABLE",
            message:
              "AI drafting is temporarily unavailable. You can still write and save the email manually.",
          });
        }
        const content = response.choices[0]?.message?.content;
        if (typeof content !== "string")
          serviceError("AI drafting returned no usable email content.");
        let generated: { subject: string; body: string };
        try {
          generated = z
            .object({
              subject: z.string().min(1).max(240),
              body: z.string().min(1).max(30_000),
            })
            .parse(JSON.parse(content));
        } catch {
          serviceError(
            "AI drafting returned an invalid email draft. Please retry or write it manually."
          );
        }
        const draft: DraftRecord = {
          type: "draft",
          title: input.title,
          objective: input.objective,
          companyName: input.companyName,
          recipientEmail: input.recipientEmail
            ? normalizeEmail(input.recipientEmail)
            : research?.contacts[0]?.email,
          recipientName: input.recipientName,
          subject: generated.subject,
          body: generated.body,
          sources: research?.sources ?? [],
          createdAt: Date.now(),
        };
        const saved = await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_DRAFT_KIND,
          draft
        );
        return { draft: publicDraft({ id: saved.id, ...draft }), research };
      }),
  }),
  campaigns: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const records = await listRecords(
        ctx.user.id,
        COMMUNICATIONS_CAMPAIGN_KIND,
        100
      );
      return records
        .map(readCampaign)
        .filter((campaign): campaign is CampaignRecord & { id: string } =>
          Boolean(campaign)
        )
        .map(publicCampaign);
    }),
    create: protectedProcedure
      .input(
        z.object({
          id: z.string().uuid().optional(),
          title: z.string().trim().min(1).max(160),
          from: z.string().trim().min(3).max(320),
          subject: z.string().trim().min(1).max(240),
          text: z.string().trim().min(1).max(30_000),
          draftId: z.string().uuid().optional(),
          recipients: z.array(recipientInput).min(1).max(MAX_RECIPIENTS),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (
          input.id &&
          (await getRecord(ctx.user.id, COMMUNICATIONS_CAMPAIGN_KIND, input.id))
        )
          conflict(
            "A saved campaign cannot be overwritten. Create a new campaign instead."
          );
        const mailbox = await mailboxFor(ctx.user.id);
        if (
          !mailbox?.encryptedCredentials ||
          mailbox.status !== "connected" ||
          !mailbox.email
        ) {
          badRequest("Connect mailbox before creating a campaign.");
        }
        const from = requireSenderAllowed(input.from, mailbox);
        const seen = new Set<string>();
        const recipients: RecipientRecord[] = [];
        for (const recipient of input.recipients) {
          const email = normalizeEmail(recipient.email);
          if (seen.has(email))
            badRequest("Each recipient may appear only once.");
          seen.add(email);
          recipients.push({
            ...recipient,
            email,
            id: randomUUID(),
            status: "pending",
          });
        }
        const campaign: CampaignRecord = {
          type: "campaign",
          title: input.title,
          from,
          subject: input.subject,
          text: input.text,
          draftId: input.draftId,
          recipients,
          status: "review",
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        const saved = await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_CAMPAIGN_KIND,
          campaign,
          input.id ?? randomUUID()
        );
        return publicCampaign({ id: saved.id, ...campaign });
      }),
    send: protectedProcedure
      .input(z.object({ id: z.string().uuid(), confirmed: z.literal(true) }))
      .mutation(async ({ ctx, input }) => {
        const record = await getRecord(
          ctx.user.id,
          COMMUNICATIONS_CAMPAIGN_KIND,
          input.id
        );
        const campaign = record ? readCampaign(record) : null;
        if (!campaign)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Campaign not found.",
          });
        if (campaign.status === "completed") return publicCampaign(campaign);
        if (
          campaignLocks.has(`${ctx.user.id}:${input.id}`) ||
          campaign.status === "sending"
        ) {
          conflict(
            "This campaign is already sending or has an indeterminate delivery. Review recipient statuses before retrying."
          );
        }
        const mailbox = await mailboxFor(ctx.user.id);
        if (!mailbox?.encryptedCredentials || mailbox.status !== "connected")
          badRequest("Connect and verify mailbox before sending.");
        requireSenderAllowed(campaign.from, mailbox);
        const credentials = decryptCredentials(mailbox.encryptedCredentials);
        const lockKey = `${ctx.user.id}:${input.id}`;
        if (campaignLocks.has(lockKey))
          conflict("This campaign is already sending.");
        campaignLocks.add(lockKey);
        const { id: _id, ...payload } = campaign;
        const sending: CampaignRecord = {
          ...payload,
          recipients: payload.recipients.map(recipient => ({ ...recipient })),
          status: "sending",
          updatedAt: Date.now(),
        };
        let transport: ReturnType<typeof transportForCredentials> | undefined;
        try {
          const claimed = await compareAndSwapRecord(
            ctx.user.id,
            COMMUNICATIONS_CAMPAIGN_KIND,
            input.id,
            record!.payload,
            sending
          );
          if (!claimed)
            conflict(
              "This campaign changed or is already sending. Refresh its saved status."
            );
          transport = transportForCredentials(credentials);
          // Intentionally sequential (concurrency 1): each recipient gets an individual message and every status is durable.
          for (const recipient of sending.recipients) {
            if (recipient.status !== "pending" && recipient.status !== "failed")
              continue;
            recipient.status = "sending";
            recipient.error = undefined;
            await saveRecord(
              ctx.user.id,
              COMMUNICATIONS_CAMPAIGN_KIND,
              sending,
              input.id
            );
            try {
              await sendSingleMessage(transport, {
                from: sending.from,
                to: recipient.email,
                subject: sending.subject,
                text: sending.text,
              });
              recipient.status = "sent";
              recipient.sentAt = Date.now();
            } catch (error) {
              recipient.status = "failed";
              recipient.error = safeDeliveryError(error);
            }
            sending.updatedAt = Date.now();
            await saveRecord(
              ctx.user.id,
              COMMUNICATIONS_CAMPAIGN_KIND,
              sending,
              input.id
            );
          }
        } finally {
          transport?.close();
          campaignLocks.delete(lockKey);
        }
        const sent = sending.recipients.filter(
          recipient => recipient.status === "sent"
        ).length;
        const unknown = sending.recipients.filter(
          recipient => recipient.status === "sending"
        ).length;
        const failed = sending.recipients.filter(
          recipient =>
            recipient.status === "failed" || recipient.status === "pending"
        ).length;
        sending.status =
          unknown || (sent && failed)
            ? "partial"
            : sent === sending.recipients.length
              ? "completed"
              : "failed";
        sending.updatedAt = Date.now();
        await saveRecord(
          ctx.user.id,
          COMMUNICATIONS_CAMPAIGN_KIND,
          sending,
          input.id
        );
        return publicCampaign({ id: input.id, ...sending });
      }),
  }),
});
