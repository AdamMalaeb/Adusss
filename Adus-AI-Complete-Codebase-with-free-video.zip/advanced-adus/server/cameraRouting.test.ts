import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
const m = vi.hoisted(() => ({ llm: vi.fn(), image: vi.fn(), save: vi.fn() }));
vi.mock("./_core/llm", async importOriginal => ({
  ...(await importOriginal<typeof import("./_core/llm")>()),
  invokeLLM: m.llm,
  listLLMModels: vi.fn(),
}));
vi.mock("./_core/imageGeneration", () => ({
  generateImage: m.image,
  listImageModels: vi.fn(),
}));
vi.mock("./workspaceStore", () => ({
  getRecord: vi.fn(async () => undefined),
  listRecords: vi.fn(async () => []),
  saveRecord: m.save,
}));
import { appRouter } from "./routers";
import { cameraFrameSchema } from "./cameraFrame";
import sharp from "sharp";
const caller = () =>
  appRouter.createCaller({
    user: { id: 7, email: "qa@example.com" },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
beforeEach(() => {
  vi.clearAllMocks();
  m.llm.mockResolvedValue({
    choices: [
      {
        message: {
          content:
            "Certainly. The reason is that waves transfer energy through local oscillations.",
        },
      },
    ],
  });
  m.save.mockResolvedValue({ id: "new1" });
});
describe("Professional camera calls", () => {
  it("uses the fast visual model with a current JPEG and never saves camera footage", async () => {
    const bytes = await sharp({
      create: { width: 32, height: 24, channels: 3, background: "blue" },
    })
      .jpeg()
      .toBuffer();
    const frame = {
      name: "Live camera frame" as const,
      mimeType: "image/jpeg" as const,
      dataUrl: "data:image/jpeg;base64," + bytes.toString("base64"),
    };
    await caller().adus.chat({
      message: "Explain what I am showing you",
      voiceMode: true,
      cameraMode: true,
      cameraFrame: frame,
    });
    const req = m.llm.mock.calls[0][0];
    expect(req.model).toBe("gemini-3-flash-preview");
    expect(req.maxTokens).toBe(1800);
    expect(req.maxCompletionTokens).toBeUndefined();
    expect(
      req.messages.at(-1).content.some((p: any) => p.type === "image_url")
    ).toBe(true);
    expect(m.save).not.toHaveBeenCalled();
    expect(m.image).not.toHaveBeenCalled();
    expect(req.messages[0].content).toMatch(/professional/i);
  });
  it("keeps ordinary audio-only call routing and enough space for explanation", async () => {
    await caller().adus.chat({
      message: "Why do waves move?",
      voiceMode: true,
    });
    const req = m.llm.mock.calls[0][0];
    expect(req.model).toBe("gpt-5-mini");
    expect(req.maxCompletionTokens).toBe(1000);
    expect(req.messages[0].content).toMatch(/reason|explanation|justif/i);
  });
  it("rejects hidden camera uploads outside camera calls", async () => {
    await expect(
      caller().adus.chat({ message: "Hi", cameraMode: true })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
  it("rejects non-JPEG URLs, tiny malformed bytes and oversized camera data", () => {
    for (const dataUrl of [
      "https://example.com/a.jpg",
      "data:image/jpeg;base64,YWJj",
      "data:image/png;base64,YWJj",
    ])
      expect(
        cameraFrameSchema.safeParse({ mimeType: "image/jpeg", dataUrl }).success
      ).toBe(false);
  });
  it("builds with an available deep model and working same-document navigation", async () => {
    m.llm.mockResolvedValue({
      choices: [
        {
          message: {
            content: JSON.stringify({
              title: "Demo",
              summary: "Demo",
              html: "<!doctype html><html><body><h1>Demo</h1></body></html>",
            }),
          },
        },
      ],
    });
    await caller().adus.website.build({ brief: "Make a website" });
    const req = m.llm.mock.calls[0][0];
    expect(req.model).toBe("gpt-5.5");
    expect(req.maxCompletionTokens).toBe(12000);
    expect(req.messages[0].content).toContain("#section-id");
    expect(req.thinking).toBeUndefined();
  });
});
