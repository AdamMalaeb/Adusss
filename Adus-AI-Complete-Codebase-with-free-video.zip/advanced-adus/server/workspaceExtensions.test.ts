import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const m = vi.hoisted(() => ({
  records: new Map<
    string,
    { id: string; userId: number; kind: string; payload: unknown }
  >(),
  invokeLLM: vi.fn(),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: m.invokeLLM,
}));

vi.mock("./workspaceStore", () => ({
  getRecord: vi.fn(async (userId: number, kind: string, id: string) => {
    const row = m.records.get(`${userId}:${kind}:${id}`);
    return row
      ? { id: row.id, payload: row.payload, createdAt: 1, updatedAt: 1 }
      : undefined;
  }),
  listRecords: vi.fn(async (userId: number, kind: string) =>
    [...m.records.values()]
      .filter(row => row.userId === userId && row.kind === kind)
      .map(row => ({
        id: row.id,
        payload: row.payload,
        createdAt: 1,
        updatedAt: 1,
      }))
  ),
  saveRecord: vi.fn(
    async (
      userId: number,
      kind: string,
      payload: unknown,
      id = crypto.randomUUID()
    ) => {
      const row = { id, userId, kind, payload };
      m.records.set(`${userId}:${kind}:${id}`, row);
      return { id, payload, createdAt: 1, updatedAt: 1 };
    }
  ),
}));

import {
  applyWorkspaceExtension,
  listWorkspaceTabs,
  parseWorkspaceExtensionRequest,
  planWorkspaceExtension,
  proposeWorkspaceExtension,
  tabSlug,
  undoWorkspaceExtension,
  workspaceExtensionsRouter,
  WorkspaceExtensionError,
  calculateWorkspaceExpression,
  executeWorkspaceAiTool,
  parseWorkspaceExtensionRequestWithAI,
  resolveWorkspaceTabTarget,
  translateWorkspaceText,
} from "./workspaceExtensions";

function caller(user: {
  id: number;
  role?: "admin" | "user";
  openId?: string;
  email?: string;
}) {
  return workspaceExtensionsRouter.createCaller({
    user,
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}

beforeEach(() => {
  m.records.clear();
  m.invokeLLM.mockReset();
});

describe("functional tab requests", () => {
  it.each([
    "Create a translator tab",
    "Generate me a translator tab",
    "Please add a new translator tab for me",
  ])("understands %s", prompt => {
    const action = planWorkspaceExtension(prompt, []);
    expect(action.after?.functionConfig.type).toBe("translator");
    expect(action.after?.label).toBe("Translator");
  });
  it("upgrades a legacy translator record without changing unrelated tabs", async () => {
    const legacy = planWorkspaceExtension(
      "Add a new tab named Translator",
      [],
      1
    ).after!;
    const { functionConfig, ...old } = legacy;
    m.records.set(`8:workspaceExtension:${legacy.id}`, {
      id: legacy.id,
      userId: 8,
      kind: "workspaceExtension",
      payload: { ...old, active: true },
    });
    expect((await listWorkspaceTabs(8))[0]?.functionConfig.type).toBe(
      "translator"
    );
    expect((await listWorkspaceTabs(8))[0]).toMatchObject({
      id: legacy.id,
      label: "Translator",
      path: legacy.path,
    });
    expect(await listWorkspaceTabs(9)).toEqual([]);
  });
});

describe("workspace extension parser and planner", () => {
  it("parses the reported add-tab request without invoking an AI preference schema", () => {
    expect(parseWorkspaceExtensionRequest("Add new tab named test")).toEqual({
      operation: "add",
      label: "test",
    });
    expect(tabSlug("Test & Notes")).toBe("test-notes");
  });

  it("supports rename and remove, while rejecting arbitrary commands and unsafe names", () => {
    expect(parseWorkspaceExtensionRequest("Rename tab Test to Study")).toEqual({
      operation: "rename",
      from: "Test",
      to: "Study",
    });
    expect(parseWorkspaceExtensionRequest("Remove tab Test")).toEqual({
      operation: "remove",
      label: "Test",
    });
    expect(() =>
      parseWorkspaceExtensionRequest("Run server code rm -rf /")
    ).toThrow("not a supported workspace change");
    expect(() =>
      parseWorkspaceExtensionRequest("Add a new tab named <script>")
    ).toThrow("tab name");
  });

  it("plans a reviewable add and rejects duplicate routes", () => {
    const action = planWorkspaceExtension("Add a new tab named Test", [], 100);
    expect(action.operation).toBe("add");
    expect(action.before).toBeNull();
    expect(action.after).toMatchObject({
      label: "Test",
      slug: "test",
      path: "/workspace/test",
      createdAt: 100,
    });
    expect(() =>
      planWorkspaceExtension("Add a new tab named test", [action.after!], 101)
    ).toThrow("already exists");
  });
});

describe("workspace extension persistence and routing", () => {
  it("requires the existing owner policy for mutations", async () => {
    await expect(
      caller({ id: 7, role: "user", openId: "not-owner" }).propose({
        prompt: "Add a new tab named Test",
      })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("stores an applied tab only for its owner and can reverse the action", async () => {
    const proposal = await caller({
      id: 8,
      role: "admin",
      email: "adammalaeb30@gmail.com",
    }).propose({
      prompt: "Add a new tab named Test",
    });
    expect(proposal.summary).toContain("/workspace/test");
    expect(await listWorkspaceTabs(8)).toEqual([]);
    expect(await listWorkspaceTabs(9)).toEqual([]);

    const applied = await caller({
      id: 8,
      role: "admin",
      email: "adammalaeb30@gmail.com",
    }).activate({
      id: proposal.id,
      confirmed: true,
    });
    expect(applied.tab).toMatchObject({
      label: "Test",
      path: "/workspace/test",
    });
    expect(await listWorkspaceTabs(8)).toHaveLength(1);
    expect(await listWorkspaceTabs(9)).toEqual([]);

    const undone = await caller({
      id: 8,
      role: "admin",
      email: "adammalaeb30@gmail.com",
    }).undo({
      id: proposal.id,
      confirmed: true,
    });
    expect(undone.undone).toBe(true);
    expect(await listWorkspaceTabs(8)).toEqual([]);
  });

  it("does not apply a stale rename or allow a second owner to read the action", async () => {
    const add = await proposeWorkspaceExtension(
      10,
      "Add a new tab named Test",
      200
    );
    await applyWorkspaceExtension(10, add.id, 201);
    const rename = await proposeWorkspaceExtension(
      10,
      "Rename tab Test to Study",
      202
    );
    await undoWorkspaceExtension(10, add.id, 203);
    await expect(
      applyWorkspaceExtension(10, rename.id, 204)
    ).rejects.toBeInstanceOf(WorkspaceExtensionError);
    await expect(
      caller({
        id: 11,
        role: "admin",
        email: "adammalaeb30@gmail.com",
      }).activate({
        id: rename.id,
        confirmed: true,
      })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("workspace extension tools and safe target resolution", () => {
  it("rejects an ambiguous removal target instead of guessing", () => {
    const left = planWorkspaceExtension(
      "Add a new tab named Notes",
      [],
      1
    ).after!;
    const right = { ...left, id: "11111111-1111-4111-8111-111111111111" };
    expect(() => resolveWorkspaceTabTarget([left, right], "Notes")).toThrow(
      "More than one active tab"
    );
    expect(resolveWorkspaceTabTarget([left, right], right.id)?.id).toBe(
      right.id
    );
  });

  it("parses a typed edit with languages and keeps it reviewable", () => {
    const tab = planWorkspaceExtension(
      "Add a new tab named Translate",
      [],
      10
    ).after!;
    const action = planWorkspaceExtension(
      `Edit tab ${tab.id} to use translator from fr to en`,
      [tab],
      20
    );
    expect(action.operation).toBe("edit");
    expect(action.after).toMatchObject({
      id: tab.id,
      functionConfig: {
        type: "translator",
        sourceLanguage: "fr",
        targetLanguage: "en",
      },
    });
  });

  it("translates through the server LLM helper without a live media call", async () => {
    m.invokeLLM.mockResolvedValue({
      model: "gpt-5-mini",
      choices: [{ message: { content: "Bonjour le monde" } }],
    });
    const result = await translateWorkspaceText({
      tabId: "11111111-1111-4111-8111-111111111111",
      text: "Hello world",
      sourceLanguage: "en",
      targetLanguage: "fr",
    });
    expect(result).toMatchObject({
      text: "Bonjour le monde",
      sourceLabel: "English",
      targetLabel: "French",
    });
    expect(m.invokeLLM).toHaveBeenCalledWith(
      expect.objectContaining({ model: "gpt-5-mini" })
    );
  });

  it("supports safe arithmetic without eval", () => {
    expect(calculateWorkspaceExpression("(2 + 3) * 4 - 1")).toBe(19);
    expect(() => calculateWorkspaceExpression("process.exit()")).toThrow(
      "only numbers"
    );
  });

  it("applies and undoes a durable function edit in the isolated account", async () => {
    const add = await proposeWorkspaceExtension(
      12,
      "Add a new tab named Tools",
      100
    );
    await applyWorkspaceExtension(12, add.id, 101);
    const edit = await proposeWorkspaceExtension(
      12,
      "Edit tab Tools to use summarizer",
      102
    );
    await applyWorkspaceExtension(12, edit.id, 103);
    expect((await listWorkspaceTabs(12))[0]?.functionConfig.type).toBe(
      "summarizer"
    );
    await undoWorkspaceExtension(12, edit.id, 104);
    expect((await listWorkspaceTabs(12))[0]?.functionConfig.type).toBe("notes");
    expect(await listWorkspaceTabs(13)).toEqual([]);
  });
});

describe("natural workspace intent and generic text tools", () => {
  it("keeps natural task names short while retaining the full reviewed duty", () => {
    const action = planWorkspaceExtension(
      "Add a tab for generating practical business ideas for local retailers",
      [],
      100
    );
    expect(action.after).toMatchObject({
      label: "Business Ideas",
      functionConfig: { type: "aiTool", name: "Business Ideas" },
    });
    expect(action.after?.functionConfig).toMatchObject({
      instructions: expect.stringContaining("local retailers"),
    });
    expect(m.invokeLLM).not.toHaveBeenCalled();
  });

  it("uses the fast structured model only after deterministic parsing fails", async () => {
    m.invokeLLM.mockResolvedValueOnce({
      model: "gpt-5-mini",
      choices: [
        {
          message: {
            content: JSON.stringify({
              operation: "add",
              label: "Action Items",
              from: null,
              to: null,
              functionType: "aiTool",
              name: "Action Items",
              instructions:
                "Turn meeting notes into clear action items with owners and due dates.",
            }),
          },
        },
      ],
    });
    const request = await parseWorkspaceExtensionRequestWithAI(
      "Could you make a workspace tool that turns meeting notes into action items with owners and due dates?"
    );
    expect(request).toMatchObject({
      operation: "add",
      label: "Action Items",
      functionConfig: {
        type: "aiTool",
        name: "Action Items",
        instructions: expect.stringContaining("owners"),
      },
    });
    expect(m.invokeLLM).toHaveBeenCalledWith(
      expect.objectContaining({
        model: "gpt-5-mini",
        responseFormat: expect.any(Object),
      })
    );
  });

  it("resolves stable numbered targets in deterministic server order", () => {
    const tabs = ["One", "Two", "Three", "Four", "Five"].map(
      (label, index) =>
        planWorkspaceExtension(`Add a new tab named ${label}`, [], index + 1)
          .after!
    );
    expect(resolveWorkspaceTabTarget(tabs, "5")?.label).toBe("Five");
    expect(resolveWorkspaceTabTarget(tabs, "#5")?.id).toBe(tabs[4]?.id);
  });

  it("generates through a reviewed generic text tool and isolates execution by user", async () => {
    const tab = planWorkspaceExtension(
      "Add a tab for generating business ideas",
      [],
      100
    ).after!;
    m.records.set(`20:workspaceExtension:${tab.id}`, {
      id: tab.id,
      userId: 20,
      kind: "workspaceExtension",
      payload: { ...tab, active: true },
    });
    m.invokeLLM.mockResolvedValueOnce({
      model: "gpt-5-mini",
      choices: [{ message: { content: "1. A neighborhood cafe loyalty kit" } }],
    });
    await expect(
      executeWorkspaceAiTool(20, {
        tabId: tab.id,
        values: { input: "Focus on low-cost ideas." },
      })
    ).resolves.toMatchObject({
      name: "Business Ideas",
      text: expect.stringContaining("loyalty"),
    });
    await expect(
      executeWorkspaceAiTool(21, {
        tabId: tab.id,
        values: { input: "Should not cross accounts." },
      })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(m.invokeLLM).toHaveBeenCalledTimes(1);
  });
});

describe("natural named duties and edited functions", () => {
  it("keeps an explicitly named business tool separate from its instructions", () => {
    const action = planWorkspaceExtension(
      "Create me a tab called Startup Lab that can generate business ideas for cafes",
      []
    );
    expect(action.after).toMatchObject({
      label: "Startup Lab",
      functionConfig: {
        type: "aiTool",
        instructions: expect.stringContaining("cafes"),
      },
    });
    expect(
      planWorkspaceExtension(
        "Remove tab 5",
        [1, 2, 3, 4, 5].map(
          n => planWorkspaceExtension(`Add tab named Tool ${n}`, []).after!
        )
      ).before?.label
    ).toBe("Tool 5");
  });
  it("passes the user's existing tabs into a natural rename request", async () => {
    const tab = planWorkspaceExtension("Add tab named Translator", []).after!;
    m.invokeLLM.mockResolvedValue({
      choices: [
        {
          message: {
            content: JSON.stringify({
              operation: "rename",
              from: "Translator",
              to: "translator",
              label: null,
              name: null,
              instructions: null,
              functionType: null,
              inputControls: null,
            }),
          },
        },
      ],
    });
    await expect(
      parseWorkspaceExtensionRequestWithAI(
        "Could you rename my translation tool to just translator please?",
        [tab]
      )
    ).resolves.toMatchObject({
      operation: "rename",
      from: "Translator",
      to: "translator",
    });
    expect(m.invokeLLM.mock.calls[0][0].messages[1].content).toContain(tab.id);
  });
});
