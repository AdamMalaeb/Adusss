import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
const m = vi.hoisted(() => ({
  records: new Map<string, any>(),
  script: vi.fn(),
  speech: vi.fn(),
  render: vi.fn(),
  save: vi.fn(),
  get: vi.fn(),
  list: vi.fn(),
}));
vi.mock("./workspaceStore", () => ({
  saveRecord: m.save,
  getRecord: m.get,
  listRecords: m.list,
}));
vi.mock("./professorVideo", () => ({
  createProfessorScript: m.script,
  prepareProfessorNarration: m.speech,
  renderProfessorVideo: m.render,
  professorErrorMessage: (e: any) => e.message,
}));
import { professorVideoRouter } from "./professorVideoRouter";
const script = {
  title: "Waves",
  summary: "Energy transfer",
  scenes: [
    {
      title: "Energy",
      bullets: ["Oscillation"],
      narration: "A wave transfers energy.",
    },
  ],
  sources: ["brief"],
  warnings: [],
};
const caller = (id = 7) =>
  professorVideoRouter.createCaller({
    user: { id, email: "adammalaeb30@gmail.com" },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
beforeEach(() => {
  vi.clearAllMocks();
  m.records.clear();
  m.save.mockImplementation(
    async (u: number, k: string, p: any, id: string) => {
      const r = { id, payload: p };
      m.records.set(`${u}:${k}:${id}`, r);
      return r;
    }
  );
  m.get.mockImplementation(async (u: number, k: string, id: string) =>
    m.records.get(`${u}:${k}:${id}`)
  );
  m.list.mockResolvedValue([]);
  m.script.mockResolvedValue(script);
  m.speech.mockResolvedValue({
    audioURL: "/manus-storage/voice.wav",
    audioDuration: 4,
  });
  m.render.mockResolvedValue("/manus-storage/video.mp4");
});
describe("request-scoped professor jobs", () => {
  it("persists creation without detached work and completes one stage per request", async () => {
    const c = caller();
    const r = await c.create({ prompt: "Explain waves" });
    expect(r.status).toBe("pending");
    expect(m.script).not.toHaveBeenCalled();
    expect(await c.status({ id: r.id })).toMatchObject({
      stage: "narration",
      title: "Waves",
    });
    expect(m.speech).not.toHaveBeenCalled();
    expect(await c.status({ id: r.id })).toMatchObject({
      stage: "render",
      audioURL: "/manus-storage/voice.wav",
    });
    expect(m.render).not.toHaveBeenCalled();
    expect(await c.status({ id: r.id })).toMatchObject({
      status: "completed",
      stage: "done",
      url: "/manus-storage/video.mp4",
    });
    await c.status({ id: r.id });
    expect(m.script).toHaveBeenCalledOnce();
    expect(m.speech).toHaveBeenCalledOnce();
    expect(m.render).toHaveBeenCalledOnce();
  });
  it("resumes failed render without repeating saved script or speech", async () => {
    const c = caller(),
      r = await c.create({ prompt: "Explain waves" });
    await c.status({ id: r.id });
    await c.status({ id: r.id });
    m.render.mockRejectedValueOnce(new Error("Busy"));
    expect(await c.status({ id: r.id })).toMatchObject({
      status: "failed",
      failedStep: "render",
    });
    expect(await c.retry({ id: r.id })).toMatchObject({
      status: "pending",
      stage: "render",
    });
    expect(await c.status({ id: r.id })).toMatchObject({ status: "completed" });
    expect(m.script).toHaveBeenCalledOnce();
    expect(m.speech).toHaveBeenCalledOnce();
  });
  it("does not expose another user job", async () => {
    const r = await caller().create({ prompt: "Private notes" });
    await expect(caller(8).status({ id: r.id })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });
  it("deduplicates overlapping status requests", async () => {
    const c = caller(),
      r = await c.create({ prompt: "Explain waves" });
    let resolve!: (x: any) => void;
    m.script.mockImplementationOnce(
      () => new Promise(done => (resolve = done))
    );
    const a = c.status({ id: r.id }),
      b = c.status({ id: r.id });
    await vi.waitFor(() => expect(m.script).toHaveBeenCalledOnce());
    resolve(script);
    expect(await a).toEqual(await b);
    expect(m.script).toHaveBeenCalledOnce();
  });
});
