import { describe, it, expect, vi } from "vitest";
vi.mock("./workspaceStore", () => ({
  getRecord: vi.fn(async () => undefined), listRecords: vi.fn(async () => []),
  saveRecord: vi.fn(async (_user: number, _kind: string, payload: unknown) => ({ id: "synthetic-qa", payload })),
}));
import { businessRouter } from "./businessRouter";
import { generatePowerPointDraft } from "./powerpointService";
import { collectChatResearch } from "./chatResearch";
import type { TrpcContext } from "./_core/context";
const ctx = { user: { id: 987, email: "synthetic-qa@example.com" }, req: { headers: {} }, res: {} } as TrpcContext;
describe.skipIf(process.env.ADUS_VALIDATE_NEW_FEATURES !== "1")("Live feature smoke tests", () => {
  it("returns a source-grounded research result or an honest unavailable status", async () => {
    const result = await collectChatResearch("latest president Lebanon official website");
    console.log("Public research result",result.status,result.sources.map(s=>s.url));
    expect(["verified", "unavailable"]).toContain(result.status);
    if(result.status === "verified") expect(result.sources[0].excerpt.length).toBeGreaterThan(40);
  }, 15000);
  it("generates a real business plan with seven factor scores and no invented economics", async () => {
    const result = await businessRouter.createCaller(ctx).generate({
      idea: "A weekend bicycle repair service with bookings by phone; validate with ten interviews before buying equipment.",
      countryOrMarket: "local neighbourhood", budget: 1000, currency: "USD", customer: "Adults using commuter bicycles", experience: "Experienced bicycle mechanic with basic tools", researchLocalMarket: false,
    });
    console.log("Business plan result", result.plan.title,result.score);
    expect(result.plan.rubricFactors).toHaveLength(7);
    expect(result.plan.strategy.actions.length).toBeGreaterThan(0);
    expect(result.plan.unitEconomics.pricePerCustomer).toBeNull();
  }, 70000);
  it("generates an actual editable outline through the existing AI, without starting a Slides task", async () => {
    const result = await generatePowerPointDraft({ topic: "Understanding wave motion", audience: "High-school learners", language:"English", style:"Executive clarity",slideCount:4,sourceFacts:["Transverse particle motion is perpendicular to propagation.","Longitudinal particle motion is parallel to propagation."] });
    console.log("Outline result",result.draft.title,result.draft.outline.length);
    expect(result.draft.outline.length).toBe(4);
    expect(result.draft.outline[0].title.length).toBeGreaterThan(1);
  }, 70000);
});
