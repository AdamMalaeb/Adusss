import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { storagePut } from "./storage";
import { getRecord, listRecords, saveRecord } from "./workspaceStore";
import {
  EMPTY_CONVERSATION_TITLE,
  MAX_CONTEXT_MESSAGES,
  type ConversationAttachment,
  type ConversationMessage,
  type ConversationPayload,
  type ConversationSummary,
} from "../shared/conversations";

export const CONVERSATION_KIND = "conversation";
const MAX_TITLE_LENGTH = 80;
const MAX_MESSAGE_LENGTH = 20_000;
const MAX_PERSISTED_MESSAGES = 10_000;
const MAX_ATTACHMENT_REFERENCE_LENGTH = 2_000;

// Appends can involve an attachment upload. Serialize mutations per owned
// conversation so an archive either happens before the append or after it, but
// never gets overwritten by a pending save that started before the archive.
const conversationMutationTails = new Map<string, Promise<void>>();

async function withConversationMutation<T>(
  userId: number,
  id: string,
  mutation: () => Promise<T>
): Promise<T> {
  const key = `${userId}:${id}`;
  const previous = conversationMutationTails.get(key) ?? Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>(resolve => {
    release = resolve;
  });
  conversationMutationTails.set(key, current);
  await previous;
  try {
    return await mutation();
  } finally {
    release();
    if (conversationMutationTails.get(key) === current)
      conversationMutationTails.delete(key);
  }
}

const attachmentInputSchema = z.object({
  name: z.string().trim().min(1).max(240),
  mimeType: z.string().trim().min(1).max(120),
  dataUrl: z.string().max(12_000_000).optional(),
  size: z
    .number()
    .int()
    .nonnegative()
    .max(8 * 1024 * 1024)
    .optional(),
  key: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
  url: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
  reference: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
});

const persistedAttachmentSchema = z.object({
  name: z.string().min(1).max(240),
  mimeType: z.string().min(1).max(120),
  size: z
    .number()
    .int()
    .nonnegative()
    .max(8 * 1024 * 1024)
    .optional(),
  key: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
  url: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
  reference: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
});

const messageInputSchema = z.object({
  id: z.string().trim().min(1).max(120).optional(),
  requestId: z.string().trim().min(1).max(120).optional(),
  role: z.enum(["user", "assistant"]),
  content: z.string().max(MAX_MESSAGE_LENGTH),
  createdAt: z.number().int().positive().optional(),
  imageUrl: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
  openBuilder: z.boolean().optional(),
  builderBrief: z.string().max(12_000).optional(),
  attachmentName: z.string().max(1_000).optional(),
  attachmentUrl: z.string().max(MAX_ATTACHMENT_REFERENCE_LENGTH).optional(),
  agent: z.string().max(120).optional(),
  research: z
    .object({
      status: z.enum(["retrieved", "unavailable"]),
      checkedAt: z.number().int().positive(),
      engine: z.string().max(120),
      searchSuggestions: z.string().max(60000).optional(),
    })
    .optional(),
  attachments: z.array(attachmentInputSchema).max(5).optional(),
});

const initialMessageSchema = messageInputSchema
  .omit({ role: true })
  .extend({ role: z.literal("user").default("user") });

function badRequest(message: string): TRPCError {
  return new TRPCError({ code: "BAD_REQUEST", message });
}

function notFound(): TRPCError {
  return new TRPCError({
    code: "NOT_FOUND",
    message: "That conversation does not exist.",
  });
}

function cleanTitle(value: string): string {
  return value.replace(/\s+/g, " ").trim().slice(0, MAX_TITLE_LENGTH).trim();
}

/** Deterministic title generation keeps creation fast and does not spend an LLM call. */
export function generateConversationTitle(prompt: string): string {
  const cleaned = cleanTitle(prompt);
  if (!cleaned) return EMPTY_CONVERSATION_TITLE;
  const lower = cleaned.toLocaleLowerCase();
  if (
    /\bmath(?:ematics)?\b/.test(lower) &&
    /\btutor(?:ing)?\b|\bhomework\b|\bexercise\b|\bhelp\b/.test(lower)
  )
    return "Math Tutoring";
  if (
    /\bphysics\b/.test(lower) &&
    /\bhelp\b|\bstudy\b|\bhomework\b/.test(lower)
  )
    return "Physics Help";
  if (/\bcode\b|\bjavascript\b|\btypescript\b|\bpython\b/.test(lower))
    return "Coding Help";
  if (/\bwrite\b|\bdraft\b|\bessay\b/.test(lower)) return "Writing Help";
  const words = cleaned.split(" ").slice(0, 6);
  const title = words
    .join(" ")
    .replace(/\b\w/g, char => char.toUpperCase())
    .replace(/[.!?,:;]+$/, "")
    .trim();
  return title || EMPTY_CONVERSATION_TITLE;
}

function isSafeReference(value: string | undefined): boolean {
  return Boolean(
    value && (value.startsWith("/manus-storage/") || /^https:\/\//i.test(value))
  );
}

function safeReference(value: string | undefined): string | undefined {
  return isSafeReference(value)
    ? value?.slice(0, MAX_ATTACHMENT_REFERENCE_LENGTH)
    : undefined;
}

function parseDataUrl(dataUrl: string): { bytes: Buffer; mimeType?: string } {
  const match = dataUrl.match(
    /^data:([^;,]*)(?:;[^,]*)?;base64,([A-Za-z0-9+/=\r\n]+)$/
  );
  if (!match)
    throw badRequest("Conversation attachments must be base64 data URLs.");
  const bytes = Buffer.from(match[2].replace(/\s+/g, ""), "base64");
  if (!bytes.length || bytes.length > 8 * 1024 * 1024)
    throw badRequest("Each conversation attachment must be smaller than 8 MB.");
  return { bytes, mimeType: match[1] || undefined };
}

async function persistAttachment(
  userId: number,
  conversationId: string,
  messageId: string,
  attachment: z.infer<typeof attachmentInputSchema>,
  index: number
): Promise<ConversationAttachment> {
  if (!attachment.dataUrl) {
    const reference =
      safeReference(attachment.reference) ?? safeReference(attachment.url);
    return {
      name: attachment.name,
      mimeType: attachment.mimeType,
      ...(attachment.size === undefined ? {} : { size: attachment.size }),
      ...(attachment.key
        ? { key: attachment.key.slice(0, MAX_ATTACHMENT_REFERENCE_LENGTH) }
        : {}),
      ...(reference ? { url: reference, reference } : {}),
    };
  }
  const parsed = parseDataUrl(attachment.dataUrl);
  const extension =
    attachment.name
      .split(".")
      .pop()
      ?.replace(/[^a-z0-9]/gi, "")
      .slice(0, 12) || "bin";
  const stored = await storagePut(
    `conversations/${userId}/${conversationId}/${messageId}-${index}.${extension}`,
    parsed.bytes,
    attachment.mimeType || parsed.mimeType || "application/octet-stream"
  );
  return {
    name: attachment.name,
    mimeType:
      attachment.mimeType || parsed.mimeType || "application/octet-stream",
    size: parsed.bytes.length,
    key: stored.key,
    url: stored.url,
    reference: stored.url,
  };
}

function normalizePersistedMessage(
  message: ConversationMessage
): ConversationMessage {
  const attachments = message.attachments?.map(item => ({
    name: item.name,
    mimeType: item.mimeType,
    ...(item.size === undefined ? {} : { size: item.size }),
    ...(item.key
      ? { key: item.key.slice(0, MAX_ATTACHMENT_REFERENCE_LENGTH) }
      : {}),
    ...(safeReference(item.url) ? { url: safeReference(item.url) } : {}),
    ...(safeReference(item.reference)
      ? { reference: safeReference(item.reference) }
      : {}),
  }));
  return {
    id: message.id,
    ...(message.requestId ? { requestId: message.requestId } : {}),
    role: message.role,
    content: message.content.slice(0, MAX_MESSAGE_LENGTH),
    createdAt: message.createdAt,
    ...(safeReference(message.imageUrl)
      ? { imageUrl: safeReference(message.imageUrl) }
      : {}),
    ...(message.openBuilder ? { openBuilder: true } : {}),
    ...(message.builderBrief
      ? { builderBrief: message.builderBrief.slice(0, 12_000) }
      : {}),
    ...(message.attachmentName
      ? { attachmentName: message.attachmentName.slice(0, 1_000) }
      : {}),
    ...(safeReference(message.attachmentUrl)
      ? { attachmentUrl: safeReference(message.attachmentUrl) }
      : {}),
    ...(message.agent ? { agent: message.agent.slice(0, 120) } : {}),
    ...(attachments?.length ? { attachments } : {}),
    ...(message.research ? { research: message.research } : {}),
  };
}

function normalizePayload(
  payload: unknown,
  now = Date.now()
): ConversationPayload {
  const value = (payload ?? {}) as Partial<ConversationPayload>;
  const messages = Array.isArray(value.messages) ? value.messages : [];
  const archived = value.archived === true;
  const archivedAt = Number.isFinite(value.archivedAt)
    ? Number(value.archivedAt)
    : undefined;
  return {
    version: 1,
    title: cleanTitle(String(value.title ?? "")) || EMPTY_CONVERSATION_TITLE,
    messages: messages
      .filter(item => item && typeof item === "object")
      .slice(-MAX_PERSISTED_MESSAGES)
      .map(item => normalizePersistedMessage(item as ConversationMessage)),
    createdAt: Number.isFinite(value.createdAt) ? Number(value.createdAt) : now,
    updatedAt: Number.isFinite(value.updatedAt) ? Number(value.updatedAt) : now,
    ...(archived ? { archived: true as const } : {}),
    ...(archived && archivedAt !== undefined ? { archivedAt } : {}),
  };
}

async function ownedConversation(userId: number, id: string) {
  const record = await getRecord(userId, CONVERSATION_KIND, id);
  if (!record) throw notFound();
  const payload = normalizePayload(record.payload, record.updatedAt);
  if (payload.archived) throw notFound();
  return {
    ...record,
    payload,
  };
}

function summary(
  id: string,
  payload: ConversationPayload,
  createdAt: number,
  updatedAt: number
): ConversationSummary {
  const last = payload.messages.at(-1);
  return {
    id,
    title: payload.title,
    preview: last?.content.slice(0, 160) ?? "No messages yet",
    messageCount: payload.messages.length,
    createdAt,
    updatedAt,
  };
}

export async function getConversationContext(
  userId: number,
  id: string,
  message?: string
): Promise<{
  conversationId: string;
  title: string;
  history: Array<{ role: "user" | "assistant"; content: string }>;
  attachmentReferences: Array<ConversationAttachment & { messageId: string }>;
}> {
  const { payload } = await ownedConversation(userId, id);
  const all = payload.messages.slice();
  if (message && all.at(-1)?.role === "user" && all.at(-1)?.content === message)
    all.pop();
  const recent = all.slice(-MAX_CONTEXT_MESSAGES);
  if (message && all.length > MAX_CONTEXT_MESSAGES) {
    const terms = (
      message.toLowerCase().match(/[A-Za-z0-9\u0600-\u06ff]{3,}/g) ?? []
    ).filter(
      t =>
        ![
          "the",
          "what",
          "that",
          "this",
          "with",
          "you",
          "and",
          "was",
          "earlier",
        ].includes(t)
    );
    const old = all
      .slice(0, -MAX_CONTEXT_MESSAGES)
      .map((item, index) => ({
        item,
        index,
        score: terms.reduce(
          (n, t) => n + (item.content.toLowerCase().includes(t) ? 1 : 0),
          0
        ),
      }))
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 6)
      .sort((a, b) => a.index - b.index);
    if (old.length)
      recent.splice(
        0,
        Math.min(old.length, recent.length),
        ...old.map(x => x.item)
      );
  }
  const attachmentReferences = recent.flatMap(item =>
    (item.attachments ?? []).map(attachment => ({
      ...attachment,
      messageId: item.id,
    }))
  );
  // Keep the optional latest prompt in the API contract for callers that use it to
  // choose a retrieval strategy, but never turn it into unbounded model memory.

  return {
    conversationId: id,
    title: payload.title,
    history: recent.map(item => ({ role: item.role, content: item.content })),
    attachmentReferences,
  };
}

export const conversationsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const records = await listRecords(ctx.user.id, CONVERSATION_KIND, 100);
    return records.flatMap(record => {
      const payload = normalizePayload(record.payload, record.updatedAt);
      if (payload.archived) return [];
      return summary(record.id, payload, record.createdAt, record.updatedAt);
    });
  }),

  create: protectedProcedure
    .input(
      z.object({
        id: z.string().trim().min(1).max(64).optional(),
        title: z.string().trim().max(MAX_TITLE_LENGTH).optional(),
        firstMessage: z.string().trim().max(MAX_MESSAGE_LENGTH).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const id = input.id ?? randomUUID();
      return withConversationMutation(ctx.user.id, id, async () => {
        const existing = await getRecord(ctx.user.id, CONVERSATION_KIND, id);
        if (existing) {
          const existingPayload = normalizePayload(
            existing.payload,
            existing.updatedAt
          );
          // Do not let a stale/retried create call reveal or revive an archive.
          if (existingPayload.archived) throw notFound();
          return summary(
            existing.id,
            existingPayload,
            existing.createdAt,
            existing.updatedAt
          );
        }
        const now = Date.now();
        const payload: ConversationPayload = {
          version: 1,
          title:
            cleanTitle(
              input.title ??
                (input.firstMessage
                  ? generateConversationTitle(input.firstMessage)
                  : "")
            ) || EMPTY_CONVERSATION_TITLE,
          messages: [],
          createdAt: now,
          updatedAt: now,
        };
        const record = await saveRecord(
          ctx.user.id,
          CONVERSATION_KIND,
          payload,
          id
        );
        return summary(record.id, payload, record.createdAt, record.updatedAt);
      });
    }),

  get: protectedProcedure
    .input(z.object({ id: z.string().trim().min(1).max(64) }))
    .query(async ({ ctx, input }) => {
      const record = await ownedConversation(ctx.user.id, input.id);
      return {
        id: record.id,
        ...record.payload,
        createdAt: record.createdAt,
        updatedAt: record.updatedAt,
      };
    }),

  rename: protectedProcedure
    .input(
      z.object({
        id: z.string().trim().min(1).max(64),
        title: z.string().trim().min(1).max(MAX_TITLE_LENGTH),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return withConversationMutation(ctx.user.id, input.id, async () => {
        const record = await ownedConversation(ctx.user.id, input.id);
        const payload = {
          ...record.payload,
          title: cleanTitle(input.title) || EMPTY_CONVERSATION_TITLE,
          updatedAt: Date.now(),
        } satisfies ConversationPayload;
        const saved = await saveRecord(
          ctx.user.id,
          CONVERSATION_KIND,
          payload,
          input.id
        );
        return summary(saved.id, payload, saved.createdAt, saved.updatedAt);
      });
    }),

  archive: protectedProcedure
    .input(z.object({ id: z.string().trim().min(1).max(64) }))
    .mutation(async ({ ctx, input }) =>
      withConversationMutation(ctx.user.id, input.id, async () => {
        const record = await getRecord(
          ctx.user.id,
          CONVERSATION_KIND,
          input.id
        );
        if (!record) throw notFound();
        const payload = normalizePayload(record.payload, record.updatedAt);
        if (payload.archived)
          return {
            id: input.id,
            archived: true as const,
            archivedAt: payload.archivedAt ?? record.updatedAt,
          };
        const archivedAt = Date.now();
        await saveRecord(
          ctx.user.id,
          CONVERSATION_KIND,
          { ...payload, archived: true, archivedAt, updatedAt: archivedAt },
          input.id
        );
        return { id: input.id, archived: true as const, archivedAt };
      })
    ),

  restore: protectedProcedure
    .input(z.object({ id: z.string().trim().min(1).max(64) }))
    .mutation(async ({ ctx, input }) =>
      withConversationMutation(ctx.user.id, input.id, async () => {
        const record = await getRecord(
          ctx.user.id,
          CONVERSATION_KIND,
          input.id
        );
        if (!record) throw notFound();
        const payload = normalizePayload(record.payload, record.updatedAt);
        if (!payload.archived)
          return summary(
            record.id,
            payload,
            record.createdAt,
            record.updatedAt
          );
        const {
          archived: _archived,
          archivedAt: _archivedAt,
          ...activePayload
        } = payload;
        const restored: ConversationPayload = {
          ...activePayload,
          updatedAt: Date.now(),
        };
        const saved = await saveRecord(
          ctx.user.id,
          CONVERSATION_KIND,
          restored,
          input.id
        );
        return summary(saved.id, restored, saved.createdAt, saved.updatedAt);
      })
    ),

  append: protectedProcedure
    .input(
      z.object({
        id: z.string().trim().min(1).max(64),
        message: messageInputSchema,
      })
    )
    .mutation(async ({ ctx, input }) => {
      return withConversationMutation(ctx.user.id, input.id, async () => {
        const record = await ownedConversation(ctx.user.id, input.id);
        const messageId = input.message.id ?? randomUUID();
        const requestId = input.message.requestId ?? messageId;
        const duplicate = record.payload.messages.find(
          item =>
            item.id === messageId ||
            (item.requestId && item.requestId === requestId)
        );
        if (duplicate)
          return {
            conversation: record.payload,
            message: duplicate,
            appended: false as const,
          };
        const now = Date.now();
        const rawAttachments = input.message.attachments ?? [];
        const persistedAttachments = rawAttachments.length
          ? await Promise.all(
              rawAttachments.map((attachment, index) =>
                persistAttachment(
                  ctx.user.id,
                  input.id,
                  messageId,
                  attachment,
                  index
                )
              )
            )
          : undefined;
        const message = normalizePersistedMessage({
          ...(input.message as ConversationMessage),
          id: messageId,
          requestId,
          createdAt: input.message.createdAt ?? now,
          ...(persistedAttachments?.length
            ? { attachments: persistedAttachments }
            : {}),
          ...(persistedAttachments?.length &&
          !safeReference(input.message.attachmentUrl)
            ? { attachmentUrl: persistedAttachments[0]?.url }
            : {}),
          ...(persistedAttachments?.length && !input.message.attachmentName
            ? {
                attachmentName: persistedAttachments
                  .map(item => item.name)
                  .join(", "),
              }
            : {}),
        });
        const title =
          record.payload.messages.length === 0 && message.role === "user"
            ? generateConversationTitle(message.content)
            : record.payload.title;
        const payload: ConversationPayload = {
          ...record.payload,
          title:
            record.payload.title === EMPTY_CONVERSATION_TITLE &&
            message.role === "user"
              ? title
              : record.payload.title,
          messages: [...record.payload.messages, message].slice(
            -MAX_PERSISTED_MESSAGES
          ),
          updatedAt: now,
        };
        await saveRecord(ctx.user.id, CONVERSATION_KIND, payload, input.id);
        return { conversation: payload, message, appended: true as const };
      });
    }),
});

// Alias kept explicit so the parent router can mount either name without coupling
// the client to this implementation detail.
export const conversationRouter = conversationsRouter;
