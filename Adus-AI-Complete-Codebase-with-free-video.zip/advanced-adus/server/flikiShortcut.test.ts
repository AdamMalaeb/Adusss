import { renderToStaticMarkup } from "react-dom/server";
import React, { createElement } from "react";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import FlikiShortcut from "../client/src/components/FlikiShortcut";

const root = resolve(import.meta.dirname, "..");

describe("free Fliki website shortcut", () => {
  beforeAll(() => vi.stubGlobal("React", React));
  afterAll(() => vi.unstubAllGlobals());

  it("renders a real, safe external link without pretending to be an API connection", () => {
    const html = renderToStaticMarkup(createElement(FlikiShortcut));
    expect(html).toContain('href="https://app.fliki.ai/"');
    expect(html).toContain('target="_blank"');
    expect(html).toContain('rel="noopener noreferrer"');
    expect(html).toContain("Open Fliki — Free Plan");
    expect(html).toContain("not automatic generation inside Adus");
    expect(html).toContain(
      "Newly generated AI video clips are not included free."
    );
  });

  it("is visible before the existing provider controls on the Videos page", () => {
    const page = readFileSync(
      resolve(root, "client/src/pages/Videos.tsx"),
      "utf8"
    );
    expect(page).toContain("<FlikiShortcut />");
    expect(page.indexOf("<FlikiShortcut />")).toBeLessThan(
      page.indexOf("<ModeButton")
    );
    expect(page).toContain("Generation uses Google Veo.");
  });
});
