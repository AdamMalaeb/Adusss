import { execFile } from "node:child_process";
import { readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { beforeEach, describe, expect, it, vi } from "vitest";

const execFileAsync = promisify(execFile);
const mocks = vi.hoisted(() => ({
  generateImage: vi.fn(),
  storagePut: vi.fn(),
  outputPath: "",
}));

vi.mock("./_core/imageGeneration", () => ({
  generateImage: mocks.generateImage,
}));
vi.mock("./naturalSpeech", async () => {
  const actual =
    await vi.importActual<typeof import("./naturalSpeech")>("./naturalSpeech");
  return {
    ...actual,
    createNaturalSpeechAudio: vi.fn(async () => {
      const audio = actual.pcmToWav(Buffer.alloc(24000 * 2 * 3, 0));
      return {
        key: "mock.wav",
        url: "/manus-storage/mock.wav",
        audio,
        contentType: "audio/wav",
      };
    }),
  };
});
vi.mock("./storage", () => ({
  storagePut: mocks.storagePut,
  storageGetSignedUrl: vi.fn(),
}));

import { createStudyVideo, type StudyVideoPayload } from "./studyVideo";

const baseScene = {
  title: "A moving process",
  bullets: [
    "First source-grounded step",
    "Second source-grounded step",
    "Final takeaway",
  ],
  narration:
    "The first step establishes the context. The second step connects the evidence to the idea. The final takeaway explains what the learner should remember.",
  visual: {
    kind: "process" as const,
    labels: ["Context", "Evidence", "Takeaway"],
    imagePrompt: "",
  },
};

function payload(
  overrides: Partial<StudyVideoPayload> = {}
): StudyVideoPayload {
  return {
    title: "A chaptered study",
    summary: "A source-grounded summary.",
    scenes: [baseScene],
    language: "english",
    ...overrides,
  };
}

async function probe(
  path: string
): Promise<{
  duration: number;
  hasAudio: boolean;
  width?: number;
  height?: number;
}> {
  const { stdout } = await execFileAsync("ffprobe", [
    "-v",
    "error",
    "-show_entries",
    "stream=codec_type,width,height:format=duration",
    "-of",
    "json",
    path,
  ]);
  const metadata = JSON.parse(stdout) as {
    streams?: Array<{ codec_type: string; width?: number; height?: number }>;
    format?: { duration?: string };
  };
  const video = metadata.streams?.find(stream => stream.codec_type === "video");
  return {
    duration: Number(metadata.format?.duration ?? 0),
    hasAudio: Boolean(
      metadata.streams?.some(stream => stream.codec_type === "audio")
    ),
    width: video?.width,
    height: video?.height,
  };
}

describe("studyVideo chapter renderer", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.generateImage.mockRejectedValue(
      new Error("paid image provider disabled in tests")
    );
    mocks.storagePut.mockImplementation(
      async (_key: string, bytes: Buffer | Uint8Array) => {
        const outputPath = join(
          tmpdir(),
          `adus-study-extended-${Date.now()}-${Math.random().toString(16).slice(2)}.mp4`
        );
        await writeFile(outputPath, bytes);
        mocks.outputPath = outputPath;
        return { key: "study/test.mp4", url: "/manus-storage/study/test.mp4" };
      }
    );
  });

  it("accepts a single scene and produces a real narrated MP4 with visible within-scene motion", async () => {
    const url = await createStudyVideo(7, "chapter-one", payload());
    expect(url).toBe("/manus-storage/study/test.mp4");
    const metadata = await probe(mocks.outputPath);
    expect(metadata.width).toBe(960);
    expect(metadata.height).toBe(540);
    expect(metadata.hasAudio).toBe(true);
    expect(metadata.duration).toBeGreaterThan(0);

    const framesDir = join(tmpdir(), `adus-study-frames-${Date.now()}`);
    const firstFrame = join(framesDir, "first.jpg");
    const middleFrame = join(framesDir, "middle.jpg");
    await execFileAsync("mkdir", ["-p", framesDir]);
    await execFileAsync("ffmpeg", [
      "-y",
      "-hide_banner",
      "-loglevel",
      "error",
      "-ss",
      "0.1",
      "-i",
      mocks.outputPath,
      "-frames:v",
      "1",
      firstFrame,
    ]);
    await execFileAsync("ffmpeg", [
      "-y",
      "-hide_banner",
      "-loglevel",
      "error",
      "-ss",
      String(Math.max(0.2, metadata.duration / 2)),
      "-i",
      mocks.outputPath,
      "-frames:v",
      "1",
      middleFrame,
    ]);
    const [firstBytes, middleBytes] = await Promise.all([
      readFile(firstFrame),
      readFile(middleFrame),
    ]);
    expect(firstBytes.equals(middleBytes)).toBe(false);
    await rm(framesDir, { recursive: true, force: true });
    await rm(mocks.outputPath, { force: true });
  }, 45_000);

  it("allows twelve scenes but rejects a thirteenth and rejects oversized complete narration", async () => {
    const twelve = Array.from({ length: 12 }, (_, index) => ({
      ...baseScene,
      title: `Scene ${index + 1}`,
      narration: "A complete sentence teaches one bounded idea.",
    }));
    await expect(
      createStudyVideo(7, "twelve-scenes", payload({ scenes: twelve }))
    ).resolves.toBe("/manus-storage/study/test.mp4");
    await rm(mocks.outputPath, { force: true });

    const thirteen = [...twelve, { ...baseScene, title: "Scene 13" }];
    await expect(
      createStudyVideo(7, "thirteen-scenes", payload({ scenes: thirteen }))
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    const oversized = { ...baseScene, narration: "x".repeat(3_001) };
    await expect(
      createStudyVideo(7, "oversized-scene", payload({ scenes: [oversized] }))
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  }, 60_000);

  it("uses a moving teaching board without waiting for an optional image provider", async () => {
    const photoScene = {
      ...baseScene,
      title: "Contextual illustration",
      visual: {
        kind: "photo" as const,
        labels: ["Source", "Context", "Takeaway"],
        imagePrompt: "A source-grounded classroom context.",
      },
    };
    await expect(
      createStudyVideo(7, "photo-fallback", payload({ scenes: [photoScene] }))
    ).resolves.toBe("/manus-storage/study/test.mp4");
    expect(mocks.generateImage).not.toHaveBeenCalled();
    const metadata = await probe(mocks.outputPath);
    expect(metadata.hasAudio).toBe(true);
    await rm(mocks.outputPath, { force: true });
  }, 45_000);
});
