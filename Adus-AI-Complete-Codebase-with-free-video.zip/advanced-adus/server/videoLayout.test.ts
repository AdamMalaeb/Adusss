import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");
const read = (relativePath: string) =>
  readFileSync(resolve(projectRoot, relativePath), "utf8");

describe("video workspace mobile layout contract", () => {
  it("removes Communications from the client shell without deleting media settings", () => {
    const app = read("client/src/App.tsx");
    const navigation = read("client/src/components/DashboardLayout.tsx");

    expect(app).not.toContain('from "@/pages/Communications"');
    expect(app).not.toMatch(
      /communicationsActive|visited\.communications|\/communications/
    );
    expect(navigation).not.toMatch(/label:\s*["']Communications["']/);
    expect(navigation).not.toContain("/communications");
  });

  it("keeps the video controls in a zero-minimum, single-column mobile flow", () => {
    const videos = read("client/src/pages/Videos.tsx");
    const sourceEdit = read("client/src/components/VideoEditPanel.tsx");
    const language = read("client/src/components/LanguageSelect.tsx");

    for (const source of [videos, sourceEdit]) {
      expect(source).toContain("min-w-0");
      expect(source).toContain("max-w-full");
      expect(source).toContain("grid-cols-1");
      expect(source).toContain("whitespace-normal");
    }
    expect(videos).toContain(
      "grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_340px]"
    );
    expect(videos).toContain("Source Editing");
    expect(videos).toContain("Google Generative Restyling");
    expect(videos).toMatch(/video-generation quota\|quota exceeded/);
    expect(language).toContain("block w-full min-w-0 max-w-full");
  });

  it("keeps narration controls in both generation and source-edit flows", () => {
    const videos = read("client/src/pages/Videos.tsx");
    const sourceEdit = read("client/src/components/VideoEditPanel.tsx");

    expect(videos).toContain('aria-label="Generated video narration script"');
    expect(videos).toContain("narrationEnabled");
    expect(videos).toContain("narrationLanguage");
    expect(sourceEdit).toContain('aria-label="Narration script"');
    expect(sourceEdit).toContain("narrationEnabled");
    expect(sourceEdit).toContain("narrationLanguage");
  });
});
