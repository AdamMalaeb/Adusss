import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getRecord, saveRecord } from "./workspaceStore";
import { storagePut } from "./storage";
import { lockedProcedure } from "./accessPolicy";
import { router } from "./_core/trpc";
import {
  createVideoEditPlan,
  executeVideoEdit,
  MAX_EDIT_DURATION_SECONDS,
  MAX_EDIT_OUTPUT_BYTES,
  validateVideoEditPlan,
  type VideoEditPlan,
  type VideoProbe,
} from "./videoEditing";
import { loadStoredVideoSource } from "./videoUpload";
import {
  addNaturalNarration,
  videoNarrationSchema,
  type VideoNarrationInput,
} from "./videoNarration";

const VIDEO_KIND = "videos";
const PLAN_KIND = "video-edit-plan";
const MAX_PROMPT_CHARS = 12_000;

type VideoRecord = {
  type?: "source" | "result";
  operation?: "generate" | "edit" | "local-edit";
  status?: "pending" | "completed" | "failed";
  name?: string;
  mimeType?: string;
  bytes?: number;
  duration?: number;
  sourceId?: string;
  prompt?: string;
  key?: string;
  url?: string;
  provider?: "veo" | "omni" | "local";
  error?: string;
};

type StoredPlan = {
  type: "plan";
  status: "review" | "applying" | "applied";
  sourceId: string;
  prompt: string;
  source: VideoProbe;
  plan: VideoEditPlan;
  narration: VideoNarrationInput;
  estimatedDuration?: number;
  resultId?: string;
  error?: string;
};

const narrationOff: VideoNarrationInput = {
  enabled: false,
  text: "",
  language: "en",
  gender: "woman",
};

const inFlightApplies = new Map<
  string,
  Promise<{
    plan: ReturnType<typeof publicPlan>;
    result: ReturnType<typeof publicVideo>;
  }>
>();

function badRequest(message: string): TRPCError {
  return new TRPCError({ code: "BAD_REQUEST", message });
}

function notFound(message: string): TRPCError {
  return new TRPCError({ code: "NOT_FOUND", message });
}

function serviceUnavailable(message: string): TRPCError {
  return new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}

function publicPlan(id: string, record: StoredPlan) {
  return {
    id,
    type: record.type,
    status: record.status,
    sourceId: record.sourceId,
    prompt: record.prompt,
    source: record.source,
    plan: record.plan,
    narration: record.narration,
    estimatedDuration: record.estimatedDuration,
    resultId: record.resultId,
    error: record.error,
  };
}

function publicVideo(id: string, payload: VideoRecord) {
  return {
    id,
    type: payload.type,
    operation: payload.operation,
    status: payload.status,
    sourceId: payload.sourceId,
    prompt: payload.prompt,
    name: payload.name,
    mimeType: payload.mimeType,
    bytes: payload.bytes,
    duration: payload.duration,
    provider: payload.provider,
    url: payload.url,
    error: payload.error,
  };
}

async function loadSource(
  userId: number,
  sourceId: string
): Promise<{
  record: VideoRecord;
  bytes: Buffer;
  probe: VideoProbe;
}> {
  const source = await loadStoredVideoSource(userId, sourceId);
  return { record: source.payload, bytes: source.bytes, probe: source.probe };
}

const planInput = z.object({
  sourceId: z.string().min(1).max(100),
  prompt: z.string().trim().min(3).max(MAX_PROMPT_CHARS),
  narration: videoNarrationSchema.default({
    enabled: false,
    text: "",
    language: "en",
    gender: "woman",
  }),
});

export const videoEditRouter = router({
  /** Create a structured, reviewable plan. This never calls Veo and never changes media. */
  plan: lockedProcedure.input(planInput).mutation(async ({ input, ctx }) => {
    const source = await loadSource(ctx.user.id, input.sourceId);
    const planned = await createVideoEditPlan({
      prompt: input.prompt,
      source: source.probe,
    });
    const id = randomUUID();
    const record: StoredPlan = {
      type: "plan",
      status: "review",
      sourceId: input.sourceId,
      prompt: input.prompt.trim(),
      source: source.probe,
      plan: planned,
      narration: input.narration,
      estimatedDuration: planned.estimatedDuration,
    };
    await saveRecord(ctx.user.id, PLAN_KIND, record, id);
    return publicPlan(id, record);
  }),

  /** Execute exactly the reviewed plan against a fresh copy of the user's source. */
  applyPlan: lockedProcedure
    .input(z.object({ planId: z.string().min(1).max(100) }))
    .mutation(async ({ input, ctx }) => {
      const key = `${ctx.user.id}:${input.planId}`;
      const existing = inFlightApplies.get(key);
      if (existing) return existing;
      const work = applyPlanOnce(ctx.user.id, input.planId);
      inFlightApplies.set(key, work);
      try {
        return await work;
      } finally {
        inFlightApplies.delete(key);
      }
    }),

  get: lockedProcedure
    .input(z.object({ planId: z.string().min(1).max(100) }))
    .query(async ({ input, ctx }) => {
      const stored = await getRecord(ctx.user.id, PLAN_KIND, input.planId);
      const plan = stored?.payload as StoredPlan | undefined;
      if (!stored || plan?.type !== "plan")
        throw notFound("That edit plan was not found.");
      return publicPlan(input.planId, plan);
    }),
});

async function applyPlanOnce(userId: number, planId: string) {
  const storedPlan = await getRecord(userId, PLAN_KIND, planId);
  const plan = storedPlan?.payload as StoredPlan | undefined;
  if (!storedPlan || plan?.type !== "plan")
    throw notFound("That edit plan is not available to this account.");
  if (plan.status === "applied" && plan.resultId) {
    const existing = await getRecord(userId, VIDEO_KIND, plan.resultId);
    const payload = existing?.payload as VideoRecord | undefined;
    if (existing && payload?.type === "result")
      return {
        plan: publicPlan(planId, plan),
        result: publicVideo(plan.resultId, payload),
      };
  }
  if (plan.status === "applying") {
    if (plan.resultId) {
      const existing = await getRecord(userId, VIDEO_KIND, plan.resultId);
      const payload = existing?.payload as VideoRecord | undefined;
      if (existing && payload?.type === "result") {
        const applied = { ...plan, status: "applied" as const };
        await saveRecord(userId, PLAN_KIND, applied, planId);
        return {
          plan: publicPlan(planId, applied),
          result: publicVideo(plan.resultId, payload),
        };
      }
    }
    throw serviceUnavailable(
      "This edit is already being processed. Check the plan again shortly."
    );
  }
  const source = await loadSource(userId, plan.sourceId);
  const validated = validateVideoEditPlan(plan.plan, source.probe);
  const narration = plan.narration ?? narrationOff;
  const resultId = plan.resultId ?? randomUUID();
  const applying: StoredPlan = {
    ...plan,
    status: "applying",
    resultId,
    error: undefined,
  };
  await saveRecord(userId, PLAN_KIND, applying, planId);
  try {
    const edited = await executeVideoEdit({
      bytes: source.bytes,
      mimeType: source.record.mimeType ?? "video/mp4",
      source: source.probe,
      plan: validated,
    });
    const narrated = narration.enabled
      ? await addNaturalNarration({ bytes: edited.bytes, narration })
      : null;
    const outputBytes = narrated?.bytes ?? edited.bytes;
    const outputDuration = narrated?.duration ?? edited.duration;
    if (!outputBytes.length || outputBytes.length > MAX_EDIT_OUTPUT_BYTES)
      throw serviceUnavailable("The edited video exceeded the output limit.");
    const name =
      `${(source.record.name ?? "source-video").replace(/\.[^.]+$/, "")}-edited.mp4`.slice(
        0,
        180
      );
    const uploaded = await storagePut(
      `videos/${userId}/${resultId}.mp4`,
      outputBytes,
      "video/mp4"
    );
    const result: VideoRecord = {
      type: "result",
      operation: "local-edit",
      status: "completed",
      name,
      mimeType: "video/mp4",
      bytes: outputBytes.length,
      duration: outputDuration,
      sourceId: plan.sourceId,
      prompt: plan.prompt,
      provider: "local",
      key: uploaded.key,
      url: uploaded.url,
    };
    await saveRecord(userId, VIDEO_KIND, result, resultId);
    const applied: StoredPlan = {
      ...plan,
      status: "applied",
      plan: validated,
      estimatedDuration: outputDuration,
      resultId,
      error: undefined,
    };
    await saveRecord(userId, PLAN_KIND, applied, planId);
    return {
      plan: publicPlan(planId, applied),
      result: publicVideo(resultId, result),
    };
  } catch (error) {
    await saveRecord(
      userId,
      PLAN_KIND,
      {
        ...applying,
        status: "review",
        error:
          error instanceof TRPCError
            ? error.message
            : "The edit could not be completed. The original source was not changed.",
      } satisfies StoredPlan,
      planId
    );
    throw error;
  }
}

export type VideoEditRouter = typeof videoEditRouter;
