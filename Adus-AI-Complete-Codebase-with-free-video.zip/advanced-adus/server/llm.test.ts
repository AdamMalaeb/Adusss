import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.BUILT_IN_FORGE_API_URL = "https://forge.test";
  process.env.BUILT_IN_FORGE_API_KEY = "test-key";
});

import { invokeLLM, selectChatModel } from "./_core/llm";

const success = (content: string | null) =>
  new Response(
    JSON.stringify({
      id: "test",
      created: 0,
      model: "test-model",
      choices: [
        {
          index: 0,
          message: { role: "assistant", content },
          finish_reason: "stop",
        },
      ],
    }),
    { status: 200, headers: { "content-type": "application/json" } }
  );

const requestBody = () =>
  JSON.parse(
    (globalThis.fetch as unknown as ReturnType<typeof vi.fn>).mock.calls.at(
      -1
    )![1].body as string
  ) as Record<string, unknown>;

beforeEach(() => {
  vi.useFakeTimers();
  vi.stubGlobal("fetch", vi.fn());
  vi.spyOn(Math, "random").mockReturnValue(0);
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe("invokeLLM reliability contract", () => {
  it("redacts the creator birth date recalled from old history", async () => {
    (globalThis.fetch as unknown as ReturnType<typeof vi.fn>).mockResolvedValue(
      success("Adam Nabil Malaeb was born 6 December 2009.")
    );
    const result = await invokeLLM({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: "Tell me about the creator" }],
    });
    expect(result.choices[0].message.content).not.toContain("2009");
    const messages = requestBody().messages as Array<{ content: string }>;
    expect(messages[0].content).toContain("date of birth is private");
    expect(messages[0].content).not.toContain("2009");
  });
  it("uses the multimodal fast model for attachments even when fast mode is selected", () => {
    expect(selectChatModel({ mode: "fast", multimodal: true })).toBe(
      "gemini-3-flash-preview"
    );
  });
  it("does not retry a permanently exhausted upstream quota", async () => {
    const fetchMock = globalThis.fetch as unknown as ReturnType<typeof vi.fn>;
    fetchMock.mockResolvedValue(
      new Response(
        JSON.stringify({
          error: { code: "insufficient_quota", message: "usage exhausted" },
        }),
        { status: 429 }
      )
    );
    const pending = invokeLLM({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: "hello" }],
    });
    const rejected = expect(pending).rejects.toThrow("LLM invoke failed: 429");
    await vi.runAllTimersAsync();
    await rejected;
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
  it("rejects a null assistant response without spending a fallback request", async () => {
    (
      globalThis.fetch as unknown as ReturnType<typeof vi.fn>
    ).mockImplementation(() => Promise.resolve(success(null)));

    await expect(
      invokeLLM({
        model: "gpt-5-mini",
        messages: [{ role: "user", content: "hello" }],
      })
    ).rejects.toThrow("empty assistant response");
    expect(globalThis.fetch).toHaveBeenCalledTimes(1);
  });

  it("supports a deliberate opt-in alternate model after an empty GPT response", async () => {
    const f = globalThis.fetch as unknown as ReturnType<typeof vi.fn>;
    f.mockResolvedValueOnce(success(null)).mockResolvedValueOnce(
      success("A professional explanation.")
    );
    const r = await invokeLLM(
      {
        model: "gpt-5-mini",
        maxCompletionTokens: 1000,
        reasoning: { effort: "low" },
        messages: [{ role: "user", content: "Explain waves" }],
      },
      true
    );
    expect(r.choices[0].message.content).toBe("A professional explanation.");
    expect(f).toHaveBeenCalledTimes(2);
    expect(requestBody()).toMatchObject({
      model: "gemini-3-flash-preview",
      max_tokens: 4500,
    });
    expect(requestBody()).not.toHaveProperty("max_completion_tokens");
    expect(requestBody()).not.toHaveProperty("reasoning");
  });

  it("uses fast GPT defaults without sending an ambiguous token alias", async () => {
    (globalThis.fetch as unknown as ReturnType<typeof vi.fn>).mockResolvedValue(
      success("OK")
    );

    await expect(
      invokeLLM({
        model: "gpt-5-mini",
        messages: [{ role: "user", content: "hello" }],
      })
    ).resolves.toMatchObject({ choices: [{ message: { content: "OK" } }] });
    const body = requestBody();
    expect(body.model).toBe("gpt-5-mini");
    expect(body).not.toHaveProperty("max_tokens");
    expect(body).not.toHaveProperty("max_completion_tokens");
  });

  it("maps deep GPT output limits to max_completion_tokens", async () => {
    (globalThis.fetch as unknown as ReturnType<typeof vi.fn>).mockResolvedValue(
      success("deep answer")
    );

    await invokeLLM({
      model: "gpt-5.5",
      maxTokens: 777,
      reasoning: { effort: "medium" },
      messages: [{ role: "user", content: "reason carefully" }],
    });
    const body = requestBody();
    expect(body.model).toBe("gpt-5.5");
    expect(body.max_completion_tokens).toBe(777);
    expect(body).not.toHaveProperty("max_tokens");
    expect(body.reasoning).toEqual({ effort: "medium" });
  });

  it("maps Gemini output limits to max_tokens", async () => {
    (globalThis.fetch as unknown as ReturnType<typeof vi.fn>).mockResolvedValue(
      success("multimodal answer")
    );

    await invokeLLM({
      model: "gemini-3-flash-preview",
      maxCompletionTokens: 333,
      messages: [{ role: "user", content: "inspect this" }],
    });
    const body = requestBody();
    expect(body.max_tokens).toBe(333);
    expect(body).not.toHaveProperty("max_completion_tokens");
  });

  it("stops after one safe retry when the provider stays rate-limited", async () => {
    const fetchMock = globalThis.fetch as unknown as ReturnType<typeof vi.fn>;
    fetchMock
      .mockResolvedValueOnce(new Response("busy", { status: 429 }))
      .mockResolvedValueOnce(new Response("still busy", { status: 429 }));

    const pending = invokeLLM({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: "retry once" }],
    });
    const rejected = expect(pending).rejects.toThrow("LLM invoke failed: 429");
    await vi.runAllTimersAsync();
    await rejected;
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("cancels a retry backoff without issuing another provider request", async () => {
    const fetchMock = globalThis.fetch as unknown as ReturnType<typeof vi.fn>;
    const controller = new AbortController();
    fetchMock.mockResolvedValue(new Response("busy", { status: 429 }));

    const pending = invokeLLM({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: "cancel" }],
      signal: controller.signal,
    });
    await Promise.resolve();
    controller.abort();
    await expect(pending).rejects.toMatchObject({ name: "AbortError" });
    await vi.runAllTimersAsync();
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
