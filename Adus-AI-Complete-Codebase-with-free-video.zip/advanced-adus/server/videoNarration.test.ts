import { describe, expect, it, vi } from "vitest";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { addNaturalNarration } from "./videoNarration";

function wavFixture(durationSeconds = 0.45): Buffer {
  const sampleRate = 24_000;
  const samples = Math.floor(sampleRate * durationSeconds);
  const pcm = Buffer.alloc(samples * 2);
  for (let index = 0; index < samples; index += 1) {
    const sample = Math.sin((2 * Math.PI * 440 * index) / sampleRate) * 0.18;
    pcm.writeInt16LE(Math.round(sample * 32767), index * 2);
  }
  const header = Buffer.alloc(44);
  header.write("RIFF", 0, "ascii");
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8, "ascii");
  header.write("fmt ", 12, "ascii");
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36, "ascii");
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

function sourceFixture(): { bytes: Buffer; directory: string } {
  const directory = mkdtempSync(join(tmpdir(), "adus-video-narration-test-"));
  const path = join(directory, "source.mp4");
  execFileSync("ffmpeg", [
    "-y",
    "-hide_banner",
    "-loglevel",
    "error",
    "-f",
    "lavfi",
    "-i",
    "testsrc=size=96x64:rate=12",
    "-f",
    "lavfi",
    "-i",
    "sine=frequency=220:sample_rate=24000",
    "-t",
    "1.5",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    "-c:a",
    "aac",
    "-shortest",
    path,
  ]);
  return { bytes: readFileSync(path), directory };
}

function probe(path: string): {
  streams: Array<{
    codec_type?: string;
    codec_name?: string;
    width?: number;
    height?: number;
  }>;
  format: { duration?: string };
} {
  return JSON.parse(
    execFileSync(
      "ffprobe",
      ["-v", "error", "-show_streams", "-show_format", "-of", "json", path],
      { encoding: "utf8" }
    )
  ) as {
    streams: Array<{
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
    }>;
    format: { duration?: string };
  };
}

describe("optional natural video narration", () => {
  it("mixes a mocked neural WAV without changing source dimensions or duration", async () => {
    const fixture = sourceFixture();
    const synthesize = vi.fn().mockResolvedValue({
      audio: wavFixture(),
      contentType: "audio/wav" as const,
      sampleRate: 24_000,
    });
    try {
      const result = await addNaturalNarration({
        bytes: fixture.bytes,
        narration: {
          enabled: true,
          text: "This is an explicitly requested narration.",
          language: "en",
          gender: "woman",
        },
        synthesize,
      });
      expect(synthesize).toHaveBeenCalledWith(
        "This is an explicitly requested narration.",
        "en",
        { gender: "woman", speechMode: "study" }
      );
      const outputDirectory = mkdtempSync(
        join(tmpdir(), "adus-video-narration-output-")
      );
      const outputPath = join(outputDirectory, "narrated.mp4");
      try {
        writeFileSync(outputPath, result.bytes);
        const metadata = probe(outputPath);
        expect(
          metadata.streams.find(stream => stream.codec_type === "video")
        ).toMatchObject({
          codec_name: "h264",
          width: 96,
          height: 64,
        });
        expect(
          metadata.streams.filter(stream => stream.codec_type === "audio")
        ).toHaveLength(1);
        expect(
          metadata.streams.find(stream => stream.codec_type === "audio")
            ?.codec_name
        ).toBe("aac");
        expect(Number(metadata.format.duration)).toBeGreaterThan(1.35);
        expect(Number(metadata.format.duration)).toBeLessThan(1.65);
        expect(result.duration).toBeGreaterThan(1.3);
      } finally {
        rmSync(outputDirectory, { recursive: true, force: true });
      }
    } finally {
      rmSync(fixture.directory, { recursive: true, force: true });
    }
  }, 30_000);

  it("never silently cuts narration longer than the clip", async () => {
    const fixture = sourceFixture();
    try {
      await expect(
        addNaturalNarration({
          bytes: fixture.bytes,
          narration: {
            enabled: true,
            text: "Long speech",
            language: "en",
            gender: "man",
          },
          synthesize: vi
            .fn()
            .mockResolvedValue({
              audio: wavFixture(3),
              contentType: "audio/wav",
              sampleRate: 24000,
            }),
        })
      ).rejects.toMatchObject({
        code: "BAD_REQUEST",
        message: expect.stringContaining("Shorten the script"),
      });
    } finally {
      rmSync(fixture.directory, { recursive: true, force: true });
    }
  });

  it("does not synthesize when narration is disabled", async () => {
    const synthesize = vi.fn();
    await expect(
      addNaturalNarration({
        bytes: Buffer.from("source"),
        narration: {
          enabled: false,
          text: "",
          language: "en",
          gender: "woman",
        },
        synthesize,
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(synthesize).not.toHaveBeenCalled();
  });
});
