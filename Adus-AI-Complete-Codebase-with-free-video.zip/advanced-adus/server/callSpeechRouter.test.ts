import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  createNaturalSpeechAudio: vi.fn(),
}));

vi.mock("./naturalSpeech", () => ({
  createNaturalSpeechAudio: mocks.createNaturalSpeechAudio,
}));

import { callSpeechRouter } from "./callSpeechRouter";

function context(
  user: TrpcContext["user"] = { id: 42 } as TrpcContext["user"]
): TrpcContext {
  return { user, req: { headers: {} }, res: {} } as TrpcContext;
}

const wav = (() => {
  const bytes = Buffer.alloc(48);
  bytes.write("RIFF", 0, "ascii");
  bytes.write("WAVE", 8, "ascii");
  bytes.writeUInt32LE(48_000, 28);
  bytes.writeUInt32LE(24_000, 40);
  return bytes;
})();

describe("callSpeech.synthesize", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.createNaturalSpeechAudio.mockResolvedValue({
      key: "call/42/call-audio.wav",
      url: "/manus-storage/call/42/call-audio.wav",
      audio: wav,
      contentType: "audio/wav",
    });
  });

  it("returns only the stored URL/key and forwards language, gender and call storage policy", async () => {
    const caller = callSpeechRouter.createCaller(context());
    const result = await caller.synthesize({
      text: "Certainly. I can help you understand the cause.",
      gender: "woman",
      language: "english",
    });
    expect(result).toMatchObject({
      url: "/manus-storage/call/42/call-audio.wav",
      key: "call/42/call-audio.wav",
      duration: 0.5,
    });
    expect(mocks.createNaturalSpeechAudio).toHaveBeenCalledWith(
      42,
      expect.stringMatching(/^call-/),
      "Certainly. I can help you understand the cause.",
      "english",
      { gender: "woman", speechMode: "call", storagePrefix: "call" }
    );
  });

  it("requires authentication and does not expose provider credentials", async () => {
    const caller = callSpeechRouter.createCaller(context(null));
    await expect(
      caller.synthesize({ text: "Bonjour.", gender: "man", language: "french" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("preserves typed provider failures for a recoverable UI message", async () => {
    const { TRPCError } = await import("@trpc/server");
    mocks.createNaturalSpeechAudio.mockRejectedValue(
      new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Retry shortly." })
    );
    const caller = callSpeechRouter.createCaller(context());
    await expect(
      caller.synthesize({ text: "مرحبا.", gender: "man", language: "arabic" })
    ).rejects.toMatchObject({
      code: "TOO_MANY_REQUESTS",
      message: "Retry shortly.",
    });
  });
});
