import { beforeEach, describe, expect, it, vi } from "vitest";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getRecord: vi.fn(),
  listRecords: vi.fn(),
  saveRecord: vi.fn(),
  storagePut: vi.fn(),
  storageGetSignedUrl: vi.fn(),
  isGeminiConfigured: vi.fn(),
  uploadGeminiFile: vi.fn(),
  waitForGeminiFileActive: vi.fn(),
  createGeminiVideoInteraction: vi.fn(),
  createGeminiVeoOperation: vi.fn(),
  resolveGeminiVideo: vi.fn(),
  getGeminiInteraction: vi.fn(),
  getGeminiVideoOperation: vi.fn(),
}));

vi.mock("./workspaceStore", () => ({
  getRecord: mocks.getRecord,
  listRecords: mocks.listRecords,
  saveRecord: mocks.saveRecord,
}));
vi.mock("./storage", () => ({
  storagePut: mocks.storagePut,
  storageGetSignedUrl: mocks.storageGetSignedUrl,
}));
vi.mock("./videoProvider", async importOriginal => ({
  ...(await importOriginal<typeof import("./videoProvider")>()),
  VideoProviderError: class VideoProviderError extends Error {
    code: string;
    constructor(message: string, code = "SERVICE_UNAVAILABLE") {
      super(message);
      this.code = code;
    }
  },
  isGeminiConfigured: mocks.isGeminiConfigured,
  uploadGeminiFile: mocks.uploadGeminiFile,
  waitForGeminiFileActive: mocks.waitForGeminiFileActive,
  createGeminiVideoInteraction: mocks.createGeminiVideoInteraction,
  createGeminiVeoOperation: mocks.createGeminiVeoOperation,
  resolveGeminiVideo: mocks.resolveGeminiVideo,
  getGeminiInteraction: mocks.getGeminiInteraction,
  getGeminiVideoOperation: mocks.getGeminiVideoOperation,
}));

import { videoRouter } from "./videoRouter";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId = 42): TrpcContext {
  const now = new Date();
  const user: AuthenticatedUser = {
    id: userId,
    openId: `video-test-${userId}`,
    email: "adammalaeb30@gmail.com",
    name: "Video Test User",
    loginMethod: "test",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function unauthenticatedCaller() {
  return videoRouter.createCaller({
    ...createAuthContext(),
    user: null,
  });
}

function dataUrl(bytes: Buffer, mimeType = "video/mp4") {
  return `data:${mimeType};base64,${bytes.toString("base64")}`;
}

const fixtureDir = mkdtempSync(join(tmpdir(), "adus-video-test-"));
const fixturePath = join(fixtureDir, "tiny.mp4");
execFileSync("ffmpeg", [
  "-y",
  "-hide_banner",
  "-loglevel",
  "error",
  "-f",
  "lavfi",
  "-i",
  "color=c=black:s=16x16:r=1",
  "-t",
  "1",
  "-an",
  "-c:v",
  "libx264",
  "-pix_fmt",
  "yuv420p",
  fixturePath,
]);
const tinyMp4 = readFileSync(fixturePath);
rmSync(fixtureDir, { recursive: true, force: true });

describe("adus.videos", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.createGeminiVeoOperation.mockReset();
    mocks.createGeminiVideoInteraction.mockReset();
    mocks.isGeminiConfigured.mockReturnValue(true);
    mocks.storagePut.mockResolvedValue({
      key: "videos/42/source.mp4",
      url: "/manus-storage/videos/42/source.mp4",
    });
    mocks.storageGetSignedUrl.mockResolvedValue(
      "https://storage.test/source.mp4"
    );
    mocks.saveRecord.mockImplementation(async (userId, kind, payload, id) => ({
      id,
      userId,
      kind,
      payload,
      createdAt: 1,
      updatedAt: 2,
    }));
    mocks.getRecord.mockResolvedValue(undefined);
    mocks.listRecords.mockResolvedValue([]);
    mocks.uploadGeminiFile.mockResolvedValue({
      name: "files/source-1",
      uri: "https://generativelanguage.googleapis.com/v1beta/files/source-1",
      mimeType: "video/mp4",
    });
    mocks.waitForGeminiFileActive.mockResolvedValue(undefined);
    mocks.createGeminiVideoInteraction.mockResolvedValue({
      id: "interaction-1",
      status: "completed",
      outputUri:
        "https://generativelanguage.googleapis.com/v1beta/files/output-1:download?alt=media",
    });
    mocks.createGeminiVeoOperation.mockResolvedValue({
      id: "operations/veo-1",
      status: "pending",
      provider: "veo",
    });
    mocks.resolveGeminiVideo.mockResolvedValue({
      id: "interaction-1",
      status: "completed",
      video: tinyMp4,
    });
  });

  it("rejects unauthenticated upload and generation", async () => {
    await expect(
      unauthenticatedCaller().upload({
        name: "source.mp4",
        mimeType: "video/mp4",
        dataUrl: dataUrl(tinyMp4),
      })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(
      unauthenticatedCaller().generate({ prompt: "A short film" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("stores a validated source by reference and returns duration metadata", async () => {
    const result = await videoRouter.createCaller(createAuthContext()).upload({
      name: "phone-shot.mp4",
      mimeType: "video/mp4",
      dataUrl: dataUrl(tinyMp4),
    });
    expect(result).toMatchObject({
      id: expect.any(String),
      type: "source",
      status: "completed",
      mimeType: "video/mp4",
      bytes: tinyMp4.length,
    });
    expect(result.duration).toBeGreaterThan(0);
    expect(mocks.storagePut).toHaveBeenCalledWith(
      expect.stringContaining("videos/42/"),
      expect.any(Buffer),
      "video/mp4"
    );
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      42,
      "videos",
      expect.objectContaining({ type: "source", key: "videos/42/source.mp4" }),
      expect.any(String)
    );
  });

  it("rejects HTML and non-video upload bytes before storage", async () => {
    await expect(
      videoRouter.createCaller(createAuthContext()).upload({
        name: "error.mp4",
        mimeType: "video/mp4",
        dataUrl: dataUrl(Buffer.from("<!doctype html><html>login</html>")),
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mocks.storagePut).not.toHaveBeenCalled();
  });

  it("keeps source ownership scoped to the signed-in user", async () => {
    mocks.getRecord.mockResolvedValue(undefined);
    await expect(
      videoRouter.createCaller(createAuthContext(99)).edit({
        sourceId: "someone-elses-source",
        prompt: "Remove the phone",
        aspectRatio: "16:9",
      })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(mocks.getRecord).toHaveBeenCalledWith(
      99,
      "videos",
      "someone-elses-source"
    );
    expect(mocks.uploadGeminiFile).not.toHaveBeenCalled();
  });

  it("runs a mocked generation and persists the provider output without a live call", async () => {
    mocks.createGeminiVeoOperation.mockResolvedValueOnce({
      id: "interaction-inline",
      status: "completed",
      video: tinyMp4,
      provider: "veo",
    });
    const result = await videoRouter
      .createCaller(createAuthContext())
      .generate({
        prompt: "A quiet ocean sunrise",
        aspectRatio: "16:9",
      });
    expect(result).toMatchObject({
      type: "result",
      status: "completed",
      url: expect.stringContaining("manus-storage"),
    });
    expect(mocks.createGeminiVeoOperation).toHaveBeenCalledWith({
      prompt: "A quiet ocean sunrise",
      aspectRatio: "16:9",
      resolution: "720p",
      durationSeconds: 8,
    });
    expect(mocks.resolveGeminiVideo).not.toHaveBeenCalled();
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      42,
      "videos",
      expect.objectContaining({ type: "result", status: "completed" }),
      expect.any(String)
    );
  });

  it("returns an actionable credential error instead of faking a result", async () => {
    mocks.isGeminiConfigured.mockReturnValue(false);
    await expect(
      videoRouter
        .createCaller(createAuthContext())
        .generate({ prompt: "A short clip" })
    ).rejects.toMatchObject({
      code: "PRECONDITION_FAILED",
      message: expect.stringContaining("GEMINI_API_KEY"),
    });
    expect(mocks.createGeminiVideoInteraction).not.toHaveBeenCalled();
  });

  it("maps mocked provider failures to a clear service error", async () => {
    mocks.createGeminiVeoOperation.mockRejectedValue(
      new Error("provider unavailable")
    );
    await expect(
      videoRouter
        .createCaller(createAuthContext())
        .generate({ prompt: "A short clip" })
    ).rejects.toMatchObject({ code: "SERVICE_UNAVAILABLE" });
  });
});

// Provider-level response validation uses the real provider module, but all
// requests are locally mocked. This separate suite is intentionally below the
// router suite so it never performs a live generation call.
describe("video provider response validation", () => {
  it("starts Veo Fast with an asynchronous operation and parses its final URI", async () => {
    vi.resetModules();
    const previousKey = process.env.GEMINI_API_KEY;
    process.env.GEMINI_API_KEY = "test-key";
    const responses = [
      new Response(
        JSON.stringify({
          name: "models/veo-3.1-generate-preview/operations/veo-test-1",
        }),
        { status: 200, headers: { "content-type": "application/json" } }
      ),
      new Response(
        JSON.stringify({
          name: "operations/veo-test-1",
          done: true,
          response: {
            generateVideoResponse: {
              generatedSamples: [
                {
                  video: {
                    uri: "https://generativelanguage.googleapis.com/v1beta/files/veo-output",
                  },
                },
              ],
            },
          },
        }),
        { status: 200, headers: { "content-type": "application/json" } }
      ),
    ];
    vi.stubGlobal(
      "fetch",
      vi.fn().mockImplementation(async () => responses.shift())
    );
    const provider =
      await vi.importActual<typeof import("./videoProvider")>(
        "./videoProvider"
      );
    const started = await provider.createGeminiVeoOperation({
      prompt: "A single blue paper boat on a calm pond",
      aspectRatio: "16:9",
    });
    expect(started).toMatchObject({
      id: "models/veo-3.1-generate-preview/operations/veo-test-1",
      status: "pending",
      provider: "veo",
    });
    const finished = await provider.getGeminiVideoOperation(started.id);
    expect(finished).toMatchObject({
      id: "operations/veo-test-1",
      status: "completed",
      provider: "veo",
      outputUri:
        "https://generativelanguage.googleapis.com/v1beta/files/veo-output",
    });
    const startCall = (globalThis.fetch as ReturnType<typeof vi.fn>).mock
      .calls[0];
    expect(startCall?.[0]).toContain(
      "models/veo-3.1-generate-preview:predictLongRunning"
    );
    expect(JSON.parse(String(startCall?.[1]?.body))).toMatchObject({
      instances: [{ prompt: "A single blue paper boat on a calm pond" }],
      parameters: {
        aspectRatio: "16:9",
        resolution: "720p",
        durationSeconds: 8,
      },
    });
    expect(
      JSON.parse(String(startCall?.[1]?.body)).parameters
    ).not.toHaveProperty("numberOfVideos");
    expect(
      (globalThis.fetch as ReturnType<typeof vi.fn>).mock.calls[1][0]
    ).toContain("/models/veo-3.1-generate-preview/operations/veo-test-1");
    vi.unstubAllGlobals();
    if (previousKey === undefined) delete process.env.GEMINI_API_KEY;
    else process.env.GEMINI_API_KEY = previousKey;
  });

  it("distinguishes a quota-exhausted 429 from a transient 429", async () => {
    vi.resetModules();
    const previousKey = process.env.GEMINI_API_KEY;
    process.env.GEMINI_API_KEY = "test-key";
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({
            error: { message: "Quota exceeded for this project" },
          }),
          { status: 429, headers: { "content-type": "application/json" } }
        )
      )
    );
    const provider =
      await vi.importActual<typeof import("./videoProvider")>(
        "./videoProvider"
      );
    await expect(
      provider.createGeminiVeoOperation({ prompt: "A tiny test clip" })
    ).rejects.toMatchObject({
      code: "TOO_MANY_REQUESTS",
      reason: "quota",
      message: expect.stringContaining("exceeded its video-generation quota"),
    });
    vi.unstubAllGlobals();
    if (previousKey === undefined) delete process.env.GEMINI_API_KEY;
    else process.env.GEMINI_API_KEY = previousKey;
  });

  it("rejects an HTML download response", async () => {
    vi.resetModules();
    const previousKey = process.env.GEMINI_API_KEY;
    process.env.GEMINI_API_KEY = "test-key";
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response("<!doctype html><html>not a video</html>", {
          status: 200,
          headers: { "content-type": "text/html" },
        })
      )
    );
    const provider = await import("./videoProvider");
    await expect(
      provider.downloadGeminiVideo(
        "https://generativelanguage.googleapis.com/v1beta/files/output-1:download?alt=media"
      )
    ).rejects.toMatchObject({ message: expect.stringContaining("HTML") });
    vi.unstubAllGlobals();
    if (previousKey === undefined) delete process.env.GEMINI_API_KEY;
    else process.env.GEMINI_API_KEY = previousKey;
  });
});
