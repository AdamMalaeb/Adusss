import { TRPCError } from "@trpc/server";
import { isLockedOwner, LOCKED_OWNER_EMAIL, normalizeEmail } from "../shared/accessPolicy";
import { protectedProcedure } from "./_core/trpc";

export { LOCKED_OWNER_EMAIL, normalizeEmail, isLockedOwner } from "../shared/accessPolicy";

export const LOCKED_ACCESS_MESSAGE =
  "This area is locked. Access is available only to the approved Adus account.";

/**
 * Middleware for all locked workspace procedures. The email comes from the
 * authenticated server identity in ctx.user; procedure input is intentionally
 * not consulted.
 */
export const lockedProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!isLockedOwner(ctx.user)) {
    throw new TRPCError({ code: "FORBIDDEN", message: LOCKED_ACCESS_MESSAGE });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});

/** Alias used by the main router for locked Operations integrations/automations. */
export const ownerProcedure = lockedProcedure;
export const assertOwner = (identity: { email?: string | null } | null | undefined): void => {
  if (!isLockedOwner(identity)) {
    throw new TRPCError({ code: "FORBIDDEN", message: LOCKED_ACCESS_MESSAGE });
  }
};
