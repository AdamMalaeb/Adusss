import { describe, expect, it, vi } from "vitest";
import {
  CAMERA_FRAME_MIME_TYPE,
  CAMERA_FRAME_NAME,
  CAMERA_STANDALONE_URL,
  CameraCallController,
  cameraCapabilityMessage,
  captureCameraFrame,
  cameraDimensions,
  getCameraCapabilities,
  type CameraCanvas,
  type CameraRuntime,
} from "../client/src/lib/cameraCall";

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((done, fail) => {
    resolve = done;
    reject = fail;
  });
  return { promise, resolve, reject };
}

function streamFixture() {
  const videoTrack = { stop: vi.fn(), enabled: true };
  const stream = {
    getTracks: () => [videoTrack],
    getVideoTracks: () => [videoTrack],
  } as unknown as MediaStream;
  return { stream, videoTrack };
}

function runtimeFixture(getUserMedia: CameraRuntime["getUserMedia"]) {
  const drawImage = vi.fn();
  const toDataURL = vi.fn(() => "data:image/jpeg;base64,frame");
  const canvas: CameraCanvas = {
    width: 0,
    height: 0,
    drawImage,
    toDataURL,
  };
  return {
    runtime: {
      getUserMedia,
      createCanvas: () => canvas,
    } satisfies CameraRuntime,
    canvas,
    drawImage,
    toDataURL,
  };
}

describe("camera call client helper", () => {
  it("preserves aspect ratio and caps the long edge at 960px", () => {
    expect(cameraDimensions(1920, 1080)).toEqual({ width: 960, height: 540 });
    expect(cameraDimensions(720, 1280)).toEqual({ width: 540, height: 960 });
    expect(cameraDimensions(640, 480)).toEqual({ width: 640, height: 480 });
    expect(cameraDimensions(0, 480)).toBeNull();
  });

  it("captures only the current video frame as a quality .75 JPEG payload", () => {
    const fixture = runtimeFixture(vi.fn());
    const video = {
      readyState: 4,
      videoWidth: 1920,
      videoHeight: 1080,
    } as unknown as HTMLVideoElement;

    const frame = captureCameraFrame(video, fixture.runtime.createCanvas);

    expect(frame).toEqual({
      dataUrl: "data:image/jpeg;base64,frame",
      mimeType: CAMERA_FRAME_MIME_TYPE,
      name: CAMERA_FRAME_NAME,
    });
    expect(fixture.canvas.width).toBe(960);
    expect(fixture.canvas.height).toBe(540);
    expect(fixture.drawImage).toHaveBeenCalledWith(video, 0, 0, 960, 540);
    expect(fixture.toDataURL).toHaveBeenCalledWith("image/jpeg", 0.75);
  });

  it("requests video only and stops the stream when disabled", async () => {
    const first = streamFixture();
    const getUserMedia = vi.fn(async () => first.stream);
    const fixture = runtimeFixture(getUserMedia);
    const changes: string[] = [];
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: state => changes.push(state.status),
    });

    await controller.start();

    expect(getUserMedia).toHaveBeenCalledWith({
      video: {
        facingMode: "user",
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    });
    expect(controller.snapshot.active).toBe(true);

    const frame = controller.captureFrame();
    expect(frame).toBeNull();
    controller.stop();
    expect(first.videoTrack.stop).toHaveBeenCalledTimes(1);
    expect(controller.snapshot.active).toBe(false);
    expect(changes.at(-1)).toBe("Camera off");
  });

  it("reports denied permission without creating a camera stream and can recover on retry", async () => {
    const recovered = streamFixture();
    const denied = Object.assign(new Error("permission denied"), {
      name: "NotAllowedError",
    });
    const getUserMedia = vi
      .fn<CameraRuntime["getUserMedia"]>()
      .mockRejectedValueOnce(denied)
      .mockResolvedValueOnce(recovered.stream);
    const fixture = runtimeFixture(getUserMedia);
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    await controller.start();
    expect(controller.snapshot.active).toBe(false);
    expect(controller.snapshot.error).toContain("permission was denied");
    expect(recovered.videoTrack.stop).not.toHaveBeenCalled();

    await controller.start();
    expect(controller.snapshot.active).toBe(true);
    controller.stop();
    expect(recovered.videoTrack.stop).toHaveBeenCalledOnce();
  });

  it("ignores a late permission response after camera stop and stops that stale stream", async () => {
    const permission = deferred<MediaStream>();
    const late = streamFixture();
    const getUserMedia = vi.fn(() => permission.promise);
    const fixture = runtimeFixture(getUserMedia);
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    const starting = controller.start();
    controller.stop();
    permission.resolve(late.stream);
    await starting;

    expect(late.videoTrack.stop).toHaveBeenCalledTimes(1);
    expect(controller.snapshot.active).toBe(false);
    expect(controller.snapshot.pending).toBe(false);
  });

  it("switches between front and rear cameras and releases the old stream", async () => {
    const front = streamFixture();
    const rear = streamFixture();
    const getUserMedia = vi
      .fn<CameraRuntime["getUserMedia"]>()
      .mockResolvedValueOnce(front.stream)
      .mockResolvedValueOnce(rear.stream);
    const fixture = runtimeFixture(getUserMedia);
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    await controller.start();
    await controller.switchCamera();

    expect(getUserMedia).toHaveBeenNthCalledWith(2, {
      video: {
        facingMode: "environment",
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    });
    expect(front.videoTrack.stop).toHaveBeenCalledTimes(1);
    expect(controller.snapshot.facingMode).toBe("environment");
    controller.stop();
    expect(rear.videoTrack.stop).toHaveBeenCalledTimes(1);
  });

  it("retries only a device/constraint failure with basic video-only constraints", async () => {
    const recovered = streamFixture();
    const overconstrained = Object.assign(new Error("lens unavailable"), {
      name: "OverconstrainedError",
    });
    const getUserMedia = vi
      .fn<CameraRuntime["getUserMedia"]>()
      .mockRejectedValueOnce(overconstrained)
      .mockResolvedValueOnce(recovered.stream);
    const fixture = runtimeFixture(getUserMedia);
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    await controller.start();

    expect(getUserMedia).toHaveBeenNthCalledWith(2, {
      video: true,
      audio: false,
    });
    expect(controller.snapshot.active).toBe(true);
    controller.stop();
  });

  it("never retries a real NotAllowed permission denial", async () => {
    const denied = Object.assign(new Error("permission denied"), {
      name: "NotAllowedError",
    });
    const getUserMedia = vi
      .fn<CameraRuntime["getUserMedia"]>()
      .mockRejectedValue(denied);
    const fixture = runtimeFixture(getUserMedia);
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    await controller.start();

    expect(getUserMedia).toHaveBeenCalledOnce();
    expect(controller.snapshot.error).toContain("permission was denied");
  });

  it("does not request media when the host reports an embedded policy block", async () => {
    const getUserMedia = vi.fn<CameraRuntime["getUserMedia"]>();
    const fixture = runtimeFixture(getUserMedia);
    fixture.runtime.getCapabilities = () => ({
      supported: true,
      secureContext: true,
      embedded: true,
      policyAllowsCamera: false,
      canRequest: false,
      standaloneUrl: CAMERA_STANDALONE_URL,
      reason: "embedded",
    });
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    await controller.start();

    expect(getUserMedia).not.toHaveBeenCalled();
    expect(controller.snapshot.error).toContain("embedded browser");
    expect(
      cameraCapabilityMessage(fixture.runtime.getCapabilities!())
    ).toContain("Safari");
  });

  it("uses the real Permissions Policy allowsFeature smoke signal for an iframe", () => {
    const allowsFeature = vi.fn(() => false);
    const parentWindow = {};
    const frameWindow = {
      isSecureContext: true,
      top: parentWindow,
      self: {},
    };
    vi.stubGlobal("window", frameWindow);
    vi.stubGlobal("navigator", {
      mediaDevices: { getUserMedia: vi.fn() },
    });
    vi.stubGlobal("document", {
      permissionsPolicy: { allowsFeature },
    });

    try {
      const capabilities = getCameraCapabilities();
      expect(allowsFeature).toHaveBeenCalledWith("camera");
      expect(capabilities).toMatchObject({
        embedded: true,
        policyAllowsCamera: false,
        canRequest: false,
        reason: "embedded",
      });
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it("explains an embedded NotAllowed denial without pretending permission was granted", async () => {
    const denied = Object.assign(new Error("permission denied"), {
      name: "NotAllowedError",
    });
    const getUserMedia = vi
      .fn<CameraRuntime["getUserMedia"]>()
      .mockRejectedValue(denied);
    const fixture = runtimeFixture(getUserMedia);
    fixture.runtime.getCapabilities = () => ({
      supported: true,
      secureContext: true,
      embedded: true,
      policyAllowsCamera: undefined,
      canRequest: true,
      standaloneUrl: CAMERA_STANDALONE_URL,
    });
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    await controller.start();

    expect(controller.snapshot.active).toBe(false);
    expect(controller.snapshot.error).toContain("embedded browser denied");
    expect(controller.snapshot.error).toContain("Safari");
  });

  it("releases the current lens before a NotReadable switch reacquire", async () => {
    const front = streamFixture();
    const rear = streamFixture();
    const busy = Object.assign(new Error("camera busy"), {
      name: "NotReadableError",
    });
    const getUserMedia = vi
      .fn<CameraRuntime["getUserMedia"]>()
      .mockResolvedValueOnce(front.stream)
      .mockRejectedValueOnce(busy)
      .mockResolvedValueOnce(rear.stream);
    const fixture = runtimeFixture(getUserMedia);
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    await controller.start();
    await controller.switchCamera();

    expect(front.videoTrack.stop).toHaveBeenCalledOnce();
    expect(controller.snapshot.active).toBe(true);
    expect(getUserMedia).toHaveBeenNthCalledWith(3, {
      video: {
        facingMode: "environment",
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    });
    controller.stop();
  });

  it("keeps the preview muted and inline when a stream is attached", async () => {
    const first = streamFixture();
    const fixture = runtimeFixture(vi.fn(async () => first.stream));
    const video = {
      muted: false,
      playsInline: false,
      autoplay: false,
      srcObject: null,
      play: vi.fn(async () => undefined),
    } as unknown as HTMLVideoElement;
    const controller = new CameraCallController({
      runtime: fixture.runtime,
      onChange: () => undefined,
    });

    controller.attachPreview(video);
    await controller.start();

    expect(video.muted).toBe(true);
    expect(video.playsInline).toBe(true);
    expect(video.autoplay).toBe(true);
    expect(video.srcObject).toBe(first.stream);
    controller.stop();
    expect(video.srcObject).toBeNull();
  });
});
