import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { automations, InsertAutomation, InsertIntegration, InsertUser, integrations, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getIntegrationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(integrations).where(eq(integrations.userId, userId)).orderBy(desc(integrations.updatedAt));
}

export async function createIntegration(input: InsertIntegration) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(integrations).values(input);
  const rows = await db.select().from(integrations).where(eq(integrations.userId, input.userId)).orderBy(desc(integrations.id)).limit(1);
  return rows[0];
}

export async function updateIntegrationStatus(userId: number, id: number, status: "draft" | "connected" | "paused") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(integrations).set({ status }).where(and(eq(integrations.id, id), eq(integrations.userId, userId)));
  const rows = await db.select().from(integrations).where(eq(integrations.userId, userId)).orderBy(desc(integrations.updatedAt));
  return rows.find(row => row.id === id);
}

export async function getAutomationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(automations).where(eq(automations.userId, userId)).orderBy(desc(automations.updatedAt));
}

export async function createAutomation(input: InsertAutomation) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(automations).values(input);
  const rows = await db.select().from(automations).where(eq(automations.userId, input.userId)).orderBy(desc(automations.id)).limit(1);
  return rows[0];
}

export async function updateAutomationStatus(userId: number, id: number, status: "draft" | "pending_approval" | "active" | "paused") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(automations).set({ status }).where(and(eq(automations.id, id), eq(automations.userId, userId)));
  const rows = await db.select().from(automations).where(eq(automations.userId, userId)).orderBy(desc(automations.updatedAt));
  return rows.find(row => row.id === id);
}
