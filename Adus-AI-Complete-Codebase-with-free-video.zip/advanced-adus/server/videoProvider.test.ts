import { afterEach, describe, expect, it, vi } from "vitest";
import { createGeminiVeoOperation } from "./videoProvider";

describe("Gemini video provider rate-limit semantics", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    delete process.env.GEMINI_API_KEY;
  });

  it.each([
    {
      message: "Quota exceeded for this project",
      reason: "quota",
      status: "quota_exhausted",
      expected: /exceeded its video-generation quota/i,
    },
    {
      message: "Too many requests; try again later",
      reason: "rate_limit",
      status: "retryable_rate_limit",
      expected: /rate-limiting/i,
    },
  ])(
    "classifies $reason without retrying",
    async ({ message, reason, status, expected }) => {
      process.env.GEMINI_API_KEY = "test-key";
      const fetchMock = vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ error: { message } }), {
          status: 429,
          headers: { "content-type": "application/json" },
        })
      );
      vi.stubGlobal("fetch", fetchMock);

      await expect(
        createGeminiVeoOperation({ prompt: "A short test clip" })
      ).rejects.toMatchObject({
        code: "TOO_MANY_REQUESTS",
        reason,
        status,
        message: expect.stringMatching(expected),
      });
      expect(fetchMock).toHaveBeenCalledTimes(1);
    }
  );
});
