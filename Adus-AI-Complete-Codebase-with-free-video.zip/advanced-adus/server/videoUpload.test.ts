import { describe, expect, it } from "vitest";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import {
  MAX_SOURCE_BYTES,
  detectVideoMime,
  normalizeDeclaredVideoMime,
} from "./videoValidation";
import { validateVideoSource } from "./videoUpload";

function makeFixture(format: "mp4" | "mov" | "webm") {
  const directory = mkdtempSync(join(tmpdir(), "adus-upload-validation-"));
  const path = join(directory, `fixture.${format}`);
  const args = [
    "-y",
    "-hide_banner",
    "-loglevel",
    "error",
    "-f",
    "lavfi",
    "-i",
    "color=c=black:s=32x24:r=4",
    "-t",
    "1",
    "-an",
    ...(format === "webm"
      ? ["-c:v", "libvpx-vp9", "-pix_fmt", "yuv420p"]
      : ["-c:v", "libx264", "-pix_fmt", "yuv420p"]),
    ...(format === "mov" ? ["-f", "mov"] : format === "webm" ? ["-f", "webm"] : []),
    path,
  ];
  execFileSync("ffmpeg", args);
  return { bytes: readFileSync(path), directory };
}

describe("video source validation", () => {
  it("accepts empty recorder MIME and an iPhone-style M4V alias after probing bytes", async () => {
    const fixture = makeFixture("mp4");
    try {
      expect(normalizeDeclaredVideoMime("video/x-m4v")).toBe("video/mp4");
      expect(detectVideoMime(fixture.bytes, "")).toBe("video/mp4");
      const validated = await validateVideoSource({
        bytes: fixture.bytes,
        name: "phone.M4V",
        mimeType: "video/x-m4v",
      });
      expect(validated.mimeType).toBe("video/mp4");
      expect(validated.probe.duration).toBeGreaterThan(0);
    } finally {
      rmSync(fixture.directory, { recursive: true, force: true });
    }
  });

  it("identifies real MOV and WebM containers instead of trusting a mislabeled MIME", async () => {
    const mov = makeFixture("mov");
    const webm = makeFixture("webm");
    try {
      expect(detectVideoMime(mov.bytes, "video/mp4")).toBe("video/quicktime");
      expect(detectVideoMime(webm.bytes, "")).toBe("video/webm");
      await expect(
        validateVideoSource({
          bytes: mov.bytes,
          name: "iphone.MOV",
          mimeType: "",
        })
      ).resolves.toMatchObject({ mimeType: "video/quicktime" });
      await expect(
        validateVideoSource({
          bytes: webm.bytes,
          name: "camera.webm",
          mimeType: "video/mp4",
        })
      ).resolves.toMatchObject({ mimeType: "video/webm" });
    } finally {
      rmSync(mov.directory, { recursive: true, force: true });
      rmSync(webm.directory, { recursive: true, force: true });
    }
  });

  it("rejects empty, fake, unsupported, and over-sized input before storage", async () => {
    await expect(
      validateVideoSource({ bytes: Buffer.alloc(0), name: "empty.mp4", mimeType: "" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      validateVideoSource({ bytes: Buffer.from("not a video"), name: "fake.mp4", mimeType: "video/mp4" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      validateVideoSource({ bytes: Buffer.from("x"), name: "fake.txt", mimeType: "text/plain" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      validateVideoSource({ bytes: Buffer.alloc(MAX_SOURCE_BYTES + 1), name: "large.mp4", mimeType: "video/mp4" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
