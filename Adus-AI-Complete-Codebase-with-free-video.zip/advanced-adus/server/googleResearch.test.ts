import { afterEach, describe, expect, it, vi } from "vitest";
import { collectGoogleResearch, parseGoogleResearch } from "./googleResearch";
const fixture = {
  candidates: [
    {
      content: { parts: [{ text: "A current fact." }] },
      groundingMetadata: {
        groundingChunks: [
          {
            web: {
              uri: "https://official.example/news",
              title: "Official news",
            },
          },
          { web: { uri: "javascript:alert(1)", title: "Bad" } },
          { web: { uri: "https://unused.example" } },
        ],
        groundingSupports: [
          {
            segment: { text: "A current fact." },
            groundingChunkIndices: [0, 1],
          },
        ],
        searchEntryPoint: { renderedContent: "<div>Search suggestions</div>" },
      },
    },
  ],
};
afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});
describe("Google Search research", () => {
  it("keeps only actual supported HTTPS citations and a checked time", () => {
    const result = parseGoogleResearch(fixture, Date.UTC(2026, 9, 11));
    expect(result.sources).toEqual([
      {
        title: "Official news",
        url: "https://official.example/news",
        excerpt: "A current fact.",
      },
    ]);
    expect(result.context).toContain("2026-10-11");
    expect(result.searchSuggestions).toContain("Search suggestions");
  });
  it("does not claim grounding without evidence", () => {
    expect(
      parseGoogleResearch({
        candidates: [{ content: { parts: [{ text: "Unknown" }] } }],
      }).status
    ).toBe("empty");
  });
  it("uses actual Google Search tooling, no private account history, and a finite timeout", async () => {
    vi.stubEnv("GEMINI_API_KEY", "fake-test");
    const fetchMock = vi
      .fn()
      .mockResolvedValue(new Response(JSON.stringify(fixture)));
    vi.stubGlobal("fetch", fetchMock);
    const result = await collectGoogleResearch(
      "current official news for QA fixture 108"
    );
    const init = fetchMock.mock.calls[0][1];
    const body = JSON.parse(init.body);
    expect(body.tools).toEqual([{ google_search: {} }]);
    expect(body.contents).toHaveLength(1);
    expect(init.signal).toBeInstanceOf(AbortSignal);
    expect(result.status).toBe("ok");
  });
  it("returns unavailable if no key is configured without fabricating evidence", async () => {
    vi.stubEnv("GEMINI_API_KEY", "");
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    expect((await collectGoogleResearch("missing key fixture")).status).toBe(
      "unavailable"
    );
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
