import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { promisify } from "node:util";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  synthesizeNaturalSpeech,
  type NaturalSpeechCallLanguage,
  type NaturalSpeechGender,
  type NaturalSpeechResult,
} from "./naturalSpeech";
import { languageSelectionSchema } from "../shared/languages";

const execFileAsync = promisify(execFile);
export const MAX_NARRATION_TEXT_CHARS = 12_000;
export const NARRATION_TIMEOUT_MS = 90_000;
export const MAX_NARRATED_VIDEO_BYTES = 64 * 1024 * 1024;

export type NarrationLanguage = NaturalSpeechCallLanguage;

export type VideoNarrationOptions = {
  enabled: boolean;
  text: string;
  language: NarrationLanguage;
  gender?: NaturalSpeechGender;
};

export const videoNarrationSchema = z.object({
  enabled: z.boolean().default(false),
  text: z.string().max(MAX_NARRATION_TEXT_CHARS).default(""),
  language: z.union([z.literal("auto"), languageSelectionSchema]).default("en"),
  gender: z.enum(["man", "woman"]).default("woman"),
});

export type VideoNarrationInput = z.infer<typeof videoNarrationSchema>;

export type NarratedVideoResult = {
  bytes: Buffer;
  duration: number;
  hasAudio: true;
};

function badRequest(message: string): TRPCError {
  return new TRPCError({ code: "BAD_REQUEST", message });
}

function serviceUnavailable(message: string): TRPCError {
  return new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}

function number(value: number): string {
  return Number(value.toFixed(3)).toString();
}

function validateNarration(
  options: VideoNarrationOptions
): VideoNarrationOptions {
  const text = options.text.trim();
  if (!options.enabled) return { ...options, text: "" };
  if (text.length < 1)
    throw badRequest("Turn on narration only after adding a narration script.");
  if (text.length > MAX_NARRATION_TEXT_CHARS)
    throw badRequest(
      `Narration scripts must be ${MAX_NARRATION_TEXT_CHARS.toLocaleString()} characters or shorter.`
    );
  return { ...options, text };
}

async function probeVideo(
  bytes: Buffer,
  directory: string
): Promise<{ duration: number; hasAudio: boolean }> {
  const sourcePath = join(directory, "source.mp4");
  await writeFile(sourcePath, bytes);
  try {
    const result = await execFileAsync(
      "ffprobe",
      [
        "-v",
        "error",
        "-show_streams",
        "-show_format",
        "-of",
        "json",
        sourcePath,
      ],
      { timeout: 20_000, maxBuffer: 256 * 1024 }
    );
    const payload = JSON.parse(result.stdout) as {
      streams?: Array<Record<string, unknown>>;
      format?: Record<string, unknown>;
    };
    const duration = Number(payload.format?.duration);
    if (!Number.isFinite(duration) || duration <= 0)
      throw new Error("The video duration could not be read.");
    return {
      duration,
      hasAudio: Boolean(
        payload.streams?.some(stream => stream.codec_type === "audio")
      ),
    };
  } catch {
    throw serviceUnavailable(
      "The edited video could not be inspected before narration."
    );
  }
}

/**
 * Mix one explicitly requested neural narration track onto an MP4. The video
 * stream is copied, so narration does not downscale or synthetic-upscale the
 * picture. Existing source audio is retained; it is never replaced silently.
 */
export async function addNaturalNarration(input: {
  bytes: Buffer;
  narration: VideoNarrationOptions;
  synthesize?: (
    text: string,
    language: NarrationLanguage,
    options?: {
      gender?: NaturalSpeechGender;
      speechMode?: "study" | "call";
    }
  ) => Promise<NaturalSpeechResult>;
}): Promise<NarratedVideoResult> {
  const narration = validateNarration(input.narration);
  if (!narration.enabled) {
    throw badRequest(
      "Narration is disabled; no narration mix should be requested."
    );
  }
  if (!input.bytes.length) throw badRequest("The video is empty.");

  const synthesize = input.synthesize ?? synthesizeNaturalSpeech;
  const speech = await synthesize(narration.text, narration.language, {
    gender: narration.gender,
    speechMode: "study",
  });
  if (!speech.audio.length)
    throw serviceUnavailable(
      "Natural narration returned an empty audio track."
    );

  const directory = await mkdtemp(join(tmpdir(), "adus-video-narration-"));
  const sourcePath = join(directory, "source.mp4");
  const speechPath = join(directory, "narration.wav");
  const outputPath = join(directory, "narrated.mp4");
  try {
    await writeFile(sourcePath, input.bytes);
    await writeFile(speechPath, speech.audio);
    const probe = await probeVideo(input.bytes, directory);
    const speechProbe = await execFileAsync(
      "ffprobe",
      [
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        speechPath,
      ],
      { timeout: 20_000, maxBuffer: 4096 }
    );
    const speechDuration = Number(speechProbe.stdout.trim());
    if (!Number.isFinite(speechDuration) || speechDuration <= 0)
      throw serviceUnavailable("The narration duration could not be read.");
    if (speechDuration > probe.duration + 0.2)
      throw badRequest(
        `The narration lasts ${speechDuration.toFixed(1)} seconds, but this clip is ${probe.duration.toFixed(1)} seconds. Shorten the script; no words were silently cut.`
      );
    const graph = probe.hasAudio
      ? `[0:a]aresample=async=1:first_pts=0[base];[1:a]aresample=async=1:first_pts=0[voice];[base][voice]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]`
      : `anullsrc=channel_layout=stereo:sample_rate=24000,atrim=duration=${number(probe.duration)},asetpts=N/SR/TB[base];[1:a]aresample=async=1:first_pts=0[voice];[base][voice]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]`;
    await execFileAsync(
      "ffmpeg",
      [
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-threads",
        "2",
        "-i",
        sourcePath,
        "-i",
        speechPath,
        "-filter_complex",
        graph,
        "-map",
        "0:v:0",
        "-map",
        "[aout]",
        "-c:v",
        "copy",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-movflags",
        "+faststart",
        "-shortest",
        outputPath,
      ],
      { timeout: NARRATION_TIMEOUT_MS, maxBuffer: 256 * 1024 }
    );
    const bytes = await readFile(outputPath);
    if (!bytes.length || bytes.length > MAX_NARRATED_VIDEO_BYTES)
      throw serviceUnavailable(
        "The narrated video exceeded the 64 MB output limit."
      );
    return { bytes, duration: probe.duration, hasAudio: true };
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    if (error && typeof error === "object" && "killed" in error && error.killed)
      throw serviceUnavailable(
        "Narration mixing exceeded the 90-second processing limit."
      );
    throw serviceUnavailable(
      "FFmpeg could not add the requested narration. The video was not changed."
    );
  } finally {
    await rm(directory, { recursive: true, force: true }).catch(
      () => undefined
    );
  }
}
