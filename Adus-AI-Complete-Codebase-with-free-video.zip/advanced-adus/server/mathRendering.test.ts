import { afterAll, describe, expect, it } from "vitest";
import {
  renderSummaryMarkdown,
  summaryDocument,
  renderSummaryPdf,
  closeSummaryPdfBrowser,
} from "./summaryPdf";
import { normalizeMathMarkdown } from "../shared/mathFormat";
import {
  languageSelectionSchema,
  matchDetectedLanguage,
  whisperLanguageHint,
} from "../shared/languages";
import { execFile } from "node:child_process";
import { readFile, rm, writeFile } from "node:fs/promises";
import { promisify } from "node:util";
import { normalizeStandaloneMathText } from "../shared/mathFormat";
const execFileAsync = promisify(execFile);
afterAll(() => closeSummaryPdfBrowser());
describe("multilingual math rendering", () => {
  it("renders equations and actual arrows inside a table without raw commands", () => {
    const html =
      renderSummaryMarkdown(String.raw`Solve $3x + 5 = 14$ and $x + 2y = 11$.

| Description | Example |
| --- | --- |
| Single direction $\rightarrow$ | $C + O_2 \rightarrow CO_2$ |
| Equilibrium $\rightleftharpoons$ | $A \rightleftharpoons B$ |`);
    expect(html).toContain('class="katex"');
    expect(html).toContain("<table>");
    expect(html).toContain("→");
    expect(html).toContain("⇌");
    expect(html).not.toContain("katex-error");
  });
  it("preserves numeric math while escaping bare currency and normalizes TeX delimiters", () => {
    expect(normalizeMathMarkdown("$3 + 5 = 8$")).toBe("$3 + 5 = 8$");
    expect(normalizeMathMarkdown("Price $5 today")).toContain("\\$5");
    expect(normalizeMathMarkdown("Prices: $5 today and $10 tomorrow")).toBe(
      "Prices: \\$5 today and \\$10 tomorrow"
    );
    expect(normalizeMathMarkdown("from $5 to $10")).toBe("from \\$5 to \\$10");
    expect(normalizeMathMarkdown(String.raw`\\[x \\rightarrow y\\]`)).toBe(
      "\n\n$$x \\rightarrow y$$\n\n"
    );
    expect(normalizeMathMarkdown(String.raw`Solve: \\rightarrow`)).toContain(
      "→"
    );
    expect(normalizeMathMarkdown("`$5` and `\\rightarrow` and ```$10```")).toBe(
      "`$5` and `\\rightarrow` and ```$10```"
    );
    expect(normalizeStandaloneMathText(String.raw`A \\rightarrow B`)).toBe(
      "A → B"
    );
    expect(renderSummaryMarkdown(String.raw`\(x \rightarrow y\)`)).toContain(
      'class="katex"'
    );
  });
  it("does not execute embedded source HTML and accepts expanded language selections", () => {
    expect(renderSummaryMarkdown("<script>alert(1)</script>")).not.toContain(
      "<script>"
    );
    expect(languageSelectionSchema.safeParse("constructor").success).toBe(
      false
    );
    expect(matchDetectedLanguage("french")).toBe("fr");
    expect(matchDetectedLanguage("japanese")).toBe("ja");
    expect(whisperLanguageHint("auto")).toBeUndefined();
  });
  it("renders a real phone-download PDF with equations and embedded math fonts", async () => {
    const pdfPath = "/tmp/adus-oct11c-math-summary.pdf";
    const pngPrefix = "/tmp/adus-oct11c-math-summary-page";
    const html = summaryDocument(
      "Equations and reactions",
      [
        {
          index: 0,
          title: "Solving equations",
          summary: String.raw`Prices remain literal: $5 today and $10 tomorrow.

$3x + 5 = 14 \Rightarrow x = 3$.

| Reaction | Result |
| --- | --- |
| Oxidation | $C + O_2 \rightarrow CO_2$ |
| Equilibrium | $A \rightleftharpoons B$ |`,
          warnings: [],
        },
      ],
      "french",
      1
    );
    const pdf = await renderSummaryPdf(html);
    expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
    expect(pdf.length).toBeGreaterThan(1000);
    expect(html).toContain('class="katex"');
    expect(html).toContain("→");
    expect(html).toContain("⇌");
    expect(html).not.toContain("\\rightarrow");
    expect(html).not.toContain("\\rightleftharpoons");
    await writeFile(pdfPath, pdf);
    const text = await execFileAsync("pdftotext", [pdfPath, "-"]);
    expect(text.stdout).toContain("5 today");
    expect(text.stdout).toContain("10 tomorrow");
    expect(text.stdout).toMatch(/CO\s*2|CO2/);
    await execFileAsync("pdftoppm", [
      "-png",
      "-f",
      "1",
      "-singlefile",
      pdfPath,
      pngPrefix,
    ]);
    const rendered = await readFile(`${pngPrefix}.png`);
    expect(rendered.subarray(0, 8).toString("hex")).toBe("89504e470d0a1a0a");
    expect(rendered.length).toBeGreaterThan(1000);
    await rm(pdfPath, { force: true });
    await rm(`${pngPrefix}.png`, { force: true });
  }, 30000);
});
