import { describe, expect, it } from "vitest";
import { currentKnowledgeGuidance } from "../shared/currentKnowledge";

describe("currentKnowledgeGuidance", () => {
  it("uses the runtime ISO date without pretending it is a training cutoff", () => {
    const guidance = currentKnowledgeGuidance("2026-10-11T21:43:15.000Z");
    expect(guidance).toContain("Current runtime date: 2026-10-11T21:43:15.000Z.");
    expect(guidance).toContain("not a model-training date or an exact knowledge cutoff");
    expect(guidance).toContain("live public-web research");
    expect(guidance).not.toMatch(/knowledge cutoff is (?:June|January|February|March|April|May|July|August|September|October|November|December) 2024/i);
  });

  it("states bounded camera and microphone capabilities", () => {
    const guidance = currentKnowledgeGuidance("2026-10-11T00:00:00Z");
    expect(guidance).toContain("snapshots or frames");
    expect(guidance).toContain("not continuous surveillance");
    expect(guidance).toContain("audio the app captures and transcribes");
    expect(guidance).toContain("not continuous listening");
  });
});
