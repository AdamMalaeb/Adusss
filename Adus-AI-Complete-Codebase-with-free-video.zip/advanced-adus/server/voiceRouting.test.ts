import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
const mocks = vi.hoisted(() => ({
  invokeLLM: vi.fn(),
  generateImage: vi.fn(),
}));
vi.mock("./_core/llm", async importOriginal => ({
  ...(await importOriginal<typeof import("./_core/llm")>()),
  invokeLLM: mocks.invokeLLM,
  listLLMModels: vi.fn(),
}));
vi.mock("./_core/imageGeneration", () => ({
  generateImage: mocks.generateImage,
  listImageModels: vi.fn(),
}));
vi.mock("./workspaceStore", () => ({
  getRecord: vi.fn(async () => undefined),
  listRecords: vi.fn(async () => []),
  saveRecord: vi.fn(),
}));
import { appRouter } from "./routers";
function caller() {
  const ctx = {
    user: { id: 1, email: "test@example.com" },
    req: { headers: {} },
    res: {},
  } as TrpcContext;
  return appRouter.createCaller(ctx);
}
beforeEach(() => {
  vi.clearAllMocks();
  mocks.invokeLLM.mockResolvedValue({
    model: "gpt-5.5",
    choices: [{ message: { content: "Here is a short spoken answer." } }],
  });
});
describe("voice-only routing", () => {
  it.each([
    "Create an image",
    "Build a website",
    "Search for travel tips",
    "Schedule a workflow",
    "Tell me a joke",
  ])(
    'returns a spoken answer for "%s" without running non-voice tools',
    async message => {
      const result = await caller().adus.chat({
        message,
        voiceMode: true,
        history: [],
      });
      expect(result.content).toBe("Here is a short spoken answer.");
      expect(result.agent).toBe("Voice Agent");
      expect(result).not.toHaveProperty("openBuilder");
      expect(mocks.generateImage).not.toHaveBeenCalled();
      expect(mocks.invokeLLM).toHaveBeenCalledTimes(1);
      const request = mocks.invokeLLM.mock.calls[0][0];
      expect(request.messages[0].content).toContain("voice-only conversation");
      expect(request.maxCompletionTokens).toBe(1000);
    }
  );
  it("preserves website handoff for ordinary text chat", async () => {
    const result = await caller().adus.chat({
      message: "Build a website",
      history: [],
    });
    expect(result).toMatchObject({ openBuilder: true, agent: "Build Agent" });
    expect(mocks.invokeLLM).not.toHaveBeenCalled();
  });
  it("requires authentication for voice chat", async () => {
    const unauthenticated = appRouter.createCaller({
      user: null,
      req: { headers: {} },
      res: {},
    } as TrpcContext);
    await expect(
      unauthenticated.adus.chat({
        message: "Hello",
        voiceMode: true,
        history: [],
      })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it.each([
    ["fast", "gpt-5-mini", 2200],
    ["deep", "gpt-5.5", 4000],
  ] as const)(
    "routes %s mode to its verified model and bounded output",
    async (modelMode, model, maxCompletionTokens) => {
      await caller().adus.chat({
        message: "Explain one useful idea in a concise way.",
        chatOnly: true,
        modelMode,
        history: [],
      });
      const request = mocks.invokeLLM.mock.calls[0][0];
      expect(request.model).toBe(model);
      expect(request.maxCompletionTokens).toBe(maxCompletionTokens);
      if (modelMode === "deep") {
        expect(request.reasoning).toEqual({ effort: "medium" });
      } else {
        expect(request.reasoning).toEqual({ effort: "low" });
      }
    }
  );
});
