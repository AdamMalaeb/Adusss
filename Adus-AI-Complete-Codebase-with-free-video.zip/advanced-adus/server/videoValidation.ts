import { Buffer } from "node:buffer";

export const MAX_SOURCE_BYTES = 80 * 1024 * 1024;
export const MAX_BASE64_SOURCE_BYTES = 12 * 1024 * 1024;
export const MAX_SOURCE_DURATION_SECONDS = 120;

export type SupportedVideoMime = "video/mp4" | "video/quicktime" | "video/webm";

function normalized(value: string | undefined | null): string {
  return (value ?? "").split(";", 1)[0].trim().toLowerCase();
}

/** Browser and iPhone recorders use several aliases for the same containers. */
export function normalizeDeclaredVideoMime(value?: string | null): string {
  const mime = normalized(value);
  if (!mime || mime === "application/octet-stream") return "";
  if (mime === "video/x-m4v" || mime === "video/m4v") return "video/mp4";
  if (mime === "video/mov") return "video/quicktime";
  if (mime === "video/x-webm") return "video/webm";
  if (mime === "video/mp4" || mime === "video/quicktime" || mime === "video/webm")
    return mime;
  return mime;
}

function ascii(bytes: Buffer, start: number, length: number): string {
  return bytes.subarray(start, start + length).toString("ascii");
}

/**
 * Identify the container from bytes, not from a browser-provided MIME string.
 * The subsequent ffprobe call is authoritative for playable video streams.
 */
export function detectVideoMime(
  bytes: Buffer,
  declaredMime?: string | null
): SupportedVideoMime {
  if (!bytes.length) throw new Error("The video upload is empty.");
  const declared = normalizeDeclaredVideoMime(declaredMime);
  if (declared && !["video/mp4", "video/quicktime", "video/webm"].includes(declared))
    throw new Error("Choose an MP4, MOV, or WEBM video.");

  if (bytes.length >= 12 && ascii(bytes, 4, 4) === "ftyp") {
    const majorBrand = ascii(bytes, 8, 4).toLowerCase();
    const brands = bytes.subarray(8, Math.min(bytes.length, 4096)).toString("ascii").toLowerCase();
    if (majorBrand === "qt  " || brands.includes("qt  "))
      return "video/quicktime";
    // MP4/M4V/HEVC iPhone files all use an ISO-BMFF ftyp box, sometimes with
    // brands not present in older browser accept lists. ffprobe rejects junk.
    return "video/mp4";
  }

  if (
    bytes.length >= 4 &&
    bytes.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3])) &&
    bytes.subarray(0, Math.min(bytes.length, 64 * 1024)).toString("ascii").toLowerCase().includes("webm")
  )
    return "video/webm";

  throw new Error("Choose a real MP4, MOV, or WEBM video file.");
}

export function videoExtensionForMime(mimeType: string): string {
  return normalizeDeclaredVideoMime(mimeType) === "video/webm"
    ? ".webm"
    : normalizeDeclaredVideoMime(mimeType) === "video/quicktime"
      ? ".mov"
      : ".mp4";
}

export function safeVideoName(name: string): string {
  return name.replace(/[\\/\u0000-\u001f\u007f]/g, "-").slice(0, 180) || "source-video";
}
