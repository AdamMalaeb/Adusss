import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  synthesizeNaturalSpeech,
  resetNaturalSpeechQueueForTests,
} from "./naturalSpeech";
const ok = () =>
  new Response(
    JSON.stringify({
      output_audio: { data: Buffer.alloc(20).toString("base64") },
    }),
    { status: 200 }
  );
beforeEach(() => {
  vi.useFakeTimers();
  resetNaturalSpeechQueueForTests();
});
afterEach(() => {
  vi.useRealTimers();
});
describe("natural narration queue and cooldown", () => {
  it("honors a long provider cooldown without making a second immediate request", async () => {
    const f = vi
      .fn()
      .mockResolvedValueOnce(
        new Response("busy", { status: 429, headers: { "retry-after": "60" } })
      );
    await expect(
      synthesizeNaturalSpeech("Hello", "english", {
        apiKey: "test",
        fetchImpl: f,
      })
    ).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    await expect(
      synthesizeNaturalSpeech("Again", "english", {
        apiKey: "test",
        fetchImpl: f,
      })
    ).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(f).toHaveBeenCalledOnce();
  });
  it("does not retry explicitly exhausted quota", async () => {
    const f = vi
      .fn()
      .mockResolvedValue(
        new Response("quota exceeded limit 0", { status: 429 })
      );
    await expect(
      synthesizeNaturalSpeech("Hello", "english", {
        apiKey: "test",
        fetchImpl: f,
      })
    ).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(f).toHaveBeenCalledOnce();
  });
  it("expires queued work without issuing delayed speech requests", async () => {
    let resolve!: (x: Response) => void;
    const f = vi
      .fn()
      .mockImplementationOnce(() => new Promise(done => (resolve = done)))
      .mockResolvedValue(ok());
    const first = synthesizeNaturalSpeech("First", "english", {
      apiKey: "test",
      fetchImpl: f,
    });
    await Promise.resolve();
    await Promise.resolve();
    const second = synthesizeNaturalSpeech("Second", "english", {
      apiKey: "test",
      fetchImpl: f,
    });
    const assertion = expect(second).rejects.toMatchObject({
      code: "TOO_MANY_REQUESTS",
    });
    await vi.advanceTimersByTimeAsync(16000);
    await assertion;
    resolve(ok());
    await first;
    await vi.advanceTimersByTimeAsync(1000);
    expect(f).toHaveBeenCalledOnce();
  });
  it("cancels queued narration before it reaches the provider", async () => {
    let resolve!: (x: Response) => void;
    const f = vi
      .fn()
      .mockImplementationOnce(() => new Promise<Response>(done => (resolve = done)))
      .mockResolvedValue(ok());
    const first = synthesizeNaturalSpeech("First", "english", {
      apiKey: "test",
      fetchImpl: f,
    });
    await Promise.resolve();
    await Promise.resolve();
    const controller = new AbortController();
    const second = synthesizeNaturalSpeech("Second", "english", {
      apiKey: "test",
      fetchImpl: f,
      signal: controller.signal,
    });
    controller.abort();
    await expect(second).rejects.toMatchObject({ code: "TIMEOUT" });
    resolve(ok());
    await first;
    await vi.advanceTimersByTimeAsync(1000);
    expect(f).toHaveBeenCalledOnce();
  });
  it("uses an informative male voice and English director instructions for Arabic calls", async () => {
    const f = vi.fn().mockResolvedValue(ok());
    await synthesizeNaturalSpeech("مرحبا", "arabic", {
      apiKey: "test",
      fetchImpl: f,
      gender: "man",
      speechMode: "call",
    });
    const r = JSON.parse(String(f.mock.calls[0][1].body));
    expect(r.generation_config.speech_config[0].voice).toBe("Charon");
    expect(r.input[0].content[0].annotations[0].style).toContain(
      "Modern Standard Arabic"
    );
    expect(r.input[0].content[0].text).toBe("مرحبا");
  });
});
