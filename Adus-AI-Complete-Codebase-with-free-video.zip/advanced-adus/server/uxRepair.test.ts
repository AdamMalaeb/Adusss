import { describe, expect, it } from "vitest";
import { normalizePreviewHtml } from "../client/src/pages/BuildLab";
import {
  normalizeStoredMediaUrl,
  sniffMediaType,
} from "../client/src/lib/downloadMedia";
import { storageKeyFromUrl } from "./mediaDownloads";

describe("UX repair regressions", () => {
  it("adds viewport and safety scaffolding once without changing generated markup", () => {
    const html = "<html><head><title>Demo</title></head><body><h1>Demo</h1></body></html>";
    const normalized = normalizePreviewHtml(html);
    expect(normalized).toContain('name="viewport"');
    expect(normalized).toContain("data-adus-preview-safety");
    expect(normalizePreviewHtml(normalized)).toBe(normalized);
    expect(normalized).toContain("<h1>Demo</h1>");
  });

  it("accepts split media signatures and rejects unsafe or malformed storage paths", () => {
    expect(sniffMediaType(Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))).toMatchObject({
      type: "image/png",
      extension: "png",
    });
    expect(storageKeyFromUrl("/manus-storage/images/7/photo%20one.png")).toBe(
      "images/7/photo one.png"
    );
    expect(storageKeyFromUrl("/manus-storage/images/7/%2e%2e%2fsecret.png")).toBeNull();
    expect(storageKeyFromUrl("/manus-storage/images/7/photo.png?ticket=old")).toBeNull();
  });

  it("normalizes same-origin legacy media URLs but leaves remote URLs alone", () => {
    const originalWindow = globalThis.window;
    Object.defineProperty(globalThis, "window", {
      configurable: true,
      value: { location: { origin: "https://adus.example" } },
    });
    try {
      expect(
        normalizeStoredMediaUrl("https://adus.example/manus-storage/images/7/a.png")
      ).toBe("/manus-storage/images/7/a.png");
      expect(
        normalizeStoredMediaUrl("https://storage.example/images/7/a.png")
      ).toBe("https://storage.example/images/7/a.png");
    } finally {
      Object.defineProperty(globalThis, "window", {
        configurable: true,
        value: originalWindow,
      });
    }
  });
});
