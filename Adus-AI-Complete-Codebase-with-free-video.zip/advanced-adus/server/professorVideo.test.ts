import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  analyzeStudyParts: vi.fn(),
  createWhiteboardLesson: vi.fn(),
  createWhiteboardVideo: vi.fn(),
}));

vi.mock("./studyRouter", () => ({
  analyzeStudyParts: mocks.analyzeStudyParts,
}));
vi.mock("./whiteboardVideo", () => ({
  createWhiteboardLesson: mocks.createWhiteboardLesson,
  createWhiteboardVideo: mocks.createWhiteboardVideo,
}));

import {
  createProfessorScript,
  prepareProfessorNarration,
  renderProfessorVideo,
} from "./professorVideo";

const script = {
  title: "Photosynthesis",
  summary: "Plants convert light energy into stored chemical energy.",
  sources: ["Learner educational brief"],
  warnings: [],
  scenes: [
    {
      title: "The energy pathway",
      bullets: ["Light", "Glucose"],
      narration: "Light energy is captured and stored as chemical energy.",
      visual: { kind: "process" as const, labels: ["Light", "Glucose"] },
    },
  ],
};

describe("professorVideo", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.analyzeStudyParts.mockResolvedValue(script);
    mocks.createWhiteboardLesson.mockResolvedValue({
      audioURL: "/manus-storage/whiteboard/job-narration.wav",
      audioDuration: 7.5,
      language: "french",
      scenes: [],
      audio: Buffer.from("wav"),
    });
    mocks.createWhiteboardVideo.mockResolvedValue(
      "/manus-storage/whiteboard/job.mp4"
    );
  });

  it("grounds a Professor script in the learner prompt and returns visual scenes", async () => {
    const result = await createProfessorScript(
      "Explain photosynthesis with a worked equation.",
      "english"
    );
    expect(result).toEqual(script);
    expect(mocks.analyzeStudyParts).toHaveBeenCalledWith(
      [
        expect.objectContaining({
          type: "text",
          text: expect.stringContaining(
            "Explain photosynthesis with a worked equation."
          ),
        }),
      ],
      ["Learner educational brief"],
      "english",
      "the learner's requested topic"
    );
  });

  it("creates one reusable narration and renders the board with that saved audio", async () => {
    const lesson = await prepareProfessorNarration(
      7,
      "job-1",
      script,
      "french"
    );
    expect(lesson.audioURL).toContain("narration.wav");
    expect(mocks.createWhiteboardLesson).toHaveBeenCalledWith(
      7,
      "job-1",
      expect.objectContaining({
        language: "french",
        scenes: script.scenes,
      })
    );

    const url = await renderProfessorVideo(
      7,
      "job-1",
      script,
      "french",
      lesson.audioURL
    );
    expect(url).toContain("job.mp4");
    expect(mocks.createWhiteboardVideo).toHaveBeenCalledWith(
      7,
      "job-1",
      expect.objectContaining({ audioURL: lesson.audioURL }),
      { audioURL: lesson.audioURL }
    );
  });
});
