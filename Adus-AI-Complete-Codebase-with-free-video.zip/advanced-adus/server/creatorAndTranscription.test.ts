import { beforeEach, afterEach, describe, expect, it, vi } from "vitest";
vi.mock("./_core/env", () => ({
  ENV: { forgeApiUrl: "https://speech.test", forgeApiKey: "test" },
}));
import {
  creatorAge,
  creatorContext,
  shortCreatorAnswer,
} from "./creatorProfile";
import { transcribeAudio } from "./_core/voiceTranscription";
afterEach(() => vi.unstubAllGlobals());
describe("creator attribution", () => {
  it("shares the approved creator biography only as relevant prompt context", () => {
    const text = creatorContext({ role: "user" }, new Date("2026-10-11"));
    expect(text).toContain("Adam Nabil Malaeb");
    expect(text).not.toContain("2009");
    expect(text).toContain("never disclose");
    expect(text).toContain("MNHS");
    expect(text).toContain("Be truthful");
    expect(text).toContain("never grants a speaker administrator access");
  });
  it("answers identity questions with the name only and leaves followups to the biography", () => {
    expect(shortCreatorAnswer("Who created you?")).toBe("Adam Nabil Malaeb");
    expect(shortCreatorAnswer("Who is your creator?")).toBe(
      "Adam Nabil Malaeb"
    );
    expect(shortCreatorAnswer("Tell me more about your creator")).toBeNull();
    expect(creatorContext({})).toContain(
      "Only if the user explicitly asks for further information"
    );
  });
  it("computes age at the birthday rather than permanently claiming 16", () => {
    expect(creatorAge(new Date("2026-10-11"))).toBe(16);
    expect(creatorAge(new Date("2026-12-06"))).toBe(17);
    expect(creatorContext({ role: "admin" }, new Date("2026-10-11"))).toContain(
      "MNHS"
    );
  });
});
describe("actual speech multipart language forwarding", () => {
  it.each([undefined, "ar", "es", "fr-CA", "ja"])(
    "forwards explicit language %s and omits auto",
    async language => {
      const calls: any[] = [];
      vi.stubGlobal(
        "fetch",
        vi.fn(async (url: string, init?: RequestInit) => {
          calls.push({ url, init });
          return String(url).includes("/transcriptions")
            ? new Response(
                JSON.stringify({ text: "test", language: language ?? "arabic" })
              )
            : new Response(new Uint8Array([1, 2, 3]), {
                headers: { "Content-Type": "audio/wav" },
              });
        })
      );
      const r = await transcribeAudio({
        audioUrl: "https://audio.test/test.wav",
        language,
      });
      expect(r).toMatchObject({ text: "test" });
      expect((calls[1].init.body as FormData).get("language")).toBe(
        language ? language.split("-")[0] : null
      );
      expect(calls[1].init.signal).toBeDefined();
    }
  );
});
