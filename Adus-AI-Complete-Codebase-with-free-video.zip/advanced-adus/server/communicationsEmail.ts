import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from "node:crypto";
import { isIP } from "node:net";
import { lookup } from "node:dns/promises";
import nodemailer, { type SentMessageInfo, type Transporter } from "nodemailer";

export type SmtpCredentials = {
  host: string;
  port: number;
  email: string;
  username: string;
  password: string;
  secure: boolean;
};

export type MailboxPublic = {
  status: "connected" | "disconnected";
  host?: string;
  port?: number;
  email?: string;
  username?: string;
  secure?: boolean;
  verifiedAt?: number;
  verifiedAliases: string[];
  lastError?: string;
};

const ENCRYPTION_VERSION = "v1";
const MAX_HOST_LENGTH = 253;
const MAX_SOURCE_REDIRECTS = 3;

function encryptionKey() {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error("JWT_SECRET is required for mailbox credential storage");
  }
  return createHash("sha256").update(secret, "utf8").digest();
}

function encode(bytes: Buffer) {
  return bytes.toString("base64url");
}

function decode(value: string) {
  return Buffer.from(value, "base64url");
}

/** Encrypts mailbox credentials with the app's existing server-only JWT secret. */
export function encryptCredentials(credentials: SmtpCredentials) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const ciphertext = Buffer.concat([
    cipher.update(JSON.stringify(credentials), "utf8"),
    cipher.final(),
  ]);
  return [
    ENCRYPTION_VERSION,
    encode(iv),
    encode(cipher.getAuthTag()),
    encode(ciphertext),
  ].join(".");
}

/** Decrypts only on the server immediately before SMTP verification or delivery. */
export function decryptCredentials(value: string): SmtpCredentials {
  const [version, ivValue, tagValue, ciphertextValue] = value.split(".");
  if (
    version !== ENCRYPTION_VERSION ||
    !ivValue ||
    !tagValue ||
    !ciphertextValue
  ) {
    throw new Error("Mailbox credential record is invalid");
  }
  const decipher = createDecipheriv(
    "aes-256-gcm",
    encryptionKey(),
    decode(ivValue)
  );
  decipher.setAuthTag(decode(tagValue));
  const plaintext = Buffer.concat([
    decipher.update(decode(ciphertextValue)),
    decipher.final(),
  ]).toString("utf8");
  const parsed = JSON.parse(plaintext) as SmtpCredentials;
  validateCredentialShape(parsed);
  return parsed;
}

function validateCredentialShape(credentials: SmtpCredentials) {
  if (
    !credentials ||
    typeof credentials.host !== "string" ||
    !Number.isInteger(credentials.port) ||
    typeof credentials.email !== "string" ||
    typeof credentials.username !== "string" ||
    typeof credentials.password !== "string" ||
    typeof credentials.secure !== "boolean"
  ) {
    throw new Error("Mailbox credential record is invalid");
  }
}

function isPrivateOrReservedIp(address: string) {
  const family = isIP(address);
  if (family === 4) {
    const octets = address.split(".").map(Number);
    const [a, b] = octets;
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && (b === 0 || b === 168)) ||
      (a === 198 && (b === 18 || b === 19 || b === 51)) ||
      (a === 203 && b === 0) ||
      a >= 224
    );
  }
  if (family === 6) {
    const normalized = address.toLowerCase();
    return (
      normalized === "::" ||
      normalized === "::1" ||
      normalized.startsWith("fc") ||
      normalized.startsWith("fd") ||
      normalized.startsWith("fe8") ||
      normalized.startsWith("fe9") ||
      normalized.startsWith("fea") ||
      normalized.startsWith("feb") ||
      normalized.startsWith("ff")
    );
  }
  return true;
}

function validHostname(host: string) {
  if (!host || host.length > MAX_HOST_LENGTH || /[\s/\\]/.test(host))
    return false;
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local")
  )
    return false;
  if (host.endsWith(".internal") || host.endsWith(".home.arpa")) return false;
  if (host.toLowerCase() === "metadata.google.internal") return false;
  if (isIP(host)) return !isPrivateOrReservedIp(host);
  return host
    .split(".")
    .every(
      label =>
        label.length > 0 &&
        label.length <= 63 &&
        /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label)
    );
}

/** Resolve a user-supplied host and reject loopback, private, link-local and metadata networks. */
export async function assertPublicHost(host: string) {
  const normalized = host.trim().replace(/\.$/, "").toLowerCase();
  if (!validHostname(normalized))
    throw new Error("SMTP host must be a public hostname");
  const answers = await lookup(normalized, { all: true, verbatim: true });
  if (
    !answers.length ||
    answers.some(answer => isPrivateOrReservedIp(answer.address))
  ) {
    throw new Error("SMTP host resolved to a private or reserved network");
  }
  return normalized;
}

export function normalizeEmail(value: string) {
  const email = value.trim().toLowerCase();
  if (
    email.length > 320 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
    email.includes("..")
  ) {
    throw new Error("Enter a valid email address");
  }
  return email;
}

export function assertPort(port: number) {
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("SMTP port must be between 1 and 65535");
  }
  return port;
}

export async function validateSmtpCredentials(input: SmtpCredentials) {
  validateCredentialShape(input);
  const host = await assertPublicHost(input.host);
  const port = assertPort(input.port);
  const email = normalizeEmail(input.email);
  const username = input.username.trim();
  if (!username || username.length > 320)
    throw new Error("SMTP username is required");
  if (normalizeEmail(username) !== email)
    throw new Error(
      "The sender must match the authenticated SMTP email. Sender aliases are not supported."
    );
  if (!input.password || input.password.length > 2048)
    throw new Error("SMTP password or app-password is required");
  return { ...input, host, port, email, username };
}

function createTransport(credentials: SmtpCredentials): Transporter {
  return nodemailer.createTransport({
    host: credentials.host,
    port: credentials.port,
    secure: credentials.secure,
    requireTLS: !credentials.secure,
    auth: { user: credentials.username, pass: credentials.password },
    connectionTimeout: 10_000,
    greetingTimeout: 10_000,
    socketTimeout: 15_000,
  });
}

/** Verify a mailbox without returning credentials or provider diagnostics. */
export async function verifySmtpCredentials(credentials: SmtpCredentials) {
  const normalized = await validateSmtpCredentials(credentials);
  const transport = createTransport(normalized);
  try {
    await transport.verify();
    return normalized;
  } finally {
    transport.close();
  }
}

export function transportForCredentials(credentials: SmtpCredentials) {
  return createTransport(credentials);
}

export async function sendSingleMessage(
  transport: Transporter,
  message: { from: string; to: string; subject: string; text: string }
): Promise<SentMessageInfo> {
  return transport.sendMail({
    from: message.from,
    to: message.to,
    subject: message.subject,
    text: message.text,
  });
}

/** Keep provider errors out of persisted records and logs; this may be shown to the user. */
export function safeDeliveryError(error: unknown) {
  const code =
    typeof error === "object" &&
    error &&
    "code" in error &&
    typeof error.code === "string"
      ? error.code
      : "SMTP_ERROR";
  return `SMTP delivery failed (${code})`;
}

/** Public URL validation shared by contact research and source-link persistence. */
export async function assertPublicUrl(value: string) {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Source URL must be a valid public HTTP(S) URL");
  }
  if (url.protocol !== "https:" && url.protocol !== "http:")
    throw new Error("Source URL must use HTTP or HTTPS");
  if (
    url.username ||
    url.password ||
    (url.port && !["80", "443"].includes(url.port))
  )
    throw new Error("Source URL contains a disallowed authority");
  await assertPublicHost(url.hostname);
  return url.toString();
}

/** Fetch a public page with redirect-by-redirect SSRF checks and a bounded body. */
export async function fetchPublicText(value: string, timeoutMs = 8_000) {
  let current = await assertPublicUrl(value);
  for (let redirect = 0; redirect <= MAX_SOURCE_REDIRECTS; redirect += 1) {
    const response = await fetch(current, {
      redirect: "manual",
      signal: AbortSignal.timeout(timeoutMs),
      headers: { accept: "text/html,text/plain;q=0.9,*/*;q=0.1" },
    });
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location || redirect === MAX_SOURCE_REDIRECTS)
        throw new Error("Source page redirects too many times");
      current = await assertPublicUrl(new URL(location, current).toString());
      continue;
    }
    if (!response.ok)
      throw new Error(`Source page returned HTTP ${response.status}`);
    const reader = response.body?.getReader();
    if (!reader) throw new Error("Source page has no body");
    const chunks: Uint8Array[] = [];
    let total = 0;
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        total += value.length;
        if (total > 700_000)
          throw new Error("Source page exceeds the readable limit");
        chunks.push(value);
      }
    } finally {
      await reader.cancel().catch(() => undefined);
    }
    return { url: current, body: Buffer.concat(chunks).toString("utf8") };
  }
  throw new Error("Source page could not be verified");
}

export function publicMailbox(record: {
  status: "connected" | "disconnected";
  host?: string;
  port?: number;
  email?: string;
  username?: string;
  secure?: boolean;
  verifiedAt?: number;
  verifiedAliases?: string[];
  lastError?: string;
}): MailboxPublic {
  return {
    status: record.status,
    host: record.host,
    port: record.port,
    email: record.email,
    username: record.username,
    secure: record.secure,
    verifiedAt: record.verifiedAt,
    verifiedAliases: record.verifiedAliases ?? [],
    lastError: record.lastError,
  };
}
