import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getRecord, listRecords, saveRecord } from "./workspaceStore";
import {
  createProfessorScript,
  prepareProfessorNarration,
  professorErrorMessage,
  renderProfessorVideo,
  type ProfessorScript,
  type ProfessorJobPayload,
  type ProfessorLanguage,
} from "./professorVideo";
import { lockedProcedure } from "./accessPolicy";
import { router } from "./_core/trpc";

const KIND = "professor-video";
const inFlight = new Map<string, Promise<ProfessorPublicResult>>();
import { languageSelectionSchema } from "../shared/languages";
const language = languageSelectionSchema;
const idInput = z.object({ id: z.string().min(1).max(100) });
type ProfessorPublicResult = {
  id: string;
  type: "professor";
  status: ProfessorJobPayload["status"];
  stage: ProfessorJobPayload["stage"];
  failedStep?: ProfessorJobPayload["failedStep"];
  prompt: string;
  language: ProfessorLanguage;
  title?: string;
  summary?: string;
  scenes?: ProfessorScript["scenes"];
  sources?: string[];
  warnings?: string[];
  audioURL?: string;
  audioDuration?: number;
  url?: string;
  error?: string;
};
function result(id: string, p: ProfessorJobPayload): ProfessorPublicResult {
  return {
    id,
    type: "professor",
    status: p.status,
    stage: p.stage,
    failedStep: p.failedStep,
    prompt: p.prompt,
    language: p.language,
    title: p.script?.title,
    summary: p.script?.summary,
    scenes: p.script?.scenes,
    sources: p.script?.sources,
    warnings: p.script?.warnings,
    audioURL: p.audioURL,
    audioDuration: p.audioDuration,
    url: p.url,
    error: p.error,
  };
}
async function load(userId: number, id: string): Promise<ProfessorJobPayload> {
  const r = await getRecord(userId, KIND, id);
  if (!r || r.payload?.type !== "professor")
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "That Professor video job is not available in your workspace.",
    });
  return r.payload as ProfessorJobPayload;
}
async function save(userId: number, id: string, p: ProfessorJobPayload) {
  await saveRecord(userId, KIND, p, id);
  return result(id, p);
}

/** One durable stage per active request. No CPU work is detached after an autoscaled response. */
async function advance(
  userId: number,
  id: string
): Promise<ProfessorPublicResult> {
  const key = `${userId}:${id}`;
  const existing = inFlight.get(key);
  if (existing) return existing;
  const run = (async () => {
    let p = await load(userId, id);
    if (p.status !== "pending") return result(id, p);
    try {
      if (!p.script) {
        p = { ...p, stage: "script", error: undefined, failedStep: undefined };
        await save(userId, id, p);
        const script = await createProfessorScript(p.prompt, p.language);
        return await save(userId, id, { ...p, script, stage: "narration" });
      }
      if (!p.audioURL) {
        p = {
          ...p,
          stage: "narration",
          error: undefined,
          failedStep: undefined,
        };
        await save(userId, id, p);
        const audio = await prepareProfessorNarration(
          userId,
          id,
          p.script!,
          p.language
        );
        return await save(userId, id, {
          ...p,
          audioURL: audio.audioURL,
          audioDuration: audio.audioDuration,
          stage: "render",
        });
      }
      p = { ...p, stage: "render", error: undefined, failedStep: undefined };
      await save(userId, id, p);
      const url =
        p.url ??
        (await renderProfessorVideo(
          userId,
          id,
          p.script!,
          p.language,
          p.audioURL!
        ));
      return await save(userId, id, {
        ...p,
        status: "completed",
        stage: "done",
        url,
      });
    } catch (e) {
      const step = p.stage === "done" ? "render" : p.stage;
      return await save(userId, id, {
        ...p,
        status: "failed",
        failedStep: step,
        error: professorErrorMessage(e, step),
      });
    }
  })();
  inFlight.set(key, run);
  try {
    return await run;
  } finally {
    inFlight.delete(key);
  }
}
export const professorVideoRouter = router({
  create: lockedProcedure
    .input(
      z.object({
        prompt: z.string().trim().min(3).max(12000),
        language: language.default("english"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const id = randomUUID();
      return await save(ctx.user.id, id, {
        type: "professor",
        status: "pending",
        stage: "script",
        prompt: input.prompt,
        language: input.language,
      });
    }),
  retry: lockedProcedure.input(idInput).mutation(async ({ ctx, input }) => {
    const key = `${ctx.user.id}:${input.id}`;
    const running = inFlight.get(key);
    if (running) return running;
    const p = await load(ctx.user.id, input.id);
    if (p.status !== "failed") return result(input.id, p);
    return await save(ctx.user.id, input.id, {
      ...p,
      status: "pending",
      stage: p.failedStep ?? p.stage,
      error: undefined,
      failedStep: undefined,
    });
  }),
  status: lockedProcedure
    .input(idInput)
    .query(async ({ ctx, input }) => advance(ctx.user.id, input.id)),
  list: lockedProcedure.query(async ({ ctx }) =>
    (await listRecords(ctx.user.id, KIND, 30)).map(r =>
      result(r.id, r.payload as ProfessorJobPayload)
    )
  ),
});
export type ProfessorVideoRouter = typeof professorVideoRouter;
