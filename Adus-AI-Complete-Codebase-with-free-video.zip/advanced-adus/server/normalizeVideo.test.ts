import { describe, it, expect } from "vitest";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { normalizeVideoOutput } from "./normalizeVideo";
describe("mobile video compatibility", () => {
  it("converts provider WebM into H264 MP4 with a real container", async () => {
    const dir = mkdtempSync(join(tmpdir(), "adus-video-format-test-"));
    try {
      const path = join(dir, "source.webm");
      execFileSync("ffmpeg", [
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-f",
        "lavfi",
        "-i",
        "color=c=blue:s=32x32:r=5",
        "-t",
        "0.4",
        "-c:v",
        "libvpx-vp9",
        path,
      ]);
      const output = await normalizeVideoOutput(readFileSync(path));
      expect(output.subarray(4, 8).toString()).toBe("ftyp");
      expect(output.length).toBeGreaterThan(100);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  }, 20000);
  it("rejects HTML instead of presenting it as a video", async () => {
    await expect(
      normalizeVideoOutput(Buffer.from("<html>error</html>"))
    ).rejects.toThrow();
  });
});
