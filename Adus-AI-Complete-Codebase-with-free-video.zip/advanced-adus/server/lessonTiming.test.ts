import { describe, expect, it } from "vitest";
import {
  boardActionProgressAt,
  buildLessonTiming,
  buildPhraseCues,
  cueProgressAt,
  findLessonScene,
  whiteboardRevealAt,
} from "../shared/lessonTiming";
import { buildWhiteboardTimelines } from "./whiteboardVideo";

const scenes = [
  {
    title: "Context",
    bullets: ["Source"],
    narration: "First, establish the context. Then name the evidence.",
  },
  {
    title: "Takeaway",
    bullets: ["Remember"],
    narration: "Finally, state the takeaway for the learner.",
  },
];

describe("lessonTiming", () => {
  it("creates readable estimated phrase cues that exactly cover each scene", () => {
    const cues = buildPhraseCues(scenes[0]!.narration, 4);
    expect(cues.map(cue => cue.text)).toEqual([
      "First, establish the context.",
      "Then name the evidence.",
    ]);
    expect(cues[0]!.start).toBe(0);
    expect(cues.at(-1)!.end).toBe(4);
    expect(cues.every(cue => cue.alignment === "estimated")).toBe(true);
  });

  it("keeps measured audio duration and boundaries identical for server/export callers", () => {
    const shared = buildLessonTiming(scenes, 10);
    const server = buildWhiteboardTimelines(scenes, 10);
    expect(server.map(item => [item.start, item.end, item.duration])).toEqual(
      shared.map(item => [item.start, item.end, item.duration])
    );
    expect(server.at(-1)!.end).toBe(10);
    expect(server.every(item => item.cues.length > 0)).toBe(true);
  });

  it("selects the next scene at an exact boundary and clamps seeks safely", () => {
    const timeline = buildLessonTiming(scenes, 10);
    const boundary = timeline[0]!.end;
    expect(findLessonScene(timeline, boundary).index).toBe(1);
    expect(findLessonScene(timeline, -10).local).toBe(0);
    expect(findLessonScene(timeline, 100).local).toBe(1);
  });

  it("uses the same progressive erase/write reveal at the start and end", () => {
    const cues = buildPhraseCues(scenes[0]!.narration, 4);
    expect(whiteboardRevealAt(cues, 0)).toBe(0);
    expect(whiteboardRevealAt(cues, 0.13)).toBeGreaterThan(0);
    expect(whiteboardRevealAt(cues, 0.85)).toBe(1);
    expect(whiteboardRevealAt(cues, 1)).toBe(1);
    const middle = cueProgressAt(cues, 0.6);
    expect(middle.cueIndex).toBeGreaterThanOrEqual(0);
    expect(middle.cueIndex).toBeLessThan(cues.length);
  });

  it("reveals board actions progressively without claiming word timestamps", () => {
    const actions = [
      { type: "write" as const, text: "Definition" },
      { type: "link" as const, text: "Why it matters" },
      { type: "highlight" as const, target: "Result" },
    ];
    expect(boardActionProgressAt(actions, 0)).toEqual({
      visibleCount: 0,
      activeIndex: 0,
      activeProgress: 0,
    });
    expect(boardActionProgressAt(actions, 0.5)).toEqual({
      visibleCount: 2,
      activeIndex: 1,
      activeProgress: 0.5,
    });
    expect(boardActionProgressAt(actions, 1)).toEqual({
      visibleCount: 3,
      activeIndex: 2,
      activeProgress: 1,
    });
  });
});
