import { createHmac, timingSafeEqual } from "node:crypto";
import type { Express } from "express";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "./_core/trpc";
import { listRecords, getRecord } from "./workspaceStore";
import { storageGetSignedUrl } from "./storage";
import { ENV } from "./_core/env";
import { sniffMediaType } from "../client/src/lib/downloadMedia";
const MAX = 64 * 1024 * 1024;
const secret = () => ENV.cookieSecret;

/** Decode the path portion once, without allowing encoded traversal or query delimiters. */
export function storageKeyFromUrl(url: string): string | null {
  if (!url.startsWith("/manus-storage/")) return null;
  const encoded = url.slice("/manus-storage/".length);
  if (!encoded || /[?#]/.test(encoded)) return null;
  let key: string;
  try {
    key = decodeURIComponent(encoded);
  } catch {
    return null;
  }
  if (
    !key ||
    key.includes("..") ||
    key.includes("\\") ||
    /[?#\x00-\x1f\x7f]/.test(key)
  )
    return null;
  return key;
}
export function signMediaTicket(
  key: string,
  filename: string,
  expires = Date.now() + 5 * 60000
) {
  const payload = Buffer.from(
    JSON.stringify({ key, filename, expires })
  ).toString("base64url");
  return (
    payload +
    "." +
    createHmac("sha256", secret()).update(payload).digest("base64url")
  );
}
export function verifyMediaTicket(ticket: string) {
  const [data, signature, ...extra] = ticket.split(".");
  if (!data || !signature || extra.length) throw Error("Invalid ticket");
  const expected = createHmac("sha256", secret()).update(data).digest();
  const actual = Buffer.from(signature, "base64url");
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected))
    throw Error("Invalid ticket");
  const payload = JSON.parse(Buffer.from(data, "base64url").toString());
  if (
    typeof payload.key !== "string" ||
    payload.key.includes("..") ||
    typeof payload.filename !== "string" ||
    !Number.isFinite(payload.expires) ||
    Date.now() > payload.expires
  )
    throw Error("Expired ticket");
  return payload as { key: string; filename: string; expires: number };
}
export const mediaRouter = router({
  websiteTicket: protectedProcedure
    .input(z.object({ id: z.string().min(1).max(64) }))
    .query(async ({ ctx, input }) => {
      const record = await getRecord(ctx.user.id, "website", input.id);
      if (!record?.payload.html)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Website draft was not found.",
        });
      return {
        url:
          "/api/website-download?ticket=" +
          encodeURIComponent(
            signMediaTicket(
              `website/${ctx.user.id}/${input.id}`,
              "adus-website.html"
            )
          ),
      };
    }),
  ticket: protectedProcedure
    .input(
      z.object({
        url: z.string().min(1).max(2000),
        filename: z.string().min(1).max(180),
      })
    )
    .query(async ({ ctx, input }) => {
      const key = storageKeyFromUrl(input.url);
      if (!key)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Only your stored media can be downloaded here.",
        });
      const kinds = [
        "images",
        "powerpoint",
        "videos",
        "professor-video",
        "study-pdf",
        "study-chapter",
      ];
      let owned = false;
      for (const kind of kinds) {
        const records = await listRecords(ctx.user.id, kind, 10000);
        if (
          records.some(r =>
            [r.payload.url, r.payload.videoURL, r.payload.audioURL].some(
              value => storageKeyFromUrl(String(value ?? "")) === key
            )
          )
        ) {
          owned = true;
          break;
        }
      }
      if (!owned)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "This file was not found in your workspace.",
        });
      const filename =
        input.filename
          .replace(/[\x00-\x1f\x7f\/\\]/g, "-")
          .trim()
          .slice(0, 180) || "download";
      return {
        url:
          "/api/media-download?ticket=" +
          encodeURIComponent(signMediaTicket(key, filename)),
      };
    }),
});
export function registerMediaDownloads(app: Express) {
  app.get("/api/website-download", async (req, res) => {
    try {
      const ticket = verifyMediaTicket(String(req.query.ticket ?? ""));
      const match = /^website\/(\d+)\/([^/]+)$/.exec(ticket.key);
      if (!match) {
        res.status(403).end();
        return;
      }
      const record = await getRecord(Number(match[1]), "website", match[2]);
      if (!record?.payload.html) {
        res.status(404).end();
        return;
      }
      res.set({
        "Content-Type": "application/octet-stream",
        "Content-Disposition": "attachment; filename=adus-website.html",
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
      });
      res.send(record.payload.html);
    } catch {
      res
        .status(403)
        .send("Reopen the website draft to refresh the export link.");
    }
  });

  app.get("/api/media-download", async (req, res) => {
    let ticket: { key: string; filename: string; expires: number };
    try {
      ticket = verifyMediaTicket(String(req.query.ticket ?? ""));
    } catch {
      res
        .status(403)
        .send(
          "This download link expired. Reopen the file to prepare a new link."
        );
      return;
    }
    try {
      const signed = await storageGetSignedUrl(ticket.key);
      const response = await fetch(signed, {
        signal: AbortSignal.timeout(60000),
      });
      if (!response.ok) throw Error("Storage unavailable");
      if (Number(response.headers.get("content-length") ?? 0) > MAX) {
        res.status(413).send("File exceeds the download limit.");
        return;
      }
      const reader = response.body?.getReader();
      if (!reader) throw Error("No bytes");
      let total = 0;
      let started = false;
      const pending: Buffer[] = [];
      let pendingBytes = 0;
      const write = async (chunk: Buffer) => {
        if (!res.write(chunk))
          await new Promise<void>(resolve => res.once("drain", resolve));
      };
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (!value) continue;
        total += value.length;
        if (total > MAX) {
          await reader.cancel();
          throw Error("File exceeds download limit");
        }
        if (!started) {
          // A ReadableStream is allowed to split signatures across chunks. Do
          // not classify a first 1–8 byte fragment as an invalid object.
          pending.push(Buffer.from(value));
          pendingBytes += value.length;
          const prefix = Buffer.concat(pending, Math.min(pendingBytes, 64));
          const kind =
            /\.pptx$/i.test(ticket.filename) &&
            prefix[0] === 0x50 &&
            prefix[1] === 0x4b
              ? {
                  type: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  extension: "pptx",
                }
              : sniffMediaType(prefix);
          if (!kind && pendingBytes < 32) continue;
          if (!kind) {
            await reader.cancel();
            res
              .status(415)
              .send(
                "The stored object is not a supported image, video or PDF."
              );
            return;
          }
          const filename =
            ticket.filename.replace(/\.[^.]+$/, "") + "." + kind.extension;
          res.set({
            "Content-Type": kind.type,
            "Content-Disposition": `attachment; filename="${filename.replace(/[^a-zA-Z0-9._ -]/g, "-")}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff",
          });
          started = true;
          for (const chunk of pending) await write(chunk);
          pending.length = 0;
          pendingBytes = 0;
          continue;
        }
        await write(Buffer.from(value));
      }
      if (!started) {
        res
          .status(415)
          .send("The stored object is not a supported image, video or PDF.");
        return;
      }
      res.end();
    } catch {
      if (!res.headersSent)
        res
          .status(502)
          .send(
            "The file could not be downloaded yet. Retry from its preview."
          );
      else res.destroy();
    }
  });
}
