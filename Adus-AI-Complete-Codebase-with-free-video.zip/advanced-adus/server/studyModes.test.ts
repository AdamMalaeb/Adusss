import { beforeEach, describe, it, expect, vi } from "vitest";
const m = vi.hoisted(() => ({
  get: vi.fn(),
  save: vi.fn(),
  list: vi.fn(),
  unit: vi.fn(),
  bundle: vi.fn(),
  invoke: vi.fn(),
  voice: vi.fn(),
  pdf: vi.fn(),
}));
vi.mock("./workspaceStore", () => ({
  getRecord: m.get,
  saveRecord: m.save,
  listRecords: m.list,
}));
vi.mock("./_core/llm", () => ({
  invokeLLM: m.invoke,
  listLLMModels: async () => ({
    data: [{ id: "gemini-3-flash-preview" }, { id: "gpt-5-mini" }],
  }),
}));
vi.mock("./whiteboardVideo", () => ({
  createWhiteboardLesson: m.voice,
  createWhiteboardVideo: vi.fn(),
}));
vi.mock("./studySources", () => ({
  readUnit: m.unit,
  readSourceBundle: m.bundle,
  prepareSources: vi.fn(),
}));
vi.mock("./summaryPdf", async () => ({
  ...(await vi.importActual("./summaryPdf")),
  storeSummaryPdf: m.pdf,
}));
import { studyRouter } from "./studyRouter";
import {
  summaryDocument,
  renderSummaryPdf,
  closeSummaryPdfBrowser,
} from "./summaryPdf";
const ctx = {
  user: { id: 7, email: "qa@example.com", role: "user" },
  req: { headers: {} },
  res: {},
} as any;
const course = {
  title: "A science lesson",
  language: "arabic",
  mode: "summary",
  sourceKey: "sources/a",
  units: [{ label: "page1", source: "lesson.pdf", page: 1, sourceIndex: 0 }],
  warnings: [],
  generateIllustrations: false,
  version: 2,
};
const lesson = {
  title: "الأمواج",
  summary: "## الطاقة\nتنقل الموجة الطاقة بينما تهتز جزيئات الماء.",
  scenes: [
    {
      title: "الطاقة",
      bullets: ["اهتزاز الماء"],
      narration: "تنقل الموجة الطاقة.",
      visual: { kind: "diagram", labels: ["ماء", "طاقة"], imagePrompt: "" },
    },
  ],
  sources: ["lesson.pdf"],
  warnings: [],
  courseId: "c",
  index: 0,
};
beforeEach(() => {
  vi.clearAllMocks();
  m.get.mockImplementation(async (_u, k, id) =>
    k === "study-course" ? { id, payload: course } : undefined
  );
  m.save.mockImplementation(async (_u, _k, payload, id) => ({ id, payload }));
  m.list.mockResolvedValue([]);
  m.bundle.mockResolvedValue({});
  m.unit.mockResolvedValue([{ type: "text", text: "source" }]);
  m.voice.mockResolvedValue({
    audioURL: "/manus-storage/voice.wav",
    audioDuration: 6,
  });
  m.pdf.mockResolvedValue({ url: "/manus-storage/summary.pdf", hash: "test" });
});
describe("independent study modes", () => {
  it("summarizes without requesting a narration script or speech", async () => {
    m.invoke.mockResolvedValue({
      choices: [
        {
          message: {
            content: JSON.stringify({
              title: "الأمواج",
              summary: "تنقل الطاقة.",
              warnings: [],
            }),
          },
        },
      ],
    });
    const out = await studyRouter
      .createCaller(ctx)
      .analyzeChapter({ id: "c", index: 0 });
    expect(out.scenes).toEqual([]);
    expect(m.voice).not.toHaveBeenCalled();
    expect(m.invoke.mock.calls[0][0].messages[1].content[0].text).toContain(
      "no script or narration needed"
    );
    expect(out.sources).toEqual(["lesson.pdf"]);
  });
  it("prepares Arabic neural voice without encoding a static movie", async () => {
    m.get.mockImplementation(async (_u, k, id) => ({
      id,
      payload: k === "study-course" ? { ...course, mode: "video" } : lesson,
    }));
    const out = await studyRouter
      .createCaller(ctx)
      .prepareChapterVoice({ id: "c", index: 0 });
    expect(out.audioURL).toContain("voice.wav");
    expect(m.voice).toHaveBeenCalledWith(
      7,
      "c:c0",
      expect.objectContaining({ language: "arabic" }),
      expect.anything()
    );
  });
  it("reuses saved voice without repeated paid synthesis", async () => {
    m.get.mockImplementation(async (_u, k, id) => ({
      id,
      payload:
        k === "study-course"
          ? course
          : {
              ...lesson,
              audioURL: "saved.wav",
              voiceVersion: 1,
              audioDuration: 6,
            },
    }));
    const out = await studyRouter
      .createCaller(ctx)
      .prepareChapterVoice({ id: "c", index: 0 });
    expect(out.audioURL).toBe("saved.wav");
    expect(m.voice).not.toHaveBeenCalled();
  });
  it("enforces ownership for PDF export and neural speech", async () => {
    m.get.mockResolvedValue(undefined);
    await expect(
      studyRouter.createCaller(ctx).summaryPdf({ id: "other" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    await expect(
      studyRouter
        .createCaller(ctx)
        .prepareChapterVoice({ id: "other", index: 0 })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
  it("produces PDF download metadata not a text file", async () => {
    m.list.mockResolvedValue([
      { payload: { ...lesson, sourceLabel: "page1" } },
    ]);
    const out = await studyRouter.createCaller(ctx).summaryPdf({ id: "c" });
    expect(out.filename).toMatch(/\.pdf$/);
    expect(m.pdf).toHaveBeenCalled();
  });
  it("renders Arabic RTL PDF with no external requests or source scripts", async () => {
    const html = summaryDocument(
      "درس",
      [
        {
          index: 0,
          title: "الأمواج",
          summary: "## الطاقة\nالطاقة تنتقل. <script>alert(1)</script>",
        },
      ],
      "arabic",
      2
    );
    expect(html).toContain('dir="rtl"');
    expect(html).toContain("partial summary");
    expect(html).not.toContain("<script>");
    const bytes = await renderSummaryPdf(html);
    expect(bytes.subarray(0, 5).toString()).toBe("%PDF-");
    await closeSummaryPdfBrowser();
  }, 30000);
});
