import { createHash, randomBytes } from "node:crypto";
import type { Express, Request, Response } from "express";
import { parse as parseCookieHeader } from "cookie";
import { and, eq } from "drizzle-orm";
import { createRemoteJWKSet, jwtVerify, SignJWT } from "jose";
import { COOKIE_NAME } from "@shared/const";
import { workspaceRecords, users } from "../drizzle/schema";
import * as db from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk, type AuthenticatedUser } from "./_core/sdk";

export const GOOGLE_STATE_COOKIE = "__Host-google_oauth_state";
export const GOOGLE_SESSION_MS = 7 * 24 * 60 * 60 * 1000;
const GOOGLE_STATE_MS = 10 * 60 * 1000;
const GOOGLE_IDENTITY_KIND = "googleIdentity";
const GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
const GOOGLE_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
const GOOGLE_JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/oauth2/v3/certs")
);
const GOOGLE_ISSUERS = ["https://accounts.google.com", "accounts.google.com"];

type GoogleMode = "login" | "link";

type GoogleConfig = {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  jwtSecret: string;
};

type GoogleState = {
  state: string;
  nonce: string;
  codeVerifier: string;
  returnTo: string;
  mode: GoogleMode;
  linkOpenId?: string;
};

export type GoogleIdClaims = {
  sub: string;
  email: string;
  email_verified: boolean;
  name?: string;
  nonce?: string;
  iss?: string;
  aud?: string | string[];
  exp?: number;
};

type GoogleTokenResponse = {
  id_token?: string;
};

export type GoogleAuthDependencies = {
  /** Injectable in tests; production uses Google's token endpoint. */
  exchangeCode?: (
    code: string,
    codeVerifier: string,
    config: GoogleConfig
  ) => Promise<GoogleTokenResponse>;
  /** Injectable in tests; production verifies with Google's remote JWKS. */
  verifyIdToken?: (
    idToken: string,
    expectedNonce: string,
    clientId: string
  ) => Promise<GoogleIdClaims>;
};

const randomToken = (bytes = 32) => randomBytes(bytes).toString("base64url");

function queryString(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

function isValidGoogleRedirectUri(value: string): boolean {
  try {
    const url = new URL(value);
    return (
      url.protocol === "https:" &&
      !url.username &&
      !url.password &&
      !url.search &&
      !url.hash &&
      url.pathname === "/api/google/callback"
    );
  } catch {
    return false;
  }
}

function readGoogleConfig(): GoogleConfig | null {
  const clientId = process.env.GOOGLE_CLIENT_ID?.trim() ?? "";
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET?.trim() ?? "";
  const redirectUri = process.env.GOOGLE_REDIRECT_URI?.trim() ?? "";
  const jwtSecret = process.env.JWT_SECRET?.trim() ?? "";

  if (
    !clientId ||
    !clientSecret ||
    !jwtSecret ||
    !isValidGoogleRedirectUri(redirectUri)
  ) {
    return null;
  }

  return { clientId, clientSecret, redirectUri, jwtSecret };
}

export function isGoogleConfigured(): boolean {
  return readGoogleConfig() !== null;
}

/** Only preserve an in-app path. Absolute and protocol-relative URLs are rejected. */
export function safeGoogleReturnTo(value: unknown): string {
  if (typeof value !== "string" || value.length === 0 || value.length > 2048) {
    return "/";
  }
  if (!value.startsWith("/") || value.startsWith("//")) return "/";

  try {
    const parsed = new URL(value, "https://adus.invalid");
    if (parsed.origin !== "https://adus.invalid") return "/";
    if (parsed.pathname === "/sign-in") return "/";
    return `${parsed.pathname}${parsed.search}${parsed.hash}` || "/";
  } catch {
    return "/";
  }
}

function redirectWithError(res: Response, returnTo: unknown, error: string) {
  const destination = new URL("/sign-in", "https://adus.invalid");
  destination.searchParams.set("returnTo", safeGoogleReturnTo(returnTo));
  destination.searchParams.set("googleError", error);
  res.redirect(
    302,
    `${destination.pathname}${destination.search}${destination.hash}`
  );
}

function stateCookieOptions(maxAge = GOOGLE_STATE_MS) {
  return {
    httpOnly: true,
    secure: true,
    sameSite: "lax" as const,
    path: "/",
    maxAge,
  };
}

function clearStateCookie(res: Response) {
  res.clearCookie(GOOGLE_STATE_COOKIE, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  });
}

async function signGoogleState(state: GoogleState, secret: string) {
  return new SignJWT(state as Record<string, unknown>)
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setExpirationTime(Math.floor((Date.now() + GOOGLE_STATE_MS) / 1000))
    .sign(new TextEncoder().encode(secret));
}

async function readSignedGoogleState(
  token: string | undefined,
  secret: string
): Promise<GoogleState | null> {
  if (!token || token.length > 4096) return null;
  try {
    const result = await jwtVerify(token, new TextEncoder().encode(secret), {
      algorithms: ["HS256"],
    });
    const payload = result.payload as Partial<GoogleState>;
    if (
      typeof payload.state !== "string" ||
      typeof payload.nonce !== "string" ||
      typeof payload.codeVerifier !== "string" ||
      typeof payload.returnTo !== "string" ||
      (payload.mode !== "login" && payload.mode !== "link")
    ) {
      return null;
    }
    if (payload.mode === "link" && typeof payload.linkOpenId !== "string") {
      return null;
    }
    return payload as GoogleState;
  } catch {
    return null;
  }
}

async function exchangeGoogleCodeDefault(
  code: string,
  codeVerifier: string,
  config: GoogleConfig
): Promise<GoogleTokenResponse> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10_000);
  try {
    const response = await fetch(GOOGLE_TOKEN_ENDPOINT, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: config.clientId,
        client_secret: config.clientSecret,
        redirect_uri: config.redirectUri,
        grant_type: "authorization_code",
        code_verifier: codeVerifier,
      }),
      signal: controller.signal,
    });
    const body = await response.text();
    if (body.length > 128 * 1024 || !response.ok) {
      throw new Error("Google token exchange failed");
    }
    const parsed = JSON.parse(body) as GoogleTokenResponse;
    return parsed;
  } finally {
    clearTimeout(timeout);
  }
}

async function verifyGoogleIdTokenDefault(
  idToken: string,
  expectedNonce: string,
  clientId: string
): Promise<GoogleIdClaims> {
  const { payload } = await jwtVerify(idToken, GOOGLE_JWKS, {
    algorithms: ["RS256"],
    audience: clientId,
    issuer: GOOGLE_ISSUERS,
  });
  if (payload.nonce !== expectedNonce) {
    throw new Error("Google ID token nonce mismatch");
  }
  return payload as unknown as GoogleIdClaims;
}

function normalizeEmail(value: string): string {
  return value.trim().toLowerCase();
}

function validateClaims(claims: GoogleIdClaims, expectedNonce: string) {
  if (
    typeof claims.sub !== "string" ||
    claims.sub.length < 1 ||
    claims.sub.length > 57 ||
    !/^[\x21-\x7e]+$/.test(claims.sub)
  ) {
    throw new Error("Invalid Google subject");
  }
  if (claims.email_verified !== true) {
    throw new Error("Google email is not verified");
  }
  if (typeof claims.email !== "string" || claims.email.length > 320) {
    throw new Error("Invalid Google email");
  }
  const email = normalizeEmail(claims.email);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("Invalid Google email");
  }
  if (claims.nonce !== expectedNonce) {
    throw new Error("Google ID token nonce mismatch");
  }
  return { sub: claims.sub, email };
}

function googleOpenId(sub: string): string {
  // users.openId is varchar(64); reject rather than truncate a provider identity.
  const openId = `google:${sub}`;
  if (openId.length > 64) throw new Error("Google subject is too long");
  return openId;
}

function googleIdentityRecordId(sub: string): string {
  // The subject is already bounded by validateClaims, making this deterministic
  // and collision-free without storing a second copy of credentials.
  return `google:${sub}`;
}

async function findGoogleIdentity(sub: string) {
  const connection = await db.getDb();
  if (!connection) return undefined;
  const rows = await connection
    .select()
    .from(workspaceRecords)
    .where(
      and(
        eq(workspaceRecords.id, googleIdentityRecordId(sub)),
        eq(workspaceRecords.kind, GOOGLE_IDENTITY_KIND)
      )
    )
    .limit(1);
  const row = rows[0];
  if (!row) return undefined;
  try {
    const payload = JSON.parse(row.payload) as { googleSub?: unknown };
    return payload.googleSub === sub ? row : undefined;
  } catch {
    return undefined;
  }
}

async function getUserById(id: number) {
  const connection = await db.getDb();
  if (!connection) return undefined;
  const rows = await connection
    .select()
    .from(users)
    .where(eq(users.id, id))
    .limit(1);
  return rows[0];
}

async function saveGoogleIdentity(sub: string, userId: number, email: string) {
  const existing = await findGoogleIdentity(sub);
  if (existing) {
    if (existing.userId !== userId) {
      throw new Error("Google identity is already linked");
    }
    return;
  }

  const connection = await db.getDb();
  if (!connection) throw new Error("Database unavailable");
  const payload = JSON.stringify({ googleSub: sub, email });
  try {
    // Intentionally insert-only: an existing deterministic key is never overwritten.
    await connection.insert(workspaceRecords).values({
      id: googleIdentityRecordId(sub),
      userId,
      kind: GOOGLE_IDENTITY_KIND,
      payload,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  } catch {
    const afterRace = await findGoogleIdentity(sub);
    if (!afterRace || afterRace.userId !== userId) {
      throw new Error("Google identity is already linked");
    }
  }
}

async function authenticateForLink(req: Request): Promise<AuthenticatedUser> {
  return sdk.authenticateRequest(req);
}

async function completeGoogleLogin(
  req: Request,
  claims: GoogleIdClaims,
  state: GoogleState
) {
  const { sub, email } = validateClaims(claims, state.nonce);
  const providerOpenId = googleOpenId(sub);
  let user;

  if (state.mode === "link") {
    const currentUser = await authenticateForLink(req);
    if (currentUser.openId !== state.linkOpenId) {
      throw new Error("Authenticated account changed during linking");
    }
    const currentEmail = currentUser.email
      ? normalizeEmail(currentUser.email)
      : "";
    if (!currentEmail || currentEmail !== email) {
      throw new Error("Google email does not match the authenticated account");
    }

    const existingIdentity = await findGoogleIdentity(sub);
    const existingProviderUser = await db.getUserByOpenId(providerOpenId);
    if (existingIdentity && existingIdentity.userId !== currentUser.id) {
      throw new Error("Google identity is already linked");
    }
    if (existingProviderUser && existingProviderUser.id !== currentUser.id) {
      throw new Error("Google identity belongs to another account");
    }

    await saveGoogleIdentity(sub, currentUser.id, email);
    user = await db.getUserByOpenId(currentUser.openId);
  } else {
    // First honor an explicitly-created identity mapping. Email is never queried
    // here, so a same-email Manus account cannot be silently claimed.
    const identity = await findGoogleIdentity(sub);
    if (identity) {
      user = await getUserById(identity.userId);
      if (!user) throw new Error("Google identity owner not found");
    } else {
      user = await db.getUserByOpenId(providerOpenId);
      if (!user) {
        await db.upsertUser({
          openId: providerOpenId,
          name:
            typeof claims.name === "string" ? claims.name.slice(0, 240) : email,
          email,
          loginMethod: "google",
          lastSignedIn: new Date(),
        });
        user = await db.getUserByOpenId(providerOpenId);
      }
    }
  }

  if (!user) throw new Error("Google user could not be created");
  await db.upsertUser({ openId: user.openId, email, lastSignedIn: new Date() });
  return user;
}

async function setGoogleSession(
  req: Request,
  res: Response,
  user: { openId: string; name: string | null }
) {
  const sessionToken = await sdk.createSessionToken(user.openId, {
    name: user.name?.trim() || "Google user",
    expiresInMs: GOOGLE_SESSION_MS,
  });
  res.cookie(COOKIE_NAME, sessionToken, {
    ...getSessionCookieOptions(req),
    maxAge: GOOGLE_SESSION_MS,
  });
}

export function registerGoogleAuthRoutes(
  app: Express,
  dependencies: GoogleAuthDependencies = {}
) {
  const exchangeCode = dependencies.exchangeCode ?? exchangeGoogleCodeDefault;
  const verifyIdToken =
    dependencies.verifyIdToken ?? verifyGoogleIdTokenDefault;

  app.get("/api/google/status", (_req: Request, res: Response) => {
    res.json({ configured: isGoogleConfigured() });
  });

  app.get("/api/google/start", async (req: Request, res: Response) => {
    const config = readGoogleConfig();
    if (!config) {
      res.status(503).json({ error: "google_not_configured" });
      return;
    }

    const mode: GoogleMode =
      queryString(req, "mode") === "link" ? "link" : "login";
    let linkOpenId: string | undefined;
    if (mode === "link") {
      try {
        const currentUser = await authenticateForLink(req);
        linkOpenId = currentUser.openId;
      } catch {
        res.status(401).json({ error: "authentication_required" });
        return;
      }
    }

    const state = randomToken();
    const nonce = randomToken();
    const codeVerifier = randomToken(48);
    const challenge = createHash("sha256")
      .update(codeVerifier)
      .digest("base64url");
    const signedState = await signGoogleState(
      {
        state,
        nonce,
        codeVerifier,
        returnTo: safeGoogleReturnTo(queryString(req, "returnTo")),
        mode,
        ...(linkOpenId ? { linkOpenId } : {}),
      },
      config.jwtSecret
    );

    res.cookie(GOOGLE_STATE_COOKIE, signedState, stateCookieOptions());
    const authorizationUrl = new URL(GOOGLE_AUTH_ENDPOINT);
    authorizationUrl.search = new URLSearchParams({
      client_id: config.clientId,
      redirect_uri: config.redirectUri,
      response_type: "code",
      scope: "openid email profile",
      state,
      nonce,
      code_challenge: challenge,
      code_challenge_method: "S256",
    }).toString();
    res.redirect(302, authorizationUrl.toString());
  });

  app.get("/api/google/callback", async (req: Request, res: Response) => {
    const config = readGoogleConfig();
    if (!config) {
      res.status(503).json({ error: "google_not_configured" });
      return;
    }

    const state = queryString(req, "state");
    const cookieToken = parseCookieHeader(req.headers.cookie ?? "")[
      GOOGLE_STATE_COOKIE
    ];
    const savedState = await readSignedGoogleState(
      cookieToken,
      config.jwtSecret
    );
    if (
      !state ||
      state.length > 512 ||
      !savedState ||
      savedState.state !== state
    ) {
      clearStateCookie(res);
      res.redirect(302, "/sign-in?googleError=invalid_state");
      return;
    }

    // Clear before exchanging the code: this state is single-use from the browser's
    // perspective, and a failed exchange cannot leave a reusable OAuth transaction.
    clearStateCookie(res);
    const returnTo = savedState.returnTo;
    const code = queryString(req, "code");
    if (queryString(req, "error")) {
      redirectWithError(res, returnTo, "access_denied");
      return;
    }
    if (!code || code.length > 4096) {
      redirectWithError(res, returnTo, "callback_failed");
      return;
    }

    try {
      const tokenResponse = await exchangeCode(
        code,
        savedState.codeVerifier,
        config
      );
      if (!tokenResponse.id_token || tokenResponse.id_token.length > 32_000) {
        throw new Error("Google ID token missing");
      }
      const claims = await verifyIdToken(
        tokenResponse.id_token,
        savedState.nonce,
        config.clientId
      );
      const user = await completeGoogleLogin(req, claims, savedState);
      await setGoogleSession(req, res, user);
      res.redirect(302, safeGoogleReturnTo(returnTo));
    } catch {
      // Deliberately do not include provider responses, tokens, or exception text.
      redirectWithError(res, returnTo, "callback_failed");
    }
  });
}

export const __googleAuthInternals = {
  readGoogleConfig,
  validateClaims,
  googleOpenId,
  googleIdentityRecordId,
  completeGoogleLogin,
};
