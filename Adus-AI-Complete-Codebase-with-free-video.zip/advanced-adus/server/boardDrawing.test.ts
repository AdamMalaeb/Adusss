import { describe, it, expect } from "vitest";
import { boardActionOpacity, boardDrawingPath } from "../shared/boardDrawing";
import { parseStudyAnswer } from "./studyRouter";
import type { LessonBoardAction } from "../shared/lessonTiming";

describe("professor board geometry and erasing", () => {
  it("draws waves and orbital circles instead of using one straight line for all topics", () => {
    const wave = boardDrawingPath({
      type: "draw",
      shape: "wave",
      from: { x: 0.1, y: 0.2 },
      to: { x: 0.8, y: 0.6 },
    });
    const circle = boardDrawingPath({
      type: "draw",
      shape: "circle",
      from: { x: 0.2, y: 0.2 },
      to: { x: 0.5, y: 0.7 },
    });
    expect(wave).toContain(" Q ");
    expect(circle).toContain(" A ");
    expect(wave).not.toContain("NaN");
  });
  it("fades the named previous mark during erase and keeps new writing", () => {
    const actions: LessonBoardAction[] = [
      { type: "write", text: "wrong formula" },
      { type: "erase", target: "wrong formula" },
      { type: "write", text: "correct formula" },
    ];
    expect(boardActionOpacity(actions, 0, 0)).toBe(1);
    expect(boardActionOpacity(actions, 0, 0.5)).toBe(0.5);
    expect(boardActionOpacity(actions, 0, 1)).toBe(0);
    expect(boardActionOpacity(actions, 2, 1)).toBe(1);
  });
  it("preserves a usable model lesson that uses percentage positions", () => {
    const p = parseStudyAnswer(
      JSON.stringify({
        title: "Waves",
        summary: "A clear explanation",
        sources: [],
        warnings: [],
        scenes: [
          {
            title: "Oscillation",
            bullets: ["Energy is transferred"],
            narration: "Water oscillates while energy travels.",
            boardActions: [
              {
                type: "draw",
                shape: "wave",
                from: { x: 10, y: 20 },
                to: { x: 90, y: 60 },
              },
            ],
          },
        ],
      })
    );
    expect(p.scenes[0].boardActions[0]).toMatchObject({
      shape: "wave",
      from: { x: 0.1, y: 0.2 },
      to: { x: 0.9, y: 0.6 },
    });
  });
  it("rejects invalid arbitrary coordinates instead of silently drawing incorrect geometry", () => {
    expect(() =>
      parseStudyAnswer(
        JSON.stringify({
          title: "Waves",
          summary: "Explanation",
          scenes: [
            {
              title: "Invalid",
              bullets: ["Energy"],
              narration: "Energy",
              boardActions: [{ type: "draw", from: { x: 999, y: 20 } }],
            },
          ],
        })
      )
    ).toThrow("another attempt");
  });
});
