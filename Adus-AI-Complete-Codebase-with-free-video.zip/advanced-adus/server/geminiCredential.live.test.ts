import {describe,it,expect} from 'vitest';
describe.skipIf(process.env.ADUS_VALIDATE_GEMINI!=='1')('Gemini project credential',()=>{
 it('authenticates the supplied project key at the model catalog',async()=>{
  const key=process.env.GEMINI_API_KEY;expect(key).toBeTruthy();
  const response=await fetch('https://generativelanguage.googleapis.com/v1beta/models',{headers:{'x-goog-api-key':key!},signal:AbortSignal.timeout(20000)});
  expect(response.status,'Gemini project credential must authenticate').toBe(200);
  const body=await response.json();expect(Array.isArray(body.models)).toBe(true);
 },30000);
});
