import { z } from "zod";
export const cameraFrameSchema = z
  .object({
    name: z.literal("Live camera frame").default("Live camera frame"),
    mimeType: z.literal("image/jpeg"),
    dataUrl: z
      .string()
      .max(1_400_000)
      .regex(/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/),
  })
  .superRefine((frame, ctx) => {
    const bytes = Buffer.from(frame.dataUrl.split(",")[1] ?? "", "base64");
    if (
      bytes.length > 1024 * 1024 ||
      bytes.length < 4 ||
      bytes[0] !== 0xff ||
      bytes[1] !== 0xd8 ||
      bytes[2] !== 0xff
    )
      ctx.addIssue({
        code: "custom",
        message: "The camera frame must be a valid JPEG under 1 MB.",
      });
  });
