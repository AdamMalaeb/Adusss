import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  assertPublicUrl: vi.fn(async (value: string) => new URL(value).toString()),
  fetchPublicText: vi.fn(),
}));

vi.mock("./communicationsEmail", () => mocks);

import { collectChatResearch, shouldResearchChat } from "./chatResearch";
import {
  groundChatCitations,
  stripProviderCitationTokens,
} from "../shared/chatCitations";

const ddgUrl = "https://html.duckduckgo.com/html/";
const bingUrl = "https://www.bing.com/search?format=rss&q=";

function ddgResult(url: string, title = "DDG result") {
  return `<a class="result__a" href="${url}">${title}</a>`;
}

function rssResult(url: string, title = "RSS result") {
  return `<rss><channel><item><title><![CDATA[${title}]]></title><link>${url}</link><description>Snippet only</description></item></channel></rss>`;
}

function page(url: string, body: string) {
  return { url, body };
}

beforeEach(() => {
  mocks.assertPublicUrl.mockReset();
  mocks.assertPublicUrl.mockImplementation(async (value: string) =>
    new URL(value).toString()
  );
  mocks.fetchPublicText.mockReset();
});

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

describe("shouldResearchChat", () => {
  it("recognizes explicit, current, directory, French, and Arabic public research intents", () => {
    expect(shouldResearchChat("Tell me colleges in Lebanon")).toBe(true);
    expect(shouldResearchChat("Search for the latest news about Lebanon")).toBe(
      true
    );
    expect(
      shouldResearchChat("Bonjour, recherche les universités au Liban")
    ).toBe(true);
    expect(shouldResearchChat("ابحث عن أحدث الأخبار في لبنان")).toBe(true);
  });

  it("avoids greetings, math/explanations, and private file or history requests", () => {
    expect(shouldResearchChat("Hello there")).toBe(false);
    expect(shouldResearchChat("What is 2 + 2?")).toBe(false);
    expect(shouldResearchChat("Explain how photosynthesis works")).toBe(false);
    expect(shouldResearchChat("Summarize my attached file", true)).toBe(false);
    expect(shouldResearchChat("Please review my chat history")).toBe(false);
  });

  it("routes current offices, leaders, prices, tuition, 2026 rules, and public URLs", () => {
    expect(
      shouldResearchChat("What are the office hours for this public agency?")
    ).toBe(true);
    expect(shouldResearchChat("Who is the current leader of Lebanon?")).toBe(
      true
    );
    expect(
      shouldResearchChat("What are the current prices for this service?")
    ).toBe(true);
    expect(
      shouldResearchChat("What is the 2026 tuition at this university?")
    ).toBe(true);
    expect(shouldResearchChat("What are the 2026 visa rules for France?")).toBe(
      true
    );
    expect(
      shouldResearchChat("Please read https://example.com/public-guide")
    ).toBe(true);
    expect(shouldResearchChat("What is photosynthesis?")).toBe(false);
    expect(
      shouldResearchChat(
        "Bonjour, quelle est la définition de la photosynthèse ?"
      )
    ).toBe(false);
    expect(shouldResearchChat("مرحبا، ما هو التمثيل الضوئي؟")).toBe(false);
  });

  it("keeps stable conservation-law teaching questions out of live research", () => {
    expect(
      shouldResearchChat("Explain the current conservation law in physics")
    ).toBe(false);
    expect(
      shouldResearchChat("Research the current conservation law in physics")
    ).toBe(true);
    expect(shouldResearchChat("Who is the current leader of Lebanon?")).toBe(
      true
    );
  });
});

describe("collectChatResearch", () => {
  it("falls back from a DDG challenge to Bing RSS and reads only the original source", async () => {
    const sourceUrl = "https://example.com/lebanon-colleges";
    mocks.fetchPublicText.mockImplementation(async (url: string) => {
      if (url.startsWith(ddgUrl))
        throw new Error("Source page returned HTTP 202");
      if (url.startsWith(bingUrl))
        return page(url, rssResult(sourceUrl, "Lebanon Colleges"));
      if (url === sourceUrl)
        return page(
          sourceUrl,
          "<html><head><title>Source title</title><style>hidden css</style></head><body><nav>menu hidden</nav><main>Verified public information about colleges in Lebanon.</main><script>alert('ignore')</script></body></html>"
        );
      throw new Error(`unexpected URL ${url}`);
    });

    const result = await collectChatResearch("Tell me colleges in Lebanon");

    expect(result.status).toBe("verified");
    expect(result.sources).toEqual([
      {
        title: "Lebanon Colleges",
        url: sourceUrl,
        excerpt: "Verified public information about colleges in Lebanon.",
      },
    ]);
    expect(result.context).toContain("Only these original public pages");
    expect(result.context).toContain(sourceUrl);
    expect(result.context).toContain("Verified public information");
    expect(result.context).toContain("untrusted evidence");
    expect(result.context).not.toContain("Snippet only");
    expect(mocks.fetchPublicText.mock.calls.map(call => call[0])).toEqual([
      expect.stringContaining("html.duckduckgo.com/html/"),
      expect.stringContaining("www.bing.com/search?format=rss&q="),
      sourceUrl,
    ]);
  });

  it("returns unavailable when search providers are challenged or every source read fails", async () => {
    mocks.fetchPublicText.mockImplementation(async (url: string) => {
      if (url.startsWith(ddgUrl))
        return page(url, "<html><body>captcha challenge</body></html>");
      if (url.startsWith(bingUrl))
        return page(
          url,
          "<rss><channel><title>bot detection</title></channel></rss>"
        );
      throw new Error(`unexpected URL ${url}`);
    });

    const result = await collectChatResearch("latest public news in Iceland");

    expect(result).toMatchObject({ status: "unavailable", sources: [] });
    expect(result.context).toContain("live web verification was unavailable");
  });

  it("does not follow search-internal, malformed, or rejected private-network result URLs", async () => {
    const sourceUrl = "https://example.com/verified";
    const privateUrl = "https://127.0.0.1/private";
    mocks.assertPublicUrl.mockImplementation(async (value: string) => {
      const parsed = new URL(value);
      if (parsed.hostname === "127.0.0.1") throw new Error("private network");
      return parsed.toString();
    });
    mocks.fetchPublicText.mockImplementation(async (url: string) => {
      if (url.startsWith(ddgUrl)) {
        return page(
          url,
          [
            ddgResult("https://duckduckgo.com/?q=internal", "internal search"),
            ddgResult("javascript:alert(1)", "bad scheme"),
            ddgResult(privateUrl, "private network"),
            ddgResult(sourceUrl, "Good source"),
          ].join("\n")
        );
      }
      if (url === sourceUrl)
        return page(
          sourceUrl,
          "<main>Original verified source text about Iceland.</main>"
        );
      throw new Error(`unexpected URL ${url}`);
    });

    const result = await collectChatResearch(
      "search public facts about Iceland"
    );

    expect(result.status).toBe("verified");
    expect(result.sources.map(source => source.url)).toEqual([sourceUrl]);
    const followed = mocks.fetchPublicText.mock.calls.map(call =>
      String(call[0])
    );
    expect(followed).not.toContain("https://duckduckgo.com/?q=internal");
    expect(followed).not.toContain("javascript:alert(1)");
    expect(followed).not.toContain(privateUrl);
    expect(followed).toContain(sourceUrl);
  });

  it("does not cite an unrelated page just because the search engine returned it", async () => {
    mocks.fetchPublicText.mockImplementation(async (url: string) => {
      if (url.startsWith(ddgUrl))
        return page(
          url,
          ddgResult("https://example.com/unrelated", "Browser support")
        );
      return page(
        url,
        "<main>Google Chrome update instructions and download help.</main>"
      );
    });
    const result = await collectChatResearch(
      "latest president Lebanon official website pineappleqq"
    );
    expect(result.status).toBe("unavailable");
    expect(result.sources).toEqual([]);
  });

  it("requires more than one shared term before citing a multi-concept result", async () => {
    mocks.fetchPublicText.mockImplementation(async (url: string) => {
      if (url.startsWith(ddgUrl))
        return page(
          url,
          ddgResult("https://example.com/only-lebanon", "Generic page")
        );
      return page(url, "A general page that mentions Lebanon but not the requested term.");
    });
    const result = await collectChatResearch(
      "latest president Lebanon pineappleqq"
    );
    expect(result.status).toBe("unavailable");
    expect(result.sources).toEqual([]);
  });

  it("has a bounded completion when a mocked public fetch never resolves", async () => {
    vi.useFakeTimers();
    mocks.fetchPublicText.mockImplementation(
      () => new Promise(() => undefined)
    );

    const pending = collectChatResearch(
      "latest public facts about bounded-time-test"
    );
    await vi.advanceTimersByTimeAsync(10_100);
    const result = await pending;

    expect(result).toMatchObject({ status: "unavailable", sources: [] });
  });

  it("reads a direct public URL through the safe fetch helper without querying search providers", async () => {
    const sourceUrl = "https://example.com/direct-public-guide";
    mocks.fetchPublicText.mockImplementation(async (url: string) => {
      if (url === sourceUrl)
        return page(sourceUrl, "<main>Direct public guide excerpt.</main>");
      throw new Error(`unexpected URL ${url}`);
    });

    const result = await collectChatResearch(`Read ${sourceUrl}`);

    expect(result).toMatchObject({
      status: "verified",
      retrievalStatus: "retrieved",
      engine: "direct-url",
      sources: [{ url: sourceUrl, excerpt: "Direct public guide excerpt." }],
    });
    expect(result.retrievedAt).toMatch(/^\d{4}-\d{2}-\d{2}T/);
    expect(mocks.fetchPublicText.mock.calls.map(call => call[0])).toEqual([
      sourceUrl,
    ]);
    expect(result.context).toContain(
      "not proof that every claim is true or current"
    );
  });
});

describe("citation cleanup", () => {
  it("removes provider controls and maps only valid retrieved numbered sources", () => {
    const providerToken = "\uE200cite\uE202turn0search1\uE201";
    const escapedToken = "\\uE200cite\\uE202turn0search2\\uE201";
    const text = `Keep ∑ x² = √4. ${providerToken} ${escapedToken} [1] [2] [99]`;
    const grounded = groundChatCitations(text, [
      "https://example.com/one#section",
      "https://example.org/two",
    ]);

    expect(grounded).toContain("Keep ∑ x² = √4.");
    expect(grounded).toContain("[1](https://example.com/one)");
    expect(grounded).toContain("[2](https://example.org/two)");
    expect(grounded).not.toContain("turn0search");
    expect(grounded).not.toContain("[99]");
    expect(
      stripProviderCitationTokens(
        "Old \\uE200cite\\uE202turn0search1\\uE201 text"
      )
    ).toBe("Old text");
  });

  it("does not double-wrap existing links or rewrite code and indexed math", () => {
    const result = groundChatCitations(
      "[1](https://example.com/one) `x[1]` A[1] + [1]",
      ["https://example.com/one"]
    );
    expect(result).toBe(
      "[1](https://example.com/one) `x[1]` A[1] + [1](https://example.com/one)"
    );
  });
});
