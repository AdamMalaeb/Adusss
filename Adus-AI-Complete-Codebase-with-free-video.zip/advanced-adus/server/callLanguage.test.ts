import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
const m = vi.hoisted(() => ({ llm: vi.fn(), transcribe: vi.fn() }));
vi.mock("./_core/llm", async importOriginal => ({
  ...(await importOriginal<typeof import("./_core/llm")>()),
  invokeLLM: m.llm,
  listLLMModels: vi.fn(),
}));
vi.mock("./_core/voiceTranscription", () => ({
  transcribeAudio: m.transcribe,
}));
vi.mock("./workspaceStore", () => ({
  getRecord: vi.fn(async () => undefined),
  listRecords: vi.fn(async () => []),
  saveRecord: vi.fn(),
}));
import { appRouter } from "./routers";
const caller = () =>
  appRouter.createCaller({
    user: { id: 1, email: "qa@example.com" },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
beforeEach(() => {
  vi.clearAllMocks();
  m.transcribe.mockResolvedValue({ text: "Bonjour", language: "french" });
  m.llm.mockResolvedValue({
    choices: [
      { message: { content: "Certainement. Voici une explication claire." } },
    ],
  });
});
describe("Multilingual professional calls", () => {
  it("auto-transcribes the original language without forcing English", async () => {
    const r = await caller().adus.transcribeVoice({
      dataUrl: "data:audio/wav;base64,YWJj",
      mimeType: "audio/wav",
    });
    expect(r).toMatchObject({ text: "Bonjour", language: "french" });
    expect(m.transcribe.mock.calls[0][0].language).toBeUndefined();
    expect(m.transcribe.mock.calls[0][0].prompt).toContain("Do not translate");
  });
  it.each(["en", "fr", "ar", "es", "ja", "de"] as const)(
    "respects selected transcription language %s",
    async language => {
      await caller().adus.transcribeVoice({
        dataUrl: "data:audio/wav;base64,YWJj",
        mimeType: "audio/wav",
        language,
      });
      expect(m.transcribe.mock.calls[0][0].language).toBe(language);
    }
  );
  it.each(["english", "french", "arabic", "es-MX", "ja"] as const)(
    "requests courteous plain spoken answers in %s",
    async callLanguage => {
      await caller().adus.chat({
        message: "Explain this clearly",
        voiceMode: true,
        callLanguage,
      });
      const messages = m.llm.mock.calls[0][0].messages;
      const final = messages.at(-2);
      expect(final.role).toBe("system");
      expect(final.content).toContain(
        (
          {
            english: "English",
            french: "French",
            arabic: "Modern Standard Arabic",
            "es-MX": "Spanish",
            ja: "Japanese",
          } as const
        )[callLanguage]
      );
      expect(final.content).toContain("no Markdown");
      expect(final.content).toContain("justify it clearly");
      expect(messages[0].content).toContain("college professor");
    }
  );
});
