import { Buffer } from "node:buffer";
/** Veo is the supported long-running video endpoint; Omni remains edit-only. */
export const GEMINI_OMNI_MODEL = "gemini-omni-1.1-flash" as const;
export const GEMINI_VEO_FAST_MODEL = "veo-3.1-fast-generate-preview" as const;
export const GEMINI_VIDEO_MODEL = GEMINI_VEO_FAST_MODEL;
const GEMINI_VEO_MODELS = new Set([
  "veo-3.1-fast-generate-preview",
  "veo-3.1-generate-preview",
  "veo-3.1-lite-generate-preview",
]);
export const GEMINI_API_ORIGIN =
  "https://generativelanguage.googleapis.com" as const;
const API_ROOT = `${GEMINI_API_ORIGIN}/v1beta`;
const UPLOAD_ROOT = `${GEMINI_API_ORIGIN}/upload/v1beta`;
export const MAX_VIDEO_OUTPUT_BYTES = 64 * 1024 * 1024;
export const PROVIDER_DEADLINE_MS = 145_000;
const FILE_POLL_MS = 5_000;

type ProviderCode =
  | "TOO_MANY_REQUESTS"
  | "BAD_REQUEST"
  | "PRECONDITION_FAILED"
  | "SERVICE_UNAVAILABLE"
  | "INTERNAL_SERVER_ERROR";

export type ProviderErrorReason = "quota" | "rate_limit";
export type ProviderErrorStatus = "quota_exhausted" | "retryable_rate_limit";

export class VideoProviderError extends Error {
  constructor(
    message: string,
    public readonly code: ProviderCode = "SERVICE_UNAVAILABLE",
    public readonly reason?: ProviderErrorReason,
    public readonly status?: ProviderErrorStatus
  ) {
    super(message);
    this.name = "VideoProviderError";
  }
}

export type GeminiFile = {
  name: string;
  uri: string;
  mimeType: string;
};

export type VideoInteraction = {
  id: string;
  status: string;
  outputUri?: string;
  video?: Buffer;
  provider?: "veo" | "omni";
  error?: string;
};

type JsonRecord = Record<string, any>;

function apiKey(): string {
  const key = process.env.GEMINI_API_KEY?.trim();
  if (!key) {
    throw new VideoProviderError(
      "Gemini video generation is not configured. Add GEMINI_API_KEY to the server environment.",
      "PRECONDITION_FAILED"
    );
  }
  return key;
}

export function isGeminiConfigured(): boolean {
  return Boolean(process.env.GEMINI_API_KEY?.trim());
}

export function configuredVeoModel(): string {
  const configured = process.env.GEMINI_VEO_MODEL?.trim();
  return configured && GEMINI_VEO_MODELS.has(configured)
    ? configured
    : "veo-3.1-generate-preview";
}

function providerCode(status: number): ProviderCode {
  if (status === 429) return "TOO_MANY_REQUESTS";
  if (status === 400 || status === 404) return "BAD_REQUEST";
  if (status === 401 || status === 403) return "PRECONDITION_FAILED";
  if (status >= 500 || status === 408) return "SERVICE_UNAVAILABLE";
  return "INTERNAL_SERVER_ERROR";
}

async function readJson(response: Response): Promise<JsonRecord> {
  const text = await response.text().catch(() => "");
  if (!response.ok) {
    let providerMessage = "";
    try {
      const parsed = JSON.parse(text) as JsonRecord;
      const error =
        parsed.error && typeof parsed.error === "object"
          ? (parsed.error as JsonRecord)
          : parsed;
      if (typeof error.message === "string") providerMessage = error.message;
    } catch {
      // Keep a stable user-facing message when the provider returns HTML/text.
    }
    if (response.status === 429) {
      const lower = providerMessage.toLowerCase();
      const quota =
        /quota|resource exhausted|daily limit|billing|limit exceeded/.test(
          lower
        );
      throw new VideoProviderError(
        quota
          ? "Google rejected this request because this project exceeded its video-generation quota (HTTP 429). No video was created. Check the configured project's limits in Google AI Studio."
          : "Google is rate-limiting this video request (HTTP 429). No video was created; no automatic retry was attempted; try again later.",
        "TOO_MANY_REQUESTS",
        quota ? "quota" : "rate_limit",
        quota ? "quota_exhausted" : "retryable_rate_limit"
      );
    }
    throw new VideoProviderError(
      providerMessage
        ? `Gemini video service returned HTTP ${response.status}: ${providerMessage.slice(0, 240)}`
        : `Gemini video service returned HTTP ${response.status}.`,
      providerCode(response.status)
    );
  }
  if (!text.trim()) {
    throw new VideoProviderError(
      "Gemini video service returned an empty response.",
      "SERVICE_UNAVAILABLE"
    );
  }
  try {
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== "object") throw new Error("not object");
    return parsed as JsonRecord;
  } catch {
    // Do not include the response body: it can contain provider URLs or HTML.
    throw new VideoProviderError(
      "Gemini video service returned an invalid response.",
      "SERVICE_UNAVAILABLE"
    );
  }
}

async function request(
  input: RequestInfo | URL,
  init: RequestInit,
  timeoutMs = PROVIDER_DEADLINE_MS
): Promise<Response> {
  try {
    return await fetch(input, {
      ...init,
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (error) {
    if (error instanceof VideoProviderError) throw error;
    throw new VideoProviderError(
      "Gemini video service could not be reached. Please try again."
    );
  }
}

function normalizedStatus(payload: JsonRecord): string {
  return String(
    payload.status ??
      payload.state?.name ??
      (payload.done === true ? "completed" : "pending")
  ).toLowerCase();
}

function firstVideoUri(payload: JsonRecord): string | undefined {
  const candidates = [
    payload.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri,
    payload.response?.generatedVideos?.[0]?.video?.uri,
    payload.generateVideoResponse?.generatedSamples?.[0]?.video?.uri,
    payload.generatedVideos?.[0]?.video?.uri,
    payload.response?.generatedSamples?.[0]?.video?.uri,
    payload.response?.generateVideoResponse?.generatedSamples?.[0]?.video
      ?.fileUri,
    payload.response?.generatedVideos?.[0]?.video?.fileUri,
  ];
  return candidates.map(safeProviderUri).find(Boolean);
}

function outputParts(payload: JsonRecord): JsonRecord[] {
  const parts: JsonRecord[] = [];
  const steps = Array.isArray(payload.steps) ? payload.steps : [];
  for (const step of steps) {
    const content = Array.isArray(step?.content) ? step.content : [];
    for (const part of content) {
      if (part && typeof part === "object" && part.type === "video")
        parts.push(part as JsonRecord);
    }
  }
  const direct = [payload.output_video, payload.outputVideo, payload.output];
  for (const candidate of direct) {
    if (candidate && typeof candidate === "object") {
      if (candidate.type === "video") parts.push(candidate);
      if (candidate.video && typeof candidate.video === "object")
        parts.push({ type: "video", ...candidate.video });
    }
  }
  return parts;
}

function validateVideoBytes(bytes: Buffer, mimeType = "video/mp4"): Buffer {
  if (bytes.length === 0 || bytes.length > MAX_VIDEO_OUTPUT_BYTES) {
    throw new VideoProviderError(
      "Gemini returned a video outside the 64 MB output limit.",
      "SERVICE_UNAVAILABLE"
    );
  }
  const head = bytes
    .subarray(0, 1024)
    .toString("utf8")
    .trimStart()
    .toLowerCase();
  if (/^(?:<!doctype\s+html|<html(?:\s|>))/i.test(head)) {
    throw new VideoProviderError(
      "Gemini returned HTML instead of a video file.",
      "SERVICE_UNAVAILABLE"
    );
  }
  const isMp4 =
    bytes.length >= 12 && bytes.subarray(4, 8).toString("ascii") === "ftyp";
  const isWebm =
    bytes.length >= 4 &&
    bytes.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3])) &&
    bytes
      .subarray(0, Math.min(bytes.length, 64 * 1024))
      .toString("ascii")
      .includes("webm");
  if (!isMp4 && !isWebm) {
    throw new VideoProviderError(
      `Gemini returned an unsupported ${mimeType || "media"} file.`,
      "SERVICE_UNAVAILABLE"
    );
  }
  return bytes;
}

function safeProviderUri(value: unknown): string | undefined {
  if (typeof value !== "string" || !value.trim()) return undefined;
  try {
    const url = new URL(value);
    if (url.origin !== GEMINI_API_ORIGIN) return undefined;
    return url.toString();
  } catch {
    return undefined;
  }
}

function videoFromPayload(payload: JsonRecord): {
  data?: Buffer;
  uri?: string;
  mimeType: string;
} {
  const part = outputParts(payload).at(-1);
  if (!part) return { mimeType: "video/mp4" };
  const mimeType =
    typeof part.mime_type === "string" ? part.mime_type : "video/mp4";
  if (typeof part.data === "string") {
    try {
      const data = Buffer.from(part.data, "base64");
      return { data: validateVideoBytes(data, mimeType), mimeType };
    } catch (error) {
      if (error instanceof VideoProviderError) throw error;
      throw new VideoProviderError("Gemini returned invalid video data.");
    }
  }
  return { uri: safeProviderUri(part.uri), mimeType };
}

function fileNameFromUri(uri: string): string {
  const match = uri.match(/\/files\/([A-Za-z0-9._-]+)/);
  if (!match?.[1])
    throw new VideoProviderError("Gemini returned an invalid file URI.");
  return `files/${match[1]}`;
}

function fileFromPayload(payload: JsonRecord): GeminiFile {
  const file =
    payload.file && typeof payload.file === "object" ? payload.file : payload;
  const name = typeof file.name === "string" ? file.name : "";
  const uri = typeof file.uri === "string" ? file.uri : "";
  if (!name || !uri)
    throw new VideoProviderError("Gemini did not return an uploaded file.");
  return {
    name,
    uri,
    mimeType:
      typeof file.mimeType === "string"
        ? file.mimeType
        : "application/octet-stream",
  };
}

export async function uploadGeminiFile(
  bytes: Buffer,
  mimeType: string,
  displayName: string
): Promise<GeminiFile> {
  const key = apiKey();
  if (!bytes.length)
    throw new VideoProviderError("The source video is empty.", "BAD_REQUEST");
  const start = await request(
    `${UPLOAD_ROOT}/files`,
    {
      method: "POST",
      headers: {
        "x-goog-api-key": key,
        "X-Goog-Upload-Protocol": "resumable",
        "X-Goog-Upload-Command": "start",
        "X-Goog-Upload-Header-Content-Length": String(bytes.length),
        "X-Goog-Upload-Header-Content-Type": mimeType,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        file: { display_name: displayName.slice(0, 120) },
      }),
    },
    30_000
  );
  if (!start.ok) {
    await readJson(start);
  }
  const uploadUrl = start.headers.get("x-goog-upload-url");
  if (!uploadUrl)
    throw new VideoProviderError(
      "Gemini did not return a resumable upload URL."
    );
  let parsedUploadUrl: URL;
  try {
    parsedUploadUrl = new URL(uploadUrl);
    if (parsedUploadUrl.origin !== GEMINI_API_ORIGIN)
      throw new Error("unexpected origin");
  } catch {
    throw new VideoProviderError(
      "Gemini returned an invalid resumable upload URL."
    );
  }
  const finalized = await request(
    parsedUploadUrl,
    {
      method: "POST",
      headers: {
        "x-goog-api-key": key,
        "Content-Length": String(bytes.length),
        "X-Goog-Upload-Offset": "0",
        "X-Goog-Upload-Command": "upload, finalize",
        "Content-Type": mimeType,
      },
      body: new Uint8Array(bytes) as unknown as BodyInit,
    },
    60_000
  );
  return fileFromPayload(await readJson(finalized));
}

export async function getGeminiFile(nameOrUri: string): Promise<JsonRecord> {
  const key = apiKey();
  const name = nameOrUri.startsWith("files/")
    ? nameOrUri
    : fileNameFromUri(nameOrUri);
  const response = await request(`${API_ROOT}/${name}`, {
    method: "GET",
    headers: { "x-goog-api-key": key },
  });
  return readJson(response);
}

function fileState(payload: JsonRecord): string {
  const file =
    payload.file && typeof payload.file === "object" ? payload.file : payload;
  return String(file.state?.name ?? file.state ?? "").toUpperCase();
}

export async function waitForGeminiFileActive(
  name: string,
  maxWaitMs = PROVIDER_DEADLINE_MS
): Promise<void> {
  const started = Date.now();
  while (Date.now() - started <= maxWaitMs) {
    const metadata = await getGeminiFile(name);
    const state = fileState(metadata);
    if (state === "ACTIVE") return;
    if (state === "FAILED")
      throw new VideoProviderError(
        "Gemini could not process the source video.",
        "BAD_REQUEST"
      );
    await new Promise(resolve => setTimeout(resolve, FILE_POLL_MS));
  }
  throw new VideoProviderError(
    "Gemini is still processing the source video. Try the edit again shortly.",
    "SERVICE_UNAVAILABLE"
  );
}

export async function getGeminiInteraction(
  interactionId: string
): Promise<VideoInteraction> {
  const key = apiKey();
  const response = await request(
    `${API_ROOT}/interactions/${encodeURIComponent(interactionId)}`,
    {
      method: "GET",
      headers: { "x-goog-api-key": key },
    }
  );
  const payload = await readJson(response);
  const video = videoFromPayload(payload);
  return {
    id: typeof payload.id === "string" ? payload.id : interactionId,
    status: normalizedStatus(payload),
    outputUri: video.uri,
    video: video.data,
    provider: "omni",
  };
}

/** Poll a Veo predictLongRunning operation by its durable operation name. */
export async function getGeminiVideoOperation(
  operationName: string
): Promise<VideoInteraction> {
  if (
    !/^(?:models\/[A-Za-z0-9._-]+\/)?operations\/[A-Za-z0-9._-]+$/.test(
      operationName
    )
  )
    throw new VideoProviderError(
      "Gemini returned an invalid video operation.",
      "BAD_REQUEST"
    );
  const response = await request(`${API_ROOT}/${operationName}`, {
    method: "GET",
    headers: { "x-goog-api-key": apiKey() },
  });
  const payload = await readJson(response);
  const done = payload.done === true;
  if (done && payload.error) {
    const providerError =
      payload.error && typeof payload.error === "object"
        ? (payload.error as JsonRecord)
        : {};
    return {
      id: typeof payload.name === "string" ? payload.name : operationName,
      status: "failed",
      provider: "veo",
      error:
        typeof providerError.message === "string"
          ? `Google video generation failed: ${providerError.message.slice(0, 240)}`
          : "Google video generation failed.",
    };
  }
  const outputUri = firstVideoUri(payload);
  if (done && !outputUri) {
    return {
      id: typeof payload.name === "string" ? payload.name : operationName,
      status: "failed",
      provider: "veo",
      error:
        "Google completed this request without a video file. It may have been filtered by the provider. No downloadable video was created; revise the prompt before trying again.",
    };
  }
  return {
    id: typeof payload.name === "string" ? payload.name : operationName,
    status: done ? "completed" : "pending",
    outputUri,
    provider: "veo",
  };
}

export async function createGeminiVideoInteraction(input: {
  operation: "generate" | "edit";
  prompt: string;
  source?: GeminiFile;
  aspectRatio?: "16:9" | "9:16";
}): Promise<VideoInteraction> {
  const key = apiKey();
  const responseFormat: JsonRecord = {
    type: "video",
    delivery: "uri",
    ...(input.aspectRatio ? { aspect_ratio: input.aspectRatio } : {}),
  };
  const body: JsonRecord = {
    model: GEMINI_OMNI_MODEL,
    response_format: responseFormat,
  };
  if (input.source) {
    body.input = [
      {
        type: "user_input",
        content: [
          {
            type: "video",
            uri: input.source.uri,
            mime_type: input.source.mimeType,
          },
          {
            type: "text",
            text: `${input.prompt.trim()} Keep everything else the same.`,
          },
        ],
      },
    ];
    body.generation_config = { video_config: { task: "edit" } };
  } else {
    body.input = input.prompt.trim();
    body.generation_config = { video_config: { task: "text_to_video" } };
  }
  const response = await request(
    `${API_ROOT}/interactions`,
    {
      method: "POST",
      headers: { "x-goog-api-key": key, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    },
    100_000
  );
  const payload = await readJson(response);
  const video = videoFromPayload(payload);
  return {
    id: typeof payload.id === "string" ? payload.id : "",
    status: normalizedStatus(payload),
    outputUri: video.uri,
    video: video.data,
    provider: "omni",
  };
}

/** Start Veo generation. Google returns immediately with a durable operation. */
export async function createGeminiVeoOperation(input: {
  prompt: string;
  aspectRatio?: "16:9" | "9:16";
  resolution?: "720p" | "1080p";
  durationSeconds?: 4 | 6 | 8;
}): Promise<VideoInteraction> {
  const resolution = input.resolution ?? "720p";
  const durationSeconds = input.durationSeconds ?? 8;
  if (resolution === "1080p" && durationSeconds !== 8)
    throw new VideoProviderError(
      "Veo 1080p output is supported only at 8 seconds.",
      "BAD_REQUEST"
    );
  const response = await request(
    `${API_ROOT}/models/${configuredVeoModel()}:predictLongRunning`,
    {
      method: "POST",
      headers: {
        "x-goog-api-key": apiKey(),
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        instances: [{ prompt: input.prompt.trim() }],
        parameters: {
          aspectRatio: input.aspectRatio ?? "16:9",
          resolution,
          durationSeconds,
        },
      }),
    },
    30_000
  );
  const payload = await readJson(response);
  const name = typeof payload.name === "string" ? payload.name : "";
  if (!/^(?:models\/[A-Za-z0-9._-]+\/)?operations\/[A-Za-z0-9._-]+$/.test(name))
    throw new VideoProviderError(
      "Google did not return a durable video operation.",
      "SERVICE_UNAVAILABLE"
    );
  return {
    id: name,
    status: payload.done === true ? "completed" : "pending",
    outputUri: firstVideoUri(payload),
    provider: "veo",
  };
}

async function readDownloadBytes(response: Response): Promise<Buffer> {
  if (!response.ok)
    throw new VideoProviderError(
      `Gemini video download returned HTTP ${response.status}.`,
      providerCode(response.status)
    );
  const length = Number(response.headers.get("content-length") ?? "0");
  if (length > MAX_VIDEO_OUTPUT_BYTES)
    throw new VideoProviderError(
      "The generated video exceeds the 64 MB output limit.",
      "BAD_REQUEST"
    );
  const reader = response.body?.getReader();
  if (!reader) {
    const bytes = Buffer.from(await response.arrayBuffer());
    return validateVideoBytes(
      bytes,
      response.headers.get("content-type") ?? "video/mp4"
    );
  }
  const chunks: Buffer[] = [];
  let total = 0;
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      if (!next.value) continue;
      total += next.value.byteLength;
      if (total > MAX_VIDEO_OUTPUT_BYTES) {
        await reader.cancel().catch(() => undefined);
        throw new VideoProviderError(
          "The generated video exceeds the 64 MB output limit.",
          "BAD_REQUEST"
        );
      }
      chunks.push(Buffer.from(next.value));
    }
  } catch (error) {
    await reader.cancel().catch(() => undefined);
    if (error instanceof VideoProviderError) throw error;
    throw new VideoProviderError(
      "The generated video could not be downloaded."
    );
  }
  return validateVideoBytes(
    Buffer.concat(chunks),
    response.headers.get("content-type") ?? "video/mp4"
  );
}

export async function downloadGeminiVideo(uri: string): Promise<Buffer> {
  const safeUri = safeProviderUri(uri);
  if (!safeUri)
    throw new VideoProviderError("Gemini returned an unsafe video URI.");
  const response = await request(safeUri, {
    method: "GET",
    headers: { "x-goog-api-key": apiKey() },
  });
  return readDownloadBytes(response);
}

export async function resolveGeminiVideo(
  interactionId: string,
  outputUri?: string,
  provider: "veo" | "omni" = "omni"
): Promise<VideoInteraction> {
  if (provider === "veo") {
    const interaction = outputUri
      ? {
          id: interactionId,
          status: "completed",
          outputUri,
          provider: "veo" as const,
        }
      : await getGeminiVideoOperation(interactionId);
    if (!interaction.outputUri) return interaction;
    return {
      ...interaction,
      status: "completed",
      video: await downloadGeminiVideo(interaction.outputUri),
    };
  }
  const interaction = outputUri
    ? { id: interactionId, status: "completed", outputUri }
    : await getGeminiInteraction(interactionId);
  if (interaction.video) return interaction;
  if (!interaction.outputUri) {
    if (["failed", "error", "cancelled"].includes(interaction.status))
      throw new VideoProviderError(
        "Gemini video generation failed.",
        "SERVICE_UNAVAILABLE"
      );
    return interaction;
  }
  const metadata = await getGeminiFile(interaction.outputUri);
  const state = fileState(metadata);
  if (state === "FAILED")
    throw new VideoProviderError(
      "Gemini video generation failed.",
      "SERVICE_UNAVAILABLE"
    );
  if (state !== "ACTIVE") return { ...interaction, status: "processing" };
  return {
    ...interaction,
    status: "completed",
    video: await downloadGeminiVideo(interaction.outputUri),
  };
}
