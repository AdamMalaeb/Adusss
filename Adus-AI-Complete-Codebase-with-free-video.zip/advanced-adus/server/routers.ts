import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { invokeLLM, listLLMModels, selectChatModel } from "./_core/llm";
import { generateImage, listImageModels } from "./_core/imageGeneration";
import { transcribeAudio } from "./_core/voiceTranscription";
import { storageGetSignedUrl, storagePut } from "./storage";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createAutomation,
  createIntegration,
  getAutomationsByUserId,
  getIntegrationsByUserId,
  updateAutomationStatus,
  updateIntegrationStatus,
} from "./db";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { studyRouter } from "./studyRouter";
import { imagesRouter } from "./imagesRouter";
import { videoRouter } from "./videoRouter";
import { freeVideoRouter } from "./freeVideoRouter";
import { mediaRouter } from "./mediaDownloads";
import { hostingRouter } from "./hostingRouter";
import { upgradeRouter, activeProfile } from "./upgradeRouter";
import { attachmentSchema, attachmentParts } from "./attachments";
import { collectChatResearch, shouldResearchChat } from "./chatResearch";
import { chatFailureMessage } from "../shared/chatErrors";
import {
  groundChatCitations,
  stripProviderCitationTokens,
} from "../shared/chatCitations";
import { saveRecord } from "./workspaceStore";
import { chatStyle, voiceStyle } from "../shared/assistantStyle";
import { cameraFrameSchema } from "./cameraFrame";
import { CAMERA_CONTEXT_GUIDANCE } from "../shared/cameraPrivacy";
import { callSpeechRouter } from "./callSpeechRouter";
import { websiteImportRouter } from "./websiteImport";
import {
  creatorContext,
  shortCreatorAnswer,
  protectCreatorBirthDate,
} from "./creatorProfile";
import { workspaceExtensionsRouter } from "./workspaceExtensions";
import { videoEditRouter } from "./videoEditRouter";
import { conversationsRouter, getConversationContext } from "./conversations";
import { businessRouter } from "./businessRouter";
import { powerpointRouter } from "./powerpointRouter";
import { collectGoogleResearch } from "./googleResearch";
import { translatorRouter } from "./translatorRouter";
import { ownerProcedure } from "./accessPolicy";
import {
  languageSelectionSchema,
  normalizeLanguage,
  whisperLanguageHint,
  languageSpeechName,
  type LanguageSelection,
} from "../shared/languages";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  business: businessRouter,
  powerpoint: powerpointRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  adus: router({
    conversations: conversationsRouter,
    translator: translatorRouter,
    study: studyRouter,
    images: imagesRouter,
    videos: videoRouter,
    freeVideo: freeVideoRouter,
    media: mediaRouter,
    hosting: hostingRouter,
    upgrade: upgradeRouter,
    callSpeech: callSpeechRouter,
    workspaceExtensions: workspaceExtensionsRouter,
    videoEdits: videoEditRouter,
    websiteImport: websiteImportRouter,
    website: router({
      build: protectedProcedure
        .input(z.object({ brief: z.string().min(4).max(12000) }))
        .mutation(async ({ input, ctx }) => {
          try {
            const result = await invokeLLM({
              model: "gpt-5.5",
              reasoning: { effort: "low" },
              maxCompletionTokens: 12000,
              messages: [
                {
                  role: "system",
                  content:
                    "You are Adus Website Builder. Create a polished, self-contained, responsive single-page website as a complete HTML document. Return JSON only with title, summary, and html. Include all requested sections in this one document. Every internal navigation link MUST use a #section-id referring to an existing element; never link to /about, /services, another local route or an unimplemented page. The html must include its own CSS, use accessible semantic markup, have a strong visual hierarchy, and never include external scripts, forms that submit data, payment flows, or claims that an action was completed. Content must be visible immediately, without a JavaScript reveal effect or opacity-zero loading screen. Do not return markdown fences. Keep the HTML under 30000 characters.",
                },
                { role: "user", content: input.brief },
              ],
              response_format: {
                type: "json_schema",
                json_schema: {
                  name: "website_artifact",
                  strict: true,
                  schema: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      summary: { type: "string" },
                      html: { type: "string" },
                    },
                    required: ["title", "summary", "html"],
                    additionalProperties: false,
                  },
                },
              },
            });
            const raw = result.choices?.[0]?.message?.content;
            const artifact =
              typeof raw === "string"
                ? (JSON.parse(raw) as {
                    title: string;
                    summary: string;
                    html: string;
                  })
                : null;
            if (!artifact?.html)
              throw new Error("The builder returned an empty website");
            const record = await saveRecord(ctx.user.id, "website", artifact);
            return { ...artifact, id: record.id };
          } catch (error) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message:
                "The website builder could not finish. Please try again. Your previous preview has not been changed.",
            });
          }
        }),
    }),
    integrations: router({
      list: ownerProcedure.query(({ ctx }) =>
        getIntegrationsByUserId(ctx.user.id)
      ),
      create: ownerProcedure
        .input(
          z.object({
            name: z.string().min(1).max(120),
            provider: z.string().min(1).max(80),
            notes: z.string().max(2000).optional(),
          })
        )
        .mutation(({ ctx, input }) =>
          createIntegration({
            userId: ctx.user.id,
            name: input.name,
            provider: input.provider,
            notes: input.notes ?? null,
            status: "draft",
          })
        ),
      setStatus: ownerProcedure
        .input(
          z.object({
            id: z.number().int().positive(),
            status: z.enum(["draft", "connected", "paused"]),
          })
        )
        .mutation(({ ctx, input }) =>
          updateIntegrationStatus(ctx.user.id, input.id, input.status)
        ),
    }),
    automations: router({
      list: ownerProcedure.query(({ ctx }) =>
        getAutomationsByUserId(ctx.user.id)
      ),
      create: ownerProcedure
        .input(
          z.object({
            name: z.string().min(1).max(160),
            trigger: z.string().min(1).max(2000),
            steps: z.string().min(1).max(8000),
          })
        )
        .mutation(({ ctx, input }) =>
          createAutomation({
            userId: ctx.user.id,
            name: input.name,
            trigger: input.trigger,
            steps: input.steps,
            status: "draft",
          })
        ),
      setStatus: ownerProcedure
        .input(
          z.object({
            id: z.number().int().positive(),
            status: z.enum(["draft", "pending_approval", "active", "paused"]),
          })
        )
        .mutation(({ ctx, input }) =>
          updateAutomationStatus(ctx.user.id, input.id, input.status)
        ),
    }),
    capabilities: protectedProcedure.query(async () => {
      const models = await listLLMModels();
      let imageModels = {
        models: [] as Array<{ model?: string; id?: string }>,
      };
      try {
        imageModels = await listImageModels();
      } catch {
        // Keep the workspace available if the optional image service is unavailable.
      }
      return {
        access: "authenticated-users",
        chat: true,
        availableModelCount: models.data?.length ?? 0,
        imageGeneration: imageModels.models.length > 0,
        modules: [
          {
            id: "chat",
            label: "AI chat",
            status: "live",
            detail: "No app-imposed message cap",
          },
          {
            id: "research",
            label: "Web research",
            status: "live",
            detail: "Search and summarize public web pages",
          },
          {
            id: "images",
            label: "Images",
            status: imageModels.models.length > 0 ? "live" : "planned",
            detail: "Generate up to 5, edit references and resize",
          },
          {
            id: "studying",
            label: "Studying",
            status: "live",
            detail: "PDF/photos to summary and narrated explainer",
          },
          {
            id: "build",
            label: "Build lab",
            status: "live",
            detail: "Generate code and website plans",
          },
          {
            id: "automations",
            label: "Automations",
            status: "ready",
            detail: "Approval-first workflows are ready",
          },
          {
            id: "integrations",
            label: "Integrations",
            status: "ready",
            detail: "7 provider lanes ready to connect",
          },
          {
            id: "agents",
            label: "AI agent team",
            status: "live",
            detail: "Coordinator routes work to specialist agents",
          },
        ],
      };
    }),
    transcribeVoice: protectedProcedure
      .input(
        z.object({
          dataUrl: z.string().max(24_000_000),
          mimeType: z.string().min(1).max(120),
          recognitionContext: z.string().trim().max(720).optional(),
          language: z
            .string()
            .trim()
            .regex(/^(auto|[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*)$/)
            .default("auto"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const prompt =
          "Transcribe the user's speech verbatim in its original language and script. Preserve language switching and dialect. Do not translate or force English.";
        const transcriptionLanguage =
          input.language === "auto" ? undefined : input.language.split("-")[0];
        const directResult = await transcribeAudio({
          audioUrl: input.dataUrl,
          mimeType: input.mimeType,
          language: transcriptionLanguage,
          prompt,
          recognitionContext: input.recognitionContext,
        });
        if (!("error" in directResult))
          return { text: directResult.text, language: directResult.language };
        if (
          /usage exhausted|quota|rate limit/i.test(directResult.details ?? "")
        ) {
          return {
            text: "",
            error:
              "Voice service usage is temporarily exhausted. Please try again later or use text chat.",
          };
        }

        // Some providers cannot fetch data URLs. Retry through the configured object storage path.
        try {
          const encoded = input.dataUrl.split(",")[1] ?? input.dataUrl;
          const buffer = Buffer.from(encoded, "base64");
          if (buffer.length > 16 * 1024 * 1024)
            throw new Error("Voice recording is too large");
          const extension = input.mimeType.includes("mp4") ? "m4a" : "webm";
          const stored = await storagePut(
            `voice/${ctx.user.id}-${Date.now()}.${extension}`,
            buffer,
            input.mimeType || "audio/webm"
          );
          const signedUrl = await storageGetSignedUrl(stored.key);
          const storedResult = await transcribeAudio({
            audioUrl: signedUrl,
            mimeType: input.mimeType,
            language: transcriptionLanguage,
            prompt,
            recognitionContext: input.recognitionContext,
          });
          if (!("error" in storedResult))
            return { text: storedResult.text, language: storedResult.language };
          console.error(
            "[Voice] Transcription provider failed after direct and storage attempts",
            storedResult.code,
            storedResult.details
          );
        } catch (error) {
          console.error("[Voice] Audio fallback failed", error);
        }
        return {
          text: "",
          error:
            "Voice transcription is temporarily unavailable. Please try again or use text chat.",
        };
      }),
    chat: protectedProcedure
      .input(
        z
          .object({
            message: z.string().min(1).max(12000),
            conversationId: z.string().min(1).max(64).optional(),
            voiceMode: z.boolean().optional(),
            cameraMode: z.boolean().optional(),
            cameraFrame: cameraFrameSchema.optional(),
            callLanguage: z
              .union([z.literal("auto"), languageSelectionSchema])
              .default("auto"),
            chatOnly: z.boolean().optional(),
            modelMode: z.enum(["auto", "fast", "deep"]).default("auto"),
            attachments: z.array(attachmentSchema).max(5).optional(),
            history: z
              .array(
                z.object({
                  role: z.enum(["user", "assistant"]),
                  content: z.string().max(20000),
                })
              )
              .max(30)
              .default([]),
            attachment: attachmentSchema.optional(),
          })
          .superRefine((input, ctx) => {
            if ((input.cameraMode || input.cameraFrame) && !input.voiceMode)
              ctx.addIssue({
                code: "custom",
                message: "Camera frames require an active call turn.",
              });
            if (input.cameraFrame && !input.cameraMode)
              ctx.addIssue({
                code: "custom",
                message: "Enable the camera before sending a frame.",
              });
          })
      )
      .mutation(async ({ input, ctx }) => {
        const creator = shortCreatorAnswer(input.message);
        if (creator)
          return {
            content: creator,
            model: "Adus identity",
            modelMode: input.modelMode,
            agent: "Adus",
          };
        const savedContext =
          input.conversationId && !input.voiceMode
            ? await getConversationContext(
                ctx.user.id,
                input.conversationId,
                input.message
              )
            : null;
        const effectiveHistory = savedContext?.history ?? input.history;
        const history = effectiveHistory
          .filter(
            item =>
              item.role !== "assistant" ||
              !/^(I could not complete that request right now\. Please try again\.|The AI service (could not answer|returned no answer|is busy|has reached)|The answer took too long to arrive)/.test(
                item.content
              )
          )
          .map(item => ({ role: item.role, content: item.content }));
        const files =
          input.attachments ?? (input.attachment ? [input.attachment] : []);
        const chatFastModel = "gpt-5-mini";
        const contextFiles = input.cameraFrame
          ? [...files, input.cameraFrame]
          : files;
        const userContent = contextFiles.length
          ? [
              { type: "text" as const, text: input.message },
              ...(await attachmentParts(contextFiles)),
            ]
          : input.message;
        const profile = await activeProfile(ctx.user.id);

        const recentContext = history
          .slice(-6)
          .map(item => `${item.role}: ${item.content}`)
          .join("\n");
        const explicitImageRequest =
          /(generate|create|make|produce|draw|render|show me|give me|turn this into|put this in|make this into|convert this into|bring this to life)[\s\S]{0,140}(image|photo|picture|illustration|poster|logo|visual|meme|artwork|graphic)/i.test(
            input.message
          );
        const imageCorrection =
          /(that'?s|this is)\s+(text|a text|just text)\s+(not|instead of)\s+(an?\s+)?(image|photo|picture)|real image|actual image|finished image|not a concept|don'?t describe|stop describing/i.test(
            input.message
          );
        const wantsImage = explicitImageRequest || imageCorrection;

        const wantsResearch =
          /(research|search|latest|news|find out|look up|compare)/i.test(
            input.message
          );
        const wantsBuild =
          /(build|website|web site|landing page|app|html|react|code)/i.test(
            input.message
          );
        const wantsAutomation =
          /(automate|automation|workflow|every day|every week|schedule)/i.test(
            input.message
          );
        const agentName = input.voiceMode
          ? "Voice Agent"
          : wantsImage
            ? "Creative Agent"
            : wantsResearch
              ? "Research Agent"
              : wantsBuild
                ? "Build Agent"
                : wantsAutomation
                  ? "Automation Agent"
                  : "Adus Coordinator";

        if (!input.voiceMode && !input.chatOnly && wantsImage) {
          try {
            const referenceImage = input.attachment?.mimeType.startsWith(
              "image/"
            )
              ? [
                  {
                    b64Json:
                      input.attachment.dataUrl.split(",")[1] ??
                      input.attachment.dataUrl,
                    mimeType: input.attachment.mimeType,
                  },
                ]
              : undefined;
            const generated = await generateImage({
              prompt: `Create the finished image now, not a description or concept. Use the user's latest request as the primary instruction. If the conversation contains an image concept, turn that concept into a complete polished visual. Render any text the user explicitly requested. Preserve the identity and important details of an attached reference image when present.\n\nLatest request:\n${input.message}\n\nRelevant conversation context:\n${recentContext}\n\nAvoid: replying with a prompt, explaining how to make it, asking for a photo when a generic subject is acceptable, watermarks, borders, UI chrome, and placeholder text.`,
              originalImages: referenceImage,
              quality: "medium",
            });
            return {
              content: generated.url
                ? "Done — I created the finished image below."
                : "The image service returned no file. Please try again.",
              model: "GPT Image 2",
              agent: "Creative Agent",
              imageUrl: generated.url,
            };
          } catch (error) {
            return {
              content:
                "I couldn’t create the finished image right now. Please try the request again.",
              model: "Adus image service",
            };
          }
        }

        if (!input.voiceMode && !input.chatOnly && wantsBuild) {
          return {
            content:
              "I’m opening the live website builder so I can create a rendered website preview instead of sending code.",
            model: "Adus Build Lab",
            agent: "Build Agent",
            openBuilder: true,
            builderBrief: input.message,
          };
        }

        if (!input.voiceMode && !input.chatOnly && wantsAutomation) {
          const plan = await invokeLLM({
            model: "gpt-5-mini",
            messages: [
              {
                role: "system",
                content:
                  "You are Adus Automation Designer. Turn the user's request into a concise workflow specification with trigger, steps, required connections, approval checkpoints, failure handling, and a clear statement that it is a draft until the user enables it.",
              },
              { role: "user", content: input.message },
            ],
          });
          return {
            content:
              typeof plan.choices?.[0]?.message?.content === "string"
                ? plan.choices[0].message.content
                : "I could not draft that automation.",
            model: "Adus Automation Designer",
            agent: "Automation Agent",
          };
        }

        const needsDeepReasoning =
          files.length > 0 ||
          wantsResearch ||
          wantsBuild ||
          wantsAutomation ||
          input.message.length > 500 ||
          /(analy[sz]e|strategy|business plan|technical architecture|compare deeply|step by step|complex|important decision)/i.test(
            input.message
          );
        const multimodal = contextFiles.some(
          file =>
            file.mimeType.startsWith("image/") ||
            file.mimeType.startsWith("audio/") ||
            file.mimeType.startsWith("video/") ||
            file.mimeType === "application/pdf"
        );
        const useDeepModel =
          !input.voiceMode &&
          input.modelMode !== "fast" &&
          (input.modelMode === "deep" || needsDeepReasoning);
        const selectedModel = selectChatModel({
          mode: input.voiceMode ? "fast" : useDeepModel ? "deep" : "fast",
          multimodal,
        });
        const shouldSearch =
          !input.voiceMode &&
          !files.length &&
          shouldResearchChat(input.message);
        const googleEvidence = shouldSearch
          ? await collectGoogleResearch(input.message)
          : null;
        const research = googleEvidence?.sources.length
          ? googleEvidence
          : shouldSearch
            ? await collectChatResearch(input.message).catch(() => ({
                sources: [],
                status: "unavailable" as const,
                context:
                  "Live web research is unavailable. Answer stable facts from general knowledge; explicitly say current details were not verified. Never invent citations.",
              }))
            : null;
        const response = await invokeLLM(
          {
            model: selectedModel,
            ...(input.voiceMode
              ? multimodal
                ? { maxTokens: 1800 }
                : { maxCompletionTokens: 1000 }
              : multimodal
                ? { maxTokens: useDeepModel ? 6000 : 3500 }
                : {
                    maxCompletionTokens: useDeepModel ? 4000 : 2200,
                  }),
            ...(input.voiceMode && selectedModel.startsWith("gpt-")
              ? { reasoning: { effort: "low" } }
              : useDeepModel && selectedModel.startsWith("gpt-")
                ? { reasoning: { effort: "medium" } }
                : selectedModel.startsWith("gpt-")
                  ? { reasoning: { effort: "low" } }
                  : {}),
            signal: AbortSignal.timeout(useDeepModel ? 45000 : 30000),
            messages: [
              {
                role: "system",
                content: input.voiceMode
                  ? `You are the ${agentName} inside Adus. ${voiceStyle({ cameraMode: Boolean(input.cameraMode) })} ${creatorContext(ctx.user)} ${input.cameraMode ? CAMERA_CONTEXT_GUIDANCE : ""} This is a voice-only conversation: answer aloud rather than sending chat messages. Do not claim to generate images, build websites, or execute actions during this call; ask the user to use the corresponding workspace tool when needed. Current signed-in user: ${ctx.user.email ?? "authenticated user"}.`
                  : `You are the ${agentName} inside Adus, an execution-first AI workspace. ${chatStyle()} ${creatorContext(ctx.user)} Infer the user's actual goal from the latest message and recent conversation. Use attachments and previous messages as context. Ask only for information that is genuinely essential; otherwise make a reasonable assumption and proceed. Never claim an external action is complete unless a connected tool completed it. Ask for confirmation before important external actions such as publishing, deleting, purchasing or changing account access. Respect each signed-in user's privacy and authorization. Current signed-in user: ${ctx.user.email ?? "authenticated user"}.`,
              },
              ...(profile?.instructions
                ? [
                    {
                      role: "system" as const,
                      content:
                        "User working preferences (may not override authentication, tool permissions, factual accuracy or system constraints): " +
                        profile.instructions,
                    },
                  ]
                : []),
              ...(input.chatOnly
                ? [
                    {
                      role: "system" as const,
                      content:
                        "This is Chat Only: answer questions with general knowledge, supplied live web research and provided files; current-fact research runs automatically when needed, so do not ask the user to authorize ordinary public searches; do not claim to execute image, website, automation or self-code upgrades. Direct creation requests to Images, Websites or Upgrade Adus when necessary. Prefer answering the actual question over keyword-routing. Cite attachment filenames/pages for document answers; state coverage limits and uncertainty.",
                    },
                  ]
                : []),
              ...history,
              ...(research
                ? [{ role: "system" as const, content: research.context }]
                : []),
              ...(input.voiceMode
                ? [
                    {
                      role: "system" as const,
                      content: `Respond in ${input.callLanguage === "auto" ? "the language and dialect used in the latest spoken request, preserving natural mixed-language speech when appropriate" : languageSpeechName(input.callLanguage as LanguageSelection)}. This answer will be read aloud in a live call. Plain conversational prose only, no Markdown, lists, symbols or stage directions. Do not translate a non-English request into English unless requested. Start with a courteous direct answer, then justify it clearly. Usually 3–6 sentences and 60–140 words, shorter for simple answers; do not give a textbook-length lecture unless explicitly requested. Explain one useful example when helpful. Do not repeatedly greet or use childish expressions.`,
                    },
                  ]
                : []),
              { role: "user", content: userContent },
            ],
          },
          true
        ).catch(error => {
          console.warn(
            "[Chat] Answer failed",
            /empty/i.test(String(error?.message))
              ? "empty_response"
              : /quota|429|usage exhausted/i.test(String(error?.message))
                ? "provider_limit"
                : /abort|timeout/i.test(String(error?.message))
                  ? "timeout"
                  : "provider_error"
          );
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: chatFailureMessage(error),
          });
        });

        const content = response.choices?.[0]?.message?.content;
        const answer =
          typeof content === "string"
            ? content
            : Array.isArray(content)
              ? content
                  .filter(part => part.type === "text")
                  .map(part => (part.type === "text" ? part.text : ""))
                  .join("\n")
              : "";
        const text = protectCreatorBirthDate(
          research
            ? groundChatCitations(
                answer.trim(),
                research.sources.map(source => source.url)
              )
            : stripProviderCitationTokens(answer.trim())
        );
        if (!text) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message:
              "The AI returned an empty response. Please try again; no action was completed.",
          });
        }
        return {
          content: research?.sources.length
            ? text +
              "\n\n**Sources checked**\n" +
              research.sources
                .map(
                  (source, index) =>
                    `[${index + 1}. ${source.title.replace(/[\[\]\n]/g, " ")}](${source.url.replace(/\(/g, "%28").replace(/\)/g, "%29")})`
                )
                .join("\n")
            : text,
          ...(research
            ? {
                research: {
                  status: research.sources.length
                    ? ("retrieved" as const)
                    : ("unavailable" as const),
                  checkedAt: Date.now(),
                  engine: googleEvidence?.sources.length
                    ? "Google Search"
                    : "Public web search",
                  ...(googleEvidence?.searchSuggestions
                    ? { searchSuggestions: googleEvidence.searchSuggestions }
                    : {}),
                },
              }
            : {}),
          model: response.model ?? chatFastModel,
          modelMode: input.modelMode,
          agent: input.chatOnly ? "Adus" : agentName,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
