import { beforeEach, describe, expect, it, vi } from "vitest";
import { randomUUID } from "node:crypto";
import type { TrpcContext } from "./_core/context";
const m = vi.hoisted(() => ({
  llm: vi.fn(),
  get: vi.fn(),
  save: vi.fn(),
  list: vi.fn(),
  images: vi.fn(),
}));
vi.mock("./_core/llm", async importOriginal => ({
  ...(await importOriginal<typeof import("./_core/llm")>()),
  invokeLLM: m.llm,
  listLLMModels: vi.fn(async () => ({
    data: [{ id: "gpt-5-mini" }, { id: "gemini-3-flash-preview" }],
  })),
}));
vi.mock("./workspaceStore", () => ({
  getRecord: m.get,
  saveRecord: m.save,
  listRecords: m.list,
}));
vi.mock("./_core/imageGeneration", () => ({
  generateImage: m.images,
  listImageModels: vi.fn(),
}));
import { appRouter } from "./routers";
import { attachmentSchema, attachmentParts } from "./attachments";
function caller(userId = 1) {
  return appRouter.createCaller({
    user: { id: userId, email: "adammalaeb30@gmail.com" },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}
beforeEach(() => {
  vi.clearAllMocks();
  m.get.mockResolvedValue(undefined);
  m.list.mockResolvedValue([]);
  m.save.mockImplementation(async (_u, _k, p, id) => ({
    id: id ?? randomUUID(),
    payload: p,
    createdAt: Date.now(),
  }));
  m.llm.mockResolvedValue({
    model: "gpt-5-mini",
    choices: [{ message: { content: "A conversational answer." } }],
  });
});
describe("Chat Only", () => {
  it.each([
    "Create 5 photos",
    "Build a website",
    "Compare these answers",
    "Schedule a workflow",
  ])("does not run execution tools for %s", async message => {
    const r = await caller().adus.chat({ message, chatOnly: true });
    expect(r.content).toBe("A conversational answer.");
    expect(r.agent).toBe("Adus");
    expect(r).not.toHaveProperty("openBuilder");
    expect(m.images).not.toHaveBeenCalled();
    expect(m.llm).toHaveBeenCalledTimes(1);
  });
  it("reads multiple text files rather than inventing their contents", async () => {
    await caller().adus.chat({
      message: "Summarize",
      chatOnly: true,
      attachments: [
        {
          name: "waves.txt",
          mimeType: "text/plain",
          dataUrl:
            "data:text/plain;base64," +
            Buffer.from("Waves transfer energy.").toString("base64"),
        },
        {
          name: "notes.csv",
          mimeType: "text/csv",
          dataUrl:
            "data:text/csv;base64," +
            Buffer.from("period,0.4").toString("base64"),
        },
      ],
    });
    const req = m.llm.mock.calls[0][0];
    expect(JSON.stringify(req.messages)).toContain("Waves transfer energy.");
    expect(JSON.stringify(req.messages)).toContain("period,0.4");
  });
  it("injects only this user’s saved preferences", async () => {
    m.get.mockResolvedValue({
      id: "profile-2",
      payload: { instructions: "Use simple examples." },
    });
    await caller(2).adus.chat({ message: "Hello", chatOnly: true });
    expect(m.get).toHaveBeenCalledWith(2, "profile", "profile-2");
    expect(JSON.stringify(m.llm.mock.calls[0][0].messages)).toContain(
      "Use simple examples."
    );
  });
});
describe("attachment validation", () => {
  it("rejects arbitrary URL fetching", () => {
    expect(
      attachmentSchema.safeParse({
        name: "x.png",
        mimeType: "image/png",
        dataUrl: "http://localhost/secret",
      }).success
    ).toBe(false);
  });
  it("rejects unsupported files clearly", async () => {
    await expect(
      attachmentParts([
        {
          name: "archive.zip",
          mimeType: "application/zip",
          dataUrl: "data:application/zip;base64,YWJj",
        },
      ])
    ).rejects.toThrow("cannot be read yet");
  });
});
describe("behaviour upgrade", () => {
  const proposal = {
    title: "Study helper",
    instructions: "Explain with a simple example.",
    changes: ["Simpler explanations"],
    checks: ["Verify a worked example"],
    requiresEngineering: false,
    engineeringNotes: "",
  };
  it("creates a proposal without applying it", async () => {
    m.llm.mockResolvedValue({
      choices: [{ message: { content: JSON.stringify(proposal) } }],
    });
    const result = await caller().adus.upgrade.propose({
      prompt: "Explain more simply",
    });
    expect(result.instructions).toBe(proposal.instructions);
    expect(m.save).toHaveBeenCalledWith(
      1,
      "upgrade",
      expect.objectContaining({ status: "proposed" })
    );
  });
  it("requires exact approval and ownership for applying", async () => {
    await expect(
      caller().adus.upgrade.activate({ id: "other", confirmed: true })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(m.save).not.toHaveBeenCalled();
    await expect(
      caller().adus.upgrade.activate({ id: "other", confirmed: false as true })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
  it("applies reviewed instructions and preserves previous version", async () => {
    m.get.mockImplementation(async (_u, k) =>
      k === "upgrade"
        ? { id: "u1", payload: { ...proposal, status: "proposed" } }
        : { payload: { instructions: "Old preferences" } }
    );
    await caller().adus.upgrade.activate({ id: "u1", confirmed: true });
    expect(m.save).toHaveBeenCalledWith(
      1,
      "profile",
      expect.objectContaining({
        instructions: proposal.instructions,
        version: "u1",
      }),
      "profile-1"
    );
    expect(m.save).toHaveBeenCalledWith(
      1,
      "upgrade",
      expect.objectContaining({
        previous: { instructions: "Old preferences" },
        status: "applied",
      }),
      "u1"
    );
  });
  it("rejects rollback of a version that is not active", async () => {
    m.get.mockImplementation(async (_u, k) =>
      k === "upgrade"
        ? { id: "u1", payload: { ...proposal, status: "applied" } }
        : { payload: { version: "u2" } }
    );
    await expect(caller().adus.upgrade.rollback({ id: "u1" })).rejects.toThrow(
      "Only the current upgrade"
    );
    expect(m.save).not.toHaveBeenCalled();
  });
  it("keeps all upgrade endpoints authenticated", async () => {
    const c = appRouter.createCaller({
      user: null,
      req: { headers: {} },
      res: {},
    } as TrpcContext);
    await expect(
      c.adus.upgrade.propose({ prompt: "Help me study" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
