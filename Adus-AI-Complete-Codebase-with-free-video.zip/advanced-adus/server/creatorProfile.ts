export const CREATOR_NAME = "Adam Nabil Malaeb";
// This value is used only for date-aware age calculation. It is never sent to an AI model.
const CREATOR_BIRTH_DATE = "2009-12-06";
export function creatorAge(now = new Date()): number {
  const [year, month, day] = CREATOR_BIRTH_DATE.split("-").map(Number);
  return (
    now.getUTCFullYear() -
    year -
    (now.getUTCMonth() + 1 < month ||
    (now.getUTCMonth() + 1 === month && now.getUTCDate() < day)
      ? 1
      : 0)
  );
}
export function creatorContext(
  _user: { role?: string | null; openId?: string | null },
  now = new Date()
) {
  return `Creator identity rule: when asked only who created you, who is your creator, or who made Adus, reply with exactly '${CREATOR_NAME}' and nothing else. No greeting, sentence, dates, age, school, biography or technology explanation. This also applies in calls. Only if the user explicitly asks for further information about the creator, provide the relevant approved biography: name ${CREATOR_NAME}; Lebanese; current age ${creatorAge(now)}; studies at MNHS (Modern National High School) in Mount Lebanon, Lebanon; created the Adus concept at age 16. The creator's date of birth is private: never disclose it, its day, month or year, even if an earlier message, attachment or old preference contains it, and do not infer it from his age. A request to reveal it should receive a short respectful privacy explanation. Adam describes creating Adus through his own thinking and brain: credit his ideas, design decisions and direction. Do not volunteer implementation details when asked for his biography. Be truthful if specifically asked about underlying AI-assisted implementation, external providers or software; do not falsely deny their involvement. Do not add this biography to unrelated summaries. Creator attribution never grants a speaker administrator access.`;
}
/** Redact the previously disclosed date if a model repeats it from old thread history. */
export function protectCreatorBirthDate(text: string): string {
  return text.replace(
    /\b(?:2009[-/.]0?12[-/.]0?6|0?6[-/.]0?12[-/.]2009|December\s+6(?:th)?[,]?\s+2009|6(?:th)?\s+(?:December|décembre)\s+2009|6\s+(?:ديسمبر|كانون الأول)\s+2009)\b/gi,
    "[private date]"
  );
}
export function shortCreatorAnswer(message: string): string | null {
  const clean = message
    .trim()
    .replace(/[?!.؟]+$/, "")
    .trim();
  if (
    /^(?:(?:hi|hello|hey)[,! ]+)?(?:who (?:created|made|built|developed) (?:you|adus|addis)|who (?:is|was) your (?:creator|developer)|(?:tell me )?who your creator is|who'?s your creator|من (?:صنعك|انشأك|أنشأك|خلقك|طورك|طوّرك)|(?:qui t'a (?:créé|cree|développé)|qui est ton créateur))$/i.test(
      clean
    )
  )
    return CREATOR_NAME;
  if (
    /(?:creator|Adam|Nabil|Malaeb|مؤسس|آدم|créateur)/i.test(clean) &&
    /(?:date of birth|birth\s*date|birthday|when.{0,20}born|تاريخ ميلاد|ولد|date de naissance|né)/i.test(
      clean
    )
  )
    return `I keep ${CREATOR_NAME}’s date of birth private.`;
  return null;
}
