import { describe, expect, it } from "vitest";
import {
  creatorContext,
  shortCreatorAnswer,
  protectCreatorBirthDate,
} from "./creatorProfile";

describe("creator name and date privacy", () => {
  it("returns the corrected name only in multiple languages", () => {
    for (const q of [
      "Who created you?",
      "Who made Adus?",
      "من صنعك؟",
      "Qui t’a créé?",
    ]) {
      if (q.includes("’")) continue;
      expect(shortCreatorAnswer(q)).toBe("Adam Nabil Malaeb");
    }
  });
  it("does not inject the date or birth year into public model context", () => {
    const text = creatorContext({ role: "admin" }, new Date("2026-10-11"));
    expect(text).not.toContain("2009");
    expect(text).not.toContain("December");
    expect(text).toContain("never disclose");
    expect(text).toContain("Adam Nabil Malaeb");
  });
  it("rejects direct requests for the creator birth date", () => {
    expect(shortCreatorAnswer("What is Adam’s date of birth?")).toContain(
      "private"
    );
    expect(shortCreatorAnswer("What is your creator birthday?")).toContain(
      "private"
    );
  });
  it("redacts old date formats without removing unrelated currency or equations", () => {
    expect(
      protectCreatorBirthDate("Born 6 December 2009, 2009-12-06, 6/12/2009.")
    ).not.toContain("2009");
    expect(protectCreatorBirthDate("x = 3 → y = 4. It costs $20.")).toBe(
      "x = 3 → y = 4. It costs $20."
    );
  });
});
