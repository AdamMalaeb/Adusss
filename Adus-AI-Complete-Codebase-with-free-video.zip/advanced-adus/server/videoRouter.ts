import { randomUUID } from "node:crypto";
import { normalizeVideoOutput } from "./normalizeVideo";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getRecord, listRecords, saveRecord } from "./workspaceStore";
import { storagePut } from "./storage";
import { lockedProcedure } from "./accessPolicy";
import { router } from "./_core/trpc";
import {
  createGeminiVideoInteraction,
  createGeminiVeoOperation,
  getGeminiInteraction,
  getGeminiVideoOperation,
  isGeminiConfigured,
  resolveGeminiVideo,
  uploadGeminiFile,
  VideoProviderError,
  waitForGeminiFileActive,
  type GeminiFile,
} from "./videoProvider";
import { professorVideoRouter } from "./professorVideoRouter";
import {
  loadStoredVideoSource,
  storeVideoSource,
  MAX_BASE64_SOURCE_BYTES,
} from "./videoUpload";
import {
  addNaturalNarration,
  videoNarrationSchema,
  type VideoNarrationInput,
} from "./videoNarration";
const VIDEO_KIND = "videos";
const MAX_SOURCE_BASE64_CHARS = Math.ceil(MAX_BASE64_SOURCE_BYTES / 3) * 4;
const MAX_PROMPT_CHARS = 12_000;

type VideoOperation = "generate" | "edit";
type VideoStatus = "pending" | "completed" | "failed";

type VideoPayload = {
  type: "source" | "result";
  operation?: VideoOperation;
  status?: VideoStatus;
  name?: string;
  mimeType?: string;
  bytes?: number;
  duration?: number;
  sourceId?: string;
  prompt?: string;
  aspectRatio?: "16:9" | "9:16";
  interactionId?: string;
  providerUri?: string;
  provider?: "veo" | "omni";
  resolution?: "720p" | "1080p";
  durationSeconds?: 4 | 6 | 8;
  narration?: VideoNarrationInput;
  key?: string;
  url?: string;
  error?: string;
};

function badRequest(message: string): TRPCError {
  return new TRPCError({ code: "BAD_REQUEST", message });
}

function notFound(message: string): TRPCError {
  return new TRPCError({ code: "NOT_FOUND", message });
}

function serviceUnavailable(message: string): TRPCError {
  return new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}

function providerError(error: unknown): TRPCError {
  if (error instanceof TRPCError) return error;
  if (error instanceof VideoProviderError)
    return new TRPCError({ code: error.code, message: error.message });
  return serviceUnavailable(
    "The video service could not finish this request. Please try again."
  );
}

function decodeDataUrl(dataUrl: string): Buffer {
  const match = dataUrl.match(
    /^data:([^;,]+)(?:;[^,]*)?;base64,([A-Za-z0-9+/=\r\n]+)$/
  );
  if (!match?.[2]) throw badRequest("Upload a base64 video data URL.");
  const encoded = match[2].replace(/\s+/g, "");
  if (encoded.length > MAX_SOURCE_BASE64_CHARS)
    throw badRequest(
      "Source videos must use a base64 payload of 12 MB or less."
    );
  const bytes = Buffer.from(encoded, "base64");
  if (!bytes.length || bytes.length > MAX_BASE64_SOURCE_BYTES)
    throw badRequest("Source videos must be 12 MB or smaller.");
  // Buffer.from is permissive. Re-encode to reject malformed base64 rather than
  // storing a truncated or silently-corrupted source.
  const canonical = bytes.toString("base64").replace(/=+$/, "");
  if (canonical !== encoded.replace(/=+$/, ""))
    throw badRequest("The video upload contains invalid base64 data.");
  return bytes;
}

function sourceInput() {
  return z
    .object({
      name: z.string().min(1).max(240),
      mimeType: z.string().max(120).optional().default(""),
      dataUrl: z.string().max(MAX_SOURCE_BASE64_CHARS + 256),
    })
    .superRefine((value, ctx) => {
      if (!value.dataUrl.startsWith("data:"))
        ctx.addIssue({
          code: "custom",
          message: "Upload a base64 video data URL.",
        });
      const comma = value.dataUrl.indexOf(",");
      if (
        comma < 0 ||
        value.dataUrl.length - comma - 1 > MAX_SOURCE_BASE64_CHARS
      )
        ctx.addIssue({
          code: "custom",
          message: "Source videos must use a base64 payload of 12 MB or less.",
        });
    });
}

const editFields = {
  prompt: z.string().trim().min(3).max(MAX_PROMPT_CHARS),
  aspectRatio: z.enum(["16:9", "9:16"]).default("16:9"),
  narration: videoNarrationSchema.default({
    enabled: false,
    text: "",
    language: "en",
    gender: "woman",
  }),
};

const operationInput = z
  .object({
    ...editFields,
    resolution: z.enum(["720p", "1080p"]).default("720p"),
    durationSeconds: z
      .union([z.literal(4), z.literal(6), z.literal(8)])
      .default(8),
  })
  .superRefine((value, ctx) => {
    if (value.resolution === "1080p" && value.durationSeconds !== 8) {
      ctx.addIssue({
        code: "custom",
        path: ["durationSeconds"],
        message: "1080p Veo output is supported only at 8 seconds.",
      });
    }
  });
const editInput = z.object({
  ...editFields,
  sourceId: z.string().min(1).max(100),
});

function publicPayload(id: string, payload: VideoPayload) {
  return {
    id,
    type: payload.type,
    operation: payload.operation,
    status: payload.status,
    name: payload.name,
    mimeType: payload.mimeType,
    bytes: payload.bytes,
    duration: payload.duration,
    sourceId: payload.sourceId,
    prompt: payload.prompt,
    aspectRatio: payload.aspectRatio,
    interactionId: payload.interactionId,
    provider: payload.provider,
    resolution: payload.resolution,
    durationSeconds: payload.durationSeconds,
    url: payload.url,
    error: payload.error,
  };
}

async function persistOutput(
  userId: number,
  recordId: string,
  payload: VideoPayload,
  bytes: Buffer
) {
  try {
    bytes = await normalizeVideoOutput(bytes);
  } catch {
    throw serviceUnavailable(
      "The video was returned in an unreadable format. Retry this result."
    );
  }
  if (payload.narration?.enabled) {
    const narrated = await addNaturalNarration({
      bytes,
      narration: payload.narration,
    });
    bytes = narrated.bytes;
  }
  const stored = await storagePut(
    `videos/${userId}/${recordId}.mp4`,
    bytes,
    "video/mp4"
  );
  const completed: VideoPayload = {
    ...payload,
    type: "result",
    status: "completed",
    key: stored.key,
    url: stored.url,
    bytes: bytes.length,
    mimeType: "video/mp4",
    providerUri: undefined,
  };
  await saveRecord(userId, VIDEO_KIND, completed, recordId);
  return publicPayload(recordId, completed);
}

async function startOperation(
  userId: number,
  operation: VideoOperation,
  prompt: string,
  aspectRatio: "16:9" | "9:16",
  sourceId?: string,
  options?: {
    resolution?: "720p" | "1080p";
    durationSeconds?: 4 | 6 | 8;
    narration?: VideoNarrationInput;
  }
) {
  if (!isGeminiConfigured())
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message:
        "Gemini video generation is not configured. Add GEMINI_API_KEY to the server environment.",
    });

  let source: GeminiFile | undefined;
  if (sourceId) {
    const record = await getRecord(userId, VIDEO_KIND, sourceId);
    const payload = record?.payload as VideoPayload | undefined;
    if (!record || payload?.type !== "source")
      throw notFound("That source video is not available.");
    const local = await loadStoredVideoSource(userId, sourceId);
    const uploaded = await uploadGeminiFile(
      local.bytes,
      local.payload.mimeType,
      local.payload.name ?? "source-video"
    );
    const maxWaitMs = 20_000;
    await waitForGeminiFileActive(uploaded.name, maxWaitMs);
    source = uploaded;
  }

  const recordId = randomUUID();
  let interaction;
  try {
    interaction = source
      ? await createGeminiVideoInteraction({
          operation,
          prompt,
          aspectRatio,
          source,
        })
      : await createGeminiVeoOperation({
          prompt,
          aspectRatio,
          resolution: options?.resolution,
          durationSeconds: options?.durationSeconds,
        });
  } catch (error) {
    throw providerError(error);
  }
  const pending: VideoPayload = {
    type: "result",
    operation,
    status: "pending",
    sourceId,
    prompt,
    aspectRatio,
    interactionId: interaction.id || undefined,
    providerUri: interaction.outputUri,
    provider: interaction.provider ?? (source ? "omni" : "veo"),
    resolution: options?.resolution,
    durationSeconds: options?.durationSeconds,
    narration: options?.narration,
  };
  if (interaction.video)
    return persistOutput(userId, recordId, pending, interaction.video);
  await saveRecord(userId, VIDEO_KIND, pending, recordId);
  // URI delivery is intentionally resolved by the explicit status procedure.
  // This keeps source fetch + Gemini upload + interaction creation bounded and
  // prevents a large output download from extending the mutation indefinitely.
  return publicPayload(recordId, pending);
}

export const videoRouter = router({
  /**
   * Prompt-grounded animated teaching is intentionally separate from the
   * cinematic Veo generate/edit procedures below. It uses the saved script,
   * natural narration, and deterministic whiteboard renderer.
   */
  professor: professorVideoRouter,

  upload: lockedProcedure
    .input(sourceInput())
    .mutation(async ({ input, ctx }) => {
      const bytes = decodeDataUrl(input.dataUrl);
      return storeVideoSource(ctx.user.id, {
        bytes,
        name: input.name,
        mimeType: input.mimeType,
      });
    }),

  list: lockedProcedure.query(async ({ ctx }) => {
    const records = await listRecords(ctx.user.id, VIDEO_KIND, 50);
    return records.map(record =>
      publicPayload(record.id, record.payload as VideoPayload)
    );
  }),

  generate: lockedProcedure
    .input(operationInput)
    .mutation(({ input, ctx }) =>
      startOperation(ctx.user.id, "generate", input.prompt, input.aspectRatio, undefined, {
        resolution: input.resolution,
        durationSeconds: input.durationSeconds,
        narration: input.narration,
      })
    ),

  edit: lockedProcedure
    .input(editInput)
    .mutation(({ input, ctx }) =>
      startOperation(
        ctx.user.id,
        "edit",
        input.prompt,
        input.aspectRatio,
        input.sourceId,
        { narration: input.narration }
      )
    ),

  status: lockedProcedure
    .input(z.object({ id: z.string().min(1).max(100) }))
    .query(async ({ input, ctx }) => {
      const record = await getRecord(ctx.user.id, VIDEO_KIND, input.id);
      const payload = record?.payload as VideoPayload | undefined;
      if (!record || payload?.type !== "result")
        throw notFound("That video result is not available.");
      if (
        payload.status !== "pending" ||
        (!payload.interactionId && !payload.providerUri)
      )
        return publicPayload(input.id, payload);
      try {
        const interaction = payload.interactionId
          ? payload.provider === "veo"
            ? await getGeminiVideoOperation(payload.interactionId)
            : await getGeminiInteraction(payload.interactionId)
          : { id: "", outputUri: payload.providerUri, status: "completed" };
        const resolved = await resolveGeminiVideo(
          interaction.id,
          interaction.outputUri ?? payload.providerUri,
          payload.provider
        );
        if (resolved.video)
          return persistOutput(ctx.user.id, input.id, payload, resolved.video);
        if (["failed", "error", "cancelled"].includes(resolved.status)) {
          const failed = {
            ...payload,
            status: "failed" as const,
            error:
              resolved.error ??
              "Gemini video generation failed. No playable video was returned.",
          };
          await saveRecord(ctx.user.id, VIDEO_KIND, failed, input.id);
          return publicPayload(input.id, failed);
        }
        return publicPayload(input.id, { ...payload, status: "pending" });
      } catch (error) {
        if (
          error instanceof VideoProviderError &&
          error.code === "BAD_REQUEST"
        ) {
          const failed = {
            ...payload,
            status: "failed" as const,
            error: error.message,
          };
          await saveRecord(ctx.user.id, VIDEO_KIND, failed, input.id);
          return publicPayload(input.id, failed);
        }
        throw providerError(error);
      }
    }),
});

export type VideoRouter = typeof videoRouter;
