import { afterEach, describe, expect, it, vi } from "vitest";
import {
  fetchDownloadFile,
  MAX_IMAGE_DOWNLOAD_BYTES,
  saveFile,
  shareFile,
} from "../client/src/lib/downloadMedia";

const originalDocument = globalThis.document;
const originalNavigator = globalThis.navigator;
const originalFetch = globalThis.fetch;

const pngBytes = Uint8Array.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d, 0x49,
  0x48, 0x44, 0x52,
]);
const jpegBytes = Uint8Array.from([
  0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0xff, 0xd9,
]);
const webpBytes = new TextEncoder().encode("RIFF\x00\x00\x00\x00WEBP");
const gifBytes = new TextEncoder().encode("GIF89a");
const mp4Bytes = new TextEncoder().encode(
  "\x00\x00\x00\x18ftypisom\x00\x00\x02\x00"
);
const pdfBytes = new TextEncoder().encode("%PDF-1.7\n1 0 obj\n");

function responseFor(
  bytes: Uint8Array,
  contentType = "application/octet-stream",
  headers: Record<string, string> = {}
) {
  return new Response(new Blob([bytes], { type: contentType }), {
    headers: { "content-type": contentType, ...headers },
  });
}

function installDocument() {
  const click = vi.fn();
  const remove = vi.fn();
  const anchor = {
    href: "",
    download: "",
    rel: "",
    style: { display: "" },
    click,
    remove,
  } as unknown as HTMLAnchorElement;
  const appendChild = vi.fn();
  const documentMock = {
    createElement: vi.fn(() => anchor),
    body: { appendChild, removeChild: vi.fn() },
  } as unknown as Document;

  Object.defineProperty(globalThis, "document", {
    configurable: true,
    value: documentMock,
  });
  return { anchor, click, remove, appendChild };
}

afterEach(() => {
  vi.restoreAllMocks();
  Object.defineProperty(globalThis, "document", {
    configurable: true,
    value: originalDocument,
  });
  Object.defineProperty(globalThis, "navigator", {
    configurable: true,
    value: originalNavigator,
  });
  globalThis.fetch = originalFetch;
});

describe("download media helpers", () => {
  it("sniffs a real PNG from octet-stream and corrects a misleading extension", async () => {
    globalThis.fetch = vi.fn().mockResolvedValue(responseFor(pngBytes));

    const file = await fetchDownloadFile(
      "https://storage.example/signed/image?token=secret",
      "adus-image.jpg"
    );

    expect(file).toBeInstanceOf(File);
    expect(file.name).toBe("adus-image.png");
    expect(file.type).toBe("image/png");
    expect(file.size).toBe(pngBytes.length);
  });

  it("sniffs JPEG, WEBP, GIF, MP4, and PDF despite generic or misleading types", async () => {
    globalThis.fetch = vi
      .fn()
      .mockResolvedValueOnce(responseFor(jpegBytes, "image/png"))
      .mockResolvedValueOnce(responseFor(webpBytes))
      .mockResolvedValueOnce(responseFor(gifBytes))
      .mockResolvedValueOnce(responseFor(mp4Bytes))
      .mockResolvedValueOnce(responseFor(pdfBytes, "text/html"));

    await expect(
      fetchDownloadFile("https://storage.example/jpeg", "photo.png")
    ).resolves.toMatchObject({ type: "image/jpeg", name: "photo.jpg" });
    await expect(
      fetchDownloadFile("https://storage.example/webp", "photo.jpg")
    ).resolves.toMatchObject({ type: "image/webp", name: "photo.webp" });
    await expect(
      fetchDownloadFile("https://storage.example/gif", "animation.bin")
    ).resolves.toMatchObject({ type: "image/gif", name: "animation.gif" });
    await expect(
      fetchDownloadFile("https://storage.example/video", "chapter.png")
    ).resolves.toMatchObject({ type: "video/mp4", name: "chapter.mp4" });
    await expect(
      fetchDownloadFile("https://storage.example/document", "notes.txt")
    ).resolves.toMatchObject({ type: "application/pdf", name: "notes.pdf" });
  });

  it("rejects HTML error pages even when the response claims to be an image", async () => {
    globalThis.fetch = vi
      .fn()
      .mockResolvedValue(
        responseFor(
          new TextEncoder().encode(
            "<!doctype html><html><body>Access denied</body></html>"
          ),
          "image/png"
        )
      );

    await expect(
      fetchDownloadFile("https://storage.example/error", "error.png")
    ).rejects.toThrow("HTML");
  });

  it("rejects unknown contents and enforces the image cap before reading the body", async () => {
    globalThis.fetch = vi
      .fn()
      .mockResolvedValueOnce(
        responseFor(new TextEncoder().encode("not media"), "text/plain")
      )
      .mockResolvedValueOnce(
        new Response(null, {
          headers: {
            "content-type": "image/png",
            "content-length": String(MAX_IMAGE_DOWNLOAD_BYTES + 1),
          },
        })
      );

    await expect(
      fetchDownloadFile("https://storage.example/text", "x.txt")
    ).rejects.toThrow("supported PNG");
    await expect(
      fetchDownloadFile(
        "https://storage.example/large-image",
        "x.png",
        MAX_IMAGE_DOWNLOAD_BYTES
      )
    ).rejects.toThrow("20 MB");
  });

  it("enforces the cap while streaming when content-length is missing", async () => {
    globalThis.fetch = vi
      .fn()
      .mockResolvedValue(responseFor(pngBytes, "application/octet-stream"));

    await expect(
      fetchDownloadFile(
        "https://storage.example/streamed-image",
        "x.png",
        pngBytes.length - 1
      )
    ).rejects.toThrow("download limit");
  });

  it("downloads a local object URL through a temporary anchor, not a remote anchor", () => {
    vi.useFakeTimers();
    const { anchor, click, remove, appendChild } = installDocument();
    const createObjectURL = vi.spyOn(URL, "createObjectURL");
    const revokeObjectURL = vi.spyOn(URL, "revokeObjectURL");
    const file = new File(
      [new Blob([pngBytes], { type: "image/png" })],
      "photo.png",
      {
        type: "image/png",
      }
    );

    saveFile(file);

    expect(createObjectURL).toHaveBeenCalledWith(file);
    expect(anchor.href).toMatch(/^blob:/);
    expect(anchor.href).not.toContain("storage.example");
    expect(anchor.download).toBe("photo.png");
    expect(click).toHaveBeenCalledOnce();
    expect(appendChild).toHaveBeenCalledWith(anchor);
    expect(remove).toHaveBeenCalledOnce();

    vi.advanceTimersByTime(1000);
    expect(revokeObjectURL).not.toHaveBeenCalled();
    vi.advanceTimersByTime(29_000);
    expect(revokeObjectURL).toHaveBeenCalledWith(anchor.href);
    vi.useRealTimers();
  });

  it("shares the preloaded File only when file sharing is supported", async () => {
    const canShare = vi.fn().mockReturnValue(true);
    const share = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: { canShare, share },
    });
    const file = new File([pngBytes], "photo.png", { type: "image/png" });

    await expect(shareFile(file)).resolves.toBe(true);
    expect(canShare).toHaveBeenCalledWith({ files: [file] });
    expect(share).toHaveBeenCalledWith({ files: [file] });
  });
});
