import { beforeEach, describe, it, expect, vi } from "vitest";
import express from "express";
const m = vi.hoisted(() => ({ list: vi.fn(), signed: vi.fn() }));
vi.mock("./workspaceStore", () => ({ listRecords: m.list }));
vi.mock("./storage", () => ({ storageGetSignedUrl: m.signed }));
import {
  mediaRouter,
  signMediaTicket,
  verifyMediaTicket,
  registerMediaDownloads,
} from "./mediaDownloads";
const ctx = {
  user: { id: 7, role: "user" },
  req: { headers: {} },
  res: {},
} as any;
beforeEach(() => {
  vi.restoreAllMocks();
  m.list.mockReset();
  m.signed.mockReset();
  m.list.mockResolvedValue([]);
});
describe("private media downloads", () => {
  it("signs a short-lived local ticket and detects tampering/expiry", () => {
    const ticket = signMediaTicket("images/7/test.png", "test.png");
    expect(verifyMediaTicket(ticket).key).toBe("images/7/test.png");
    expect(() => verifyMediaTicket(ticket + "x")).toThrow();
    expect(() =>
      verifyMediaTicket(signMediaTicket("test.png", "test.png", 1))
    ).toThrow();
  });
  it("does not proxy arbitrary URLs or another user’s media", async () => {
    await expect(
      mediaRouter
        .createCaller(ctx)
        .ticket({ url: "https://example.com/a.png", filename: "a.png" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      mediaRouter
        .createCaller(ctx)
        .ticket({ url: "/manus-storage/images/99/a.png", filename: "a.png" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
  it("authorizes the actual stored object from the owner’s history", async () => {
    m.list.mockResolvedValue([
      { payload: { url: "/manus-storage/images/7/a.png" } },
    ]);
    const result = await mediaRouter
      .createCaller(ctx)
      .ticket({ url: "/manus-storage/images/7/a.png", filename: "a.png" });
    expect(result.url).toMatch(/^\/api\/media-download\?ticket=/);
    expect(m.list).toHaveBeenCalledWith(7, "images", 10000);
  });
  it("authorizes a professor video without borrowing another user history", async () => {
    m.list.mockImplementation(async (userId, kind) =>
      userId === 7 && kind === "professor-video"
        ? [{ payload: { url: "/manus-storage/whiteboard/7/prof.mp4" } }]
        : []
    );
    const r = await mediaRouter
      .createCaller(ctx)
      .ticket({
        url: "/manus-storage/whiteboard/7/prof.mp4",
        filename: "prof.mp4",
      });
    expect(r.url).toContain("/api/media-download?ticket=");
    expect(m.list).toHaveBeenCalledWith(7, "professor-video", 10000);
  });
  it("serves actual PNG bytes with attachment headers even when storage says octet-stream", async () => {
    const app = express();
    registerMediaDownloads(app);
    const server = app.listen(0);
    const port = (server.address() as any).port;
    const originalFetch = globalThis.fetch;
    const png = Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aK8sAAAAASUVORK5CYII=",
      "base64"
    );
    m.signed.mockResolvedValue("https://storage.test/a");
    vi.spyOn(globalThis, "fetch").mockImplementation(async (input, init) =>
      String(input).startsWith("https://storage.test")
        ? new Response(png, {
            headers: { "content-type": "application/octet-stream" },
          })
        : originalFetch(input, init)
    );
    try {
      const result = await originalFetch(
        `http://127.0.0.1:${port}/api/media-download?ticket=${signMediaTicket("images/a.png", "photo.png")}`
      );
      expect(result.headers.get("content-type")).toBe("image/png");
      expect(result.headers.get("content-disposition")).toContain("attachment");
      expect(Buffer.from(await result.arrayBuffer()).equals(png)).toBe(true);
    } finally {
      server.close();
    }
  }, 15000);
  it("blocks unsigned HTTP downloads", async () => {
    const app = express();
    registerMediaDownloads(app);
    const server = app.listen(0);
    try {
      const r = await fetch(
        `http://127.0.0.1:${(server.address() as any).port}/api/media-download?ticket=bad`
      );
      expect(r.status).toBe(403);
      expect(m.signed).not.toHaveBeenCalled();
    } finally {
      server.close();
    }
  });
});
