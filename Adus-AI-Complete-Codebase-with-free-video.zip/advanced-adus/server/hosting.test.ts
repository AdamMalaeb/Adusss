import { beforeEach, describe, expect, it, vi } from "vitest";
import { unzipSync, strFromU8 } from "fflate";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getRecord: vi.fn(),
  saveRecord: vi.fn(),
}));

vi.mock("./workspaceStore", () => ({
  getRecord: mocks.getRecord,
  saveRecord: mocks.saveRecord,
}));

import { hostingRouter } from "./hostingRouter";

const website = {
  id: "website-1",
  payload: {
    title: "Safferni Tours",
    summary: "A travel landing page",
    html: '<!doctype html><html><head><meta name="viewport" content="width=device-width"></head><body><main><h1>Safferni Tours</h1></main></body></html>',
  },
  createdAt: 1,
  updatedAt: 1,
};

function caller(userId = 1) {
  return hostingRouter.createCaller({
    user: { id: userId, email: `user-${userId}@example.com` },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}

function unauthenticatedCaller() {
  return hostingRouter.createCaller({
    user: null,
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}

function response(body: unknown, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: vi.fn().mockResolvedValue(body),
  } as unknown as Response;
}

describe("adus.hosting", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubGlobal("fetch", vi.fn());
    mocks.getRecord.mockResolvedValue(website);
    mocks.saveRecord.mockImplementation(
      async (userId: number, kind: string, payload: unknown, id: string) => ({
        id,
        userId,
        kind,
        payload,
        createdAt: 1,
        updatedAt: 2,
      })
    );
  });

  it("protects publish and status routes", async () => {
    await expect(
      unauthenticatedCaller().publish({
        websiteId: "website-1",
        host: "netlify",
        siteName: "safferni-tours",
        token: "pat-test",
        confirm: true,
      })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(
      unauthenticatedCaller().status({ id: "deployment-1" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("reports adapter readiness without exposing provider credentials", async () => {
    const result = await caller().configuration();
    expect(result).toMatchObject({
      netlify: {
        host: "netlify",
        adapter: "ready",
        userTokenSupported: true,
        credentialEnv: "NETLIFY_ACCESS_TOKEN",
      },
      github: {
        host: "github",
        adapter: "ready",
        userTokenSupported: true,
        credentialEnv: "GITHUB_PAGES_TOKEN",
      },
      vercel: { adapter: "coming-soon", userTokenSupported: false },
      other: { adapter: "export", userTokenSupported: false },
    });
    expect(JSON.stringify(result)).not.toMatch(/pat|token-value|secret/i);
  });

  it("scopes website lookup to the signed-in owner", async () => {
    mocks.getRecord.mockResolvedValue(undefined);
    await expect(
      caller(42).publish({
        websiteId: "website-1",
        host: "netlify",
        siteName: "safferni-tours",
        token: "pat-test",
        confirm: true,
      })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(mocks.getRecord).toHaveBeenCalledWith(42, "website", "website-1");
    expect(fetch).not.toHaveBeenCalled();
  });

  it("does not call any provider before the final confirmation", async () => {
    await expect(
      caller().publish({
        websiteId: "website-1",
        host: "netlify",
        siteName: "safferni-tours",
        token: "pat-test",
        confirm: false,
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(fetch).not.toHaveBeenCalled();
  });

  it("requires confirmation for GitHub Pages before calling GitHub", async () => {
    await expect(
      caller().publish({
        websiteId: "website-1",
        host: "github",
        siteName: "safferni-tours",
        token: "github-pat",
        confirm: false,
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(fetch).not.toHaveBeenCalled();
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });

  it("returns an honest unsupported-host precondition without making an API call", async () => {
    await expect(
      caller().publish({
        websiteId: "website-1",
        host: "vercel",
        siteName: "safferni-tours",
        token: "not-used",
        confirm: true,
      })
    ).rejects.toMatchObject({
      code: "PRECONDITION_FAILED",
      message:
        "This host adapter is not configured yet. Export the HTML file and publish it with your host.",
    });
    expect(fetch).not.toHaveBeenCalled();
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });

  it("verifies the token, creates a site, uploads a complete ZIP, and only publishes a ready HTTPS deploy", async () => {
    const deployResponses = [
      response({ id: "netlify-user" }),
      response({ id: "site-1", name: "safferni-tours" }),
      response({ id: "deploy-1", state: "uploading" }),
      response({
        id: "deploy-1",
        state: "ready",
        ssl_url: "https://safferni-tours.netlify.app",
      }),
    ];
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockImplementation(async () => deployResponses.shift()!);

    const result = await caller().publish({
      websiteId: "website-1",
      host: "netlify",
      siteName: "Safferni-Tours",
      token: "pat-test",
      confirm: true,
    });

    expect(result).toMatchObject({
      state: "published",
      url: "https://safferni-tours.netlify.app",
    });
    expect(result.id).toMatch(/^deployment-/);
    expect(fetchMock).toHaveBeenCalledTimes(4);
    expect(fetchMock.mock.calls[0]?.[0]).toBe(
      "https://api.netlify.com/api/v1/user"
    );
    expect(fetchMock.mock.calls[0]?.[1]).toMatchObject({
      method: "GET",
      headers: expect.objectContaining({ Authorization: "Bearer pat-test" }),
    });
    expect(fetchMock.mock.calls[1]?.[0]).toBe(
      "https://api.netlify.com/api/v1/sites"
    );
    expect(
      JSON.parse(
        String(
          fetchMock.mock.calls[1]?.[1] &&
            (fetchMock.mock.calls[1]?.[1] as RequestInit).body
        )
      )
    ).toEqual({ name: "safferni-tours" });

    const deployRequest = fetchMock.mock.calls[2]?.[1] as RequestInit;
    expect(fetchMock.mock.calls[2]?.[0]).toBe(
      "https://api.netlify.com/api/v1/sites/site-1/deploys"
    );
    expect(deployRequest.method).toBe("POST");
    expect(deployRequest.headers).toMatchObject({
      "Content-Type": "application/zip",
      Authorization: "Bearer pat-test",
    });
    expect(deployRequest.body).toBeInstanceOf(Uint8Array);
    const files = unzipSync(deployRequest.body as Uint8Array);
    expect(Object.keys(files)).toEqual(["index.html"]);
    expect(strFromU8(files["index.html"]!)).toBe(website.payload.html);

    expect(mocks.saveRecord).toHaveBeenCalledTimes(2);
    const finalSave = mocks.saveRecord.mock.calls[1];
    expect(finalSave?.[0]).toBe(1);
    expect(finalSave?.[1]).toBe("deployment");
    expect(finalSave?.[2]).toMatchObject({
      websiteId: "website-1",
      host: "netlify",
      siteName: "safferni-tours",
      siteId: "site-1",
      deployId: "deploy-1",
      state: "published",
      url: "https://safferni-tours.netlify.app",
    });
  });

  it("does not mark a deploy published when ready has no valid HTTPS URL", async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockImplementation(async () =>
      response({ id: "x", state: "ready", url: "http://insecure.example" })
    );
    const result = await caller().publish({
      websiteId: "website-1",
      host: "netlify",
      siteName: "safferni-tours",
      token: "pat-test",
      confirm: true,
    });
    expect(result).toMatchObject({ state: "failed" });
    expect(result).not.toHaveProperty("url");
  });

  it("returns a bounded actionable error when Netlify rejects a request", async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(response({ error: "token invalid" }, 401));

    await expect(
      caller().publish({
        websiteId: "website-1",
        host: "netlify",
        siteName: "safferni-tours",
        token: "pat-test",
        confirm: true,
      })
    ).rejects.toMatchObject({
      code: "BAD_GATEWAY",
      message: expect.stringContaining("Netlify rejected the token"),
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });

  it("creates a new public repository, uploads Base64 files without sha, and returns processing", async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock
      .mockResolvedValueOnce(response({ login: "octocat" }))
      .mockResolvedValueOnce(
        response(
          {
            name: "safferni-pages",
            owner: { login: "octocat" },
            default_branch: "main",
            html_url: "https://github.com/octocat/safferni-pages",
          },
          201
        )
      )
      .mockResolvedValueOnce(response({ content: { path: "index.html" } }, 201))
      .mockResolvedValueOnce(response({ content: { path: ".nojekyll" } }, 201))
      .mockResolvedValueOnce(response({ status: "building" }, 201));

    const result = await caller().publish({
      websiteId: "website-1",
      host: "github",
      siteName: "Safferni-Pages",
      token: "github-pat",
      confirm: true,
    });

    expect(result).toMatchObject({ state: "processing", host: "github" });
    expect(fetchMock).toHaveBeenCalledTimes(5);
    expect(fetchMock.mock.calls.map(call => call[0])).toEqual([
      "https://api.github.com/user",
      "https://api.github.com/user/repos",
      "https://api.github.com/repos/octocat/safferni-pages/contents/index.html",
      "https://api.github.com/repos/octocat/safferni-pages/contents/.nojekyll",
      "https://api.github.com/repos/octocat/safferni-pages/pages",
    ]);

    const createRequest = fetchMock.mock.calls[1]?.[1] as RequestInit;
    expect(JSON.parse(String(createRequest.body))).toEqual({
      name: "safferni-pages",
      private: false,
      auto_init: true,
    });
    const indexRequest = fetchMock.mock.calls[2]?.[1] as RequestInit;
    const indexBody = JSON.parse(String(indexRequest.body));
    expect(indexBody.branch).toBe("main");
    expect(indexBody.content).toBe(
      Buffer.from(website.payload.html, "utf8").toString("base64")
    );
    expect(indexBody).not.toHaveProperty("sha");
    const nojekyllBody = JSON.parse(
      String((fetchMock.mock.calls[3]?.[1] as RequestInit).body)
    );
    expect(nojekyllBody.content).toBe("");
    expect(nojekyllBody).not.toHaveProperty("sha");
    expect(
      JSON.parse(String((fetchMock.mock.calls[4]?.[1] as RequestInit).body))
    ).toEqual({
      source: { branch: "main", path: "/" },
    });
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      1,
      "deployment",
      expect.objectContaining({
        host: "github",
        githubOwner: "octocat",
        githubRepo: "safferni-pages",
        githubBranch: "main",
        state: "processing",
      }),
      expect.stringMatching(/^deployment-/)
    );
  });

  it("rejects a repository response outside the authenticated owner before uploading files", async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock
      .mockResolvedValueOnce(response({ login: "octocat" }))
      .mockResolvedValueOnce(
        response(
          {
            name: "safferni-pages",
            owner: { login: "someone-else" },
            default_branch: "main",
          },
          201
        )
      );

    await expect(
      caller().publish({
        websiteId: "website-1",
        host: "github",
        siteName: "safferni-pages",
        token: "github-pat",
        confirm: true,
      })
    ).rejects.toMatchObject({ code: "BAD_GATEWAY" });
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(
      fetchMock.mock.calls.some(call => String(call[0]).includes("/contents/"))
    ).toBe(false);
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });

  it("checks the actual GitHub Pages build before returning published", async () => {
    const deployment = {
      id: "deployment-github",
      payload: {
        websiteId: "website-1",
        host: "github",
        siteName: "safferni-pages",
        siteId: "safferni-pages",
        deployId: "octocat/safferni-pages",
        githubOwner: "octocat",
        githubRepo: "safferni-pages",
        githubBranch: "main",
        state: "processing",
      },
    };
    mocks.getRecord.mockResolvedValue(deployment);
    mocks.saveRecord.mockResolvedValue({
      ...deployment,
      payload: {
        ...deployment.payload,
        state: "published",
        url: "https://octocat.github.io/safferni-pages/",
      },
    });
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValueOnce(
      response({
        status: "built",
        html_url: "https://octocat.github.io/safferni-pages/",
      })
    );

    const result = await caller().check({
      id: "deployment-github",
      token: "github-pat",
    });

    expect(result).toEqual({
      id: "deployment-github",
      host: "github",
      state: "published",
      url: "https://octocat.github.io/safferni-pages/",
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.github.com/repos/octocat/safferni-pages/pages",
      expect.objectContaining({ method: "GET" })
    );
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      1,
      "deployment",
      expect.objectContaining({
        state: "published",
        url: "https://octocat.github.io/safferni-pages/",
      }),
      "deployment-github"
    );
  });
});
