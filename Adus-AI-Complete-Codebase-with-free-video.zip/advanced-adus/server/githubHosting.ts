const GITHUB_API_ORIGIN = "https://api.github.com";
const GITHUB_API_VERSION = "2022-11-28";

type GithubResponse = Record<string, unknown>;

function githubPath(owner: string, repo: string, suffix: string) {
  return `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}${suffix}`;
}

function githubHeaders(token: string, json = false) {
  return {
    Accept: "application/vnd.github+json",
    Authorization: `Bearer ${token}`,
    "X-GitHub-Api-Version": GITHUB_API_VERSION,
    ...(json ? { "Content-Type": "application/json" } : {}),
  };
}

async function githubRequest(
  path: string,
  token: string,
  init: RequestInit,
  failureMessage: string,
  allowEmpty = false
): Promise<GithubResponse> {
  if (!path.startsWith("/") || path.includes("//")) {
    throw new Error("Invalid GitHub API path");
  }
  let response: Response;
  try {
    response = await fetch(`${GITHUB_API_ORIGIN}${path}`, {
      ...init,
      headers: { ...githubHeaders(token, Boolean(init.body)), ...init.headers },
      redirect: "error",
      signal: AbortSignal.timeout(15_000),
    });
  } catch {
    throw new Error(failureMessage);
  }
  let body: unknown;
  try {
    body = await response.json();
  } catch {
    body = undefined;
  }
  if (!response.ok) throw new Error(failureMessage);
  if (!body || typeof body !== "object") {
    if (allowEmpty && response.status === 204) return {};
    throw new Error("GitHub returned an invalid response. Please try again.");
  }
  return body as GithubResponse;
}

function stringField(value: unknown, field: string, failureMessage: string) {
  if (typeof value !== "string" || !value.trim())
    throw new Error(failureMessage);
  return value;
}

export type GithubRepository = {
  owner: string;
  repo: string;
  branch: string;
  htmlUrl?: string;
};

export type GithubPageStatus = {
  state: "processing" | "published" | "failed";
  url?: string;
};

export async function verifyGithubToken(token: string) {
  const user = await githubRequest(
    "/user",
    token,
    { method: "GET" },
    "GitHub could not verify that token. Check it and try again."
  );
  return stringField(
    user.login,
    "login",
    "GitHub did not return the authenticated account. Check the token and try again."
  );
}

export async function createGithubRepository(
  token: string,
  repoName: string
): Promise<GithubRepository> {
  const authenticatedLogin = await verifyGithubToken(token);
  const repository = await githubRequest(
    "/user/repos",
    token,
    {
      method: "POST",
      body: JSON.stringify({ name: repoName, private: false, auto_init: true }),
    },
    "GitHub could not create the repository. Use a new repository name and check your token permissions."
  );
  const owner = stringField(
    (repository.owner as GithubResponse | undefined)?.login,
    "owner.login",
    "GitHub returned no repository owner. The repository was not published."
  );
  if (owner.toLowerCase() !== authenticatedLogin.toLowerCase()) {
    throw new Error(
      "GitHub returned a repository outside the authenticated account. The repository was not published."
    );
  }
  const repo = stringField(
    repository.name,
    "name",
    "GitHub returned no repository name. The repository was not published."
  );
  const branch = stringField(
    repository.default_branch,
    "default_branch",
    "GitHub returned no default branch. The repository was not published."
  );
  return {
    owner,
    repo,
    branch,
    htmlUrl:
      typeof repository.html_url === "string" ? repository.html_url : undefined,
  };
}

async function putRepositoryFile(
  token: string,
  repository: GithubRepository,
  path: string,
  content: string,
  commitMessage: string
) {
  await githubRequest(
    githubPath(repository.owner, repository.repo, `/contents/${path}`),
    token,
    {
      method: "PUT",
      body: JSON.stringify({
        message: commitMessage,
        content: Buffer.from(content, "utf8").toString("base64"),
        branch: repository.branch,
      }),
    },
    "GitHub could not upload the reviewed website files. The repository remains available without an overwrite."
  );
}

export async function publishGithubRepository(
  token: string,
  repoName: string,
  html: string
): Promise<GithubRepository> {
  const repository = await createGithubRepository(token, repoName);
  // The repository was just created with auto_init, so both writes intentionally omit sha.
  // That makes an existing-file overwrite impossible in this operation.
  await putRepositoryFile(
    token,
    repository,
    "index.html",
    html,
    "Publish reviewed website index"
  );
  await putRepositoryFile(
    token,
    repository,
    ".nojekyll",
    "",
    "Disable Jekyll for static website"
  );
  await githubRequest(
    githubPath(repository.owner, repository.repo, "/pages"),
    token,
    {
      method: "POST",
      body: JSON.stringify({
        source: { branch: repository.branch, path: "/" },
      }),
    },
    "GitHub could not configure Pages for the new repository. The repository remains available for review."
  );
  return repository;
}

function httpsUrl(value: unknown) {
  if (typeof value !== "string" || !value) return undefined;
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? value : undefined;
  } catch {
    return undefined;
  }
}

export async function getGithubPageStatus(
  token: string,
  repository: GithubRepository
): Promise<GithubPageStatus> {
  const page = await githubRequest(
    githubPath(repository.owner, repository.repo, "/pages"),
    token,
    { method: "GET" },
    "GitHub could not check the Pages build yet. Keep this window open and try again."
  );
  const status =
    typeof page.status === "string" ? page.status.toLowerCase() : "";
  if (
    ["errored", "error", "failed", "canceled", "cancelled"].includes(status)
  ) {
    return { state: "failed" };
  }
  const url = httpsUrl(page.html_url);
  if (status === "built" && url) return { state: "published", url };
  return { state: "processing" };
}
