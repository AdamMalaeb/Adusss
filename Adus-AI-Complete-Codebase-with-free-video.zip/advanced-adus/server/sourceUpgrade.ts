import { randomUUID } from "node:crypto";
import { jsonrepair } from "jsonrepair";
import { z } from "zod";
import { isLockedOwner } from "../shared/accessPolicy";
import { invokeLLM, selectChatModel, type InvokeParams } from "./_core/llm";

export const MAX_SOURCE_FILES = 32;
export const MAX_SOURCE_FILE_BYTES = 64_000;
export const MAX_SOURCE_CONTEXT_BYTES = 260_000;
export const MAX_CHANGED_FILES = 8;
export const MAX_CHANGED_FILE_BYTES = 80_000;
export const MAX_CHANGED_TOTAL_BYTES = 240_000;

const allowedSourceRoots = [
  "client/src/",
  "server/",
  "shared/",
  "drizzle/",
  "docs/",
] as const;
const allowedRootFiles = new Set(["package.json"]);

const protectedPathPatterns = [
  /(^|\/)\.env(?:$|\.)/i,
  /(^|\/)\.github\/workflows(?:\/|$)/i,
  /(^|\/)server\/_core(?:\/|$)/i,
  /(^|\/)(?:auth|authentication)(?:\/|[._-])/i,
  /(^|\/)(?:permission|permissions|rbac|roles?)(?:\/|[._-])/i,
  /(^|\/)(?:billing|payment|payments|checkout)(?:\/|[._-])/i,
  /(^|\/)(?:secret|secrets|credential|credentials)(?:\/|[._-])/i,
  /(^|\/)package-lock\.json$/i,
  /(^|\/)pnpm-lock\.yaml$/i,
  /(^|\/)yarn\.lock$/i,
  /(^|\/)server\/(?:upgradeRouter|sourceUpgrade)\.ts$/i,
  /(^|\/)server\/workspaceExtensions\.ts$/i,
  /(^|\/)client\/src\/pages\/Upgrade\.tsx$/i,
  /(^|\/)client\/src\/pages\/WorkspaceExtension\.tsx$/i,
  /(^|\/)client\/src\/components\/DashboardLayout\.tsx$/i,
  /(^|\/)client\/src\/App\.tsx$/i,
];

const allowedExtensions = new Set([
  ".cjs",
  ".css",
  ".html",
  ".js",
  ".jsx",
  ".json",
  ".md",
  ".mjs",
  ".sql",
  ".ts",
  ".tsx",
]);

export type GitHubRepository = {
  owner: string;
  name: string;
  slug: string;
};

export type SourceUpgradeConfig = {
  rawRepository: string;
  repository: GitHubRepository | null;
  token: string;
  baseBranch?: string;
};

export type SourceUpgradeConfigStatus = {
  configured: boolean;
  repository?: string;
  baseBranch?: string;
  missing: string[];
  message: string;
};

export type SourceUpgradeErrorCode =
  | "CONFIGURATION"
  | "CONFLICT"
  | "FORBIDDEN_REPOSITORY"
  | "INVALID_PROPOSAL"
  | "GITHUB";

export class SourceUpgradeError extends Error {
  readonly code: SourceUpgradeErrorCode;

  constructor(code: SourceUpgradeErrorCode, message: string) {
    super(message);
    this.name = "SourceUpgradeError";
    this.code = code;
  }
}

export function parseGitHubRepository(value: string): GitHubRepository | null {
  const trimmed = value.trim().replace(/\.git$/, "");
  const match = trimmed.match(
    /^(?:https?:\/\/github\.com\/)?([^/\s]+)\/([^/\s]+?)(?:\/)?$/i
  );
  if (!match) return null;
  const [, owner, name] = match;
  if (!owner || !name || owner.length > 100 || name.length > 100) return null;
  if (!/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(name))
    return null;
  return { owner, name, slug: `${owner}/${name}` };
}

export function getSourceUpgradeConfig(
  env: NodeJS.ProcessEnv = process.env
): SourceUpgradeConfig {
  const rawRepository = env.ADUS_SOURCE_REPO?.trim() ?? "";
  return {
    rawRepository,
    repository: parseGitHubRepository(rawRepository),
    // GITHUB_SOURCE_TOKEN is canonical; retain the old alias for migration.
    token:
      env.GITHUB_SOURCE_TOKEN?.trim() || env.ADUS_GITHUB_TOKEN?.trim() || "",
    baseBranch: env.ADUS_SOURCE_BASE_BRANCH?.trim() || undefined,
  };
}

export function getSourceUpgradeConfigStatus(
  config: SourceUpgradeConfig
): SourceUpgradeConfigStatus {
  const missing: string[] = [];
  if (!config.rawRepository) missing.push("ADUS_SOURCE_REPO");
  else if (!config.repository) {
    return {
      configured: false,
      missing: ["ADUS_SOURCE_REPO"],
      message:
        "ADUS_SOURCE_REPO must be a GitHub owner/repository or https://github.com/owner/repository.",
    };
  }
  if (!config.token) missing.push("GITHUB_SOURCE_TOKEN");
  if (missing.length > 0) {
    return {
      configured: false,
      repository: config.repository?.slug,
      baseBranch: config.baseBranch,
      missing,
      message: `Source upgrades are not connected. Configure ${missing.join(" and ")} in the deployed server environment; no source mutation is attempted.`,
    };
  }
  return {
    configured: true,
    repository: config.repository?.slug,
    baseBranch: config.baseBranch,
    missing: [],
    message:
      "Repository connection is configured. The repository must be private; proposals are reviewed before a draft PR is created.",
  };
}

export function isSourceUpgradeOwner(
  user: { email?: string | null; role?: string | null; openId?: string | null },
  _legacyOwnerOpenId?: string
): boolean {
  // Keep the optional second parameter for callers compiled against the old
  // helper, but deliberately ignore roles and OWNER_OPEN_ID. Locked access is
  // granted only from the authoritative authenticated email.
  return isLockedOwner(user);
}

export function isAllowedSourcePath(path: string): boolean {
  const normalized = path.replaceAll("\\", "/");
  if (
    !normalized ||
    normalized.startsWith("/") ||
    normalized.includes("..") ||
    protectedPathPatterns.some(pattern => pattern.test(normalized))
  )
    return false;
  if (
    !allowedRootFiles.has(normalized) &&
    !allowedSourceRoots.some(root => normalized.startsWith(root))
  )
    return false;
  const dot = normalized.lastIndexOf(".");
  return (
    dot > normalized.lastIndexOf("/") &&
    allowedExtensions.has(normalized.slice(dot).toLowerCase())
  );
}

export type GitHubFetch = typeof fetch;

type GitHubRepositoryResponse = {
  full_name: string;
  private: boolean;
  default_branch: string;
  html_url?: string;
};

type GitHubRefResponse = { object: { sha: string; type?: string } };
type GitHubTreeResponse = {
  sha: string;
  truncated?: boolean;
  tree: Array<{
    path: string;
    mode?: string;
    type?: string;
    sha: string;
    size?: number;
  }>;
};
type GitHubBlobResponse = { sha: string; content: string; encoding: string };
type GitHubCommitResponse = { sha: string; tree: { sha: string } };
type GitHubCreateResponse = { sha: string };
type GitHubPullResponse = {
  number: number;
  html_url: string;
  draft?: boolean;
  head?: { sha?: string };
};
type GitHubCheckRunsResponse = {
  total_count?: number;
  check_runs?: Array<{
    name?: string;
    status?: string;
    conclusion?: string | null;
    html_url?: string | null;
  }>;
};

const encodePath = (value: string) => encodeURIComponent(value);

export class GitHubSourceClient {
  private readonly baseUrl = "https://api.github.com";

  constructor(
    private readonly config: SourceUpgradeConfig,
    private readonly fetchImpl: GitHubFetch = fetch
  ) {
    if (!config.repository || !config.token) {
      throw new SourceUpgradeError(
        "CONFIGURATION",
        getSourceUpgradeConfigStatus(config).message
      );
    }
  }

  private repoPath() {
    const repository = this.config.repository!;
    return `/repos/${encodePath(repository.owner)}/${encodePath(repository.name)}`;
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const headers = new Headers(init.headers);
    headers.set("Accept", "application/vnd.github+json");
    headers.set("X-GitHub-Api-Version", "2022-11-28");
    headers.set("Authorization", `Bearer ${this.config.token}`);
    if (init.body && !headers.has("content-type"))
      headers.set("content-type", "application/json");
    let response: Response;
    try {
      response = await this.fetchImpl(`${this.baseUrl}${path}`, {
        ...init,
        headers,
      });
    } catch {
      throw new SourceUpgradeError(
        "GITHUB",
        "GitHub could not be reached. No source change was created."
      );
    }
    const text = await response.text();
    let parsed: unknown;
    try {
      parsed = text ? JSON.parse(text) : {};
    } catch {
      parsed = {};
    }
    if (!response.ok) {
      const message =
        typeof parsed === "object" && parsed && "message" in parsed
          ? String(
              (parsed as { message?: unknown }).message ??
                "GitHub request failed"
            )
          : "GitHub request failed";
      throw new SourceUpgradeError(
        "GITHUB",
        `GitHub request failed (${response.status}): ${message.slice(0, 240)}`
      );
    }
    return parsed as T;
  }

  async getRepository() {
    return this.request<GitHubRepositoryResponse>(this.repoPath());
  }

  async getRef(branch: string) {
    const ref = branch
      .split("/")
      .map(part => encodePath(part))
      .join("/");
    return this.request<GitHubRefResponse>(
      `${this.repoPath()}/git/ref/heads/${ref}`
    );
  }

  async getTree(commitSha: string) {
    return this.request<GitHubTreeResponse>(
      `${this.repoPath()}/git/trees/${encodePath(commitSha)}?recursive=1`
    );
  }

  async getBlob(blobSha: string) {
    return this.request<GitHubBlobResponse>(
      `${this.repoPath()}/git/blobs/${encodePath(blobSha)}`
    );
  }

  async getCommit(commitSha: string) {
    return this.request<GitHubCommitResponse>(
      `${this.repoPath()}/git/commits/${encodePath(commitSha)}`
    );
  }

  async createBlob(content: string) {
    return this.request<GitHubCreateResponse>(`${this.repoPath()}/git/blobs`, {
      method: "POST",
      body: JSON.stringify({ content, encoding: "utf-8" }),
    });
  }

  async createTree(
    baseTree: string,
    entries: Array<{ path: string; sha: string }>
  ) {
    return this.request<GitHubCreateResponse>(`${this.repoPath()}/git/trees`, {
      method: "POST",
      body: JSON.stringify({
        base_tree: baseTree,
        tree: entries.map(entry => ({
          path: entry.path,
          mode: "100644",
          type: "blob",
          sha: entry.sha,
        })),
      }),
    });
  }

  async createCommit(message: string, tree: string, parent: string) {
    return this.request<GitHubCreateResponse>(
      `${this.repoPath()}/git/commits`,
      {
        method: "POST",
        body: JSON.stringify({ message, tree, parents: [parent] }),
      }
    );
  }

  async createRef(branch: string, commitSha: string) {
    return this.request<GitHubCreateResponse>(`${this.repoPath()}/git/refs`, {
      method: "POST",
      body: JSON.stringify({ ref: `refs/heads/${branch}`, sha: commitSha }),
    });
  }

  async createDraftPullRequest(input: {
    title: string;
    body: string;
    head: string;
    base: string;
  }) {
    return this.request<GitHubPullResponse>(`${this.repoPath()}/pulls`, {
      method: "POST",
      body: JSON.stringify({ ...input, draft: true }),
    });
  }

  async getCheckRuns(commitSha: string) {
    return this.request<GitHubCheckRunsResponse>(
      `${this.repoPath()}/commits/${encodePath(commitSha)}/check-runs`
    );
  }
}

export type SourceSnapshotFile = {
  path: string;
  content: string;
  sha: string;
  size: number;
};

export type SourceSnapshot = {
  repository: string;
  baseBranch: string;
  baseCommit: string;
  files: SourceSnapshotFile[];
  knownPaths: Set<string>;
};

function sourceEntryPriority(path: string, request: string) {
  return request.toLowerCase().includes(path.toLowerCase()) ? 0 : 1;
}

export async function loadSourceSnapshot(
  client: GitHubSourceClient,
  request: string,
  requestedBranch?: string
): Promise<SourceSnapshot> {
  const repository = await client.getRepository();
  if (!repository.private) {
    throw new SourceUpgradeError(
      "FORBIDDEN_REPOSITORY",
      "The configured GitHub repository is public. Use a private repository for source upgrades; no source mutation was attempted."
    );
  }
  const baseBranch = requestedBranch?.trim() || "";
  const branch = baseBranch || repository.default_branch || "main";
  const ref = await client.getRef(branch);
  const tree = await client.getTree(ref.object.sha);
  if (tree.truncated) {
    throw new SourceUpgradeError(
      "GITHUB",
      "GitHub returned a truncated source tree. Narrow the repository or use a smaller source tree before proposing an upgrade."
    );
  }
  const knownPaths = new Set(
    tree.tree.filter(entry => entry.type === "blob").map(entry => entry.path)
  );
  const candidates = tree.tree
    .filter(
      entry =>
        entry.type === "blob" &&
        isAllowedSourcePath(entry.path) &&
        (entry.size ?? 0) <= MAX_SOURCE_FILE_BYTES
    )
    .sort(
      (a, b) =>
        sourceEntryPriority(a.path, request) -
          sourceEntryPriority(b.path, request) || a.path.localeCompare(b.path)
    );
  const files: SourceSnapshotFile[] = [];
  let contextBytes = 0;
  for (const entry of candidates) {
    if (files.length >= MAX_SOURCE_FILES) break;
    const blob = await client.getBlob(entry.sha);
    if (blob.encoding !== "base64") continue;
    let content: string;
    try {
      content = Buffer.from(blob.content.replace(/\s/g, ""), "base64").toString(
        "utf8"
      );
    } catch {
      continue;
    }
    const size = Buffer.byteLength(content, "utf8");
    if (
      size > MAX_SOURCE_FILE_BYTES ||
      contextBytes + size > MAX_SOURCE_CONTEXT_BYTES
    )
      continue;
    files.push({ path: entry.path, content, sha: entry.sha, size });
    contextBytes += size;
  }
  if (files.length === 0) {
    throw new SourceUpgradeError(
      "GITHUB",
      "No bounded, allowed source files were readable from the private repository. No source change was created."
    );
  }
  return {
    repository: repository.full_name,
    baseBranch: branch,
    baseCommit: ref.object.sha,
    files,
    knownPaths,
  };
}

const sourceModelProposalSchema = z.object({
  title: z.string().trim().min(1).max(120),
  summary: z.string().trim().min(1).max(2400),
  changedFiles: z
    .array(
      z.object({
        path: z.string().trim().min(1).max(240),
        content: z.string().max(MAX_CHANGED_FILE_BYTES),
        reason: z.string().trim().min(1).max(800),
      })
    )
    .max(MAX_CHANGED_FILES),
  tests: z.array(z.string().trim().min(1).max(500)).max(8),
});

export type SourceModelProposal = z.infer<typeof sourceModelProposalSchema>;
export type SourceChangedFile = SourceModelProposal["changedFiles"][number] & {
  originalContent: string;
  diff: string;
};

export type ValidatedSourceProposal = {
  title: string;
  summary: string;
  changedFiles: SourceChangedFile[];
  tests: string[];
  baseCommit: string;
  baseBranch: string;
  repository: string;
};

/** Convert Forge content variants into a single bounded text response. */
export function responseContentToText(raw: unknown): string | null {
  if (typeof raw === "string") return raw.trim() || null;
  if (!Array.isArray(raw)) return null;
  const text = raw
    .map(part => {
      if (typeof part === "string") return part;
      if (
        typeof part === "object" &&
        part !== null &&
        "text" in part &&
        typeof (part as { text?: unknown }).text === "string"
      )
        return (part as { text: string }).text;
      return "";
    })
    .join("")
    .trim();
  return text || null;
}

function validateDependencyManifestChange(
  originalContent: string,
  proposedContent: string
) {
  let before: Record<string, unknown>;
  let after: Record<string, unknown>;
  try {
    before = JSON.parse(originalContent) as Record<string, unknown>;
    after = JSON.parse(proposedContent) as Record<string, unknown>;
  } catch {
    throw new SourceUpgradeError(
      "INVALID_PROPOSAL",
      "package.json must remain valid JSON and only dependency changes are reviewable."
    );
  }
  const dependencyKeys = new Set(["dependencies", "devDependencies"]);
  for (const key of Array.from(
    new Set([...Object.keys(before), ...Object.keys(after)])
  )) {
    if (dependencyKeys.has(key)) continue;
    if (JSON.stringify(before[key]) !== JSON.stringify(after[key]))
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        "package.json changes are limited to dependencies and devDependencies."
      );
  }
  for (const key of Array.from(dependencyKeys)) {
    const value = after[key];
    if (value === undefined) continue;
    if (typeof value !== "object" || value === null || Array.isArray(value))
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        `package.json ${key} must remain an object.`
      );
    for (const [name, version] of Object.entries(value)) {
      if (!/^@[A-Za-z0-9._-]+\/[A-Za-z0-9._-]+$|^[A-Za-z0-9._-]+$/.test(name))
        throw new SourceUpgradeError(
          "INVALID_PROPOSAL",
          `package.json contains an invalid dependency name (${name}).`
        );
      if (
        typeof version !== "string" ||
        version.length > 120 ||
        !version.trim()
      )
        throw new SourceUpgradeError(
          "INVALID_PROPOSAL",
          `package.json contains an invalid dependency range (${name}).`
        );
    }
  }
}

/** Parse strict JSON, then make one bounded repair attempt and validate it. */
export function parseStructuredJson<T>(
  raw: unknown,
  schema: z.ZodType<T>,
  label: string
): T {
  const text = responseContentToText(raw);
  if (!text)
    throw new SourceUpgradeError(
      "INVALID_PROPOSAL",
      `${label} returned an empty response. No source change was created. Please retry with a narrower request.`
    );
  const cleaned = text
    .replace(/^\s*```(?:json)?\s*/i, "")
    .replace(/\s*```\s*$/i, "")
    .trim();
  let parsed: unknown;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    try {
      parsed = JSON.parse(jsonrepair(cleaned));
    } catch {
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        `${label} returned invalid structured output. No source change was created. Please retry with a narrower request.`
      );
    }
  }
  const result = schema.safeParse(parsed);
  if (!result.success) {
    const issue = result.error.issues[0];
    const location = issue?.path.length ? ` (${issue.path.join(".")})` : "";
    throw new SourceUpgradeError(
      "INVALID_PROPOSAL",
      `${label} returned a proposal that did not match the required schema${location}. No source change was created.`
    );
  }
  return result.data;
}

export function buildExactUnifiedDiff(
  path: string,
  originalContent: string,
  proposedContent: string
): string {
  const normalize = (value: string) => value.replace(/\r\n/g, "\n");
  const oldLines = normalize(originalContent).replace(/\n$/, "").split("\n");
  const newLines = normalize(proposedContent).replace(/\n$/, "").split("\n");
  const oldDisplay = originalContent.length === 0 ? [] : oldLines;
  const newDisplay = proposedContent.length === 0 ? [] : newLines;
  return [
    `--- a/${path}`,
    `+++ b/${path}`,
    `@@ -1,${oldDisplay.length} +1,${newDisplay.length} @@`,
    ...oldDisplay.map(line => `-${line}`),
    ...newDisplay.map(line => `+${line}`),
  ].join("\n");
}

export function validateSourceModelProposal(
  modelProposal: unknown,
  snapshot: SourceSnapshot
): ValidatedSourceProposal {
  const parsed = sourceModelProposalSchema.safeParse(modelProposal);
  if (!parsed.success)
    throw new SourceUpgradeError(
      "INVALID_PROPOSAL",
      "The code proposal did not match the required schema. No source change was created."
    );
  const proposal = parsed.data;
  if (proposal.changedFiles.length === 0) {
    throw new SourceUpgradeError(
      "INVALID_PROPOSAL",
      "The code agent did not propose a source change. Refine the request and try again."
    );
  }
  const seen = new Set<string>();
  let totalBytes = 0;
  const changedFiles: SourceChangedFile[] = [];
  for (const file of proposal.changedFiles) {
    const path = file.path.replaceAll("\\", "/");
    if (!isAllowedSourcePath(path)) {
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        `The proposal targets a protected or disallowed path (${path}). No source change was created.`
      );
    }
    if (seen.has(path)) {
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        `The proposal contains the file more than once (${path}). No source change was created.`
      );
    }
    seen.add(path);
    const existing = snapshot.files.find(candidate => candidate.path === path);
    if (!existing && snapshot.knownPaths.has(path)) {
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        `The proposal targets a source file outside the bounded snapshot (${path}). Try a narrower request so the file can be read first.`
      );
    }
    const proposedBytes = Buffer.byteLength(file.content, "utf8");
    totalBytes += proposedBytes;
    if (
      proposedBytes > MAX_CHANGED_FILE_BYTES ||
      totalBytes > MAX_CHANGED_TOTAL_BYTES
    ) {
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        "The proposed source change exceeds the bounded file-size limit. Narrow the request."
      );
    }
    const originalContent = existing?.content ?? "";
    if (originalContent === file.content) {
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        `The proposal does not change ${path}. No source change was created.`
      );
    }
    if (path === "package.json")
      validateDependencyManifestChange(originalContent, file.content);
    changedFiles.push({
      ...file,
      path,
      originalContent,
      diff: buildExactUnifiedDiff(path, originalContent, file.content),
    });
  }
  return {
    title: proposal.title,
    summary: proposal.summary,
    changedFiles,
    tests: proposal.tests,
    baseCommit: snapshot.baseCommit,
    baseBranch: snapshot.baseBranch,
    repository: snapshot.repository,
  };
}

const proposalSchemaForStoredPayload = z.object({
  title: z.string().min(1).max(120),
  summary: z.string().min(1).max(2400),
  changedFiles: z
    .array(
      z.object({
        path: z.string().min(1).max(240),
        content: z.string().max(MAX_CHANGED_FILE_BYTES),
        reason: z.string().min(1).max(800),
        originalContent: z.string().max(MAX_CHANGED_FILE_BYTES),
        diff: z.string().max(600_000),
      })
    )
    .min(1)
    .max(MAX_CHANGED_FILES),
  tests: z.array(z.string().min(1).max(500)).max(8),
  baseCommit: z.string().regex(/^[0-9a-f]{7,64}$/i),
  baseBranch: z.string().min(1).max(200),
  repository: z.string().min(3).max(220),
});

export type StoredSourceProposal = z.infer<
  typeof proposalSchemaForStoredPayload
>;

export function parseStoredSourceProposal(
  value: unknown
): StoredSourceProposal {
  return proposalSchemaForStoredPayload.parse(value);
}

const proposalPrompt = (request: string, snapshot: SourceSnapshot) => {
  const files = snapshot.files
    .map(file => `FILE: ${file.path}\n---\n${file.content}\n---`)
    .join("\n\n");
  return `User's requested code upgrade:\n${request}\n\nRepository: ${snapshot.repository}\nBase branch: ${snapshot.baseBranch}\nBase commit: ${snapshot.baseCommit}\n\nBounded allowed source snapshot (the only existing files you may edit):\n${files}`;
};

const proposalResponseFormat: NonNullable<InvokeParams["response_format"]> = {
  type: "json_schema",
  json_schema: {
    name: "source_upgrade_proposal",
    strict: true,
    schema: {
      type: "object",
      properties: {
        title: { type: "string" },
        summary: { type: "string" },
        changedFiles: {
          type: "array",
          maxItems: MAX_CHANGED_FILES,
          items: {
            type: "object",
            properties: {
              path: { type: "string" },
              content: { type: "string" },
              reason: { type: "string" },
            },
            required: ["path", "content", "reason"],
            additionalProperties: false,
          },
        },
        tests: { type: "array", maxItems: 8, items: { type: "string" } },
      },
      required: ["title", "summary", "changedFiles", "tests"],
      additionalProperties: false,
    },
  },
};

export async function createSourceProposal(
  request: string,
  config: SourceUpgradeConfig,
  options: {
    branch?: string;
    client?: GitHubSourceClient;
    llm?: typeof invokeLLM;
  } = {}
): Promise<ValidatedSourceProposal> {
  const status = getSourceUpgradeConfigStatus(config);
  if (!status.configured || !config.repository || !config.token)
    throw new SourceUpgradeError("CONFIGURATION", status.message);
  const client = options.client ?? new GitHubSourceClient(config);
  const snapshot = await loadSourceSnapshot(
    client,
    request,
    options.branch ?? config.baseBranch
  );
  const llm = options.llm ?? invokeLLM;
  let response;
  try {
    response = await llm({
      model: selectChatModel({ mode: "deep" }),
      reasoning: { effort: "medium" },
      maxCompletionTokens: 12_000,
      messages: [
        {
          role: "system",
          content:
            "You are Adus Code Review Agent. Propose one narrow, testable, reviewable repository change. Return JSON matching the schema exactly. You may edit only existing files shown in the bounded snapshot. You may add new TypeScript modules, API adapters, specialist agents, components and tests under client/src/, server/, shared/, or docs/ if their paths do not already exist. Return complete contents for every changed or added file. A reviewed package.json change may add or update dependencies or devDependencies only; never change scripts, engines, package manager, lockfiles, or other manifest fields. Read API keys only from server environment variables; never include a credential value or claim a new service is authorized. Never edit authentication, authorization, roles, permissions, billing, payment, secrets, .env, GitHub workflows, server framework internals, or the Adus upgrade control plane. Do not execute scripts, change deployment, publish code, delete files, merge PRs, or claim that tests ran. Preserve existing behavior unless the request requires a bounded fix. If the request cannot be implemented within these limits, return an empty changedFiles array and explain why in summary.",
        },
        { role: "user", content: proposalPrompt(request, snapshot) },
      ],
      response_format: proposalResponseFormat,
    });
  } catch {
    throw new SourceUpgradeError(
      "GITHUB",
      "The code proposal agent could not respond. No source change was created."
    );
  }
  const parsed = parseStructuredJson(
    response.choices?.[0]?.message?.content,
    sourceModelProposalSchema,
    "The code proposal agent"
  );
  return validateSourceModelProposal(parsed, snapshot);
}

export type CiCheck = {
  name: string;
  status: string;
  conclusion: string | null;
  url?: string;
};

export type SourceUpgradeApplyResult = {
  branch: string;
  commitSha: string;
  pullRequestNumber: number;
  pullRequestUrl: string;
  draft: true;
  ci: {
    status: "passed" | "failed" | "pending" | "not_started" | "unavailable";
    checks: CiCheck[];
    url: string;
  };
};

export async function applySourceProposal(
  proposal: StoredSourceProposal,
  config: SourceUpgradeConfig,
  options: { client?: GitHubSourceClient; id?: string; now?: () => number } = {}
): Promise<SourceUpgradeApplyResult> {
  const status = getSourceUpgradeConfigStatus(config);
  if (!status.configured || !config.repository || !config.token)
    throw new SourceUpgradeError("CONFIGURATION", status.message);
  if (
    proposal.repository.toLowerCase() !== config.repository.slug.toLowerCase()
  )
    throw new SourceUpgradeError(
      "CONFLICT",
      "The configured source repository changed. Draft a fresh proposal for this repository before approving."
    );
  const client = options.client ?? new GitHubSourceClient(config);
  const repository = await client.getRepository();
  if (!repository.private) {
    throw new SourceUpgradeError(
      "FORBIDDEN_REPOSITORY",
      "The configured GitHub repository is public. Use a private repository; no source mutation was attempted."
    );
  }
  const currentRef = await client.getRef(proposal.baseBranch);
  if (currentRef.object.sha !== proposal.baseCommit) {
    throw new SourceUpgradeError(
      "CONFLICT",
      `The base branch changed from ${proposal.baseCommit.slice(0, 12)} to ${currentRef.object.sha.slice(0, 12)}. Draft a fresh proposal before approving. No source mutation was attempted.`
    );
  }
  const baseCommit = await client.getCommit(proposal.baseCommit);
  const blobEntries: Array<{ path: string; sha: string }> = [];
  for (const file of proposal.changedFiles) {
    if (!isAllowedSourcePath(file.path))
      throw new SourceUpgradeError(
        "INVALID_PROPOSAL",
        "The stored proposal targets a protected path."
      );
    const blob = await client.createBlob(file.content);
    blobEntries.push({ path: file.path, sha: blob.sha });
  }
  const tree = await client.createTree(baseCommit.tree.sha, blobEntries);
  const id = options.id ?? randomUUID();
  const now = options.now ?? Date.now;
  const branch = `adus/upgrade/${now()}-${id.replace(/[^a-zA-Z0-9-]/g, "").slice(0, 24)}`;
  const commit = await client.createCommit(
    `Adus upgrade: ${proposal.title}`.slice(0, 200),
    tree.sha,
    proposal.baseCommit
  );
  await client.createRef(branch, commit.sha);
  const pullRequest = await client.createDraftPullRequest({
    title: proposal.title,
    head: branch,
    base: proposal.baseBranch,
    body: [
      "## Adus source upgrade",
      "",
      proposal.summary,
      "",
      "### Changed files",
      ...proposal.changedFiles.map(
        file => `- \`${file.path}\`: ${file.reason}`
      ),
      "",
      "### Requested checks",
      ...(proposal.tests.length > 0
        ? proposal.tests.map(test => `- ${test}`)
        : ["- No checks were supplied by the proposal agent."]),
      "",
      `Base commit: \`${proposal.baseCommit}\``,
      "",
      "This PR was created as a draft after explicit owner approval. It was not merged, published, deployed, or used to change permissions.",
    ].join("\n"),
  });
  let ci: SourceUpgradeApplyResult["ci"] = {
    status: "pending",
    checks: [],
    url: pullRequest.html_url,
  };
  try {
    const checkRuns = await client.getCheckRuns(commit.sha);
    const checks = (checkRuns.check_runs ?? []).map(check => ({
      name: check.name ?? "Unnamed check",
      status: check.status ?? "unknown",
      conclusion: check.conclusion ?? null,
      url: check.html_url ?? undefined,
    }));
    const completed =
      checks.length > 0 && checks.every(check => check.status === "completed");
    const failed = checks.some(check =>
      [
        "failure",
        "cancelled",
        "timed_out",
        "action_required",
        "stale",
      ].includes(check.conclusion ?? "")
    );
    ci = {
      status: failed
        ? "failed"
        : completed
          ? "passed"
          : checks.length
            ? "pending"
            : "not_started",
      checks,
      url: pullRequest.html_url,
    };
  } catch {
    ci = {
      status: "unavailable",
      checks: [],
      url: pullRequest.html_url,
    };
  }
  return {
    branch,
    commitSha: commit.sha,
    pullRequestNumber: pullRequest.number,
    pullRequestUrl: pullRequest.html_url,
    draft: true,
    ci,
  };
}
