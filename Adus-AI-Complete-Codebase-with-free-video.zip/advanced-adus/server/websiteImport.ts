import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { saveRecord } from "./workspaceStore";
import { protectedProcedure, router } from "./_core/trpc";

/** Keep imported source bounded so preview, persistence, and export remain request-safe. */
export const MAX_IMPORTED_HTML_LENGTH = 200_000;

export const websiteImportInput = z.object({
  filename: z.string().min(1).max(255),
  html: z.string().min(1).max(MAX_IMPORTED_HTML_LENGTH),
  title: z.string().max(200).optional(),
});

function badRequest(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}

function titleFromFilename(filename: string) {
  const base = filename
    .trim()
    .replace(/[\\/]+/g, " ")
    .replace(/\.(?:html?|HTML?)$/, "")
    .replace(/[-_]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return base || "Imported website";
}

function titleFromHtml(html: string) {
  const match = html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i);
  if (!match?.[1]) return "";
  return match[1]
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 200);
}

export type ImportedWebsiteArtifact = {
  title: string;
  summary: string;
  html: string;
  source: "imported";
  filename: string;
};

/**
 * Validate without rewriting the source. The preview can safely render this in
 * the existing sandbox; the hosting adapter applies its stricter static-page
 * publish checks before any public upload.
 */
export function validateImportedHtml(
  input: z.infer<typeof websiteImportInput>
) {
  if (!/\.html?$/i.test(input.filename.trim())) {
    badRequest("Import a .html or .htm file.");
  }
  const html = input.html;
  if (/\u0000/.test(html))
    badRequest("This HTML file contains an invalid null character.");
  if (!/<html\b/i.test(html) || !/<body\b/i.test(html)) {
    badRequest(
      "Import a complete HTML document containing <html> and <body> tags."
    );
  }
  const title =
    input.title?.trim().slice(0, 200) ||
    titleFromHtml(html) ||
    titleFromFilename(input.filename);
  if (!title)
    badRequest("Give the imported HTML document a title and try again.");
  return {
    title,
    summary: `Imported from ${input.filename.trim()}. Review the private preview before publishing.`,
    html,
    source: "imported" as const,
    filename: input.filename.trim(),
  } satisfies ImportedWebsiteArtifact;
}

export const websiteImportRouter = router({
  importHtml: protectedProcedure
    .input(websiteImportInput)
    .mutation(async ({ ctx, input }) => {
      const artifact = validateImportedHtml(input);
      const record = await saveRecord(ctx.user.id, "website", artifact);
      return { ...artifact, id: record.id };
    }),
});

export default websiteImportRouter;
