import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
const exec = promisify(execFile);
export async function normalizeVideoOutput(bytes: Buffer): Promise<Buffer> {
  // The provider can return WebM despite requesting video output; never label WebM as MP4.
  const dir = await mkdtemp(join(tmpdir(), "adus-compatible-video-"));
  try {
    const source = join(dir, "input");
    const output = join(dir, "output.mp4");
    await writeFile(source, bytes);
    const result = await exec(
      "ffprobe",
      [
        "-v",
        "error",
        "-show_entries",
        "stream=codec_name,codec_type",
        "-of",
        "json",
        source,
      ],
      { timeout: 10000, maxBuffer: 100000 }
    );
    const streams = JSON.parse(result.stdout).streams ?? [];
    const video = streams.find((s: any) => s.codec_type === "video");
    if (!video) throw Error("No video");
    if (
      bytes.subarray(4, 8).toString() === "ftyp" &&
      video.codec_name === "h264"
    )
      return bytes;
    await exec(
      "ffmpeg",
      [
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        source,
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-crf",
        "23",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-movflags",
        "+faststart",
        output,
      ],
      { timeout: 60000, maxBuffer: 100000 }
    );
    const mp4 = await readFile(output);
    if (mp4.length > 64 * 1024 * 1024) throw Error("Output too large");
    return mp4;
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}
