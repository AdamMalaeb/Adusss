import { afterEach, describe, expect, it, vi } from "vitest";

const store = vi.hoisted(() => ({
  getRecord: vi.fn(),
  saveRecord: vi.fn(),
}));

vi.mock("./workspaceStore", () => store);
vi.mock("./storage", () => ({ storagePut: vi.fn() }));

import {
  checkManusReadiness,
  deckTaskPrompt,
  decodePptxDataUrl,
  getManusReadiness,
  isAllowedArtifactUrl,
  parseTaskState,
  promptProhibitsPictures,
  promptRequestsPictures,
  picturesPermitted,
  sendPowerPointMessage,
} from "./powerpointService";
import { TRPCError } from "@trpc/server";

const validDraft = {
  title: "A reviewed deck",
  topic: "A reviewed deck",
  audience: "Product leaders",
  language: "English" as const,
  style: "Executive clarity" as const,
  slideCount: 4,
  sourceFacts: [],
  outline: [1, 2, 3, 4].map(index => ({
    id: `slide-${index}`,
    title: `Slide ${index}`,
    summary: "A grounded message.",
    bullets: [],
    sourceFacts: [],
  })),
};

function pptxDataUrl() {
  return `data:application/vnd.openxmlformats-officedocument.presentationml.presentation;base64,${Buffer.from("PK\\x03\\x04test").toString("base64")}`;
}

afterEach(() => {
  vi.restoreAllMocks();
  delete process.env.MANUS_API_KEY;
});

describe("PowerPoint service contracts", () => {
  it("keeps the exact user prompt and effects preference in the Slides request", () => {
    const prompt = "Create a text-only quarterly operating review for the board.";
    const text = deckTaskPrompt(
      {
        ...validDraft,
        prompt,
        effectsPrompt: "Use a restrained fade between sections.",
        allowPictures: false,
      },
      undefined,
      []
    );
    expect(text).toContain(`User request (preserve this intent exactly): ${prompt}`);
    expect(text).toContain("Use a restrained fade between sections.");
    expect(text).toContain("Pictures are not permitted for this request.");
  });

  it("lets an explicit picture prohibition override picture permission", () => {
    expect(promptProhibitsPictures("Create a deck with no pictures or images.")).toBe(true);
    expect(promptProhibitsPictures("Create a deck with pictures of the product.")).toBe(false);
    expect(promptRequestsPictures("Create a deck with pictures of the product.")).toBe(true);
    expect(picturesPermitted("Create a deck with pictures of the product.", false)).toBe(true);
    expect(picturesPermitted("Create a text-only deck with no pictures.", true)).toBe(false);
  });

  it("accepts a bounded PPTX data URL and rejects invalid package signatures", () => {
    expect(decodePptxDataUrl(pptxDataUrl()).subarray(0, 2).toString()).toBe(
      "PK"
    );
    expect(() => decodePptxDataUrl("data:text/plain;base64,aGVsbG8=")).toThrow(
      TRPCError
    );
  });

  it("does not treat a stopped main agent as complete while background work is unknown", () => {
    expect(
      parseTaskState({
        task: { status: "stopped", has_running_background_jobs: true },
      })
    ).toMatchObject({ state: "unknown" });
    expect(parseTaskState({ task: { status: "stopped" } })).toMatchObject({
      state: "unknown",
    });
    expect(
      parseTaskState({
        task: { status: "stopped", has_running_background_jobs: false },
      })
    ).toMatchObject({ state: "completed" });
  });

  it("distinguishes normal questions from action confirmations", () => {
    expect(
      parseTaskState({
        task: {
          status: "waiting",
          status_detail: { waiting_for_event_type: "messageAskUser" },
        },
      })
    ).toMatchObject({ state: "waiting_input" });
    expect(
      parseTaskState({
        task: {
          status: "waiting",
          status_detail: { waiting_for_event_type: "gmailSendAction" },
        },
      })
    ).toMatchObject({ state: "waiting_action" });
  });

  it("allows only HTTPS Manus artifact hosts by default", () => {
    expect(
      isAllowedArtifactUrl("https://private.manuscdn.com/output.pptx")
    ).toBe(true);
    expect(isAllowedArtifactUrl("https://evil.example/output.pptx")).toBe(
      false
    );
    expect(
      isAllowedArtifactUrl("http://private.manuscdn.com/output.pptx")
    ).toBe(false);
  });

  it("reports missing credentials without attempting a billable call", async () => {
    expect(getManusReadiness()).toMatchObject({
      available: false,
      credentialEnv: "MANUS_API_KEY",
    });
    await expect(
      sendPowerPointMessage(7, "missing", "continue")
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("reports a rejected API key as unavailable after user.me", async () => {
    process.env.MANUS_API_KEY = "invalid-test-key";
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response('{"ok":false}', { status: 401 }))
    );
    const result = await checkManusReadiness();
    expect(result).toMatchObject({
      available: false,
      credentialEnv: "MANUS_API_KEY",
    });
    expect(result.message).toMatch(/rejected/i);
  });

  it("uses the authenticated user's ID when looking up a task record", async () => {
    store.getRecord.mockResolvedValue(undefined);
    await expect(
      sendPowerPointMessage(42, "task-record", "Please continue")
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(store.getRecord).toHaveBeenCalledWith(
      42,
      "powerpointTask",
      "task-record"
    );
  });
});

describe("documented presentation API envelopes", () => {
  it("creates a Slides task only after authentication and sends the reviewed deck privately", async () => {
    process.env.MANUS_API_KEY = "authenticated-envelope-test";
    store.saveRecord.mockImplementation(async (_u, _k, payload, id) => ({
      id,
      payload,
    }));
    const calls: Array<{ url: string; init?: RequestInit }> = [];
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url, init) => {
        calls.push({ url: String(url), init });
        if (String(url).endsWith("/v2/user.me"))
          return new Response(JSON.stringify({ ok: true, user: { id: "qa" } }));
        if (String(url).endsWith("/v2/skill.list"))
          return new Response(
            JSON.stringify({
              ok: true,
              data: [
                {
                  id: "slides-qa",
                  name: "Slides",
                  description: "Presentations",
                },
              ],
            })
          );
        if (String(url).endsWith("/v2/task.create"))
          return new Response(
            JSON.stringify({
              ok: true,
              task_id: "task-qa",
              task_url: "https://manus.im/app/task-qa",
            })
          );
        throw new Error("Unexpected API endpoint");
      })
    );
    const { createPowerPointTask } = await import("./powerpointService");
    const result = await createPowerPointTask(7, { draft: validDraft });
    expect(result.taskId).toBe("task-qa");
    expect(calls.map(x => x.url)).toEqual([
      "https://api.manus.ai/v2/user.me",
      "https://api.manus.ai/v2/skill.list",
      "https://api.manus.ai/v2/task.create",
    ]);
    const request = JSON.parse(String(calls[2].init?.body));
    expect(request).toMatchObject({
      share_visibility: "private",
      message: { force_skills: ["slides-qa"] },
    });
    expect(request.message.content[0].text).toContain("Reviewed outline");
    expect(store.saveRecord).toHaveBeenCalledWith(
      7,
      "powerpointTask",
      expect.objectContaining({ taskId: "task-qa" }),
      expect.any(String)
    );
  });

  it("reads completed-task attachments from assistant_message and stores an owned PPTX", async () => {
    process.env.MANUS_API_KEY = "polling-envelope-test";
    store.getRecord.mockResolvedValue({
      id: "record-qa",
      payload: {
        recordId: "record-qa",
        taskId: "task-qa",
        title: "Wave lesson",
        draft: validDraft,
      },
    });
    store.saveRecord.mockImplementation(async (_u, _k, payload, id) => ({
      id,
      payload,
    }));
    const { storagePut } = await import("./storage");
    vi.mocked(storagePut).mockResolvedValue({
      key: "powerpoint/7/test.pptx",
      url: "/manus-storage/powerpoint/7/test.pptx",
    });
    const bytes = Buffer.from([0x50, 0x4b, 3, 4, 0, 0, 0, 0]);
    vi.stubGlobal(
      "fetch",
      vi.fn(async url => {
        const value = String(url);
        if (value.endsWith("/v2/user.me"))
          return new Response(JSON.stringify({ ok: true, user: { id: "qa" } }));
        if (value.includes("task.detail"))
          return new Response(
            JSON.stringify({
              ok: true,
              task: {
                agent_status: "stopped",
                has_running_background_jobs: false,
              },
            })
          );
        if (value.includes("task.listMessages"))
          return new Response(
            JSON.stringify({
              ok: true,
              messages: [
                {
                  type: "assistant_message",
                  assistant_message: {
                    attachments: [
                      {
                        filename: "lesson.pptx",
                        url: "https://private.manuscdn.com/lesson.pptx",
                      },
                    ],
                  },
                },
              ],
            })
          );
        if (value === "https://private.manuscdn.com/lesson.pptx")
          return new Response(bytes);
        throw new Error("Unexpected API endpoint");
      })
    );
    const { pollPowerPointTask } = await import("./powerpointService");
    const result = await pollPowerPointTask(7, "record-qa");
    expect(result).toMatchObject({
      state: "completed",
      output: { filename: "lesson.pptx", bytes: bytes.length },
    });
    expect(storagePut).toHaveBeenCalledWith(
      expect.stringMatching(/^powerpoint\/7\//),
      bytes,
      "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    );
    expect(store.saveRecord).toHaveBeenCalledWith(
      7,
      "powerpoint",
      expect.objectContaining({ taskRecordId: "record-qa" }),
      undefined
    );
  });
});
