import { execFile } from "node:child_process";
import { readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const execFileAsync = promisify(execFile);
const mocks = vi.hoisted(() => ({
  invokeLLM: vi.fn(),
  listLLMModels: vi.fn(),
  attachmentParts: vi.fn(),
  saveRecord: vi.fn(),
  getRecord: vi.fn(),
  listRecords: vi.fn(),
  createStudyVideo: vi.fn(),
  storagePut: vi.fn(),
  renderedVideoPath: "",
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: mocks.invokeLLM,
  listLLMModels: mocks.listLLMModels,
}));
vi.mock("./workspaceStore", () => ({
  saveRecord: mocks.saveRecord,
  getRecord: mocks.getRecord,
  listRecords: mocks.listRecords,
}));
vi.mock("./studyVideo", () => ({ createStudyVideo: mocks.createStudyVideo }));
vi.mock("./naturalSpeech", async () => {
  const actual =
    await vi.importActual<typeof import("./naturalSpeech")>("./naturalSpeech");
  return {
    ...actual,
    createNaturalSpeechAudio: vi.fn(async () => {
      const audio = actual.pcmToWav(Buffer.alloc(24000 * 2 * 3, 0));
      return {
        key: "mock.wav",
        url: "/manus-storage/mock.wav",
        audio,
        contentType: "audio/wav",
      };
    }),
  };
});
vi.mock("./storage", () => ({
  storagePut: mocks.storagePut,
}));
vi.mock("./attachments", async () => {
  const actual =
    await vi.importActual<typeof import("./attachments")>("./attachments");
  return { ...actual, attachmentParts: mocks.attachmentParts };
});

import { appRouter } from "./routers";

function context(userId = 7): TrpcContext {
  return {
    user: {
      id: userId,
      openId: `study-user-${userId}`,
      email: `study-${userId}@example.com`,
      name: "Study Tester",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const sourceFile = {
  name: "lesson.txt",
  mimeType: "text/plain",
  dataUrl: "data:text/plain;base64,aGVsbG8=",
  textContent: "A short source lesson.",
};

const modelLesson = {
  title: "A short lesson",
  summary:
    "This lesson explains four connected ideas from the uploaded source.",
  scenes: [
    {
      title: "Context",
      bullets: ["The source establishes context."],
      narration: "The source establishes context.",
    },
    {
      title: "Core idea",
      bullets: ["The main idea is clearly stated."],
      narration: "The main idea is clearly stated.",
    },
    {
      title: "Evidence",
      bullets: ["Evidence supports the main idea."],
      narration: "Evidence supports the main idea.",
    },
    {
      title: "Takeaway",
      bullets: ["The takeaway stays within the source."],
      narration: "The takeaway stays within the source.",
    },
  ],
  sources: ["lesson.txt"],
  warnings: [],
};

describe("adus.study", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.listLLMModels.mockResolvedValue({ data: [{ id: "gpt-5-mini" }] });
    mocks.attachmentParts.mockResolvedValue([
      {
        type: "text",
        text: "Source attachment: lesson.txt\nA short source lesson.",
      },
    ]);
    mocks.invokeLLM.mockResolvedValue({
      choices: [{ message: { content: JSON.stringify(modelLesson) } }],
    });
    mocks.saveRecord.mockImplementation(
      async (
        _userId: number,
        _kind: string,
        payload: unknown,
        id?: string
      ) => ({ id: id ?? "study-1", payload, createdAt: 1000 })
    );
    mocks.getRecord.mockResolvedValue(undefined);
    mocks.listRecords.mockResolvedValue([]);
    mocks.createStudyVideo.mockResolvedValue("/manus-storage/study/test.mp4");
  });

  it("analyzes attachments with a live catalog model and saves grounded source metadata", async () => {
    const result = await appRouter
      .createCaller(context())
      .adus.study.analyze({ files: [sourceFile], language: "english" });
    expect(result).toMatchObject({
      id: "study-1",
      title: "A short lesson",
      sources: ["lesson.txt"],
    });
    expect(result.scenes).toHaveLength(4);
    expect(mocks.listLLMModels).toHaveBeenCalledTimes(1);
    expect(mocks.invokeLLM).toHaveBeenCalledWith(
      expect.objectContaining({
        model: "gpt-5-mini",
        response_format: expect.objectContaining({ type: "json_schema" }),
      })
    );
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      7,
      "study",
      expect.objectContaining({
        title: "A short lesson",
        sources: ["lesson.txt"],
      })
    );
  });

  it("rejects a nonexistent or non-owned video record", async () => {
    mocks.getRecord.mockResolvedValue(undefined);
    await expect(
      appRouter
        .createCaller(context(7))
        .adus.study.generateVideo({ id: "someone-elses-id" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(mocks.createStudyVideo).not.toHaveBeenCalled();
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });

  it("lists only the signed-in user's study records", async () => {
    mocks.listRecords.mockResolvedValue([
      { id: "mine", payload: modelLesson, createdAt: 1000 },
    ]);
    const result = await appRouter.createCaller(context(23)).adus.study.list();
    expect(result).toHaveLength(1);
    expect(result[0]?.id).toBe("mine");
    expect(mocks.listRecords).toHaveBeenCalledWith(23, "study");
  });

  it("renders a real MP4 with video frames and an audio stream", async () => {
    const outputPath = join(tmpdir(), `adus-study-test-${Date.now()}.mp4`);
    mocks.storagePut.mockImplementation(
      async (_key: string, bytes: Buffer | Uint8Array) => {
        await writeFile(outputPath, bytes);
        mocks.renderedVideoPath = outputPath;
        return { key: "study/test.mp4", url: "/manus-storage/study/test.mp4" };
      }
    );
    const actual =
      await vi.importActual<typeof import("./studyVideo")>("./studyVideo");
    const url = await actual.createStudyVideo(7, "study-smoke", {
      ...modelLesson,
      language: "english",
    });
    expect(url).toBe("/manus-storage/study/test.mp4");
    const { stdout } = await execFileAsync("ffprobe", [
      "-v",
      "error",
      "-show_entries",
      "stream=codec_type,width,height:format=duration",
      "-of",
      "json",
      outputPath,
    ]);
    const metadata = JSON.parse(stdout) as {
      streams?: Array<{ codec_type: string; width?: number; height?: number }>;
      format?: { duration?: string };
    };
    expect(
      metadata.streams?.some(
        stream =>
          stream.codec_type === "video" &&
          stream.width === 960 &&
          stream.height === 540
      )
    ).toBe(true);
    expect(
      metadata.streams?.some(stream => stream.codec_type === "audio")
    ).toBe(true);
    expect(Number(metadata.format?.duration ?? 0)).toBeGreaterThan(0);
    await rm(outputPath, { force: true });
  }, 45_000);
});
