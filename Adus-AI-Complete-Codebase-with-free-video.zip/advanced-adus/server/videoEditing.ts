import { execFile } from "node:child_process";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { invokeLLM, selectChatModel } from "./_core/llm";

const execFileAsync = promisify(execFile);

export const MAX_EDIT_DURATION_SECONDS = 120;
export const MAX_EDIT_SEGMENTS = 24;
export const MAX_EDIT_RANGES = 24;
export const MAX_EDIT_OUTPUT_BYTES = 64 * 1024 * 1024;
export const EDIT_REQUEST_TIMEOUT_MS = 90_000;
const MAX_EDIT_PLAN_PROMPT_CHARS = 12_000;

type Range = { start: number; end: number };
export type EditCrop = { x: number; y: number; width: number; height: number };
export type EditSpeed = Range & { factor: number };

export type VideoEditPlan = {
  version: 1;
  supported: boolean;
  summary: string;
  unsupportedReason: string;
  segments: Range[];
  mute: Range[];
  speed: EditSpeed[];
  crop: EditCrop | null;
  rotate: 0 | 90 | 180 | 270;
};

export type VideoProbe = {
  duration: number;
  width: number;
  height: number;
  hasAudio: boolean;
  fps?: number;
};

const rangeSchema = z.object({
  start: z.number().finite().min(0),
  end: z.number().finite().positive(),
});

const editPlanSchema = z.object({
  version: z.literal(1),
  supported: z.boolean(),
  summary: z.string().min(1).max(600),
  unsupportedReason: z.string().max(600),
  segments: z.array(rangeSchema).max(MAX_EDIT_SEGMENTS),
  mute: z.array(rangeSchema).max(MAX_EDIT_RANGES),
  speed: z
    .array(
      rangeSchema.extend({
        factor: z.number().finite().min(0.5).max(2),
      })
    )
    .max(MAX_EDIT_RANGES),
  crop: z
    .object({
      x: z.number().finite().min(0).max(1),
      y: z.number().finite().min(0).max(1),
      width: z.number().finite().gt(0).max(1),
      height: z.number().finite().gt(0).max(1),
    })
    .nullable(),
  rotate: z.union([
    z.literal(0),
    z.literal(90),
    z.literal(180),
    z.literal(270),
  ]),
});

export const videoEditPlanResponseFormat = {
  type: "json_schema" as const,
  json_schema: {
    name: "video_edit_plan",
    strict: true,
    schema: {
      type: "object",
      properties: {
        version: { type: "integer", enum: [1] },
        supported: { type: "boolean" },
        summary: { type: "string" },
        unsupportedReason: { type: "string" },
        segments: {
          type: "array",
          maxItems: MAX_EDIT_SEGMENTS,
          items: {
            type: "object",
            properties: {
              start: { type: "number" },
              end: { type: "number" },
            },
            required: ["start", "end"],
            additionalProperties: false,
          },
        },
        mute: {
          type: "array",
          maxItems: MAX_EDIT_RANGES,
          items: {
            type: "object",
            properties: {
              start: { type: "number" },
              end: { type: "number" },
            },
            required: ["start", "end"],
            additionalProperties: false,
          },
        },
        speed: {
          type: "array",
          maxItems: MAX_EDIT_RANGES,
          items: {
            type: "object",
            properties: {
              start: { type: "number" },
              end: { type: "number" },
              factor: { type: "number", minimum: 0.5, maximum: 2 },
            },
            required: ["start", "end", "factor"],
            additionalProperties: false,
          },
        },
        crop: {
          anyOf: [
            { type: "null" },
            {
              type: "object",
              properties: {
                x: { type: "number", minimum: 0, maximum: 1 },
                y: { type: "number", minimum: 0, maximum: 1 },
                width: { type: "number", exclusiveMinimum: 0, maximum: 1 },
                height: { type: "number", exclusiveMinimum: 0, maximum: 1 },
              },
              required: ["x", "y", "width", "height"],
              additionalProperties: false,
            },
          ],
        },
        rotate: { type: "integer", enum: [0, 90, 180, 270] },
      },
      required: [
        "version",
        "supported",
        "summary",
        "unsupportedReason",
        "segments",
        "mute",
        "speed",
        "crop",
        "rotate",
      ],
      additionalProperties: false,
    },
  },
};

function badRequest(message: string): TRPCError {
  return new TRPCError({ code: "BAD_REQUEST", message });
}

function serviceUnavailable(message: string): TRPCError {
  return new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function finiteNumber(value: unknown): number | undefined {
  if (typeof value === "number")
    return Number.isFinite(value) ? value : undefined;
  if (typeof value !== "string" || !value.trim()) return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function normalizeRange(value: unknown): unknown {
  if (!isRecord(value)) return value;
  return {
    start: finiteNumber(value.start),
    end: finiteNumber(value.end),
  };
}

function normalizePlannerPayload(value: unknown): unknown {
  if (!isRecord(value)) return value;
  // Some providers wrap structured output in a top-level `plan`; unwrapping
  // that wrapper does not add an operation or change any requested value.
  const raw =
    isRecord(value.plan) && !("version" in value) ? value.plan : value;
  const supported =
    typeof raw.supported === "boolean"
      ? raw.supported
      : typeof raw.supported === "string"
        ? raw.supported.toLowerCase() === "true"
          ? true
          : raw.supported.toLowerCase() === "false"
            ? false
            : raw.supported
        : raw.supported;
  const version = finiteNumber(raw.version);
  const summary =
    typeof raw.summary === "string" ? raw.summary.trim() : raw.summary;
  const unsupportedReason = raw.unsupportedReason;
  const ranges = (field: unknown) =>
    Array.isArray(field) ? field.map(normalizeRange) : field;
  const speed = Array.isArray(raw.speed)
    ? raw.speed.map(item => {
        if (!isRecord(item)) return item;
        const range = normalizeRange(item);
        return isRecord(range)
          ? { ...range, factor: finiteNumber(item.factor) }
          : {
              start: undefined,
              end: undefined,
              factor: finiteNumber(item.factor),
            };
      })
    : raw.speed;
  const crop = isRecord(raw.crop)
    ? {
        x: finiteNumber(raw.crop.x),
        y: finiteNumber(raw.crop.y),
        width: finiteNumber(raw.crop.width),
        height: finiteNumber(raw.crop.height),
      }
    : raw.crop === null || raw.crop === undefined
      ? raw.crop
      : raw.crop;
  const rotate = finiteNumber(raw.rotate);
  return {
    version: version === 1 ? 1 : raw.version,
    supported,
    summary,
    unsupportedReason,
    segments: ranges(raw.segments),
    mute: ranges(raw.mute),
    speed,
    crop,
    rotate: rotate ?? raw.rotate,
  };
}

function extractJsonObject(text: string): string | undefined {
  let start = -1;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (inString) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === '"') inString = false;
      continue;
    }
    if (character === '"') {
      inString = true;
      continue;
    }
    if (character === "{" && start < 0) {
      start = index;
      depth = 1;
      continue;
    }
    if (start >= 0 && character === "{") depth++;
    if (start >= 0 && character === "}") {
      depth--;
      if (depth === 0) return text.slice(start, index + 1);
    }
  }
  return undefined;
}

function parseJsonContent(content: unknown): unknown {
  if (isRecord(content)) return content;
  const text = messageText(content);
  const cleaned = text
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
  if (!cleaned) throw new Error("The edit planner returned no JSON.");
  try {
    return JSON.parse(cleaned);
  } catch {
    const candidate = extractJsonObject(cleaned);
    if (!candidate)
      throw new Error("The edit planner returned no JSON object.");
    return JSON.parse(candidate);
  }
}

function messageText(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content))
    return content
      .filter((part): part is { type: "text"; text: string } =>
        Boolean(part && typeof part === "object" && part.type === "text")
      )
      .map(part => part.text)
      .join("\n");
  return "";
}

function sortedRanges<T extends Range>(ranges: T[]): T[] {
  return [...ranges].sort((a, b) => a.start - b.start || a.end - b.end);
}

function validateRange(range: Range, duration: number, label: string): Range {
  if (!Number.isFinite(range.start) || !Number.isFinite(range.end))
    throw badRequest(`${label} contains a non-finite time.`);
  if (range.end <= range.start)
    throw badRequest(`${label} ranges must have an end after their start.`);
  if (range.start < 0 || range.end > duration + 0.001)
    throw badRequest(`${label} must stay within the source duration.`);
  return { start: range.start, end: Math.min(duration, range.end) };
}

function rejectOverlaps(ranges: Range[], label: string): void {
  for (let i = 1; i < ranges.length; i++) {
    if (ranges[i].start < ranges[i - 1].end - 0.001)
      throw badRequest(`${label} ranges may not overlap.`);
  }
}

/** Validate and normalize an AI plan again at execution time; never trust client JSON. */
export function validateVideoEditPlan(
  value: unknown,
  source: VideoProbe
): VideoEditPlan & { estimatedDuration: number } {
  const parsed = editPlanSchema.safeParse(value);
  if (!parsed.success)
    throw badRequest(
      "The edit plan is invalid. Generate a fresh plan and review it again."
    );
  const plan = parsed.data;
  if (!plan.supported) {
    return { ...plan, segments: [], estimatedDuration: 0 };
  }
  const duration = source.duration;
  const segments = sortedRanges(
    plan.segments.length
      ? plan.segments.map(range => validateRange(range, duration, "Cut"))
      : [{ start: 0, end: duration }]
  );
  rejectOverlaps(segments, "Cut");
  const mute = sortedRanges(
    plan.mute.map(range => validateRange(range, duration, "Mute"))
  );
  const speed = sortedRanges(
    plan.speed.map(range => ({
      ...validateRange(range, duration, "Speed"),
      factor: range.factor,
    }))
  );
  rejectOverlaps(speed, "Speed");
  const crop = plan.crop;
  if (crop && (crop.x + crop.width > 1.0001 || crop.y + crop.height > 1.0001))
    throw badRequest("Crop must stay inside the source frame.");
  const estimatedDuration = segments.reduce((total, segment) => {
    let cursor = segment.start;
    let result = 0;
    for (const piece of splitAtSpeedBoundaries(segment, speed)) {
      const factor = speed.find(
        item =>
          item.start <= piece.start + 0.001 && item.end >= piece.end - 0.001
      )?.factor;
      result += (piece.end - piece.start) / (factor ?? 1);
      cursor = piece.end;
    }
    return total + (cursor < segment.end ? segment.end - cursor : 0) + result;
  }, 0);
  if (!Number.isFinite(estimatedDuration) || estimatedDuration <= 0)
    throw badRequest("The edit would produce an empty video.");
  if (estimatedDuration > MAX_EDIT_DURATION_SECONDS)
    throw badRequest(
      "The edited video would exceed the 120-second output limit."
    );
  return { ...plan, segments, mute, speed, estimatedDuration };
}

function splitAtSpeedBoundaries(segment: Range, speed: EditSpeed[]): Range[] {
  const points = new Set([segment.start, segment.end]);
  for (const item of speed) {
    if (item.start > segment.start && item.start < segment.end)
      points.add(item.start);
    if (item.end > segment.start && item.end < segment.end)
      points.add(item.end);
  }
  const sorted = Array.from(points).sort((a, b) => a - b);
  return sorted
    .slice(0, -1)
    .map((start, index) => ({ start, end: sorted[index + 1] }));
}

function splitTimeline(
  plan: VideoEditPlan
): Array<Range & { muted: boolean; factor: number }> {
  const pieces: Array<Range & { muted: boolean; factor: number }> = [];
  for (const segment of plan.segments) {
    const points = new Set([segment.start, segment.end]);
    for (const item of [...plan.mute, ...plan.speed]) {
      if (item.start > segment.start && item.start < segment.end)
        points.add(item.start);
      if (item.end > segment.start && item.end < segment.end)
        points.add(item.end);
    }
    const sorted = Array.from(points).sort((a, b) => a - b);
    for (let i = 0; i < sorted.length - 1; i++) {
      const start = sorted[i];
      const end = sorted[i + 1];
      if (end - start < 0.01) continue;
      const speed = plan.speed.find(
        item => item.start <= start + 0.001 && item.end >= end - 0.001
      );
      pieces.push({
        start,
        end,
        factor: speed?.factor ?? 1,
        muted: plan.mute.some(
          item => item.start < end - 0.001 && item.end > start + 0.001
        ),
      });
    }
  }
  return pieces;
}

function number(value: number): string {
  return Number(value.toFixed(4)).toString();
}

function ffmpegUnavailable(error: unknown): boolean {
  return Boolean(
    error &&
      typeof error === "object" &&
      "code" in error &&
      (error as { code?: unknown }).code === "ENOENT"
  );
}

function videoFilters(plan: VideoEditPlan, source: VideoProbe): string[] {
  const filters: string[] = [];
  if (plan.crop) {
    const width = Math.max(
      2,
      Math.floor((source.width * plan.crop.width) / 2) * 2
    );
    const height = Math.max(
      2,
      Math.floor((source.height * plan.crop.height) / 2) * 2
    );
    const x = Math.max(0, Math.floor((source.width * plan.crop.x) / 2) * 2);
    const y = Math.max(0, Math.floor((source.height * plan.crop.y) / 2) * 2);
    filters.push(`crop=${width}:${height}:${x}:${y}`);
  }
  if (plan.rotate === 90) filters.push("transpose=1");
  if (plan.rotate === 270) filters.push("transpose=2");
  if (plan.rotate === 180) filters.push("hflip", "vflip");
  return filters;
}

/** Execute only the validated deterministic operation set. The original is never overwritten. */
export async function executeVideoEdit(input: {
  bytes: Buffer;
  mimeType: string;
  source: VideoProbe;
  plan: VideoEditPlan;
}): Promise<{ bytes: Buffer; duration: number }> {
  const plan = validateVideoEditPlan(input.plan, input.source);
  if (!plan.supported)
    throw badRequest(
      plan.unsupportedReason ||
        "This request needs a generative video provider, not local editing."
    );
  if (!Buffer.isBuffer(input.bytes) || input.bytes.length === 0)
    throw badRequest("The source video is empty.");
  if (
    !Number.isFinite(input.source.duration) ||
    input.source.duration <= 0 ||
    !Number.isFinite(input.source.width) ||
    !Number.isFinite(input.source.height) ||
    input.source.width < 2 ||
    input.source.height < 2
  )
    throw badRequest(
      "The source video has invalid media dimensions or duration."
    );
  const pieces = splitTimeline(plan);
  if (!pieces.length)
    throw badRequest("The edit would produce an empty video.");

  const directory = await mkdtemp(join(tmpdir(), "adus-video-edit-"));
  const extension =
    input.mimeType === "video/webm"
      ? ".webm"
      : input.mimeType === "video/quicktime"
        ? ".mov"
        : ".mp4";
  const sourcePath = join(directory, `source${extension}`);
  const outputPath = join(directory, "edited.mp4");
  await writeFile(sourcePath, input.bytes);
  const vf = videoFilters(plan, input.source);
  const graph: string[] = [];
  const videoLabels: string[] = [];
  const audioLabels: string[] = [];
  const outputHasAudio = true;
  const audioInputIndex = input.source.hasAudio ? 0 : 1;
  pieces.forEach((piece, index) => {
    const videoLabel = `v${index}`;
    const audioLabel = `a${index}`;
    const video = [
      `trim=start=${number(piece.start)}:end=${number(piece.end)}`,
      "setpts=PTS-STARTPTS",
      ...(piece.factor === 1 ? [] : [`setpts=PTS/${number(piece.factor)}`]),
      ...vf,
      "format=yuv420p",
    ].join(",");
    graph.push(`[0:v]${video}[${videoLabel}]`);
    videoLabels.push(`[${videoLabel}]`);
    if (outputHasAudio) {
      const audioFilters = [
        input.source.hasAudio
          ? `atrim=start=${number(piece.start)}:end=${number(piece.end)}`
          : `atrim=start=0:end=${number(piece.end - piece.start)}`,
        "asetpts=PTS-STARTPTS",
        ...(piece.factor === 1 ? [] : [`atempo=${number(piece.factor)}`]),
        ...(piece.muted ? ["volume=0"] : []),
      ];
      graph.push(
        `[${audioInputIndex}:a]${audioFilters.join(",")}\[${audioLabel}\]`
      );
      audioLabels.push(`[${audioLabel}]`);
    }
  });
  const videoOutput = "vout";
  if (videoLabels.length === 1)
    graph.push(`${videoLabels[0]}null[${videoOutput}]`);
  else
    graph.push(
      `${videoLabels.join("")}concat=n=${videoLabels.length}:v=1:a=0[${videoOutput}]`
    );
  const audioOutput = "aout";
  if (outputHasAudio) {
    if (audioLabels.length === 1)
      graph.push(`${audioLabels[0]}anull[${audioOutput}]`);
    else
      graph.push(
        `${audioLabels.join("")}concat=n=${audioLabels.length}:v=0:a=1[${audioOutput}]`
      );
  }

  const args = [
    "-y",
    "-hide_banner",
    "-loglevel",
    "error",
    "-threads",
    "2",
    "-i",
    sourcePath,
    ...(input.source.hasAudio
      ? []
      : [
          "-f",
          "lavfi",
          "-i",
          "anullsrc=channel_layout=stereo:sample_rate=48000",
        ]),
    "-filter_complex",
    graph.join(";"),
    "-map",
    `[${videoOutput}]`,
    "-map",
    `[${audioOutput}]`,
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-crf",
    "23",
    "-pix_fmt",
    "yuv420p",
    "-c:a",
    "aac",
    "-b:a",
    "128k",
    "-movflags",
    "+faststart",
    "-t",
    String(MAX_EDIT_DURATION_SECONDS),
    outputPath,
  ];
  try {
    await execFileAsync("ffmpeg", args, {
      timeout: EDIT_REQUEST_TIMEOUT_MS,
      maxBuffer: 256 * 1024,
    });
    const { readFile, stat } = await import("node:fs/promises");
    const outputStat = await stat(outputPath);
    if (!outputStat.size || outputStat.size > MAX_EDIT_OUTPUT_BYTES)
      throw serviceUnavailable("The edited video exceeded the output limit.");
    const bytes = await readFile(outputPath);
    const outputProbe = await probeVideo(bytes, "video/mp4");
    return { bytes, duration: outputProbe.duration };
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    if (ffmpegUnavailable(error))
      throw serviceUnavailable(
        "FFmpeg is not available on the server. No video was changed."
      );
    if (error && typeof error === "object" && "killed" in error && error.killed)
      throw serviceUnavailable(
        "Video editing exceeded the 90-second processing limit."
      );
    throw serviceUnavailable(
      "FFmpeg could not complete this edit. Review the plan and try again."
    );
  } finally {
    await rm(directory, { recursive: true, force: true }).catch(
      () => undefined
    );
  }
}

export async function probeVideo(
  bytes: Buffer,
  mimeType: string
): Promise<VideoProbe> {
  const directory = await mkdtemp(join(tmpdir(), "adus-video-probe-"));
  const extension =
    mimeType === "video/webm"
      ? ".webm"
      : mimeType === "video/quicktime"
        ? ".mov"
        : ".mp4";
  const inputPath = join(directory, `source${extension}`);
  await writeFile(inputPath, bytes);
  try {
    const result = await execFileAsync(
      "ffprobe",
      [
        "-v",
        "error",
        "-show_streams",
        "-show_format",
        "-of",
        "json",
        inputPath,
      ],
      { timeout: 20_000, maxBuffer: 256 * 1024 }
    );
    const payload = JSON.parse(result.stdout) as {
      streams?: Array<Record<string, unknown>>;
      format?: Record<string, unknown>;
    };
    const video = payload.streams?.find(
      stream => stream.codec_type === "video"
    );
    if (!video) throw new Error("no video stream");
    const duration = Number(payload.format?.duration ?? video.duration);
    const width = Number(video.width);
    const height = Number(video.height);
    if (
      !Number.isFinite(duration) ||
      duration <= 0 ||
      !Number.isFinite(width) ||
      !Number.isFinite(height)
    )
      throw new Error("invalid metadata");
    if (duration > MAX_EDIT_DURATION_SECONDS)
      throw badRequest("Source videos must be 120 seconds or shorter.");
    const fpsText = String(video.avg_frame_rate ?? "");
    const [fpsNumerator, fpsDenominator] = fpsText.split("/").map(Number);
    return {
      duration,
      width,
      height,
      hasAudio: Boolean(
        payload.streams?.some(stream => stream.codec_type === "audio")
      ),
      fps: fpsDenominator > 0 ? fpsNumerator / fpsDenominator : undefined,
    };
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    throw badRequest("Choose a playable MP4, MOV, or WEBM video.");
  } finally {
    await rm(directory, { recursive: true, force: true }).catch(
      () => undefined
    );
  }
}

export async function createVideoEditPlan(input: {
  prompt: string;
  source: VideoProbe;
  llm?: typeof invokeLLM;
}): Promise<VideoEditPlan & { estimatedDuration?: number }> {
  const prompt = input.prompt.trim();
  if (prompt.length < 3 || prompt.length > MAX_EDIT_PLAN_PROMPT_CHARS)
    throw badRequest("Describe the source edit in 3 to 12,000 characters.");
  const llm = input.llm ?? invokeLLM;
  const model = selectChatModel({ mode: "fast" });
  let response;
  try {
    response = await llm({
      model,
      ...(model.startsWith("gpt-")
        ? { maxCompletionTokens: 2_000, reasoning: { effort: "low" as const } }
        : { maxTokens: 2_000 }),
      messages: [
        {
          role: "system",
          content:
            "You are the Adus deterministic video-edit planner. Return JSON matching the schema exactly. Plan only operations that FFmpeg can perform without AI generation: keep/cut time ranges, mute audio ranges, speed ranges, one normalized crop, and one rotation of 0/90/180/270 degrees. Never plan object removal, background replacement, restyling, inpainting, captions, or other generative changes; set supported=false and explain that a cinematic provider is required. Use source time in seconds. To keep the whole source, return one segment from 0 to the source duration. Cut is represented by omitting time from segments. Keep every numeric range inside the source duration. Do not add an operation the user did not request. Return all required fields, with crop=null and empty arrays when unused.",
        },
        {
          role: "user",
          content: `Source metadata: duration=${input.source.duration.toFixed(3)} seconds, width=${input.source.width}, height=${input.source.height}, audio=${input.source.hasAudio ? "yes" : "no"}.\nUser request: ${prompt}`,
        },
      ],
      response_format: videoEditPlanResponseFormat,
    });
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    throw serviceUnavailable(
      "The structured edit planner is unavailable. No video was changed."
    );
  }
  let parsed: VideoEditPlan;
  try {
    parsed = editPlanSchema.parse(
      normalizePlannerPayload(
        parseJsonContent(response.choices?.[0]?.message?.content)
      )
    );
  } catch {
    throw serviceUnavailable(
      "The structured edit planner returned an invalid plan. No video was changed."
    );
  }
  if (!parsed.supported) return parsed;
  return validateVideoEditPlan(parsed, input.source);
}
