import { beforeEach, describe, expect, it, vi } from "vitest";

const storageMocks = vi.hoisted(() => ({
  storagePut: vi.fn(),
}));

vi.mock("./storage", () => ({
  storagePut: storageMocks.storagePut,
}));

import {
  buildWhiteboardTimelines,
  createWhiteboardLesson,
  createWhiteboardVideo,
  whiteboardSvg,
  type WhiteboardLessonPayload,
} from "./whiteboardVideo";
import {
  buildGeminiSpeechRequest,
  naturalSpeechDefaults,
  pcmToWav,
  resetNaturalSpeechQueueForTests,
  synthesizeNaturalSpeech,
} from "./naturalSpeech";

const pcm = Buffer.alloc(24_000 * 2 * 2, 0);
const basePayload: WhiteboardLessonPayload = {
  title: "A moving lesson",
  language: "english",
  scenes: [
    {
      title: "Connect the ideas",
      bullets: ["Context", "Evidence", "Takeaway"],
      narration:
        "First we establish the context. Then we connect the evidence to the final takeaway.",
      visual: { kind: "diagram", labels: ["Context", "Evidence", "Takeaway"] },
    },
    {
      title: "Compare the result",
      bullets: ["Before", "After"],
      narration: "Now compare the before state with the after state.",
      visual: { kind: "comparison", labels: ["Before", "After"] },
    },
  ],
};

function responseJson(value: unknown): Response {
  return new Response(JSON.stringify(value), {
    status: 200,
    headers: { "content-type": "application/json" },
  });
}

describe("naturalSpeech", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    resetNaturalSpeechQueueForTests();
    delete process.env.GEMINI_API_KEY;
    storageMocks.storagePut.mockResolvedValue({
      key: "whiteboard/test-narration.wav",
      url: "/manus-storage/whiteboard/test-narration.wav",
    });
  });

  it("builds the documented Interactions request and wraps raw PCM in a valid WAV", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValue(
        responseJson({ output_audio: { data: pcm.toString("base64") } })
      );
    const result = await synthesizeNaturalSpeech("Hello learners.", "english", {
      apiKey: "gemini-test-key",
      fetchImpl,
    });
    expect(result.contentType).toBe("audio/wav");
    expect(result.audio.subarray(0, 4).toString("ascii")).toBe("RIFF");
    expect(result.audio.subarray(8, 12).toString("ascii")).toBe("WAVE");
    expect(result.audio.readUInt32LE(24)).toBe(24_000);
    expect(fetchImpl).toHaveBeenCalledOnce();
    const [url, init] = fetchImpl.mock.calls[0]!;
    expect(url).toBe(naturalSpeechDefaults.endpoint);
    expect((init?.headers as Record<string, string>)["x-goog-api-key"]).toBe(
      "gemini-test-key"
    );
    const request = JSON.parse(String(init?.body)) as Record<string, any>;
    expect(request.model).toBe("gemini-3.8-flash-tts");
    expect(request.response_format).toEqual({ type: "audio" });
    expect(request.generation_config.speech_config).toEqual([
      { voice: "Kore" },
    ]);
    expect(request.input[0].content[0].annotations[0].type).toBe(
      "speech_metadata"
    );
  });

  it("also accepts raw REST step audio and preserves a complete WAV", async () => {
    const wav = pcmToWav(pcm);
    const fetchImpl = vi.fn<typeof fetch>().mockResolvedValue(
      responseJson({
        steps: [
          {
            type: "model_output",
            content: [{ type: "audio", data: wav.toString("base64") }],
          },
        ],
      })
    );
    const result = await synthesizeNaturalSpeech("Bonjour.", "french", {
      apiKey: "gemini-test-key",
      fetchImpl,
    });
    expect(result.audio.equals(wav)).toBe(true);
  });

  it("fails clearly when production Gemini credentials are missing and never uses OpenAI credentials", async () => {
    process.env.OPENAI_API_KEY = "must-not-be-used";
    await expect(
      synthesizeNaturalSpeech("Hello.", "english", { fetchImpl: vi.fn() })
    ).rejects.toMatchObject({
      code: "PRECONDITION_FAILED",
    });
    delete process.env.OPENAI_API_KEY;
  });

  it("includes target-language style instructions in the request without translating the script", () => {
    const request = buildGeminiSpeechRequest("مرحبا بالمتعلمين", "arabic");
    const text = (request.input as any[])[0].content[0];
    expect(text.text).toBe("مرحبا بالمتعلمين");
    expect(text.annotations[0].style).toContain("Modern Standard Arabic");
  });

  it("honors a short Retry-After once, without overlapping provider requests", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(
        new Response("busy", {
          status: 429,
          headers: { "retry-after": "0" },
        })
      )
      .mockResolvedValueOnce(
        responseJson({ output_audio: { data: pcm.toString("base64") } })
      );
    const result = await synthesizeNaturalSpeech("Retry me.", "english", {
      apiKey: "gemini-test-key",
      fetchImpl,
    });
    expect(result.audio.subarray(0, 4).toString("ascii")).toBe("RIFF");
    expect(fetchImpl).toHaveBeenCalledTimes(2);
  });
});

describe("whiteboardVideo", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    storageMocks.storagePut.mockImplementation(
      async (
        key: string,
        _bytes: Buffer | Uint8Array,
        contentType: string
      ) => ({
        key,
        url: `/manus-storage/${key}`,
        contentType,
      })
    );
  });

  it("normalizes scene timelines to the actual audio duration", () => {
    const timelines = buildWhiteboardTimelines(basePayload.scenes, 10);
    expect(timelines).toHaveLength(2);
    expect(timelines[0]!.start).toBe(0);
    expect(timelines[0]!.end).toBeCloseTo(timelines[1]!.start);
    expect(timelines.at(-1)!.end).toBe(10);
    expect(timelines.every(item => item.duration > 0)).toBe(true);
  });

  it("renders real within-scene motion, erase transition, progressive labels, and an animated tutor marker", () => {
    const erase = whiteboardSvg(basePayload.scenes[0]!, 0.04, 0, 2);
    const early = whiteboardSvg(basePayload.scenes[0]!, 0.28, 0, 2);
    const late = whiteboardSvg(basePayload.scenes[0]!, 0.88, 0, 2);
    expect(erase).toContain("eraseSweep");
    expect(early).not.toBe(late);
    expect(early).toContain("markerHand");
    expect(early).toContain("boardArrow");
    expect(early).toContain("Context");
    expect(late).toContain("Takeaway");
  });

  it("renders source-specific board actions progressively", () => {
    const scene = {
      ...basePayload.scenes[0]!,
      boardActions: [
        { type: "write" as const, text: "Definition" },
        {
          type: "link" as const,
          text: "Why it matters",
          from: { x: 0.2, y: 0.5 },
          to: { x: 0.7, y: 0.5 },
        },
        {
          type: "highlight" as const,
          target: "Takeaway",
          emphasis: "accent" as const,
        },
        { type: "erase" as const, target: "Definition" },
      ],
    };
    const early = whiteboardSvg(scene, 0.18, 0, 1);
    const late = whiteboardSvg(scene, 0.92, 0, 1);
    expect(early).toContain('data-action-index="0"');
    expect(early).not.toContain('data-action-index="3"');
    expect(late).toContain('data-action-index="3"');
    expect(late).toContain("Definition");
    expect(late).toContain("actionHighlight");
    expect(late).toContain("boardActionLink");
  });

  it("generates one chapter narration and returns scene timelines plus the stored audio URL", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValue(
        responseJson({ output_audio: { data: pcm.toString("base64") } })
      );
    const lesson = await createWhiteboardLesson(7, "chapter-one", basePayload, {
      speech: { apiKey: "gemini-test-key", fetchImpl },
    });
    expect(fetchImpl).toHaveBeenCalledOnce();
    expect(storageMocks.storagePut).toHaveBeenCalledOnce();
    expect(lesson.audioURL).toContain("/manus-storage/");
    expect(lesson.scenes).toHaveLength(2);
    expect(lesson.audioDuration).toBeCloseTo(2, 2);
  });

  it("assembles an MP4 with audio using only deterministic board frames", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValue(
        responseJson({ output_audio: { data: pcm.toString("base64") } })
      );
    const url = await createWhiteboardVideo(7, "chapter-video", basePayload, {
      speech: { apiKey: "gemini-test-key", fetchImpl },
    });
    expect(url).toContain("/manus-storage/whiteboard/");
    expect(fetchImpl).toHaveBeenCalledOnce();
    expect(storageMocks.storagePut).toHaveBeenCalledTimes(2);
    expect(storageMocks.storagePut.mock.calls[1]![2]).toBe("video/mp4");
  }, 45_000);
});
