import { beforeEach, describe, expect, it, vi } from "vitest";
import sharp from "sharp";
import { imagesRouter } from "./imagesRouter";
import { runImageBatch } from "../client/src/pages/Images";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

const mocks = vi.hoisted(() => ({
  generateImage: vi.fn(),
  storagePut: vi.fn(),
  saveRecord: vi.fn(),
  listRecords: vi.fn(),
  getRecord: vi.fn(),
}));

vi.mock("./_core/imageGeneration", () => ({
  generateImage: mocks.generateImage,
  listImageModels: vi.fn(),
}));
vi.mock("./storage", () => ({
  storagePut: mocks.storagePut,
  storageGetSignedUrl: vi.fn(),
  storageGet: vi.fn(),
}));
vi.mock("./workspaceStore", () => ({
  saveRecord: mocks.saveRecord,
  listRecords: mocks.listRecords,
  getRecord: mocks.getRecord,
}));

function createAuthContext(userId = 42): TrpcContext {
  const now = new Date();
  const user: AuthenticatedUser = {
    id: userId,
    openId: `image-test-${userId}`,
    email: `image-${userId}@example.com`,
    name: "Image Test User",
    loginMethod: "test",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function dataUrl(buffer: Buffer, mimeType = "image/png") {
  return `data:${mimeType};base64,${buffer.toString("base64")}`;
}

function imageAttachment(buffer: Buffer, name = "reference.png") {
  return {
    name,
    mimeType: "image/png",
    dataUrl: dataUrl(buffer),
  };
}

async function smallPortraitPng() {
  return sharp({
    create: {
      width: 2,
      height: 4,
      channels: 4,
      background: { r: 230, g: 40, b: 80, alpha: 1 },
    },
  })
    .png()
    .toBuffer();
}

describe("adus.images", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.generateImage.mockResolvedValue({
      url: "/manus-storage/generated/result.png",
    });
    mocks.saveRecord.mockResolvedValue(undefined);
    mocks.listRecords.mockResolvedValue([]);
    mocks.getRecord.mockResolvedValue(undefined);
    mocks.storagePut.mockResolvedValue({
      key: "images/result.png",
      url: "/manus-storage/images/result.png",
    });
  });

  it("generates one standalone ordinal and passes an image reference explicitly for edits", async () => {
    const reference = await smallPortraitPng();
    const caller = imagesRouter.createCaller(createAuthContext());

    const result = await caller.generateOne({
      prompt: "Fix the small logo and keep the person exactly the same",
      index: 1,
      count: 3,
      reference: imageAttachment(reference),
    });

    expect(result).toEqual({
      url: "/manus-storage/generated/result.png",
      index: 1,
    });
    expect(mocks.generateImage).toHaveBeenCalledOnce();
    const options = mocks.generateImage.mock.calls[0]?.[0];
    expect(options.originalImages).toEqual([
      { b64Json: reference.toString("base64"), mimeType: "image/png" },
    ]);
    expect(options.prompt).toContain("item 2 of 3");
    expect(options.prompt).toContain("Preserve the reference identity");
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      42,
      "images",
      expect.objectContaining({
        url: "/manus-storage/generated/result.png",
        index: 1,
        edited: true,
      })
    );
  });

  it("rejects invalid batch counts and out-of-range ordinals", async () => {
    const caller = imagesRouter.createCaller(createAuthContext());

    await expect(
      caller.generateOne({ prompt: "test", index: 0, count: 0 })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      caller.generateOne({ prompt: "test", index: 0, count: 6 })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      caller.generateOne({ prompt: "test", index: 3, count: 3 })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      caller.generateOne({ prompt: "test", index: 5, count: 5 })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mocks.generateImage).not.toHaveBeenCalled();
  });

  it("rejects unauthenticated image work", async () => {
    const caller = imagesRouter.createCaller({
      ...createAuthContext(),
      user: null,
    });

    await expect(
      caller.generateOne({ prompt: "test", index: 0, count: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("resizes a real PNG to exact dimensions while preserving aspect ratio with contain", async () => {
    const source = await smallPortraitPng();
    const caller = imagesRouter.createCaller(createAuthContext());

    const result = await caller.resize({
      file: imageAttachment(source),
      width: 4,
      height: 4,
      fit: "contain",
      format: "png",
    });

    expect(result).toMatchObject({
      url: "/manus-storage/images/result.png",
      width: 4,
      height: 4,
      format: "png",
    });
    expect(mocks.storagePut).toHaveBeenCalledOnce();
    const storedBuffer = mocks.storagePut.mock.calls[0]?.[1] as Buffer;
    const metadata = await sharp(storedBuffer).metadata();
    expect(metadata.width).toBe(4);
    expect(metadata.height).toBe(4);

    const raw = await sharp(storedBuffer)
      .ensureAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });
    const centerPixel = (2 * raw.info.width + 2) * 4;
    const paddedPixel = (0 * raw.info.width + 0) * 4;
    expect(raw.data[centerPixel + 3]).toBeGreaterThan(0);
    expect(raw.data[paddedPixel + 3]).toBe(0);
  });

  it("rejects non-image resize inputs and output dimensions above 16 megapixels", async () => {
    const caller = imagesRouter.createCaller(createAuthContext());
    const text = Buffer.from("not an image");
    const nonImage = {
      name: "notes.txt",
      mimeType: "text/plain",
      dataUrl: dataUrl(text, "text/plain"),
    };

    await expect(
      caller.resize({
        file: nonImage,
        width: 100,
        height: 100,
        fit: "contain",
        format: "png",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      caller.resize({
        file: imageAttachment(await smallPortraitPng()),
        width: 4096,
        height: 4096,
        fit: "contain",
        format: "png",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mocks.storagePut).not.toHaveBeenCalled();
  });

  it("keeps batch UI work at two concurrent calls and reports partial failures", async () => {
    let active = 0;
    let maxActive = 0;
    const results: Array<{ index: number; value?: string; error?: unknown }> =
      [];
    await runImageBatch(
      [0, 1, 2, 3],
      async index => {
        active += 1;
        maxActive = Math.max(maxActive, active);
        await new Promise(resolve => setTimeout(resolve, index === 0 ? 8 : 2));
        active -= 1;
        if (index === 1) throw new Error("provider failed for item 2");
        return `image-${index}`;
      },
      result => results.push(result),
      2
    );

    expect(maxActive).toBeLessThanOrEqual(2);
    expect(results).toHaveLength(4);
    expect(results.find(result => result.index === 1)?.error).toBeInstanceOf(
      Error
    );
    expect(results.filter(result => result.value)).toHaveLength(3);
  });
});
