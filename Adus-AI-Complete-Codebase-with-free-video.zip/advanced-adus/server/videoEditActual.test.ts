import { afterAll, beforeEach, describe, expect, it, vi } from "vitest";
import { execFileSync, spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import type { TrpcContext } from "./_core/context";
import {
  createVideoEditPlan,
  probeVideo,
  type VideoEditPlan,
} from "./videoEditing";

const mocks = vi.hoisted(() => ({
  getRecord: vi.fn(),
  saveRecord: vi.fn(),
  storagePut: vi.fn(),
  loadStoredVideoSource: vi.fn(),
}));

vi.mock("./workspaceStore", () => ({
  getRecord: mocks.getRecord,
  saveRecord: mocks.saveRecord,
}));
vi.mock("./storage", () => ({
  storagePut: mocks.storagePut,
}));
vi.mock("./videoUpload", () => ({
  loadStoredVideoSource: mocks.loadStoredVideoSource,
}));

import { videoEditRouter } from "./videoEditRouter";

const sourceDirectory = mkdtempSync(join(tmpdir(), "adus-video-edit-actual-"));
const sourcePath = join(sourceDirectory, "source.mp4");
execFileSync("ffmpeg", [
  "-y",
  "-hide_banner",
  "-loglevel",
  "error",
  "-f",
  "lavfi",
  "-i",
  "testsrc=size=64x48:rate=10",
  "-f",
  "lavfi",
  "-i",
  "sine=frequency=440:sample_rate=8000",
  "-t",
  "2",
  "-c:v",
  "libx264",
  "-pix_fmt",
  "yuv420p",
  "-c:a",
  "aac",
  sourcePath,
]);
const sourceBytes = readFileSync(sourcePath);
const plan: VideoEditPlan = {
  version: 1,
  supported: true,
  summary: "Keep two ranges, mute one range, speed one range, and crop.",
  unsupportedReason: "",
  segments: [
    { start: 0, end: 0.8 },
    { start: 1.2, end: 2 },
  ],
  mute: [{ start: 0.2, end: 0.4 }],
  speed: [{ start: 1.2, end: 1.6, factor: 1.5 }],
  crop: { x: 0, y: 0, width: 0.75, height: 1 },
  rotate: 0,
};

function createAuthContext(userId = 42): TrpcContext {
  const now = new Date();
  return {
    user: {
      id: userId,
      openId: `video-edit-actual-${userId}`,
      email: "adammalaeb30@gmail.com",
      name: "Video Edit Actual Test",
      loginMethod: "test",
      role: "user",
      createdAt: now,
      updatedAt: now,
      lastSignedIn: now,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function ffprobe(path: string) {
  return JSON.parse(
    execFileSync(
      "ffprobe",
      ["-v", "error", "-show_streams", "-show_format", "-of", "json", path],
      { encoding: "utf8" }
    )
  ) as {
    streams: Array<{
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
    }>;
    format: { duration?: string };
  };
}

function meanVolume(path: string, start: number, duration: number): number {
  const output = spawnSync(
    "ffmpeg",
    [
      "-hide_banner",
      "-ss",
      String(start),
      "-t",
      String(duration),
      "-i",
      path,
      "-vn",
      "-af",
      "volumedetect",
      "-f",
      "null",
      "-",
    ],
    { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }
  );
  const report = `${output.stdout ?? ""}\n${output.stderr ?? ""}`;
  const match = /mean_volume:\s*(-?\d+(?:\.\d+)?) dB/.exec(report);
  if (!match) throw new Error(`FFmpeg did not report a volume for ${start}s.`);
  return Number(match[1]);
}

describe("actual deterministic video edit path", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.saveRecord.mockResolvedValue(undefined);
    mocks.storagePut.mockResolvedValue({
      key: "videos/42/result-1.mp4",
      url: "/manus-storage/videos/42/result-1.mp4",
    });
    mocks.loadStoredVideoSource.mockResolvedValue({
      id: "source-1",
      payload: {
        type: "source",
        name: "source.mp4",
        mimeType: "video/mp4",
      },
      bytes: sourceBytes,
      probe: {
        duration: 2,
        width: 64,
        height: 48,
        hasAudio: true,
        fps: 10,
      },
    });
    mocks.getRecord.mockImplementation(async (_userId, kind, id) =>
      kind === "video-edit-plan" && id === "plan-1"
        ? {
            id,
            payload: {
              type: "plan",
              status: "review",
              sourceId: "source-1",
              prompt:
                "Keep the first and last ranges, mute, crop, and speed up the middle.",
              source: {
                duration: 2,
                width: 64,
                height: 48,
                hasAudio: true,
                fps: 10,
              },
              plan,
              narration: {
                enabled: false,
                text: "",
                language: "en",
                gender: "woman",
              },
              estimatedDuration: 1.466666,
            },
          }
        : undefined
    );
  });

  it("normalizes provider JSON without inventing operations", async () => {
    const source = await probeVideo(sourceBytes, "video/mp4");
    const llm = vi.fn().mockResolvedValue({
      choices: [
        {
          message: {
            content: [
              {
                type: "text",
                text: `Here is the reviewed plan:\n\n
envelope: {"plan":{"version":"1","supported":"true","summary":"Keep the first second.","unsupportedReason":"","segments":[{"start":"0","end":"1"}],"mute":[],"speed":[],"crop":null,"rotate":"0"}}`,
              },
            ],
          },
        },
      ],
    });

    const result = await createVideoEditPlan({
      prompt: "Keep the first second.",
      source,
      llm,
    });

    expect(result).toMatchObject({
      supported: true,
      segments: [{ start: 0, end: 1 }],
      mute: [],
      speed: [],
      crop: null,
      rotate: 0,
      estimatedDuration: 1,
    });
    expect(llm).toHaveBeenCalledOnce();
    expect(llm.mock.calls[0]?.[0]).toMatchObject({
      model: "gpt-5-mini",
      response_format: expect.objectContaining({
        type: "json_schema",
        json_schema: expect.objectContaining({ strict: true }),
      }),
    });
  });

  it("applies a stored reviewed plan through the app router and stores playable output", async () => {
    const sourceProbe = await probeVideo(sourceBytes, "video/mp4");
    expect(sourceProbe).toMatchObject({
      duration: 2,
      width: 64,
      height: 48,
      hasAudio: true,
    });

    const result = await videoEditRouter
      .createCaller(createAuthContext())
      .applyPlan({ planId: "plan-1" });

    expect(result.plan).toMatchObject({
      status: "applied",
      sourceId: "source-1",
      resultId: expect.any(String),
    });
    expect(result.result).toMatchObject({
      type: "result",
      status: "completed",
      provider: "local",
      mimeType: "video/mp4",
      url: "/manus-storage/videos/42/result-1.mp4",
    });
    expect(mocks.storagePut).toHaveBeenCalledWith(
      expect.stringMatching(/^videos\/42\/.*\.mp4$/),
      expect.any(Buffer),
      "video/mp4"
    );

    const storedBytes = mocks.storagePut.mock.calls[0]?.[1] as Buffer;
    expect(Buffer.isBuffer(storedBytes)).toBe(true);
    expect(storedBytes.subarray(4, 8).toString("ascii")).toBe("ftyp");
    const outputDirectory = mkdtempSync(
      join(tmpdir(), "adus-video-edit-output-")
    );
    const outputPath = join(outputDirectory, "result.mp4");
    try {
      writeFileSync(outputPath, storedBytes);
      const metadata = ffprobe(outputPath);
      const video = metadata.streams.find(
        stream => stream.codec_type === "video"
      );
      const audio = metadata.streams.find(
        stream => stream.codec_type === "audio"
      );
      expect(video).toMatchObject({
        codec_name: "h264",
        width: 48,
        height: 48,
      });
      expect(audio).toMatchObject({ codec_name: "aac" });
      expect(Number(metadata.format.duration)).toBeGreaterThan(1.25);
      expect(Number(metadata.format.duration)).toBeLessThan(1.65);
      expect(meanVolume(outputPath, 0.22, 0.14)).toBeLessThan(-50);
      expect(meanVolume(outputPath, 0.55, 0.14)).toBeGreaterThan(-40);
    } finally {
      rmSync(outputDirectory, { recursive: true, force: true });
    }
  }, 30_000);
});

afterAll(() => {
  rmSync(sourceDirectory, { recursive: true, force: true });
});
