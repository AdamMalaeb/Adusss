import { beforeEach, describe, it, expect, vi } from "vitest";
import express from "express";
const m = vi.hoisted(() => ({ get: vi.fn() }));
vi.mock("./workspaceStore", () => ({ getRecord: m.get, listRecords: vi.fn() }));
import { mediaRouter, registerMediaDownloads } from "./mediaDownloads";
const ctx = { user: { id: 7 }, req: { headers: {} }, res: {} } as any;
beforeEach(() => {
  vi.clearAllMocks();
  m.get.mockResolvedValue(undefined);
});
describe("website source exports", () => {
  it("exports only owner-scoped reviewed HTML through a signed attachment link", async () => {
    const html = "<!doctype html><html><h1>Reviewed page</h1></html>";
    m.get.mockResolvedValue({ payload: { html } });
    const link = await mediaRouter
      .createCaller(ctx)
      .websiteTicket({ id: "web1" });
    expect(m.get).toHaveBeenCalledWith(7, "website", "web1");
    const app = express();
    registerMediaDownloads(app);
    const server = app.listen(0);
    try {
      const response = await fetch(
        `http://127.0.0.1:${(server.address() as any).port}${link.url}`
      );
      expect(response.headers.get("content-disposition")).toContain(
        "adus-website.html"
      );
      expect(response.headers.get("content-type")).toContain(
        "application/octet-stream"
      );
      expect(await response.text()).toBe(html);
    } finally {
      server.close();
    }
  });
  it("rejects an unowned draft before issuing an export ticket", async () => {
    await expect(
      mediaRouter.createCaller(ctx).websiteTicket({ id: "other" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});
