import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  invokeLLM: vi.fn(),
  listLLMModels: vi.fn(),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: mocks.invokeLLM,
  listLLMModels: mocks.listLLMModels,
}));

import {
  chatStyle,
  PROFESSIONAL_STYLE,
  voiceStyle,
} from "../shared/assistantStyle";
import { analyzeStudyParts, analyzeSummaryParts } from "./studyRouter";

const lesson = {
  title: "A source-grounded lesson",
  summary: "The source establishes one supported idea.",
  scenes: [
    {
      title: "The idea",
      bullets: ["The source states the idea."],
      narration: "The source states the idea and gives its supporting reason.",
    },
  ],
  sources: ["lesson.txt"],
  warnings: [],
};

beforeEach(() => {
  vi.clearAllMocks();
  mocks.listLLMModels.mockResolvedValue({ data: [{ id: "gpt-5-mini" }] });
  mocks.invokeLLM.mockResolvedValue({
    choices: [{ message: { content: JSON.stringify(lesson) } }],
  });
});

describe("assistant communication style", () => {
  it("provides neutral professional defaults and camera-specific uncertainty guidance", () => {
    expect(PROFESSIONAL_STYLE).toContain("mature, courteous, professional");
    expect(PROFESSIONAL_STYLE).toContain("Do not assume the user's gender");
    expect(PROFESSIONAL_STYLE).toContain(
      "never claim that a tool, file, or external action is finished"
    );
    expect(voiceStyle()).toContain("3–6 sentences");
    expect(voiceStyle()).toContain("60–140 words");
    expect(voiceStyle({ cameraMode: true })).toContain("directly visible");
    expect(voiceStyle({ cameraMode: true })).toContain(
      "separate observation from inference"
    );
    expect(voiceStyle({ cameraMode: true })).toContain(
      "not a continuous live view"
    );
    expect(chatStyle()).toContain(
      "do not add a ceremonial greeting to every turn"
    );
  });

  it("includes the shared style in the study-teacher prompt", async () => {
    await analyzeStudyParts(
      [{ type: "text", text: "A short source passage." }],
      ["lesson.txt"],
      "english"
    );

    const request = mocks.invokeLLM.mock.calls[0]?.[0];
    const system = request.messages.find(
      (message: { role: string }) => message.role === "system"
    );
    const userText = request.messages
      .find((message: { role: string }) => message.role === "user")
      ?.content.find((part: { type: string }) => part.type === "text")?.text;

    expect(system.content).toContain(PROFESSIONAL_STYLE);
    expect(userText).toContain(PROFESSIONAL_STYLE);
    expect(userText).toContain("worked reasoning");
    expect(userText).toContain("selected language");
  });

  it("keeps formal summaries source-grounded and free of conversational greetings", async () => {
    mocks.invokeLLM.mockResolvedValueOnce({
      choices: [
        {
          message: {
            content: JSON.stringify({
              title: "A source summary",
              summary: "The source supports one conclusion.",
              warnings: [],
            }),
          },
        },
      ],
    });

    await analyzeSummaryParts(
      [{ type: "text", text: "A short source passage." }],
      ["lesson.txt"],
      "english",
      "the source page"
    );

    const request = mocks.invokeLLM.mock.calls[0]?.[0];
    const system = request.messages.find(
      (message: { role: string }) => message.role === "system"
    );
    const userText = request.messages
      .find((message: { role: string }) => message.role === "user")
      ?.content.find((part: { type: string }) => part.type === "text")?.text;

    expect(system.content).toContain(PROFESSIONAL_STYLE);
    expect(system.content).toContain("formal academic summary");
    expect(userText).toContain("formal, source-grounded academic register");
    expect(userText).toContain("no script or narration needed");
    expect(userText).toContain(
      "do not insert a conversational greeting or honorific"
    );
  });
});
