import { describe, expect, it } from "vitest";
import { prepareInteractivePreview } from "../shared/websitePreview";
describe("Private website navigation", () => {
  it("installs a local navigation guard before user scripts, without changing saved source", () => {
    const original =
      '<!doctype html><html><head><script>window.example=true</script></head><body><a href="#services">Services</a><section id="services">Details</section></body></html>';
    const preview = prepareInteractivePreview(original);
    expect(preview.indexOf("data-adus-preview-navigation")).toBeLessThan(
      preview.indexOf("window.example")
    );
    expect(preview).toContain("event.stopImmediatePropagation");
    expect(preview).toContain("scrollIntoView");
    expect(preview).toContain(
      "This page is not part of this single-page draft"
    );
    expect(original).not.toContain("data-adus-preview-navigation");
    expect(prepareInteractivePreview(preview)).toBe(preview);
  });
  it("supports a document without a head element", () => {
    expect(prepareInteractivePreview("<h1>Demo</h1>")).toContain(
      "<h1>Demo</h1>"
    );
  });
});
