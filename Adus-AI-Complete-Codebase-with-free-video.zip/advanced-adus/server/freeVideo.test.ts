import { describe, expect, it } from "vitest";
import {
  FREE_VIDEO_MAX_SCENES,
  allocateSceneSeconds,
  clampDuration,
  countWords,
  dayKey,
  parseDailyLimit,
  pickEdgeVoice,
  splitIntoScenes,
  splitSentences,
  wrapText,
  type EdgeVoice,
} from "../shared/freeVideo";
import { parseEdgeVoiceTable, sceneSvg, wavSeconds } from "./freeVideoEngine";

const voices: EdgeVoice[] = [
  { ShortName: "en-US-AriaNeural", Gender: "Female", Locale: "en-US" },
  { ShortName: "en-US-GuyNeural", Gender: "Male", Locale: "en-US" },
  { ShortName: "ar-EG-SalmaNeural", Gender: "Female", Locale: "ar-EG" },
  { ShortName: "ar-SA-HamedNeural", Gender: "Male", Locale: "ar-SA" },
  { ShortName: "fr-FR-DeniseNeural", Gender: "Female", Locale: "fr-FR" },
];

describe("free video limits", () => {
  it("clamps length to 15-60 seconds", () => {
    expect(clampDuration(3)).toBe(15);
    expect(clampDuration(200)).toBe(60);
    expect(clampDuration(33.4)).toBe(33);
    expect(clampDuration(Number.NaN)).toBe(15);
  });
  it("parses the daily limit with a safe default", () => {
    expect(parseDailyLimit(undefined)).toBe(3);
    expect(parseDailyLimit("5")).toBe(5);
    expect(parseDailyLimit("0")).toBe(3);
    expect(parseDailyLimit("abc")).toBe(3);
  });
  it("uses UTC day keys", () => {
    expect(dayKey(Date.UTC(2026, 9, 18, 23, 59))).toBe("2026-10-18");
  });
});

describe("free video scenes", () => {
  it("never drops text when splitting into scenes", () => {
    const text = Array.from({ length: 20 }, (_, i) => `Sentence number ${i} is here.`).join(" ");
    const scenes = splitIntoScenes(text);
    expect(scenes.length).toBeGreaterThan(1);
    expect(scenes.length).toBeLessThanOrEqual(FREE_VIDEO_MAX_SCENES);
    expect(scenes.join(" ")).toBe(splitSentences(text).join(" "));
  });
  it("keeps a single short sentence as one scene", () => {
    expect(splitIntoScenes("Hello world.")).toEqual(["Hello world."]);
  });
  it("splits Arabic and CJK sentence terminators", () => {
    expect(splitSentences("مرحبا؟ كيف الحال.")).toHaveLength(2);
    expect(splitSentences("你好。再见！")).toHaveLength(2);
  });
  it("allocates exactly the requested total", () => {
    const seconds = allocateSceneSeconds(["a b c", "d e f g h i j"], 30);
    expect(seconds.reduce((a, b) => a + b, 0)).toBeCloseTo(30, 5);
    expect(seconds[1]!).toBeGreaterThan(seconds[0]!);
  });
  it("counts words in unspaced scripts", () => {
    expect(countWords("你好世界你好世界")).toBeGreaterThan(1);
    expect(countWords("one two three")).toBe(3);
  });
  it("wraps without losing words", () => {
    const lines = wrapText("one two three four five six", 9);
    expect(lines.join(" ")).toBe("one two three four five six");
  });
});

describe("free voices", () => {
  it("prefers exact locale and requested gender", () => {
    expect(pickEdgeVoice(voices, "ar-EG", "woman")?.ShortName).toBe("ar-EG-SalmaNeural");
    expect(pickEdgeVoice(voices, "ar", "man")?.ShortName).toBe("ar-SA-HamedNeural");
    expect(pickEdgeVoice(voices, "en", "man")?.ShortName).toBe("en-US-GuyNeural");
  });
  it("falls back to the other gender, and to nothing for unknown languages", () => {
    expect(pickEdgeVoice(voices, "fr", "man")?.ShortName).toBe("fr-FR-DeniseNeural");
    expect(pickEdgeVoice(voices, "ace-Arab", "woman")).toBeUndefined();
  });
  it("parses the edge-tts voice table", () => {
    const table = [
      "Name                     Gender    ContentCategories      VoicePersonalities",
      "-----------------------  --------  ---------------------  --------------------",
      "af-ZA-AdriNeural         Female    General                Friendly, Positive",
      "zh-CN-liaoning-XiaobeiNeural  Female  General  Humorous",
    ].join("\n");
    const parsed = parseEdgeVoiceTable(table);
    expect(parsed.map(v => v.Locale)).toEqual(["af-ZA", "zh-CN"]);
  });
});

describe("free video rendering helpers", () => {
  it("escapes text and sets RTL for Arabic", () => {
    const svg = sceneSvg({ text: "a < b & c", index: 0, count: 2, language: "ar", aspect: "16:9" });
    expect(svg).toContain("a &lt; b &amp; c");
    expect(svg).toContain('direction="rtl"');
    expect(svg).toContain('width="1280"');
  });
  it("uses a vertical canvas for 9:16", () => {
    const svg = sceneSvg({ text: "hi", index: 0, count: 1, language: "en", aspect: "9:16" });
    expect(svg).toContain('width="720"');
    expect(svg).toContain('height="1280"');
  });
  it("reads WAV duration", () => {
    const header = Buffer.alloc(44);
    header.write("RIFF", 0, "ascii");
    header.write("WAVE", 8, "ascii");
    header.writeUInt32LE(48_000, 28);
    header.write("data", 36, "ascii");
    header.writeUInt32LE(96_000, 40);
    expect(wavSeconds(Buffer.concat([header, Buffer.alloc(96_000)]))).toBeCloseTo(2, 5);
  });
});
