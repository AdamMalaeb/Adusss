import type { Express, Request } from "express";
import { isLockedOwner } from "./accessPolicy";
import { sdk } from "./_core/sdk";
import { MAX_SOURCE_BYTES, storeVideoSource } from "./videoUpload";

const MAX_MULTIPART_OVERHEAD = 1 * 1024 * 1024;
const MAX_MULTIPART_BYTES = MAX_SOURCE_BYTES + MAX_MULTIPART_OVERHEAD;

function messageFor(error: unknown): string {
  return error && typeof error === "object" && "message" in error
    ? String((error as { message?: unknown }).message ?? "")
    : "The video upload could not be completed.";
}

function statusFor(error: unknown): number {
  if (error && typeof error === "object" && "statusCode" in error) {
    const statusCode = Number((error as { statusCode?: unknown }).statusCode);
    if (statusCode >= 400 && statusCode < 600) return statusCode;
  }
  const code = error && typeof error === "object" && "code" in error
    ? String((error as { code?: unknown }).code ?? "")
    : "";
  return code === "UNAUTHORIZED" || code === "FORBIDDEN" ? 401
    : code === "BAD_REQUEST" ? 400
      : code === "NOT_FOUND" ? 404
        : 503;
}

async function readRequestBytes(req: Request): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let total = 0;
  for await (const chunk of req) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    total += bytes.length;
    if (total > MAX_MULTIPART_BYTES) {
      req.destroy();
      throw Object.assign(new Error("Multipart upload exceeds the 80 MB source limit."), { code: "BAD_REQUEST" });
    }
    chunks.push(bytes);
  }
  return Buffer.concat(chunks, total);
}

function parseBoundary(contentType: string): string {
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType);
  const boundary = match?.[1] ?? match?.[2]?.trim();
  if (!boundary || boundary.length > 200) throw Object.assign(new Error("Malformed multipart upload."), { code: "BAD_REQUEST" });
  return boundary;
}

function parseMultipart(body: Buffer, boundary: string): { name: string; mimeType: string; bytes: Buffer } {
  const marker = Buffer.from(`--${boundary}`);
  const first = body.indexOf(marker);
  if (first < 0) throw Object.assign(new Error("Malformed multipart upload."), { code: "BAD_REQUEST" });
  const headersStart = first + marker.length + 2;
  const headerEnd = body.indexOf(Buffer.from("\r\n\r\n"), headersStart);
  if (headerEnd < 0) throw Object.assign(new Error("Malformed multipart upload."), { code: "BAD_REQUEST" });
  const headers = body.subarray(headersStart, headerEnd).toString("utf8");
  const nextBoundary = body.indexOf(Buffer.from(`\r\n--${boundary}`), headerEnd + 4);
  if (nextBoundary < 0) throw Object.assign(new Error("Malformed multipart upload."), { code: "BAD_REQUEST" });
  const bytes = body.subarray(headerEnd + 4, nextBoundary);
  const disposition = /content-disposition:\s*form-data;[^\r\n]*name="file"[^\r\n]*filename="([^"]*)"/i.exec(headers);
  if (!disposition?.[1]) throw Object.assign(new Error("Choose a video file to upload."), { code: "BAD_REQUEST" });
  const contentType = /content-type:\s*([^\r\n]+)/i.exec(headers)?.[1]?.trim() || "";
  return { name: disposition[1], mimeType: contentType, bytes: Buffer.from(bytes) };
}

/** Parent integration: call registerVideoUploadRoute(app) before the tRPC middleware. */
export function registerVideoUploadRoute(app: Express): void {
  app.post("/api/videos/upload", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!isLockedOwner(user)) {
        res.status(403).json({ error: "This area is locked to the approved Adus account." });
        return;
      }
      const contentType = String(req.headers["content-type"] ?? "");
      if (!/^multipart\/form-data\s*;/i.test(contentType)) {
        res.status(400).json({ error: "Use multipart/form-data with a file field named file." });
        return;
      }
      const body = await readRequestBytes(req);
      const file = parseMultipart(body, parseBoundary(contentType));
      const result = await storeVideoSource(user.id, file);
      res.status(200).json(result);
    } catch (error) {
      res.status(statusFor(error)).json({ error: messageFor(error) });
    }
  });
}
