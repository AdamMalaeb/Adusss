import { ENV } from "./env";
import { protectCreatorBirthDate } from "../creatorProfile";
import { currentKnowledgeGuidance } from "../../shared/currentKnowledge";

export type Role = "system" | "user" | "assistant" | "tool" | "function";

export type TextContent = {
  type: "text";
  text: string;
};

export type ImageContent = {
  type: "image_url";
  image_url: {
    url: string;
    detail?: "auto" | "low" | "high";
  };
};

export type FileContent = {
  type: "file_url";
  file_url: {
    url: string;
    mime_type?:
      | "audio/mpeg"
      | "audio/wav"
      | "application/pdf"
      | "audio/mp4"
      | "video/mp4";
  };
};

export type MessageContent = string | TextContent | ImageContent | FileContent;

export type Message = {
  role: Role;
  content: MessageContent | MessageContent[];
  name?: string;
  tool_call_id?: string;
};

export type Tool = {
  type: "function";
  function: {
    name: string;
    description?: string;
    parameters?: Record<string, unknown>;
  };
};

export type ToolChoicePrimitive = "none" | "auto" | "required";
export type ToolChoiceByName = { name: string };
export type ToolChoiceExplicit = {
  type: "function";
  function: {
    name: string;
  };
};

export type ToolChoice =
  | ToolChoicePrimitive
  | ToolChoiceByName
  | ToolChoiceExplicit;

export type InvokeParams = {
  messages: Message[];
  tools?: Tool[];
  toolChoice?: ToolChoice;
  tool_choice?: ToolChoice;
  maxTokens?: number;
  max_tokens?: number;
  maxCompletionTokens?: number;
  max_completion_tokens?: number;
  outputSchema?: OutputSchema;
  output_schema?: OutputSchema;
  responseFormat?: ResponseFormat;
  response_format?: ResponseFormat;
  model?: string;
  thinking?: Record<string, unknown>;
  reasoning?: Record<string, unknown>;
  /** Cancels the request and any bounded retry backoff. */
  signal?: AbortSignal;
};

export type ToolCall = {
  id: string;
  type: "function";
  function: {
    name: string;
    arguments: string;
  };
};

export type InvokeResult = {
  id: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: Role;
      content: string | null | Array<TextContent | ImageContent | FileContent>;
      tool_calls?: ToolCall[];
    };
    finish_reason: string | null;
  }>;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
};

export type JsonSchema = {
  name: string;
  schema: Record<string, unknown>;
  strict?: boolean;
};

export type OutputSchema = JsonSchema;

export type ResponseFormat =
  | { type: "text" }
  | { type: "json_object" }
  | { type: "json_schema"; json_schema: JsonSchema };

/**
 * IDs verified against the live Forge catalog on 2026-10-10. Keep these in
 * one place so chat routing cannot silently drift to an unavailable provider.
 */
export const CHAT_MODELS = {
  fast: "gpt-5-mini",
  deep: "gpt-5.5",
  multimodalFast: "gemini-3-flash-preview",
  multimodalDeep: "gemini-3.1-pro-preview",
} as const;

export type ChatModelMode = "auto" | "fast" | "deep";

export function selectChatModel(options: {
  mode?: ChatModelMode;
  voiceMode?: boolean;
  multimodal?: boolean;
  needsDeepReasoning?: boolean;
}): string {
  const mode = options.mode ?? "auto";
  if (options.voiceMode) return CHAT_MODELS.fast;

  const deep =
    mode === "deep" || (mode === "auto" && options.needsDeepReasoning);
  if (options.multimodal) {
    return deep ? CHAT_MODELS.multimodalDeep : CHAT_MODELS.multimodalFast;
  }
  if (mode === "fast") return CHAT_MODELS.fast;
  return deep ? CHAT_MODELS.deep : CHAT_MODELS.fast;
}

const ensureArray = (
  value: MessageContent | MessageContent[]
): MessageContent[] => (Array.isArray(value) ? value : [value]);

const normalizeContentPart = (
  part: MessageContent
): TextContent | ImageContent | FileContent => {
  if (typeof part === "string") {
    return { type: "text", text: part };
  }

  if (part.type === "text") {
    return part;
  }

  if (part.type === "image_url") {
    return part;
  }

  if (part.type === "file_url") {
    return part;
  }

  throw new Error("Unsupported message content part");
};

const normalizeMessage = (message: Message) => {
  const { role, name, tool_call_id } = message;

  if (role === "tool" || role === "function") {
    const content = ensureArray(message.content)
      .map(part => (typeof part === "string" ? part : JSON.stringify(part)))
      .join("\n");

    return {
      role,
      name,
      tool_call_id,
      content,
    };
  }

  const contentParts = ensureArray(message.content).map(normalizeContentPart);

  // If there's only text content, collapse to a single string for compatibility
  if (contentParts.length === 1 && contentParts[0].type === "text") {
    return {
      role,
      name,
      content: contentParts[0].text,
    };
  }

  return {
    role,
    name,
    content: contentParts,
  };
};

const normalizeToolChoice = (
  toolChoice: ToolChoice | undefined,
  tools: Tool[] | undefined
): "none" | "auto" | ToolChoiceExplicit | undefined => {
  if (!toolChoice) return undefined;

  if (toolChoice === "none" || toolChoice === "auto") {
    return toolChoice;
  }

  if (toolChoice === "required") {
    if (!tools || tools.length === 0) {
      throw new Error(
        "tool_choice 'required' was provided but no tools were configured"
      );
    }

    if (tools.length > 1) {
      throw new Error(
        "tool_choice 'required' needs a single tool or specify the tool name explicitly"
      );
    }

    return {
      type: "function",
      function: { name: tools[0].function.name },
    };
  }

  if ("name" in toolChoice) {
    return {
      type: "function",
      function: { name: toolChoice.name },
    };
  }

  return toolChoice;
};

const resolveApiUrl = () =>
  ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0
    ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions`
    : "https://forge.manus.im/v1/chat/completions";

const assertApiKey = () => {
  if (!ENV.forgeApiKey) {
    throw new Error("OPENAI_API_KEY is not configured");
  }
};

const normalizeResponseFormat = ({
  responseFormat,
  response_format,
  outputSchema,
  output_schema,
}: {
  responseFormat?: ResponseFormat;
  response_format?: ResponseFormat;
  outputSchema?: OutputSchema;
  output_schema?: OutputSchema;
}):
  | { type: "json_schema"; json_schema: JsonSchema }
  | { type: "text" }
  | { type: "json_object" }
  | undefined => {
  const explicitFormat = responseFormat || response_format;
  if (explicitFormat) {
    if (
      explicitFormat.type === "json_schema" &&
      !explicitFormat.json_schema?.schema
    ) {
      throw new Error(
        "responseFormat json_schema requires a defined schema object"
      );
    }
    return explicitFormat;
  }

  const schema = outputSchema || output_schema;
  if (!schema) return undefined;

  if (!schema.name || !schema.schema) {
    throw new Error("outputSchema requires both name and schema");
  }

  return {
    type: "json_schema",
    json_schema: {
      name: schema.name,
      schema: schema.schema,
      ...(typeof schema.strict === "boolean" ? { strict: schema.strict } : {}),
    },
  };
};

// One bounded retry is enough to cover a transient network/provider blip
// without multiplying quota usage when the upstream is unavailable.
const RETRY_MAX_RETRIES = 1;
const RETRY_BASE_DELAY_MS = 250;
const RETRY_MAX_DELAY_MS = 4_000;

type FetchInit = NonNullable<Parameters<typeof fetch>[1]>;

const abortError = () =>
  new DOMException("The LLM request was cancelled.", "AbortError");

const sleep = (ms: number, signal?: AbortSignal) => {
  if (ms <= 0) {
    if (signal?.aborted) return Promise.reject(abortError());
    return Promise.resolve();
  }
  if (signal?.aborted) return Promise.reject(abortError());
  return new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", cancel);
      resolve();
    }, ms);
    const cancel = () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", cancel);
      reject(abortError());
    };
    signal?.addEventListener("abort", cancel, { once: true });
  });
};

const parseRetryAfter = (value: string | null): number | undefined => {
  if (!value) return undefined;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000);
  const at = Date.parse(value);
  return Number.isNaN(at) ? undefined : Math.max(0, at - Date.now());
};

// Equal-jitter exponential backoff. The cap/2 floor guarantees a minimum
// delay so a misbehaving caller loop slows down instead of hammering the
// upstream while it keeps returning errors.
const computeBackoffDelay = (
  attempt: number,
  retryAfterMs?: number
): number => {
  const cap = Math.min(RETRY_BASE_DELAY_MS * 2 ** attempt, RETRY_MAX_DELAY_MS);
  const jittered = cap / 2 + Math.random() * (cap / 2);
  return Math.min(Math.max(jittered, retryAfterMs ?? 0), RETRY_MAX_DELAY_MS);
};

const isRetryableStatus = (status: number) =>
  status === 408 ||
  status === 409 ||
  status === 425 ||
  status === 429 ||
  status >= 500;

// Retries only transient statuses and network errors, then returns the final
// Response so callers keep their existing error handling. Auth, validation,
// and unsupported-model errors are not retried because another request would
// not improve them and would consume more provider quota.
const fetchWithBackoff = async (
  url: string,
  init: FetchInit
): Promise<Response> => {
  let lastError: unknown;
  const signal = init.signal ?? undefined;

  for (let attempt = 0; attempt <= RETRY_MAX_RETRIES; attempt++) {
    if (signal?.aborted) throw abortError();
    try {
      const response = await fetch(url, init);
      if (
        response.ok ||
        attempt === RETRY_MAX_RETRIES ||
        !isRetryableStatus(response.status)
      ) {
        return response;
      }

      const providerFailure = await response
        .clone()
        .text()
        .catch(() => "");
      if (
        /usage exhausted|insufficient_quota|quota_exceeded|quota exhausted|quota exceeded|billing_hard_limit/i.test(
          providerFailure
        )
      ) {
        return response;
      }
      const retryAfterMs = parseRetryAfter(response.headers.get("retry-after"));
      try {
        await response.body?.cancel();
      } catch {
        // Body already settled; nothing to clean up.
      }
      console.warn(`LLM request retry after status ${response.status}`);
      await sleep(computeBackoffDelay(attempt, retryAfterMs), signal);
    } catch (error) {
      lastError = error;
      if (signal?.aborted) throw error;
      if (attempt === RETRY_MAX_RETRIES) throw error;
      console.warn("LLM request retry after network error");
      await sleep(computeBackoffDelay(attempt), signal);
    }
  }

  throw lastError instanceof Error
    ? lastError
    : new Error("LLM request failed after exhausting retries");
};

export async function invokeLLM(
  params: InvokeParams,
  allowEmptyFallback = false
): Promise<InvokeResult> {
  assertApiKey();

  const {
    messages,
    tools,
    toolChoice,
    tool_choice,
    outputSchema,
    output_schema,
    responseFormat,
    response_format,
    model,
    thinking,
    reasoning,
    maxTokens,
    max_tokens,
    maxCompletionTokens,
    max_completion_tokens,
    signal,
  } = params;

  const payload: Record<string, unknown> = {
    messages: [
      {
        role: "system",
        content:
          "Privacy rule for Adus: the creator is Adam Nabil Malaeb. His date of birth is private. Never disclose or reconstruct it from previous messages, attachments or preferences. Do not include it in generated documents, scripts or tool responses.",
      },
      { role: "system", content: currentKnowledgeGuidance() },
      ...messages.map(normalizeMessage),
    ],
  };

  if (model) {
    payload.model = model;
  }

  if (tools && tools.length > 0) {
    payload.tools = tools;
  }

  const normalizedToolChoice = normalizeToolChoice(
    toolChoice || tool_choice,
    tools
  );
  if (normalizedToolChoice) {
    payload.tool_choice = normalizedToolChoice;
  }

  // The proxy uses different output-token keys by model family. Normalize
  // aliases here so callers cannot accidentally send GPT's key to Gemini (or
  // vice versa), which can produce a null/length response.
  const modelId = model ?? "";
  const isGpt = /^(?:gpt|o[1-9])/i.test(modelId);
  const resolvedMaxTokens = max_tokens ?? maxTokens;
  const resolvedMaxCompletionTokens =
    max_completion_tokens ?? maxCompletionTokens;
  if (isGpt) {
    const gptMax = resolvedMaxCompletionTokens ?? resolvedMaxTokens;
    if (typeof gptMax === "number") payload.max_completion_tokens = gptMax;
  } else {
    const providerMax = resolvedMaxTokens ?? resolvedMaxCompletionTokens;
    if (typeof providerMax === "number") payload.max_tokens = providerMax;
  }

  if (thinking) {
    payload.thinking = thinking;
  }
  if (reasoning) {
    payload.reasoning = reasoning;
  }

  const normalizedResponseFormat = normalizeResponseFormat({
    responseFormat,
    response_format,
    outputSchema,
    output_schema,
  });

  if (normalizedResponseFormat) {
    payload.response_format = normalizedResponseFormat;
  }

  const response = await fetchWithBackoff(resolveApiUrl(), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${ENV.forgeApiKey}`,
    },
    body: JSON.stringify(payload),
    signal,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(
      `LLM invoke failed: ${response.status} ${response.statusText} – ${errorText}`
    );
  }

  const result = (await response.json()) as InvokeResult;
  const message = result.choices?.[0]?.message;
  const hasToolCalls = Boolean(message?.tool_calls?.length);
  const hasText =
    typeof message?.content === "string"
      ? message.content.trim().length > 0
      : Array.isArray(message?.content)
        ? message.content.some(
            part => part.type === "text" && part.text.trim().length > 0
          )
        : false;
  if (!message || (!hasText && !hasToolCalls)) {
    // Some GPT proxy responses can be successful HTTP responses with no text.
    // One independent model attempt is allowed only for this concrete failure,
    // never for auth/quota errors or requests that might execute tools.
    if (
      allowEmptyFallback &&
      !tools?.length &&
      (model === CHAT_MODELS.fast || model === CHAT_MODELS.deep)
    ) {
      const fallbackModel =
        model === CHAT_MODELS.fast
          ? CHAT_MODELS.multimodalFast
          : CHAT_MODELS.multimodalDeep;
      return invokeLLM(
        {
          ...params,
          model: fallbackModel,
          maxTokens: Math.max(
            4500,
            resolvedMaxCompletionTokens ?? resolvedMaxTokens ?? 4500
          ),
          max_tokens: undefined,
          maxCompletionTokens: undefined,
          max_completion_tokens: undefined,
          reasoning: undefined,
          thinking: undefined,
        },
        false
      );
    }
    throw new Error("LLM returned an empty assistant response");
  }
  for (const choice of result.choices ?? []) {
    if (typeof choice.message.content === "string")
      choice.message.content = protectCreatorBirthDate(choice.message.content);
    else if (Array.isArray(choice.message.content))
      for (const part of choice.message.content) {
        if (part.type === "text")
          part.text = protectCreatorBirthDate(part.text);
      }
  }
  return result;
}

export type ModelInfo = {
  id: string;
  object: string;
  created: number;
  owned_by: string;
};

export type ModelsResponse = {
  object: string;
  data: ModelInfo[];
};

export async function listLLMModels(): Promise<ModelsResponse> {
  assertApiKey();

  const url =
    ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0
      ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/models`
      : "https://forge.manus.im/v1/models";

  const response = await fetchWithBackoff(url, {
    headers: { authorization: `Bearer ${ENV.forgeApiKey}` },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(
      `List LLM models failed: ${response.status} ${response.statusText} – ${errorText}`
    );
  }

  return (await response.json()) as ModelsResponse;
}
