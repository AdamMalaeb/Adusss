import { createHash, randomUUID } from "node:crypto";
import { zipSync, strToU8 } from "fflate";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getRecord, saveRecord } from "./workspaceStore";
import { protectedProcedure, router } from "./_core/trpc";
import { getGithubPageStatus, publishGithubRepository } from "./githubHosting";

const NETLIFY_API_ORIGIN = "https://api.netlify.com";
const NETLIFY_API_BASE = `${NETLIFY_API_ORIGIN}/api/v1`;
const MAX_TOKEN_LENGTH = 400;
const MAX_HTML_LENGTH = 200_000;
const DEPLOYMENT_KIND = "deployment";
const NETLIFY_TOKEN_ENV = "NETLIFY_ACCESS_TOKEN";
const GITHUB_TOKEN_ENV = "GITHUB_PAGES_TOKEN";

type Host = "netlify" | "github" | "vercel" | "other";
type DeploymentState = "processing" | "published" | "failed";

type WebsiteArtifact = {
  title: string;
  summary?: string;
  html: string;
};

type DeploymentPayload = {
  websiteId: string;
  host: Host;
  siteName: string;
  siteId: string;
  deployId: string;
  state: DeploymentState;
  url?: string;
  githubOwner?: string;
  githubRepo?: string;
  githubBranch?: string;
};

type NetlifyResponse = Record<string, unknown>;

const publishInput = z.object({
  websiteId: z.string().min(1).max(64),
  host: z.enum(["netlify", "github", "vercel", "other"]),
  siteName: z.string().min(1).max(63),
  token: z.string().min(1).max(MAX_TOKEN_LENGTH),
  confirm: z.boolean(),
});

const statusInput = z.object({ id: z.string().min(1).max(64) });
const checkInput = statusInput.extend({
  token: z.string().min(1).max(MAX_TOKEN_LENGTH),
});

function badRequest(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}

function notFound(message: string): never {
  throw new TRPCError({ code: "NOT_FOUND", message });
}

function preconditionFailed(message: string): never {
  throw new TRPCError({ code: "PRECONDITION_FAILED", message });
}

function gatewayError(message: string): never {
  throw new TRPCError({ code: "BAD_GATEWAY", message });
}

function providerHttpMessage(
  provider: "Netlify" | "GitHub",
  status: number,
  operation: string
) {
  if (status === 401)
    return `${provider} rejected the token while ${operation}. Check that it is active and has the required account permissions.`;
  if (status === 403)
    return `${provider} denied this operation while ${operation}. Check token scopes, account access, and (for GitHub Pages) repository administration permissions.`;
  if (status === 404)
    return `${provider} could not find the requested resource while ${operation}. Check the site or repository name and try again.`;
  if (status === 409)
    return `${provider} reported a conflict while ${operation}. The name may already be in use or the provider may already have a Pages configuration.`;
  if (status === 422)
    return `${provider} rejected the request while ${operation}. Check the slug and account limits, then retry with the reviewed draft.`;
  if (status === 429)
    return `${provider} rate-limited this request while ${operation}. Wait before retrying; the reviewed draft remains available.`;
  return `${provider} could not complete the request while ${operation} (HTTP ${status}). The reviewed draft remains available to retry.`;
}

function normalizeSiteName(value: string) {
  const siteName = value.trim().toLowerCase();
  if (!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(siteName)) {
    badRequest(
      "Use a site name slug with lowercase letters, numbers, and hyphens."
    );
  }
  return siteName;
}

function validateToken(token: string, host: Host = "netlify") {
  const normalized = token.trim();
  if (!normalized || normalized.length > MAX_TOKEN_LENGTH) {
    badRequest(
      host === "github"
        ? "Enter a valid GitHub personal access token."
        : "Enter a valid Netlify personal access token."
    );
  }
  return normalized;
}

function validateWebsitePayload(payload: unknown): WebsiteArtifact {
  if (!payload || typeof payload !== "object") {
    badRequest(
      "This website draft is no longer available. Regenerate it and try again."
    );
  }
  const candidate = payload as Partial<WebsiteArtifact>;
  if (
    typeof candidate.title !== "string" ||
    !candidate.title.trim() ||
    candidate.title.length > 200
  ) {
    badRequest(
      "This website draft has an invalid title. Regenerate it and try again."
    );
  }
  if (
    typeof candidate.html !== "string" ||
    !candidate.html.trim() ||
    candidate.html.length > MAX_HTML_LENGTH
  ) {
    badRequest(
      "This website draft has invalid HTML. Regenerate it and try again."
    );
  }
  const html = candidate.html;
  if (
    /<\s*script(?:\s|>)/i.test(html) ||
    /\bon[a-z][\w-]*\s*=/i.test(html) ||
    /javascript\s*:/i.test(html)
  ) {
    badRequest(
      "This website contains script code and cannot be published as a static page."
    );
  }
  if (/<\s*form(?:\s|>)/i.test(html)) {
    badRequest(
      "This website contains a form and cannot be published as a static page."
    );
  }
  return { title: candidate.title.trim(), summary: candidate.summary, html };
}

function asHttpsUrl(value: unknown) {
  if (typeof value !== "string" || !value) return undefined;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" ? value : undefined;
  } catch {
    return undefined;
  }
}

function outputFor(record: { id: string; payload: DeploymentPayload }) {
  return record.payload.url
    ? {
        id: record.id,
        host: record.payload.host,
        state: record.payload.state,
        url: record.payload.url,
      }
    : { id: record.id, host: record.payload.host, state: record.payload.state };
}

function deploymentIdFor(websiteId: string, siteName: string) {
  // The time and UUID make each explicit publish a new record; hashing keeps the DB id within varchar(64).
  const entropy = `${websiteId}:${siteName}:${Date.now()}:${randomUUID()}`;
  return `deployment-${createHash("sha256").update(entropy).digest("hex").slice(0, 40)}`;
}

function authorization(token: string) {
  return { Authorization: `Bearer ${token}` };
}

async function netlifyRequest(
  path: string,
  init: RequestInit,
  failureMessage: string
): Promise<NetlifyResponse> {
  // The path is selected only from the fixed endpoint allowlist below. Never fetch a user-provided URL.
  const url = `${NETLIFY_API_BASE}${path}`;
  let response: Response;
  try {
    response = await fetch(url, {
      ...init,
      redirect: "error",
      signal: AbortSignal.timeout(15_000),
    });
  } catch {
    gatewayError(failureMessage);
  }
  let body: unknown;
  try {
    body = await response.json();
  } catch {
    body = undefined;
  }
  if (!response.ok)
    gatewayError(
      providerHttpMessage("Netlify", response.status, failureMessage)
    );
  if (!body || typeof body !== "object") {
    gatewayError("Netlify returned an invalid response. Please try again.");
  }
  return body as NetlifyResponse;
}

async function verifyNetlifyToken(token: string) {
  const user = await netlifyRequest(
    "/user",
    {
      method: "GET",
      headers: { ...authorization(token), Accept: "application/json" },
    },
    "Netlify could not verify that token. Check it and try again."
  );
  if (
    typeof user.id !== "string" &&
    typeof user.email !== "string" &&
    typeof user.full_name !== "string"
  ) {
    gatewayError(
      "Netlify returned no authenticated account details. Check the token and try again."
    );
  }
}

function zipWebsite(html: string) {
  return zipSync({ "index.html": strToU8(html) });
}

async function createNetlifySite(token: string, siteName: string) {
  const body = JSON.stringify({ name: siteName });
  const site = await netlifyRequest(
    "/sites",
    {
      method: "POST",
      headers: {
        ...authorization(token),
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body,
    },
    "Netlify could not create the site. Check the name and your account access."
  );
  const siteId =
    typeof site.id === "string"
      ? site.id
      : typeof site.site_id === "string"
        ? site.site_id
        : undefined;
  if (!siteId) gatewayError("Netlify returned no site ID. Please try again.");
  return siteId;
}

async function createNetlifyDeploy(
  token: string,
  siteId: string,
  html: string
) {
  const zip = zipWebsite(html);
  const deploy = await netlifyRequest(
    `/sites/${encodeURIComponent(siteId)}/deploys`,
    {
      method: "POST",
      headers: {
        ...authorization(token),
        Accept: "application/json",
        "Content-Type": "application/zip",
      },
      body: zip as unknown as BodyInit,
    },
    "Netlify could not start the deployment. The draft is still available to retry."
  );
  const deployId = typeof deploy.id === "string" ? deploy.id : undefined;
  if (!deployId)
    gatewayError(
      "Netlify returned no deployment ID. The draft is still available to retry."
    );
  return deployId;
}

async function getNetlifyDeploy(token: string, deployId: string) {
  return netlifyRequest(
    `/deploys/${encodeURIComponent(deployId)}`,
    {
      method: "GET",
      headers: { ...authorization(token), Accept: "application/json" },
    },
    "Netlify could not check the deployment yet. Keep this window open and try again."
  );
}

function netlifyState(response: NetlifyResponse): {
  state: DeploymentState;
  url?: string;
} {
  const state =
    typeof response.state === "string" ? response.state.toLowerCase() : "";
  if (["error", "failed", "canceled", "cancelled"].includes(state))
    return { state: "failed" };
  const url =
    asHttpsUrl(response.ssl_url) ??
    asHttpsUrl(response.deploy_ssl_url) ??
    asHttpsUrl(response.url);
  if (state === "ready" && url) return { state: "published", url };
  if (state === "ready") return { state: "failed" };
  return { state: "processing" };
}

async function waitForNetlifyDeploy(token: string, deployId: string) {
  const deadline = Date.now() + 30_000;
  try {
    while (true) {
      const response = await getNetlifyDeploy(token, deployId);
      const current = netlifyState(response);
      if (current.state !== "processing") return current;
      if (Date.now() + 2_000 > deadline) return current;
      await new Promise(resolve => setTimeout(resolve, 2_000));
    }
  } catch {
    // The provider IDs are already persisted. Let the caller retain the deployment ID
    // and use the explicit check mutation rather than losing a transient deploy error.
    return { state: "processing" as const };
  }
}

async function loadDeployment(userId: number, id: string) {
  const record = await getRecord(userId, DEPLOYMENT_KIND, id);
  if (!record) notFound("That deployment was not found in your workspace.");
  const payload = record.payload as Partial<DeploymentPayload>;
  if (
    typeof payload.websiteId !== "string" ||
    typeof payload.host !== "string" ||
    typeof payload.siteName !== "string" ||
    typeof payload.siteId !== "string" ||
    typeof payload.deployId !== "string" ||
    !["processing", "published", "failed"].includes(String(payload.state))
  ) {
    badRequest(
      "That deployment record is invalid. Please publish the website again."
    );
  }
  return { id: record.id, payload: payload as DeploymentPayload };
}

async function checkDeployment(userId: number, id: string, rawToken: string) {
  const record = await loadDeployment(userId, id);
  if (record.payload.state !== "processing") {
    return outputFor(record);
  }
  const token = validateToken(rawToken, record.payload.host);
  if (record.payload.host === "github") {
    if (
      !record.payload.githubOwner ||
      !record.payload.githubRepo ||
      !record.payload.githubBranch
    ) {
      badRequest(
        "That GitHub Pages deployment record is incomplete. Please publish the website again."
      );
    }
    const status = await getGithubPageStatus(token, {
      owner: record.payload.githubOwner,
      repo: record.payload.githubRepo,
      branch: record.payload.githubBranch,
    });
    if (status.state === "processing") return outputFor(record);
    const nextPayload: DeploymentPayload = status.url
      ? { ...record.payload, state: status.state, url: status.url }
      : { ...record.payload, state: status.state };
    const saved = await saveRecord(
      userId,
      DEPLOYMENT_KIND,
      nextPayload,
      record.id
    );
    return outputFor({
      id: saved.id,
      payload: saved.payload as DeploymentPayload,
    });
  }
  const status = netlifyState(
    await getNetlifyDeploy(token, record.payload.deployId)
  );
  if (status.state === "processing") return outputFor(record);
  const nextPayload: DeploymentPayload = status.url
    ? { ...record.payload, state: status.state, url: status.url }
    : { ...record.payload, state: status.state };
  const saved = await saveRecord(
    userId,
    DEPLOYMENT_KIND,
    nextPayload,
    record.id
  );
  return outputFor({
    id: saved.id,
    payload: saved.payload as DeploymentPayload,
  });
}

export const hostingRouter = router({
  configuration: protectedProcedure.query(() => ({
    netlify: {
      host: "netlify" as const,
      adapter: "ready" as const,
      userTokenSupported: true,
      serverCredentialConfigured: Boolean(
        process.env[NETLIFY_TOKEN_ENV]?.trim()
      ),
      credentialEnv: NETLIFY_TOKEN_ENV,
    },
    github: {
      host: "github" as const,
      adapter: "ready" as const,
      userTokenSupported: true,
      serverCredentialConfigured: Boolean(
        process.env[GITHUB_TOKEN_ENV]?.trim()
      ),
      credentialEnv: GITHUB_TOKEN_ENV,
    },
    vercel: {
      host: "vercel" as const,
      adapter: "coming-soon" as const,
      userTokenSupported: false,
      serverCredentialConfigured: false,
      credentialEnv: null,
    },
    other: {
      host: "other" as const,
      adapter: "export" as const,
      userTokenSupported: false,
      serverCredentialConfigured: false,
      credentialEnv: null,
    },
  })),
  publish: protectedProcedure
    .input(publishInput)
    .mutation(async ({ ctx, input }) => {
      if (!input.confirm)
        badRequest(
          "Confirm the final public-internet warning before publishing."
        );
      const website = await getRecord(ctx.user.id, "website", input.websiteId);
      if (!website)
        notFound(
          "That website draft was not found in your workspace. Regenerate it and try again."
        );
      const artifact = validateWebsitePayload(website.payload);
      const siteName = normalizeSiteName(input.siteName);
      const host = input.host as Host;

      if (host === "github") {
        const token = validateToken(input.token, host);
        let repository;
        try {
          repository = await publishGithubRepository(
            token,
            siteName,
            artifact.html
          );
        } catch (error) {
          gatewayError(
            error instanceof Error
              ? error.message
              : "GitHub could not publish the reviewed website. Please try again."
          );
        }
        const id = deploymentIdFor(input.websiteId, siteName);
        const initialPayload: DeploymentPayload = {
          websiteId: input.websiteId,
          host,
          siteName,
          siteId: repository.repo,
          deployId: `${repository.owner}/${repository.repo}`,
          state: "processing",
          githubOwner: repository.owner,
          githubRepo: repository.repo,
          githubBranch: repository.branch,
        };
        const saved = await saveRecord(
          ctx.user.id,
          DEPLOYMENT_KIND,
          initialPayload,
          id
        );
        return outputFor({
          id: saved.id,
          payload: saved.payload as DeploymentPayload,
        });
      }

      if (host !== "netlify") {
        preconditionFailed(
          "This host adapter is not configured yet. Export the HTML file and publish it with your host."
        );
      }

      const token = validateToken(input.token, host);
      await verifyNetlifyToken(token);
      const siteId = await createNetlifySite(token, siteName);
      const deployId = await createNetlifyDeploy(token, siteId, artifact.html);
      const id = deploymentIdFor(input.websiteId, siteName);
      const initialPayload: DeploymentPayload = {
        websiteId: input.websiteId,
        host,
        siteName,
        siteId,
        deployId,
        state: "processing",
      };

      // Persist the provider IDs before polling so a transient poll/storage error never loses the deployment.
      const savedInitial = await saveRecord(
        ctx.user.id,
        DEPLOYMENT_KIND,
        initialPayload,
        id
      );
      const completed = await waitForNetlifyDeploy(token, deployId);
      const finalPayload: DeploymentPayload = completed.url
        ? { ...initialPayload, state: completed.state, url: completed.url }
        : { ...initialPayload, state: completed.state };
      let saved = savedInitial;
      try {
        saved = await saveRecord(
          ctx.user.id,
          DEPLOYMENT_KIND,
          finalPayload,
          id
        );
      } catch {
        // The initial record contains siteId/deployId, so a later explicit check can finish it.
      }
      return outputFor({
        id: saved.id,
        payload: saved.payload as DeploymentPayload,
      });
    }),
  status: protectedProcedure
    .input(statusInput)
    .query(({ ctx, input }) =>
      loadDeployment(ctx.user.id, input.id).then(outputFor)
    ),
  check: protectedProcedure
    .input(checkInput)
    .mutation(({ ctx, input }) =>
      checkDeployment(ctx.user.id, input.id, input.token)
    ),
});

export default hostingRouter;
