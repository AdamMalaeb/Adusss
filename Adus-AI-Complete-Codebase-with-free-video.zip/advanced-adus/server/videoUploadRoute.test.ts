import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import express from "express";
import { createServer, type Server } from "node:http";
const m = vi.hoisted(() => ({ auth: vi.fn(), store: vi.fn() }));
vi.mock("./_core/sdk", () => ({ sdk: { authenticateRequest: m.auth } }));
vi.mock("./videoUpload", () => ({
  MAX_SOURCE_BYTES: 80 * 1024 * 1024,
  storeVideoSource: m.store,
}));
import { registerVideoUploadRoute } from "./videoUploadRoute";
let server: Server;
let url: string;
beforeEach(async () => {
  vi.clearAllMocks();
  m.auth.mockResolvedValue({ id: 7, email: "adammalaeb30@gmail.com" });
  m.store.mockImplementation(async (userId, file) => ({
    id: "source",
    bytes: file.bytes.length,
    type: "source",
    mimeType: file.mimeType,
    name: file.name,
  }));
  const app = express();
  app.use(express.json({ limit: "50mb" }));
  registerVideoUploadRoute(app);
  server = createServer(app);
  await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
  url = `http://127.0.0.1:${(server.address() as { port: number }).port}/api/videos/upload`;
});
afterEach(async () => {
  await new Promise<void>(resolve => server.close(() => resolve()));
});
describe("native video uploads", () => {
  it("accepts an original multipart file larger than the old 12 MB base64 cap", async () => {
    const body = new FormData();
    body.append(
      "file",
      new Blob([new Uint8Array(13 * 1024 * 1024)], { type: "video/quicktime" }),
      "phone.MOV"
    );
    const response = await fetch(url, { method: "POST", body });
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({
      id: "source",
      bytes: 13 * 1024 * 1024,
      name: "phone.MOV",
    });
    expect(m.store.mock.calls[0][0]).toBe(7);
  });
  it("rejects missing authentication before storing file bytes", async () => {
    m.auth.mockRejectedValue(
      Object.assign(new Error("Sign in to upload a video."), {
        code: "UNAUTHORIZED",
      })
    );
    const body = new FormData();
    body.append("file", new Blob(["test"]), "video.mp4");
    const response = await fetch(url, { method: "POST", body });
    expect(response.status).toBe(401);
    expect(m.store).not.toHaveBeenCalled();
  });
  it("reports malformed multipart fields without pretending a source was accepted", async () => {
    const body = new FormData();
    body.append("wrong", new Blob(["test"]), "video.mp4");
    const response = await fetch(url, { method: "POST", body });
    expect(response.status).toBe(400);
    expect(m.store).not.toHaveBeenCalled();
  });
});
