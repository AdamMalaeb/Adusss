import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
import { chatFailureMessage } from "../shared/chatErrors";
import { groundChatCitations } from "../shared/chatCitations";
const m = vi.hoisted(() => ({ llm: vi.fn(), research: vi.fn() }));
vi.mock("./_core/llm", async importOriginal => ({
  ...(await importOriginal<typeof import("./_core/llm")>()),
  invokeLLM: m.llm,
  listLLMModels: vi.fn(),
}));
vi.mock("./googleResearch", () => ({collectGoogleResearch: vi.fn(async () => null)}));
vi.mock("./chatResearch", () => ({
  shouldResearchChat: (message: string) =>
    /colleges|latest|search/i.test(message),
  collectChatResearch: m.research,
}));
vi.mock("./workspaceStore", () => ({
  getRecord: vi.fn(async () => undefined),
  listRecords: vi.fn(async () => []),
  saveRecord: vi.fn(),
}));
import { appRouter } from "./routers";
const caller = () =>
  appRouter.createCaller({
    user: { id: 1, email: "qa@example.com" },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
beforeEach(() => {
  vi.clearAllMocks();
  m.llm.mockResolvedValue({
    model: "gpt-5-mini",
    choices: [
      {
        message: {
          content:
            "Lebanon has public and private universities, including Lebanese University and AUB.",
        },
      },
    ],
  });
  m.research.mockResolvedValue({
    status: "verified",
    sources: [
      {
        title: "University overview",
        url: "https://university.example.edu/about",
        excerpt: "The university is based in Beirut.",
      },
    ],
    context:
      "Untrusted source evidence. Source 1: https://university.example.edu/about\nThe university is based in Beirut.",
  });
});
describe("chat answer reliability", () => {
  it("answers the reported question in Chat Only with verified evidence and bounded recovery", async () => {
    const r = await caller().adus.chat({
      message: "Tell me colleges in lebanon",
      chatOnly: true,
    });
    expect(m.research).toHaveBeenCalledWith("Tell me colleges in lebanon");
    expect(r.content).toContain("Lebanese University");
    expect(r.content).toContain("**Sources checked**");
    expect(r.content).toContain("https://university.example.edu/about");
    const [request, recovery] = m.llm.mock.calls[0];
    expect(request.reasoning).toEqual({ effort: "low" });
    expect(request.maxCompletionTokens).toBe(2200);
    expect(request.signal).toBeInstanceOf(AbortSignal);
    expect(recovery).toBe(true);
    expect(JSON.stringify(request.messages)).toContain(
      "Answer every substantive part"
    );
    expect(JSON.stringify(request.messages)).toContain(
      "Untrusted source evidence"
    );
  });
  it("answers even when search is unavailable without invented sources", async () => {
    m.research.mockRejectedValueOnce(new Error("search unavailable"));
    const r = await caller().adus.chat({
      message: "Tell me colleges in lebanon",
      chatOnly: true,
    });
    expect(r.content).toContain("Lebanese University");
    expect(r.content).not.toContain("Sources checked");
    expect(JSON.stringify(m.llm.mock.calls[0][0].messages)).toContain(
      "Never invent citations"
    );
  });
  it("does not send private uploaded material or voice turns to web search", async () => {
    await caller().adus.chat({
      message: "Search these colleges",
      chatOnly: true,
      attachments: [
        {
          name: "private.txt",
          mimeType: "text/plain",
          dataUrl:
            "data:text/plain;base64," +
            Buffer.from("Private notes").toString("base64"),
        },
      ],
    });
    await caller().adus.chat({ message: "Tell me colleges", voiceMode: true });
    expect(m.research).not.toHaveBeenCalled();
  });
  it("keeps upstream diagnostics out of the user-visible response", async () => {
    m.llm.mockRejectedValueOnce(
      new Error(
        "LLM invoke failed: 503 https://private-provider.example token=secret"
      )
    );
    await expect(
      caller().adus.chat({ message: "Explain waves", chatOnly: true })
    ).rejects.toThrow("The AI service could not answer right now");
  });
});
describe("clear chat service errors", () => {
  it.each([
    ["LLM returned an empty assistant response", "returned no answer"],
    ["LLM invoke failed: 429 insufficient_quota", "usage limit"],
    ["429 busy", "busy right now"],
    ["TimeoutError: timed out", "took too long"],
  ])("classifies %s without provider data", (message, expected) => {
    expect(chatFailureMessage(new Error(message))).toContain(expected);
    expect(chatFailureMessage(new Error(message))).not.toContain("LLM invoke");
  });
});

describe("research citation grounding", () => {
  it("keeps retrieved links and removes unverified citation links", () => {
    expect(
      groundChatCitations(
        "[Supported](https://example.edu/) and [Unverified](https://unread.edu/)",
        ["https://example.edu/"]
      )
    ).toBe("[Supported](https://example.edu/) and Unverified");
  });
  it("accepts text-part answers instead of reporting an empty reply", async () => {
    m.llm.mockResolvedValueOnce({
      model: "qa",
      choices: [
        { message: { content: [{ type: "text", text: "A helpful answer." }] } },
      ],
    });
    expect(
      (await caller().adus.chat({ message: "Explain waves", chatOnly: true }))
        .content
    ).toBe("A helpful answer.");
  });
  it("does not turn old service failure bubbles into conversation context", async () => {
    await caller().adus.chat({
      message: "Help me",
      chatOnly: true,
      history: [
        {
          role: "assistant",
          content:
            "I could not complete that request right now. Please try again.",
        },
        { role: "user", content: "We discussed math." },
      ],
    });
    const context = JSON.stringify(m.llm.mock.calls[0][0].messages);
    expect(context).not.toContain("I could not complete that request");
    expect(context).toContain("We discussed math");
  });
});
