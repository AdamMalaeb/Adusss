import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createNaturalSpeechAudio,
  type NaturalSpeechCallLanguage,
} from "./naturalSpeech";
import { protectedProcedure, router } from "./_core/trpc";

import { languageSelectionSchema } from "../shared/languages";
const callSpeechInput = z.object({
  text: z.string().trim().min(1).max(20_000),
  gender: z.enum(["man", "woman"]),
  language: z.union([z.literal("auto"), languageSelectionSchema]),
});

function durationFromWav(audio: Buffer): number | undefined {
  if (audio.length < 44) return undefined;
  const bytesPerSecond = audio.readUInt32LE(28);
  const dataBytes = audio.readUInt32LE(40);
  if (!bytesPerSecond || dataBytes < 0) return undefined;
  return Number((dataBytes / bytesPerSecond).toFixed(2));
}

/**
 * Neural audio for live calls. The provider key and audio bytes stay server-side;
 * callers receive only the authenticated Manus storage reference.
 */
export const callSpeechRouter = router({
  synthesize: protectedProcedure
    .input(callSpeechInput)
    .mutation(async ({ ctx, input }) => {
      try {
        const stored = await createNaturalSpeechAudio(
          ctx.user.id,
          `call-${randomUUID()}`,
          input.text,
          input.language as NaturalSpeechCallLanguage,
          { gender: input.gender, speechMode: "call", storagePrefix: "call" }
        );
        return {
          url: stored.url,
          key: stored.key,
          duration: durationFromWav(stored.audio),
        };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({
          code: "SERVICE_UNAVAILABLE",
          message:
            "Natural call audio is temporarily unavailable. The written answer is ready; use Replay answer to try again.",
        });
      }
    }),
});

export type CallSpeechRouter = typeof callSpeechRouter;
export default callSpeechRouter;
