import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { lockedProcedure } from "./accessPolicy";
import { router } from "./_core/trpc";
import { getRecord, listRecords, saveRecord } from "./workspaceStore";
import { storagePut } from "./storage";
import { buildFreeVideo, translateFree } from "./freeVideoEngine";
import {
  FREE_VIDEO_MAX_INPUT_CHARS,
  FREE_VIDEO_MAX_SECONDS,
  FREE_VIDEO_MIN_SECONDS,
  dayKey,
  parseDailyLimit,
  type FreeVideoGender,
} from "../shared/freeVideo";
import { languageSelectionSchema, normalizeLanguage } from "../shared/languages";

const KIND = "free-video";
/**
 * Free video is locked to the approved account like every other video tool.
 * To open it to all signed-in users, replace this with `protectedProcedure`
 * from ./_core/trpc (the daily limit below then applies per user).
 */
const procedure = lockedProcedure;

type Stage = "translate" | "render" | "done";
type Job = {
  type: "free-video";
  status: "pending" | "completed" | "failed";
  stage: Stage;
  day: string;
  text: string;
  language: string;
  translate: boolean;
  narrate: boolean;
  gender: FreeVideoGender;
  aspectRatio: "16:9" | "9:16";
  requestedSeconds?: number;
  finalText?: string;
  url?: string;
  seconds?: number;
  scenes?: number;
  note?: string;
  failedStep?: Exclude<Stage, "done">;
  error?: string;
};

const idInput = z.object({ id: z.string().min(1).max(100) });
const inFlight = new Map<string, Promise<ReturnType<typeof view>>>();

function view(id: string, j: Job) {
  return {
    id,
    status: j.status,
    stage: j.stage,
    language: j.language,
    translate: j.translate,
    narrate: j.narrate,
    aspectRatio: j.aspectRatio,
    text: j.text,
    finalText: j.finalText,
    url: j.url,
    seconds: j.seconds,
    scenes: j.scenes,
    note: j.note,
    failedStep: j.failedStep,
    error: j.error,
  };
}

async function load(userId: number, id: string): Promise<Job> {
  const r = await getRecord(userId, KIND, id);
  if (!r || r.payload?.type !== "free-video")
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "That free video is not available in your workspace.",
    });
  return r.payload as Job;
}

async function usedToday(userId: number): Promise<number> {
  const today = dayKey();
  const rows = await listRecords(userId, KIND, 200);
  return rows.filter(
    r => r.payload?.day === today && r.payload?.status !== "failed"
  ).length;
}

function limits(used: number) {
  const limit = parseDailyLimit(process.env.FREE_VIDEO_DAILY_LIMIT);
  return {
    used,
    limit,
    remaining: Math.max(0, limit - used),
    minSeconds: FREE_VIDEO_MIN_SECONDS,
    maxSeconds: FREE_VIDEO_MAX_SECONDS,
    translationConfigured:
      Boolean(process.env.LIBRETRANSLATE_URL?.trim()) ||
      process.env.FREE_VIDEO_ALLOW_LLM_TRANSLATE === "true",
  };
}

function friendly(error: unknown, step: Stage): string {
  if (error instanceof TRPCError) return error.message;
  return `Free video stopped during ${step}. Retry to continue.`;
}

/** One durable stage per request; mirrors the Professor video job pattern. */
async function advance(userId: number, id: string) {
  const key = `${userId}:${id}`;
  const existing = inFlight.get(key);
  if (existing) return existing;
  const run = (async () => {
    let j = await load(userId, id);
    if (j.status !== "pending") return view(id, j);
    const save = async (next: Job) => {
      await saveRecord(userId, KIND, next, id);
      return next;
    };
    try {
      if (j.stage === "translate") {
        const finalText = j.translate
          ? await translateFree(j.text, j.language)
          : j.text;
        j = await save({ ...j, finalText, stage: "render" });
        return view(id, j);
      }
      const built = await buildFreeVideo({
        text: j.finalText ?? j.text,
        language: j.language,
        narrate: j.narrate,
        gender: j.gender,
        aspect: j.aspectRatio,
        requestedSeconds: j.requestedSeconds,
      });
      const stored = await storagePut(
        `free-video/${userId}/${id}.mp4`,
        built.video,
        "video/mp4"
      );
      j = await save({
        ...j,
        status: "completed",
        stage: "done",
        url: stored.url,
        seconds: Math.round(built.seconds * 10) / 10,
        scenes: built.scenes,
        note: !built.genderMatched
          ? "No voice of the chosen gender exists in this language, so another voice was used."
          : undefined,
      });
      return view(id, j);
    } catch (error) {
      // Server busy is not a failure: leave the job pending so polling retries.
      if (error instanceof TRPCError && error.code === "TOO_MANY_REQUESTS")
        return view(id, j);
      const step: Stage = j.stage;
      const failed = await save({
        ...j,
        status: "failed",
        failedStep: step === "done" ? "render" : step,
        error: friendly(error, step),
      });
      return view(id, failed);
    }
  })();
  inFlight.set(key, run);
  try {
    return await run;
  } finally {
    inFlight.delete(key);
  }
}

export const freeVideoRouter = router({
  limits: procedure.query(async ({ ctx }) =>
    limits(await usedToday(ctx.user.id))
  ),

  create: procedure
    .input(
      z.object({
        text: z.string().trim().min(3).max(FREE_VIDEO_MAX_INPUT_CHARS),
        language: languageSelectionSchema.default("en"),
        translate: z.boolean().default(false),
        narrate: z.boolean().default(true),
        gender: z.enum(["woman", "man"]).default("woman"),
        aspectRatio: z.enum(["16:9", "9:16"]).default("16:9"),
        durationSeconds: z
          .number()
          .int()
          .min(FREE_VIDEO_MIN_SECONDS)
          .max(FREE_VIDEO_MAX_SECONDS)
          .optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const state = limits(await usedToday(ctx.user.id));
      if (state.remaining <= 0)
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Daily free video limit reached (${state.limit}). It resets at 00:00 UTC.`,
        });
      if (input.translate && !state.translationConfigured)
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message:
            "Free translation is not configured on this server. Turn translation off, or set LIBRETRANSLATE_URL.",
        });
      const id = randomUUID();
      const job: Job = {
        type: "free-video",
        status: "pending",
        stage: "translate",
        day: dayKey(),
        text: input.text,
        language: normalizeLanguage(input.language),
        translate: input.translate,
        narrate: input.narrate,
        gender: input.gender,
        aspectRatio: input.aspectRatio,
        // Narrated videos take their length from the speech; the chosen
        // length only applies to silent (subtitle-only) videos.
        requestedSeconds: input.narrate ? undefined : input.durationSeconds,
      };
      await saveRecord(ctx.user.id, KIND, job, id);
      return view(id, job);
    }),

  status: procedure
    .input(idInput)
    .query(({ ctx, input }) => advance(ctx.user.id, input.id)),

  retry: procedure.input(idInput).mutation(async ({ ctx, input }) => {
    const j = await load(ctx.user.id, input.id);
    if (j.status !== "failed") return view(input.id, j);
    const next: Job = {
      ...j,
      status: "pending",
      stage: j.failedStep ?? "translate",
      error: undefined,
      failedStep: undefined,
    };
    await saveRecord(ctx.user.id, KIND, next, input.id);
    return view(input.id, next);
  }),

  list: procedure.query(async ({ ctx }) =>
    (await listRecords(ctx.user.id, KIND, 30)).map(r =>
      view(r.id, r.payload as Job)
    )
  ),
});
