import { assertPublicUrl, fetchPublicText } from "./communicationsEmail";

export type ResearchedContact = {
  email: string;
  sourceURL: string;
  sourceVerified: true;
  evidence: string;
};

export type ContactSearchResult = {
  query: string;
  contacts: ResearchedContact[];
  sources: Array<{ url: string; title: string }>;
  warnings: string[];
};

const SEARCH_URL = "https://html.duckduckgo.com/html/";
const MAX_RESULT_PAGES = 8;
const MAX_CONTACTS = 25;
const EMAIL_PATTERN = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63}/gi;

function decodeHtml(value: string) {
  return value
    .replace(/&#x([0-9a-f]+);/gi, (_, hex: string) =>
      String.fromCodePoint(Number.parseInt(hex, 16))
    )
    .replace(/&#(\d+);/g, (_, code: string) =>
      String.fromCodePoint(Number(code))
    )
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

function stripMarkup(value: string) {
  return decodeHtml(
    value
      .replace(/<[^>]*>/g, " ")
      .replace(/\s+/g, " ")
      .trim()
  );
}

function unwrapSearchURL(raw: string) {
  const decoded = decodeHtml(raw);
  try {
    const parsed = new URL(decoded, SEARCH_URL);
    const redirected = parsed.searchParams.get("uddg");
    return redirected ? decodeURIComponent(redirected) : parsed.toString();
  } catch {
    return null;
  }
}

/** Parse DDG HTML without accepting non-http(s) or search-internal links as sources. */
export function extractSearchResults(html: string) {
  const results: Array<{ url: string; title: string; snippet: string }> = [];
  const resultPattern =
    /<a[^>]+class=["'][^"']*result__a[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let match: RegExpExecArray | null;
  while (
    (match = resultPattern.exec(html)) &&
    results.length < MAX_RESULT_PAGES
  ) {
    const url = unwrapSearchURL(match[1]);
    if (!url) continue;
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:" && parsed.protocol !== "http:") continue;
      if (parsed.hostname.endsWith("duckduckgo.com")) continue;
      const resultContainer = html.slice(match.index, match.index + 5000);
      const snippetMatch = resultContainer.match(
        /class=["'][^"']*result__snippet[^"']*["'][^>]*>([\s\S]*?)<\//i
      );
      results.push({
        url: parsed.toString(),
        title: stripMarkup(match[2]).slice(0, 240),
        snippet: snippetMatch ? stripMarkup(snippetMatch[1]).slice(0, 500) : "",
      });
    } catch {
      // Ignore malformed search result links.
    }
  }
  return results;
}

function normalizeEmail(value: string) {
  const email = value
    .trim()
    .toLowerCase()
    .replace(/[),.;:]+$/g, "");
  if (
    email.length > 320 ||
    email.includes("..") ||
    email.startsWith(".") ||
    email.endsWith(".") ||
    email.includes("@example.") ||
    email.endsWith("@example.com") ||
    !/^[^\s@]+@[^\s@]+\.[a-z]{2,63}$/i.test(email)
  ) {
    return null;
  }
  return email;
}

/** Extract only literal addresses present in a verified public page; never infer or generate one. */
export function extractPublicEmails(text: string) {
  const found = new Set<string>();
  for (const raw of text.match(EMAIL_PATTERN) ?? []) {
    const email = normalizeEmail(raw);
    if (email) found.add(email);
  }
  return Array.from(found);
}

function excerptForEmail(text: string, email: string) {
  const index = text.toLowerCase().indexOf(email.toLowerCase());
  if (index < 0) return "Public page contains this exact email address.";
  return text
    .slice(
      Math.max(0, index - 100),
      Math.min(text.length, index + email.length + 180)
    )
    .replace(/\s+/g, " ")
    .trim();
}

async function mapWithConcurrency<T, R>(
  items: T[],
  limit: number,
  fn: (item: T) => Promise<R>
) {
  const output: R[] = [];
  let cursor = 0;
  async function worker() {
    while (cursor < items.length) {
      const item = items[cursor++];
      output.push(await fn(item));
    }
  }
  await Promise.all(
    Array.from({ length: Math.min(limit, items.length) }, worker)
  );
  return output;
}

/** Search DDG, then fetch and verify each public source page before returning a contact. */
export async function searchPublicContacts(
  companyName: string
): Promise<ContactSearchResult> {
  const company = companyName.trim().replace(/\s+/g, " ");
  if (company.length < 2 || company.length > 160)
    throw new Error("Enter a valid company name");
  const query = `${company} contact email`;
  const searchURL = await assertPublicUrl(
    `${SEARCH_URL}?q=${encodeURIComponent(query)}`
  );
  const searchPage = await fetchPublicText(searchURL);
  const searchResults = extractSearchResults(searchPage.body);
  const warnings: string[] = [];
  const verifiedPages = await mapWithConcurrency(
    searchResults,
    3,
    async result => {
      try {
        const page = await fetchPublicText(result.url);
        return { ...result, url: page.url, body: page.body };
      } catch {
        warnings.push(`Could not verify ${result.url}`);
        return null;
      }
    }
  );
  const contacts: ResearchedContact[] = [];
  const seen = new Set<string>();
  for (const page of verifiedPages) {
    if (!page) continue;
    for (const email of extractPublicEmails(page.body)) {
      const key = `${email}|${page.url}`;
      if (seen.has(key) || contacts.length >= MAX_CONTACTS) continue;
      seen.add(key);
      contacts.push({
        email,
        sourceURL: page.url,
        sourceVerified: true,
        evidence: excerptForEmail(page.body, email),
      });
    }
  }
  if (!contacts.length)
    warnings.push(
      "No exact public email address was found. Review sources or enter a recipient yourself."
    );
  return {
    query,
    contacts,
    sources: verifiedPages
      .filter(Boolean)
      .map(page => ({ url: page!.url, title: page!.title })),
    warnings,
  };
}
