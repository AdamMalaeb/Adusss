import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Request } from "express";
import { COOKIE_NAME } from "../shared/const";
const mocks = vi.hoisted(() => ({
  getUserByOpenId: vi.fn(),
  upsertUser: vi.fn(),
  post: vi.fn(),
}));
vi.mock("./db", () => ({
  getUserByOpenId: mocks.getUserByOpenId,
  upsertUser: mocks.upsertUser,
}));
vi.mock("./_core/env", () => ({
  ENV: {
    appId: "google-session-test",
    cookieSecret: "unit-test-signing-secret",
    oAuthServerUrl: "https://legacy.example",
  },
}));
vi.mock("axios", () => ({ default: { create: () => ({ post: mocks.post }) } }));
import { sdk } from "./_core/sdk";
beforeEach(() => {
  vi.clearAllMocks();
});
describe("independent Google sessions", () => {
  it("authenticates a locally signed Google identity without an external OAuth call", async () => {
    const user = {
      id: 77,
      openId: "google:subject-77",
      email: "person@example.com",
      name: "Person",
      role: "user",
    };
    mocks.getUserByOpenId.mockResolvedValue(user);
    const token = await sdk.createSessionToken(user.openId, {
      name: user.name,
      expiresInMs: 60000,
    });
    const result = await sdk.authenticateRequest({
      headers: { cookie: `${COOKIE_NAME}=${token}` },
    } as Request);
    expect(result).toEqual(user);
    expect(mocks.post).not.toHaveBeenCalled();
  });
  it("does not contact the legacy provider for a removed Google identity", async () => {
    mocks.getUserByOpenId.mockResolvedValue(undefined);
    const token = await sdk.createSessionToken("google:removed", {
      name: "Removed",
      expiresInMs: 60000,
    });
    await expect(
      sdk.authenticateRequest({
        headers: { cookie: `${COOKIE_NAME}=${token}` },
      } as Request)
    ).rejects.toThrow("Google account no longer exists");
    expect(mocks.post).not.toHaveBeenCalled();
  });
});
