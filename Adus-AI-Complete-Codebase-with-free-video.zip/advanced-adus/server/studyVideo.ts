import { createWhiteboardVideo, type WhiteboardScene } from "./whiteboardVideo";
import type { LanguageSelection } from "../shared/languages";
export type StudyVideoPayload = {
  title: string;
  summary: string;
  scenes: WhiteboardScene[];
  sources?: string[];
  warnings?: string[];
  language?: LanguageSelection;
};
/** Compatibility path for saved older lessons. New lessons animate in the browser with reusable neural narration. */
export async function createStudyVideo(
  userId: number,
  id: string,
  payload: StudyVideoPayload
): Promise<string> {
  return createWhiteboardVideo(
    userId,
    id,
    { ...payload, language: payload.language ?? "english" },
    { speech: { signal: AbortSignal.timeout(120000) } }
  );
}
