import { beforeEach, describe, expect, it, vi } from "vitest";
const m = vi.hoisted(() => ({
  invoke: vi.fn(),
  catalog: vi.fn(),
  prepare: vi.fn(),
  bundle: vi.fn(),
  unit: vi.fn(),
  save: vi.fn(),
  get: vi.fn(),
  list: vi.fn(),
  video: vi.fn(),
}));
vi.mock("./_core/llm", () => ({
  invokeLLM: m.invoke,
  listLLMModels: m.catalog,
}));
vi.mock("./studySources", () => ({
  prepareSources: m.prepare,
  readSourceBundle: m.bundle,
  readUnit: m.unit,
}));
vi.mock("./workspaceStore", () => ({
  saveRecord: m.save,
  getRecord: m.get,
  listRecords: m.list,
}));
vi.mock("./studyVideo", () => ({ createStudyVideo: m.video }));
import { studyRouter, parseStudyAnswer } from "./studyRouter";
const lesson = {
  title: "A full lesson",
  summary: "Every source fact is described here.",
  scenes: [
    {
      title: "Meaning",
      bullets: ["Key evidence"],
      narration: "A complete narration.".repeat(40),
      visual: {
        kind: "photo",
        labels: ["Evidence"],
        imagePrompt: "Contextual illustration",
      },
    },
  ],
  sources: ["invented.pdf"],
  warnings: [],
};
const units = Array.from({ length: 55 }, (_, i) => ({
  sourceIndex: 0,
  source: "book.pdf",
  page: i + 1,
  label: `book.pdf page ${i + 1}`,
}));
const course = {
  title: "book.pdf",
  language: "english",
  sourceKey: "study-sources/7/book.json",
  units,
  warnings: [],
  generateIllustrations: false,
  version: 2,
};
function ctx(id = 7) {
  return {
    user: {
      id,
      openId: "test",
      name: "Tester",
      email: "tester@example.com",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
      loginMethod: "test",
    },
    req: { headers: {} },
    res: {},
  } as any;
}
beforeEach(() => {
  vi.clearAllMocks();
  m.catalog.mockResolvedValue({
    data: [{ id: "gemini-3-flash-preview" }, { id: "gpt-5-mini" }],
  });
  m.invoke.mockResolvedValue({
    choices: [{ message: { content: JSON.stringify(lesson) } }],
  });
  m.prepare.mockResolvedValue({
    sourceKey: course.sourceKey,
    units,
    warnings: [],
  });
  m.unit.mockResolvedValue([
    { type: "text", text: "Page51 full evidence" },
    { type: "image_url", image_url: { url: "data:image/png;base64,eA==" } },
  ]);
  m.bundle.mockResolvedValue({ files: [], units });
  m.get.mockImplementation(async (_u, k, id) =>
    k === "study-course" && id === "course1"
      ? { id, payload: course }
      : undefined
  );
  m.save.mockImplementation(async (_u, _k, payload, id = "course1") => ({
    id,
    payload,
    createdAt: 100,
  }));
  m.list.mockResolvedValue([]);
  m.video.mockResolvedValue("/manus-storage/chapter.mp4");
});
describe("complete source study courses", () => {
  it("accepts long narration and one-scene title pages instead of fragile 280-character checks", () =>
    expect(
      parseStudyAnswer(JSON.stringify(lesson)).scenes[0].narration.length
    ).toBeGreaterThan(280));
  it("reads fenced/trailing comma JSON without losing usable narration", () =>
    expect(
      parseStudyAnswer(
        "```json\n" + JSON.stringify(lesson).replace(/}$/, " ,}") + "\n```"
      ).title
    ).toBe("A full lesson"));
  it("reports an empty answer as retryable and never fabricates a lesson", () =>
    expect(() => parseStudyAnswer(null)).toThrow(/retry/i));
  it("creates a 55-page manifest and does not expose a source storage key", async () => {
    const result = await studyRouter
      .createCaller(ctx())
      .createCourse({
        files: [
          {
            name: "book.pdf",
            mimeType: "application/pdf",
            dataUrl: "data:application/pdf;base64,eA==",
          },
        ],
        language: "english",
      });
    expect(result.units).toHaveLength(55);
    expect(result.sourceKey).toBeUndefined();
    expect(m.save).toHaveBeenCalledWith(
      7,
      "study-course",
      expect.objectContaining({ sourceKey: course.sourceKey })
    );
  });
  it("analyzes page51 with visual evidence and exact source provenance", async () => {
    const result = await studyRouter
      .createCaller(ctx())
      .analyzeChapter({ id: "course1", index: 50 });
    expect(m.unit).toHaveBeenCalledWith(expect.anything(), units[50]);
    expect(result.sources).toEqual(["book.pdf"]);
    expect(result.scenes[0].visual.kind).toBe("diagram");
    expect(m.invoke).toHaveBeenCalledWith(
      expect.objectContaining({
        model: "gemini-3-flash-preview",
        maxTokens: 16000,
      })
    );
    expect(m.save).toHaveBeenCalledWith(
      7,
      "study-chapter",
      expect.objectContaining({ index: 50 }),
      "course1:c50"
    );
  });
  it("resumes an existing chapter without a second AI call", async () => {
    m.get.mockImplementation(async (_u, k, id) =>
      k === "study-course"
        ? { id, payload: course }
        : { id, payload: { ...lesson, courseId: "course1", index: 3 } }
    );
    await studyRouter
      .createCaller(ctx())
      .analyzeChapter({ id: "course1", index: 3 });
    expect(m.invoke).not.toHaveBeenCalled();
  });
  it("does not let another user view or render a course", async () => {
    m.get.mockResolvedValue(undefined);
    await expect(
      studyRouter.createCaller(ctx(99)).getCourse({ id: "course1" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(m.video).not.toHaveBeenCalled();
  });
  it("does not render before the source summary is available", async () => {
    await expect(
      studyRouter.createCaller(ctx()).renderChapter({ id: "course1", index: 0 })
    ).rejects.toMatchObject({ code: "PRECONDITION_FAILED" });
    expect(m.video).not.toHaveBeenCalled();
  });
  it("returns already saved chapter video without rendering again", async () => {
    m.get.mockImplementation(async (_u, k, id) => ({
      id,
      payload:
        k === "study-course"
          ? course
          : { ...lesson, videoURL: "/manus-storage/saved.mp4" },
    }));
    expect(
      await studyRouter
        .createCaller(ctx())
        .renderChapter({ id: "course1", index: 0 })
    ).toMatchObject({ url: "/manus-storage/saved.mp4" });
    expect(m.video).not.toHaveBeenCalled();
  });
});
