import { COOKIE_NAME } from "../shared/const";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  MAX_SOURCE_BYTES,
  uploadVideoFile,
  validateVideoFileSelection,
} from "../client/src/lib/videoUpload";

describe("video upload UI transport", () => {
  afterEach(() => vi.unstubAllGlobals());
  beforeEach(() => {
    vi.restoreAllMocks();
    vi.stubGlobal("sessionStorage", {
      getItem: vi.fn(() => `${COOKIE_NAME}=preview-token`),
    });
  });

  it("accepts recorder MIME aliases and sends the original file as multipart", async () => {
    const file = new File([new Uint8Array([1, 2, 3])], "iPhone.M4V", {
      type: "video/x-m4v",
    });
    expect(validateVideoFileSelection(file)).toBeNull();
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: "source-1", type: "source" }), {
        status: 200,
        headers: { "content-type": "application/json" },
      })
    );
    vi.stubGlobal("fetch", fetchMock);

    await expect(uploadVideoFile(file)).resolves.toMatchObject({
      id: "source-1",
    });
    const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(init.method).toBe("POST");
    expect(init.credentials).toBe("include");
    expect(init.headers).toMatchObject({
      Authorization: "Bearer preview-token",
    });
    expect(init.body).toBeInstanceOf(FormData);
    expect((init.body as FormData).get("file")).toBeInstanceOf(File);
  });

  it("rejects empty, unsupported, and over-sized selections before fetch", () => {
    expect(
      validateVideoFileSelection(new File([], "empty.mp4", { type: "" }))
    ).toMatch(/non-empty/i);
    expect(
      validateVideoFileSelection(
        new File(["x"], "notes.txt", { type: "text/plain" })
      )
    ).toMatch(/MP4|MOV|M4V|WEBM/);
    expect(
      validateVideoFileSelection(
        new File([new Uint8Array(MAX_SOURCE_BYTES + 1)], "large.mp4", {
          type: "video/mp4",
        })
      )
    ).toMatch(/80 MB/i);
  });
});
