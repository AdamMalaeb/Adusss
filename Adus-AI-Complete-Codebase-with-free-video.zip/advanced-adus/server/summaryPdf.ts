import puppeteer, { type Browser } from "puppeteer-core";
import { marked, Marked, Renderer } from "marked";
import katex from "katex";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";
import { languageDirection, normalizeMathMarkdown } from "../shared/mathFormat";

export type SummaryChapter = {
  index: number;
  title: string;
  sourceLabel?: string;
  summary: string;
  warnings?: string[];
};

export const escapeHtml = (text: string) =>
  text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

type MathToken = {
  type: "blockMath" | "inlineMath";
  raw: string;
  text: string;
};

function renderMath(token: MathToken): string {
  return katex.renderToString(token.text, {
    displayMode: token.type === "blockMath",
    throwOnError: false,
    // The PDF is rendered from this HTML in a no-network Chromium page. Use
    // the visible KaTeX spans rather than embedding a hidden annotation that
    // repeats raw TeX commands in the exported document source/text layer.
    output: "html",
    errorColor: "#8c5d08",
  });
}

/** Marked extensions for the same `$...$` and `$$...$$` contract as RichText. */
const mathExtensions = {
  extensions: [
    {
      name: "blockMath",
      level: "block" as const,
      start(source: string) {
        const dollar = source.indexOf("$$");
        const bracket = source.indexOf("\\[");
        if (dollar < 0) return bracket < 0 ? undefined : bracket;
        return bracket < 0 ? dollar : Math.min(dollar, bracket);
      },
      tokenizer(source: string): MathToken | undefined {
        const dollars = source.match(/^ {0,3}\$\$([\s\S]*?)\$\$(?:\n|$)/);
        if (dollars)
          return {
            type: "blockMath",
            raw: dollars[0],
            text: dollars[1].trim(),
          };
        const brackets = source.match(/^ {0,3}\\\[([\s\S]*?)\\\](?:\n|$)/);
        if (brackets)
          return {
            type: "blockMath",
            raw: brackets[0],
            text: brackets[1].trim(),
          };
        return undefined;
      },
      renderer: renderMath,
    },
    {
      name: "inlineMath",
      level: "inline" as const,
      start(source: string) {
        const dollar = source.indexOf("$");
        const paren = source.indexOf("\\(");
        if (dollar < 0) return paren < 0 ? undefined : paren;
        return paren < 0 ? dollar : Math.min(dollar, paren);
      },
      tokenizer(source: string): MathToken | undefined {
        const dollars = source.match(/^\$\$([\s\S]*?)\$\$/);
        if (dollars)
          return {
            type: "blockMath",
            raw: dollars[0],
            text: dollars[1].trim(),
          };
        const inline = source.match(/^\$((?:\\.|[^$\\\n])+?)\$/);
        if (inline)
          return { type: "inlineMath", raw: inline[0], text: inline[1] };
        const parens = source.match(/^\\\(((?:\\.|[^)\\\n])+?)\\\)/);
        if (parens)
          return { type: "inlineMath", raw: parens[0], text: parens[1] };
        return undefined;
      },
      renderer: renderMath,
    },
  ],
};

let cachedKatexCss: string | undefined;

/**
 * KaTeX's stylesheet normally points at relative font files. PDF pages have
 * network requests disabled, so inline the WOFF2 files into the document.
 */
function katexPdfCss(): string {
  if (cachedKatexCss) return cachedKatexCss;
  const require = createRequire(import.meta.url);
  const katexEntry = require.resolve("katex");
  const dist = dirname(katexEntry);
  let css = readFileSync(join(dist, "katex.min.css"), "utf8");
  css = css.replace(/@font-face\{[^}]+\}/g, block => {
    const font = block.match(/url\(fonts\/([^)]*?\.woff2)\)/);
    if (!font) return block;
    const path = join(dist, "fonts", font[1]);
    const data = readFileSync(path).toString("base64");
    return block.replace(
      /src:[^;]+;/,
      `src:url(data:font/woff2;base64,${data}) format("woff2");`
    );
  });
  return (cachedKatexCss = css);
}

export function renderSummaryMarkdown(markdown: string): string {
  const renderer = new Renderer();
  renderer.html = ({ text }) => escapeHtml(text);
  renderer.image = () => "";
  renderer.link = ({ text }) => escapeHtml(text);
  const parser = new Marked(mathExtensions);
  return parser.parse(normalizeMathMarkdown(markdown), {
    renderer,
    async: false,
  }) as string;
}

function languageTag(language: string): string {
  const legacy: Record<string, string> = {
    english: "en",
    french: "fr",
    arabic: "ar",
  };
  const tag = legacy[language] ?? (language.trim().split(/[-_]/)[0] || "en");
  return escapeHtml(tag);
}

export function summaryDocument(
  title: string,
  chapters: SummaryChapter[],
  language: string,
  total: number,
  warnings: string[] = []
) {
  const direction = languageDirection(language);
  const html = chapters
    .slice()
    .sort((a, b) => a.index - b.index)
    .map(
      ch =>
        `<section><h2>${ch.index + 1}. ${escapeHtml(ch.title)}</h2><p class="source">${escapeHtml(ch.sourceLabel ?? "")}</p>${renderSummaryMarkdown(ch.summary)}${(ch.warnings ?? []).map(w => `<p class="warning">${escapeHtml(w)}</p>`).join("")}</section>`
    )
    .join("");
  return `<!doctype html><html lang="${languageTag(language)}" dir="${direction}"><head><meta charset="utf-8"><style>${katexPdfCss()}@page{size:A4;margin:18mm 16mm}body{font-family:'Noto Sans Arabic','Noto Sans','DejaVu Sans',sans-serif;font-size:11pt;line-height:1.7;color:#152638}header{border-bottom:2px solid #c6a75e;margin-bottom:20px}h1{font-size:24pt;line-height:1.35}h2{font-size:16pt;break-after:avoid}h3{break-after:avoid}section{margin:18px 0}p,li{overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:9pt}td,th{border:1px solid #b6c4cc;padding:6px}pre{white-space:pre-wrap;direction:ltr}.katex{font-size:1.05em}.katex-display{overflow-x:auto;overflow-y:hidden;margin:1em 0}.katex-display>.katex{white-space:normal}img{display:none}.source,.warning{font-size:9pt;color:#526476}.warning{color:#8c5d08}footer{font-size:9pt;border-top:1px solid #c6a75e;padding-top:10px}</style></head><body><header><p>ADUS · STUDY SUMMARY</p><h1>${escapeHtml(title)}</h1><p>Source coverage: ${chapters.length}/${total} sections${chapters.length < total ? " — partial summary; unread sections are not included." : ""}</p></header>${html}<footer>${warnings.map(escapeHtml).join("<br>")}<p>Generated from your uploaded material. Review important formulas, dates and source references.</p></footer></body></html>`;
}

let browser: Browser | undefined;
let queue: Promise<unknown> = Promise.resolve();
export async function renderSummaryPdf(html: string): Promise<Buffer> {
  const prior = queue;
  let release!: () => void;
  queue = new Promise<void>(r => (release = r));
  await prior.catch(() => undefined);
  try {
    if (!browser?.connected)
      browser = await puppeteer.launch({
        executablePath:
          process.env.PUPPETEER_EXECUTABLE_PATH ?? "/usr/bin/chromium",
        headless: true,
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
          "--disable-dev-shm-usage",
          "--disable-gpu",
        ],
      });
    const page = await browser.newPage();
    try {
      await page.setRequestInterception(true);
      page.on("request", req => void req.abort());
      await page.setJavaScriptEnabled(false);
      await page.setContent(html, {
        waitUntil: "domcontentloaded",
        timeout: 15000,
      });
      const pdf = await page.pdf({
        format: "A4",
        printBackground: true,
        preferCSSPageSize: true,
        timeout: 25000,
      });
      return Buffer.from(pdf);
    } finally {
      await page.close();
    }
  } catch {
    throw new TRPCError({
      code: "SERVICE_UNAVAILABLE",
      message:
        "The PDF could not be prepared yet. Your saved summary is still available; please retry.",
    });
  } finally {
    release();
  }
}
export async function storeSummaryPdf(
  userId: number,
  id: string,
  html: string
) {
  const hash = createHash("sha256").update(html).digest("hex").slice(0, 16);
  const bytes = await renderSummaryPdf(html);
  return {
    ...(await storagePut(
      `study-pdf/${userId}/${id}-${hash}.pdf`,
      bytes,
      "application/pdf"
    )),
    hash,
  };
}
export async function closeSummaryPdfBrowser() {
  if (browser) await browser.close();
  browser = undefined;
}
