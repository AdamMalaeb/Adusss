import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const m = vi.hoisted(() => ({
  get: vi.fn(),
  list: vi.fn(),
  save: vi.fn(),
  storagePut: vi.fn(),
}));

vi.mock("./workspaceStore", () => ({
  getRecord: m.get,
  listRecords: m.list,
  saveRecord: m.save,
}));
vi.mock("./storage", () => ({ storagePut: m.storagePut }));

import {
  CONVERSATION_KIND,
  conversationsRouter,
  generateConversationTitle,
  getConversationContext,
} from "./conversations";

function caller(userId: number | null = 7) {
  return conversationsRouter.createCaller({
    user:
      userId === null ? null : { id: userId, email: `${userId}@example.com` },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}

const records = new Map<
  string,
  { id: string; payload: any; createdAt: number; updatedAt: number }
>();

beforeEach(() => {
  vi.clearAllMocks();
  records.clear();
  m.get.mockImplementation(async (userId: number, kind: string, id: string) => {
    if (kind !== CONVERSATION_KIND) return undefined;
    return records.get(`${userId}:${id}`);
  });
  m.list.mockImplementation(async (userId: number, kind: string) => {
    if (kind !== CONVERSATION_KIND) return [];
    return [...records.entries()]
      .filter(([key]) => key.startsWith(`${userId}:`))
      .map(([, record]) => record);
  });
  m.save.mockImplementation(
    async (userId: number, kind: string, payload: any, id: string) => {
      const now = Date.now();
      const key = `${userId}:${id}`;
      const previous = records.get(key);
      const record = {
        id,
        payload,
        createdAt: previous?.createdAt ?? now,
        updatedAt: now,
      };
      records.set(key, record);
      return record;
    }
  );
  m.storagePut.mockResolvedValue({
    key: "conversations/7/chat/file.png",
    url: "/manus-storage/conversations/7/chat/file.png",
  });
});

describe("conversation history", () => {
  it("requires authentication for every operation", async () => {
    await expect(caller(null).list()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
    await expect(caller(null).create({})).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
    await expect(caller(null).get({ id: "missing" })).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("generates a useful title from the first prompt and persists a complete message", async () => {
    const created = await caller(7).create({
      id: "math-chat",
      firstMessage: "Can you help with my math tutoring exercise?",
    });
    expect(created.title).toBe("Math Tutoring");

    const appended = await caller(7).append({
      id: "math-chat",
      message: {
        id: "turn-1",
        requestId: "send-1",
        role: "user",
        content: "Can you help with my math tutoring exercise?",
        attachmentName: "notes.pdf",
        attachments: [
          {
            name: "notes.pdf",
            mimeType: "application/pdf",
            reference: "/manus-storage/conversations/7/notes.pdf",
            size: 1234,
          },
        ],
      },
    });
    expect(appended.appended).toBe(true);
    expect(appended.message).toMatchObject({
      id: "turn-1",
      requestId: "send-1",
      attachmentName: "notes.pdf",
    });
    expect(appended.message.attachments?.[0]).toMatchObject({
      name: "notes.pdf",
      reference: "/manus-storage/conversations/7/notes.pdf",
    });

    const reopened = await caller(7).get({ id: "math-chat" });
    expect(reopened.messages).toHaveLength(1);
    expect(reopened.messages[0]).toMatchObject({
      id: "turn-1",
      content: "Can you help with my math tutoring exercise?",
    });
  });

  it("treats repeated request ids as idempotent and does not duplicate turns", async () => {
    await caller(7).create({ id: "stable" });
    const input = {
      id: "stable",
      message: {
        id: "turn-1",
        requestId: "request-1",
        role: "user" as const,
        content: "hello",
      },
    };
    expect((await caller(7).append(input)).appended).toBe(true);
    const duplicate = await caller(7).append({
      ...input,
      message: { ...input.message, content: "hello again" },
    });
    expect(duplicate.appended).toBe(false);
    expect(duplicate.message.content).toBe("hello");
    expect((await caller(7).get({ id: "stable" })).messages).toHaveLength(1);
    expect(m.save).toHaveBeenCalledTimes(2);
  });

  it("isolates threads by account and rejects another user's reopen, rename, or append", async () => {
    await caller(7).create({ id: "private", firstMessage: "Private notes" });
    await caller(7).append({
      id: "private",
      message: { id: "one", role: "user", content: "secret" },
    });
    expect(await caller(8).list()).toEqual([]);
    await expect(caller(8).get({ id: "private" })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
    await expect(
      caller(8).rename({ id: "private", title: "stolen" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    await expect(
      caller(8).append({
        id: "private",
        message: { id: "x", role: "user", content: "nope" },
      })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("soft-deletes idempotently, hides archived data, and restores it without losing messages", async () => {
    await caller(7).create({ id: "recoverable", firstMessage: "Keep this" });
    await caller(7).append({
      id: "recoverable",
      message: { id: "saved", role: "user", content: "Keep this" },
    });

    const archived = await caller(7).archive({ id: "recoverable" });
    expect(archived.archived).toBe(true);
    expect(
      (await caller(7).list()).some(item => item.id === "recoverable")
    ).toBe(false);
    await expect(caller(7).get({ id: "recoverable" })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
    await expect(
      caller(7).append({
        id: "recoverable",
        message: { id: "blocked", role: "user", content: "Do not resurrect" },
      })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    await expect(
      getConversationContext(7, "recoverable", "hidden")
    ).rejects.toMatchObject({ code: "NOT_FOUND" });

    const archivedAgain = await caller(7).archive({ id: "recoverable" });
    expect(archivedAgain).toEqual(archived);
    expect(m.save).toHaveBeenCalledTimes(3);

    const restored = await caller(7).restore({ id: "recoverable" });
    expect(restored.id).toBe("recoverable");
    expect((await caller(7).get({ id: "recoverable" })).messages).toHaveLength(
      1
    );
    expect(
      (await caller(7).list()).some(item => item.id === "recoverable")
    ).toBe(true);
  });

  it("serializes archive after a pending append so the archived flag is not lost", async () => {
    await caller(7).create({ id: "race" });
    let releaseSave!: () => void;
    let markSaveEntered!: () => void;
    const saveEntered = new Promise<void>(resolve => {
      markSaveEntered = resolve;
    });
    const saveGate = new Promise<void>(resolve => {
      releaseSave = resolve;
    });
    const originalSave = m.save.getMockImplementation();
    let delayed = true;
    m.save.mockImplementation(async (...args: any[]) => {
      if (delayed) {
        delayed = false;
        markSaveEntered();
        await saveGate;
      }
      return originalSave?.(...args);
    });

    const appendPromise = caller(7).append({
      id: "race",
      message: { id: "pending", role: "user", content: "pending" },
    });
    await saveEntered;
    let archiveFinished = false;
    const archivePromise = caller(7)
      .archive({ id: "race" })
      .then(result => {
        archiveFinished = true;
        return result;
      });
    await Promise.resolve();
    expect(archiveFinished).toBe(false);
    releaseSave();
    await appendPromise;
    await archivePromise;
    expect((await caller(7).list()).some(item => item.id === "race")).toBe(
      false
    );
    await expect(getConversationContext(7, "race")).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });

  it("does not allow another account to archive or restore a conversation", async () => {
    await caller(7).create({ id: "owned" });
    await expect(caller(8).archive({ id: "owned" })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
    await caller(7).archive({ id: "owned" });
    await expect(caller(8).restore({ id: "owned" })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
    expect(await caller(8).list()).toEqual([]);
  });

  it("returns only bounded relevant context while retaining durable history", async () => {
    await caller(7).create({ id: "long" });
    for (let index = 0; index < 32; index += 1) {
      await caller(7).append({
        id: "long",
        message: {
          id: `turn-${index}`,
          role: index % 2 ? "assistant" : "user",
          content: `message ${index}`,
        },
      });
    }
    const reopened = await caller(7).get({ id: "long" });
    expect(reopened.messages).toHaveLength(32);
    const context = await getConversationContext(7, "long", "latest question");
    expect(context.history).toHaveLength(25);
    expect(context.history[0]?.content).toBe("message 7");
    expect(context.history.at(-1)?.content).toBe("message 31");
  });

  it("retrieves relevant older information only from the selected thread", async () => {
    await caller(7).create({ id: "memory" });
    await caller(7).append({
      id: "memory",
      message: {
        id: "old",
        role: "user",
        content: "My chemistry project is about cobalt reactions.",
      },
    });
    for (let i = 0; i < 30; i++)
      await caller(7).append({
        id: "memory",
        message: {
          id: `filler-${i}`,
          role: "assistant",
          content: `Unrelated turn ${i}`,
        },
      });
    const question = "What was my cobalt project about?";
    await caller(7).append({
      id: "memory",
      message: { id: "latest", role: "user", content: question },
    });
    const context = await getConversationContext(7, "memory", question);
    expect(context.history).toHaveLength(25);
    expect(
      context.history.some(m => m.content.includes("cobalt reactions"))
    ).toBe(true);
    expect(context.history.some(m => m.content === question)).toBe(false);
    await expect(
      getConversationContext(8, "memory", question)
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect((await caller(7).get({ id: "memory" })).messages).toHaveLength(32);
  });
});

describe("title generation", () => {
  it("uses a bounded fallback for ordinary prompts", () => {
    expect(
      generateConversationTitle("please explain photosynthesis in simple terms")
    ).toBe("Please Explain Photosynthesis In Simple Terms");
    expect(generateConversationTitle("   ")).toBe("New conversation");
  });
});
