import { describe, it, expect } from "vitest";

describe.skipIf(process.env.ADUS_VALIDATE_MANUS !== "1")("Manus presentation credential", () => {
  it("authenticates with the official identity endpoint", async () => {
    const key = process.env.MANUS_API_KEY;
    expect(Boolean(key)).toBe(true);
    const response = await fetch("https://api.manus.ai/v2/user.me", {
      headers: { "x-manus-api-key": key! },
      signal: AbortSignal.timeout(15000),
    });
    expect(response.ok, `Identity request returned HTTP ${response.status}`).toBe(true);
    const result = await response.json();
    expect(result.ok).toBe(true);
  }, 20000);
});
