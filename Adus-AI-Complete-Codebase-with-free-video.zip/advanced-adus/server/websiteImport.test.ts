import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({ saveRecord: vi.fn() }));

vi.mock("./workspaceStore", () => ({ saveRecord: mocks.saveRecord }));

import { websiteImportRouter } from "./websiteImport";

function caller(userId = 7) {
  return websiteImportRouter.createCaller({
    user: { id: userId, email: `user-${userId}@example.com` },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}

function unauthenticatedCaller() {
  return websiteImportRouter.createCaller({
    user: null,
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}

describe("adus.websiteImport", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.saveRecord.mockResolvedValue({ id: "website-import-1" });
  });

  it("persists an owner-scoped complete document byte-for-byte", async () => {
    const html =
      "<!doctype html><html><head><title>Imported page</title></head><body><main><h1>Reviewed</h1></main></body></html>";
    const result = await caller(42).importHtml({
      filename: "landing-page.htm",
      html,
    });

    expect(result).toMatchObject({
      id: "website-import-1",
      title: "Imported page",
      source: "imported",
      filename: "landing-page.htm",
      html,
    });
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      42,
      "website",
      expect.objectContaining({ html, source: "imported" })
    );
  });

  it("uses an explicit title when supplied and never rewrites source", async () => {
    const html =
      "<html><head><title>Source title</title></head><body><p>Exact source</p></body></html>";
    const result = await caller().importHtml({
      filename: "source.html",
      title: "Reviewed title",
      html,
    });

    expect(result.title).toBe("Reviewed title");
    expect(result.html).toBe(html);
  });

  it("rejects unsupported filenames, fragments, and oversized source", async () => {
    await expect(
      caller().importHtml({
        filename: "page.txt",
        html: "<html><body /></html>",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      caller().importHtml({
        filename: "page.html",
        html: "<body>fragment</body>",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      caller().importHtml({
        filename: "page.html",
        html: `<html><body>${"x".repeat(200_001)}</body></html>`,
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });

  it("protects the import mutation", async () => {
    await expect(
      unauthenticatedCaller().importHtml({
        filename: "page.html",
        html: "<html><body>private</body></html>",
      })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });
});
