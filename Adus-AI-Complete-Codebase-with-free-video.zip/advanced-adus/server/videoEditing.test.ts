import { describe, expect, it } from "vitest";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import {
  executeVideoEdit,
  probeVideo,
  validateVideoEditPlan,
  type VideoEditPlan,
} from "./videoEditing";

function fixture(withAudio: boolean): { bytes: Buffer; path: string; directory: string } {
  const directory = mkdtempSync(join(tmpdir(), "adus-video-edit-test-"));
  const path = join(directory, withAudio ? "source-audio.mp4" : "source-silent.mp4");
  const args = [
    "-y",
    "-hide_banner",
    "-loglevel",
    "error",
    "-f",
    "lavfi",
    "-i",
    "testsrc=size=64x48:rate=10",
    ...(withAudio
      ? ["-f", "lavfi", "-i", "sine=frequency=440:sample_rate=8000"]
      : []),
    "-t",
    "2",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    ...(withAudio ? ["-c:a", "aac"] : ["-an"]),
    path,
  ];
  execFileSync("ffmpeg", args);
  return { bytes: readFileSync(path), path, directory };
}

const plan: VideoEditPlan = {
  version: 1,
  supported: true,
  summary: "Keep two ranges, mute one range, speed one range, crop and rotate.",
  unsupportedReason: "",
  segments: [
    { start: 0, end: 0.8 },
    { start: 1.2, end: 2 },
  ],
  mute: [{ start: 0.2, end: 0.4 }],
  speed: [{ start: 1.2, end: 1.6, factor: 1.5 }],
  crop: { x: 0, y: 0, width: 0.75, height: 1 },
  rotate: 90,
};

describe("server-side source video editing", () => {
  it("rejects an edit range outside the uploaded source duration", async () => {
    const source = { duration: 2, width: 64, height: 48, hasAudio: false };
    expect(() =>
      validateVideoEditPlan(
        { ...plan, segments: [{ start: 0, end: 3 }] },
        source
      )
    ).toThrow(/within the source duration/i);
  });

  it("renders reviewed cuts, mute, speed, crop and rotation as H264/AAC MP4", async () => {
    const sourceFixture = fixture(true);
    try {
      const bytesBefore = Buffer.from(sourceFixture.bytes);
      const source = await probeVideo(sourceFixture.bytes, "video/mp4");
      const output = await executeVideoEdit({
        bytes: sourceFixture.bytes,
        mimeType: "video/mp4",
        source,
        plan,
      });
      expect(sourceFixture.bytes.equals(bytesBefore)).toBe(true);
      expect(output.bytes.subarray(4, 8).toString("ascii")).toBe("ftyp");
      const outputDirectory = mkdtempSync(join(tmpdir(), "adus-video-output-test-"));
      const outputPath = join(outputDirectory, "edited.mp4");
      try {
        const { writeFileSync } = await import("node:fs");
        writeFileSync(outputPath, output.bytes);
        const metadata = JSON.parse(
          execFileSync("ffprobe", [
            "-v",
            "error",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            outputPath,
          ], { encoding: "utf8" })
        ) as { streams: Array<{ codec_name?: string; width?: number; height?: number; codec_type?: string }>; format: { duration?: string } };
        expect(metadata.streams.find(stream => stream.codec_type === "video")?.codec_name).toBe("h264");
        expect(metadata.streams.find(stream => stream.codec_type === "audio")?.codec_name).toBe("aac");
        expect(metadata.streams.find(stream => stream.codec_type === "video")).toMatchObject({ width: 48, height: 48 });
        expect(Number(metadata.format.duration)).toBeGreaterThan(1.2);
        expect(Number(metadata.format.duration)).toBeLessThan(1.8);
      } finally {
        rmSync(outputDirectory, { recursive: true, force: true });
      }
    } finally {
      rmSync(sourceFixture.directory, { recursive: true, force: true });
    }
  }, 30_000);

  it("adds a compatible AAC track when the uploaded source is silent", async () => {
    const sourceFixture = fixture(false);
    try {
      const source = await probeVideo(sourceFixture.bytes, "video/mp4");
      const output = await executeVideoEdit({
        bytes: sourceFixture.bytes,
        mimeType: "video/mp4",
        source,
        plan: {
          ...plan,
          segments: [{ start: 0, end: 0.5 }],
          mute: [],
          speed: [],
          crop: null,
          rotate: 0,
        },
      });
      const outputDirectory = mkdtempSync(join(tmpdir(), "adus-video-silent-output-test-"));
      const outputPath = join(outputDirectory, "edited.mp4");
      try {
        const { writeFileSync } = await import("node:fs");
        writeFileSync(outputPath, output.bytes);
        const metadata = JSON.parse(
          execFileSync("ffprobe", ["-v", "error", "-show_streams", "-of", "json", outputPath], { encoding: "utf8" })
        ) as { streams: Array<{ codec_name?: string; codec_type?: string }> };
        expect(metadata.streams.find(stream => stream.codec_type === "video")?.codec_name).toBe("h264");
        expect(metadata.streams.find(stream => stream.codec_type === "audio")?.codec_name).toBe("aac");
      } finally {
        rmSync(outputDirectory, { recursive: true, force: true });
      }
    } finally {
      rmSync(sourceFixture.directory, { recursive: true, force: true });
    }
  }, 30_000);
});
