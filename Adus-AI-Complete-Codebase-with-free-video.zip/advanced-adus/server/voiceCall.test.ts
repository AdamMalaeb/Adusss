import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  SilenceDetector,
  VoiceCallController,
  type VoiceAudio,
  type VoiceRuntime,
  type VoiceState,
  type VoiceTurn,
} from "../client/src/lib/voiceCall";

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(done => {
    resolve = done;
  });
  return { promise, resolve };
}
function fixture() {
  const track = { enabled: true, stop: vi.fn() };
  const stream = {
    getAudioTracks: () => [track],
    getTracks: () => [track],
  } as unknown as MediaStream;
  const recorders: any[] = [];
  const synthesis = {
    cancel: vi.fn(),
    resume: vi.fn(),
    speak: vi.fn(),
    getVoices: () => [],
  };
  const runtime: VoiceRuntime = {
    getUserMedia: vi.fn(async () => stream),
    makeRecorder: vi.fn(() => {
      const recorder = {
        state: "inactive",
        mimeType: "audio/webm",
        ondataavailable: null as any,
        onstop: null as any,
        start: vi.fn(() => {
          recorder.state = "recording";
        }),
        stop: vi.fn(() => {
          recorder.state = "inactive";
          recorder.ondataavailable?.({
            data: new Blob(["valid recorded audio"]),
          });
          recorder.onstop?.();
        }),
      };
      recorders.push(recorder);
      return recorder as unknown as MediaRecorder;
    }),
    createAudioContext: () => null,
    synthesis: synthesis as unknown as SpeechSynthesis,
    makeUtterance: text => ({ text }) as SpeechSynthesisUtterance,
    now: () => Date.now(),
  };
  const states: VoiceState[] = [];
  const transcribe = vi.fn(async (_blob: Blob) => ({ text: "Hello" }));
  const reply = vi.fn(
    async (_text: string, _history: VoiceTurn[]) => "Hello! How can I help?"
  );
  const controller = new VoiceCallController({
    runtime,
    onChange: state => states.push(state),
    transcribe,
    reply,
  });
  return {
    controller,
    runtime,
    track,
    recorders,
    synthesis,
    transcribe,
    reply,
    states,
  };
}
const settle = async () => {
  for (let i = 0; i < 12; i++) await Promise.resolve();
};

beforeEach(() => vi.useFakeTimers());
afterEach(() => {
  vi.clearAllTimers();
  vi.useRealTimers();
});

describe("live call microphone-only mute", () => {
  it("plays returned neural audio without invoking browser speech synthesis", async () => {
    const f = fixture();
    const audio: VoiceAudio = {
      currentTime: 0,
      onplay: null,
      onended: null,
      onerror: null,
      play: vi.fn(async () => undefined),
      pause: vi.fn(),
    };
    const synthesize = vi.fn(async () => ({
      url: "/manus-storage/call/test.wav",
      key: "call/test.wav",
    }));
    f.runtime.createAudio = vi.fn(() => audio);
    const controller = new VoiceCallController({
      ...f,
      runtime: f.runtime,
      synthesize,
      language: "english",
      onChange: state => f.states.push(state),
    });
    await controller.start();
    controller.finishTurn();
    await settle();
    expect(synthesize).toHaveBeenCalledWith(
      "Hello! How can I help?",
      "woman",
      "english"
    );
    expect(f.runtime.createAudio).toHaveBeenCalledWith(
      "/manus-storage/call/test.wav"
    );
    expect(audio.play).toHaveBeenCalledOnce();
    expect(f.synthesis.speak).toHaveBeenCalledTimes(1); // start gesture primer only
    audio.onplay?.({} as Event);
    expect(controller.snapshot.phase).toBe("speaking");
    audio.onended?.({} as Event);
    await vi.advanceTimersByTimeAsync(250);
    expect(f.recorders).toHaveLength(2);
    controller.stop();
  });

  it("does not create or play blank neural audio", async () => {
    const f = fixture();
    const synthesize = vi.fn(async () => ({ url: "" }));
    f.runtime.createAudio = vi.fn(() => {
      throw new Error("should not create blank audio");
    });
    const controller = new VoiceCallController({
      runtime: f.runtime,
      onChange: state => f.states.push(state),
      transcribe: f.transcribe,
      reply: f.reply,
      synthesize,
    });
    await controller.start();
    controller.finishTurn();
    await settle();
    expect(controller.snapshot.phase).toBe("error");
    expect(controller.snapshot.canReplay).toBe(true);
    controller.stop();
  });

  it("does not cancel bot speech and resumes listening only after unmuting", async () => {
    const f = fixture();
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    const utterance = f.synthesis.speak.mock.calls.at(
      -1
    )![0] as SpeechSynthesisUtterance;
    utterance.onstart?.({} as SpeechSynthesisEvent);
    const cancellations = f.synthesis.cancel.mock.calls.length;
    f.controller.setMuted(true);
    expect(f.track.enabled).toBe(false);
    expect(f.controller.snapshot.phase).toBe("speaking");
    expect(f.controller.snapshot.muted).toBe(true);
    expect(f.synthesis.cancel).toHaveBeenCalledTimes(cancellations);
    await vi.advanceTimersByTimeAsync(4200);
    expect(f.synthesis.resume).toHaveBeenCalled();
    expect(f.synthesis.cancel).toHaveBeenCalledTimes(cancellations);
    utterance.onend?.({} as SpeechSynthesisEvent);
    await vi.advanceTimersByTimeAsync(13000);
    expect(f.recorders).toHaveLength(1);
    expect(f.transcribe).toHaveBeenCalledTimes(1);
    expect(f.controller.snapshot.phase).toBe("muted");
    f.controller.setMuted(false);
    expect(f.recorders).toHaveLength(2);
    expect(f.track.enabled).toBe(true);
    f.controller.stop();
  });

  it("still speaks a pending AI reply when the customer mutes during thinking", async () => {
    const f = fixture();
    const answer = deferred<string>();
    f.reply.mockImplementation(() => answer.promise);
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    expect(f.controller.snapshot.phase).toBe("thinking");
    f.controller.setMuted(true);
    expect(f.controller.snapshot.phase).toBe("thinking");
    answer.resolve("You can still hear me while your microphone is muted.");
    await settle();
    expect(f.synthesis.speak.mock.calls.at(-1)![0].text).toContain(
      "still hear me"
    );
    expect(f.controller.snapshot.phase).toBe("speaking");
    expect(f.controller.snapshot.muted).toBe(true);
    f.controller.stop();
  });

  it("preserves the last captured turn when muting during recording", async () => {
    const f = fixture();
    await f.controller.start();
    f.controller.setMuted(true);
    await settle();
    expect(f.transcribe).toHaveBeenCalledTimes(1);
    expect(f.reply).toHaveBeenCalledTimes(1);
    expect(f.controller.snapshot.phase).toBe("speaking");
    expect(f.track.enabled).toBe(false);
    f.controller.stop();
  });

  it("does not re-enable microphone capture when unmuting during bot speech", async () => {
    const f = fixture();
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    f.controller.setMuted(true);
    f.controller.setMuted(false);
    expect(f.track.enabled).toBe(false);
    expect(f.recorders).toHaveLength(1);
    expect(f.controller.snapshot.phase).toBe("speaking");
    const utterance = f.synthesis.speak.mock.calls.at(
      -1
    )![0] as SpeechSynthesisUtterance;
    utterance.onend?.({} as SpeechSynthesisEvent);
    await vi.advanceTimersByTimeAsync(250);
    expect(f.track.enabled).toBe(true);
    expect(f.recorders).toHaveLength(2);
    f.controller.stop();
  });

  it("applies mute even when microphone permission resolves later", async () => {
    const f = fixture();
    const permission = deferred<MediaStream>();
    f.runtime.getUserMedia = () => permission.promise;
    const start = f.controller.start();
    f.controller.setMuted(true);
    permission.resolve({
      getAudioTracks: () => [f.track],
      getTracks: () => [f.track],
    } as unknown as MediaStream);
    await start;
    expect(f.track.enabled).toBe(false);
    expect(f.recorders).toHaveLength(0);
    f.controller.stop();
  });
});

describe("call lifecycle and recovery", () => {
  it("never plays a late response after the call ends", async () => {
    const f = fixture();
    const answer = deferred<string>();
    f.reply.mockImplementation(() => answer.promise);
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    f.controller.stop();
    const speechCalls = f.synthesis.speak.mock.calls.length;
    answer.resolve("This must not play.");
    await settle();
    expect(f.synthesis.speak).toHaveBeenCalledTimes(speechCalls);
    expect(f.track.stop).toHaveBeenCalledTimes(1);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("does not let a previous call reply leak into a newly started call", async () => {
    const f = fixture();
    const answer = deferred<string>();
    f.reply.mockImplementation(() => answer.promise);
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    f.controller.stop();
    await f.controller.start();
    const speechCalls = f.synthesis.speak.mock.calls.length;
    answer.resolve("Old call response");
    await settle();
    expect(f.synthesis.speak).toHaveBeenCalledTimes(speechCalls);
    expect(f.controller.snapshot.phase).toBe("listening");
    f.controller.stop();
  });

  it("pauses on a transcription failure instead of repeatedly submitting audio", async () => {
    const f = fixture();
    f.transcribe.mockResolvedValue({
      text: "",
      error: "Voice service unavailable",
    } as any);
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    await vi.advanceTimersByTimeAsync(30000);
    expect(f.transcribe).toHaveBeenCalledTimes(1);
    expect(f.controller.snapshot.phase).toBe("error");
    f.controller.retryListening();
    await vi.advanceTimersByTimeAsync(1);
    expect(f.controller.snapshot.phase).toBe("listening");
    f.controller.stop();
  });

  it("retains call context without adding voice turns to the chat", async () => {
    const f = fixture();
    await f.controller.start([{ role: "user", content: "My name is Adam." }]);
    f.controller.finishTurn();
    await settle();
    const utterance = f.synthesis.speak.mock.calls.at(
      -1
    )![0] as SpeechSynthesisUtterance;
    utterance.onend?.({} as SpeechSynthesisEvent);
    await vi.advanceTimersByTimeAsync(250);
    f.controller.finishTurn();
    await settle();
    expect(f.reply.mock.calls[1][1]).toEqual([
      { role: "user", content: "My name is Adam." },
      { role: "user", content: "Hello" },
      { role: "assistant", content: "Hello! How can I help?" },
    ]);
    f.controller.stop();
  });

  it("offers explicit replay when browser speech playback is blocked", async () => {
    const f = fixture();
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    await vi.advanceTimersByTimeAsync(6000);
    expect(f.controller.snapshot.canReplay).toBe(true);
    expect(f.controller.snapshot.phase).toBe("error");
    f.controller.setMuted(true);
    expect(f.controller.snapshot.phase).toBe("error");
    const calls = f.synthesis.speak.mock.calls.length;
    f.controller.replay();
    expect(f.synthesis.speak).toHaveBeenCalledTimes(calls + 1);
    expect(f.controller.snapshot.muted).toBe(true);
    f.controller.stop();
  });

  it("keeps a recognized user turn when interrupting a pending reply", async () => {
    const f = fixture();
    const answer = deferred<string>();
    f.reply.mockImplementationOnce(() => answer.promise);
    f.reply.mockResolvedValue("The next answer remembers you.");
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    expect(f.reply).toHaveBeenCalledWith("Hello", []);

    f.controller.interrupt();
    expect(f.controller.snapshot.phase).toBe("listening");
    answer.resolve("This stale answer must not play.");
    await settle();
    expect(f.synthesis.speak).toHaveBeenCalledTimes(1); // start primer only

    f.controller.finishTurn();
    await settle();
    expect(f.reply.mock.calls[1]?.[1]).toEqual([
      { role: "user", content: "Hello" },
    ]);
    f.controller.stop();
  });

  it("keeps interruption microphone-only when the user is muted", async () => {
    const f = fixture();
    await f.controller.start();
    f.controller.setMuted(true);
    f.controller.interrupt();
    expect(f.controller.snapshot).toMatchObject({
      active: true,
      muted: true,
      phase: "muted",
    });
    expect(f.track.enabled).toBe(false);
    f.controller.stop();
  });
});

describe("automatic speech pause detection", () => {
  it("submits recorded audio after a detected pause through the actual controller", async () => {
    const f = fixture();
    let level = 0.1;
    f.runtime.createAudioContext = () =>
      ({
        state: "running",
        resume: async () => {},
        close: async () => {},
        createMediaStreamSource: () => ({ connect() {}, disconnect() {} }),
        createAnalyser: () => ({
          fftSize: 512,
          getFloatTimeDomainData(samples: Float32Array) {
            samples.fill(level);
          },
        }),
      }) as unknown as AudioContext;
    await f.controller.start();
    await vi.advanceTimersByTimeAsync(500);
    level = 0;
    await vi.advanceTimersByTimeAsync(1300);
    expect(f.transcribe).toHaveBeenCalledTimes(1);
    expect(f.controller.snapshot.phase).toBe("speaking");
    f.controller.stop();
  });

  it("does not send completely silent recordings to transcription", async () => {
    const f = fixture();
    f.runtime.createAudioContext = () =>
      ({
        state: "running",
        resume: async () => {},
        close: async () => {},
        createMediaStreamSource: () => ({ connect() {}, disconnect() {} }),
        createAnalyser: () => ({
          fftSize: 512,
          getFloatTimeDomainData(samples: Float32Array) {
            samples.fill(0);
          },
        }),
      }) as unknown as AudioContext;
    await f.controller.start();
    await vi.advanceTimersByTimeAsync(12000);
    expect(f.transcribe).not.toHaveBeenCalled();
    f.controller.setMuted(true);
    await vi.advanceTimersByTimeAsync(30000);
    expect(f.transcribe).not.toHaveBeenCalled();
    f.controller.stop();
  });

  it("ends a turn after a safe trailing pause, not after a fixed maximum", () => {
    const detector = new SilenceDetector(0);
    expect(detector.sample(0.1, 500)).toBe(false);
    expect(detector.sample(0.1, 1000)).toBe(false);
    expect(detector.sample(0, 1800)).toBe(false);
    expect(detector.sample(0, 2200)).toBe(true);
  });
  it("does not submit silence and preserves a 30-second maximum turn", () => {
    const detector = new SilenceDetector(0);
    expect(detector.sample(0, 9000)).toBe(false);
    expect(detector.heardSpeech).toBe(false);
    expect(detector.expired(29999)).toBe(false);
    expect(detector.expired(30000)).toBe(true);
  });
});

describe("multilingual call recovery", () => {
  it("uses the detected Spanish speech language for a natural reply", async () => {
    const f = fixture();
    f.transcribe.mockResolvedValue({
      text: "Hola, explica esto",
      language: "spanish",
    } as any);
    f.reply.mockResolvedValue("Por supuesto. Aquí está la explicación.");
    const synthesize = vi.fn(async () => ({ url: "/spanish.wav" }));
    const audio: VoiceAudio = {
      currentTime: 0,
      onplay: null,
      onended: null,
      onerror: null,
      play: vi.fn(),
      pause: vi.fn(),
    };
    f.runtime.createAudio = () => audio;
    const c = new VoiceCallController({
      ...f,
      runtime: f.runtime,
      onChange: vi.fn(),
      synthesize,
      language: "auto",
    });
    await c.start();
    c.finishTurn();
    await settle();
    expect(synthesize.mock.calls[0][2]).toBe("es-MX");
    c.setMuted(true);
    expect(audio.pause).not.toHaveBeenCalled();
    c.stop();
  });
  it("pauses after a stuck transcription and ignores its late result", async () => {
    const f = fixture();
    const stalled = deferred<{ text: string }>();
    f.transcribe.mockImplementation(() => stalled.promise);
    await f.controller.start();
    f.controller.finishTurn();
    await settle();
    await vi.advanceTimersByTimeAsync(60001);
    expect(f.controller.snapshot.phase).toBe("error");
    stalled.resolve({ text: "late" });
    await settle();
    expect(f.reply).not.toHaveBeenCalled();
    f.controller.stop();
    expect(vi.getTimerCount()).toBe(0);
  });
  it("offers replay when neural audio does not start, while keeping mute microphone-only", async () => {
    const f = fixture();
    const audio: VoiceAudio = {
      currentTime: 0,
      onplay: null,
      onended: null,
      onerror: null,
      play: vi.fn(),
      pause: vi.fn(),
    };
    f.runtime.createAudio = () => audio;
    const c = new VoiceCallController({
      ...f,
      runtime: f.runtime,
      onChange: vi.fn(),
      synthesize: async () => ({ url: "/voice.wav" }),
    });
    await c.start();
    c.finishTurn();
    await settle();
    c.setMuted(true);
    expect(audio.pause).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(8001);
    expect(c.snapshot.phase).toBe("error");
    expect(c.snapshot.canReplay).toBe(true);
    c.stop();
    expect(vi.getTimerCount()).toBe(0);
  });
});
