import { describe, expect, it, vi } from "vitest";
const m=vi.hoisted(()=>({get:vi.fn(),make:vi.fn()}));
vi.mock("../client/src/lib/voiceCall",()=>({browserVoiceRuntime:()=>({getUserMedia:m.get,makeRecorder:m.make})}));
import {DictationController} from "../client/src/lib/dictation";
describe("recorded multilingual dictation",()=>{
 it("transcribes the original speech without browser language forcing and stops microphone",async()=>{
 const track={stop:vi.fn()}; const stream={getTracks:()=>[track]};let recorder:any={state:"inactive",mimeType:"audio/webm",start(){this.state="recording";},stop(){this.state="inactive";this.ondataavailable?.({data:new Blob(["audio"])});this.onstop?.();}};
 m.get.mockResolvedValue(stream);m.make.mockReturnValue(recorder);const onText=vi.fn(),onStatus=vi.fn(),transcribe=vi.fn(async()=>({text:"مرحبا، اشرحلي الدرس"}));
 const c=new DictationController({onText,onStatus,transcribe});await c.toggle();expect(c.recording).toBe(true);await c.toggle();await Promise.resolve();await Promise.resolve();expect(transcribe).toHaveBeenCalledOnce();expect(onText).toHaveBeenCalledWith("مرحبا، اشرحلي الدرس");expect(track.stop).toHaveBeenCalledOnce();c.stop();
 });
 it("ignores late permission results after cleanup",async()=>{
 let resolve!: (s:any)=>void; const track={stop:vi.fn()};m.get.mockReturnValue(new Promise(r=>resolve=r));const c=new DictationController({onText:vi.fn(),onStatus:vi.fn(),transcribe:vi.fn()});const start=c.toggle();c.stop();resolve({getTracks:()=>[track]});await start;expect(track.stop).toHaveBeenCalledOnce();expect(c.recording).toBe(false);
 });
});
