import http from "node:http";
import express from "express";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getDb: vi.fn(),
  getUserByOpenId: vi.fn(),
  upsertUser: vi.fn(),
  authenticateRequest: vi.fn(),
  createSessionToken: vi.fn(),
}));

vi.mock("./db", () => ({
  getDb: mocks.getDb,
  getUserByOpenId: mocks.getUserByOpenId,
  upsertUser: mocks.upsertUser,
}));
vi.mock("./_core/sdk", () => ({
  sdk: {
    authenticateRequest: mocks.authenticateRequest,
    createSessionToken: mocks.createSessionToken,
  },
}));

import {
  __googleAuthInternals,
  GOOGLE_STATE_COOKIE,
  isGoogleConfigured,
  registerGoogleAuthRoutes,
  safeGoogleReturnTo,
} from "./googleAuth";

type HttpResult = {
  status: number;
  headers: http.IncomingHttpHeaders;
  body: string;
};

function request(
  server: http.Server,
  path: string,
  headers: http.OutgoingHttpHeaders = {}
): Promise<HttpResult> {
  const address = server.address();
  if (!address || typeof address === "string")
    throw new Error("server not listening");
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        host: "127.0.0.1",
        port: address.port,
        path,
        headers,
      },
      response => {
        const chunks: Buffer[] = [];
        response.on("data", chunk => chunks.push(Buffer.from(chunk)));
        response.on("end", () =>
          resolve({
            status: response.statusCode ?? 0,
            headers: response.headers,
            body: Buffer.concat(chunks).toString("utf8"),
          })
        );
      }
    );
    req.on("error", reject);
    req.end();
  });
}

async function withServer<T>(callback: (server: http.Server) => Promise<T>) {
  const app = express();
  registerGoogleAuthRoutes(app);
  const server = app.listen(0);
  try {
    return await callback(server);
  } finally {
    await new Promise<void>(resolve => server.close(() => resolve()));
  }
}

const originalEnv = { ...process.env };

beforeEach(() => {
  process.env.GOOGLE_CLIENT_ID = "test-client.apps.googleusercontent.com";
  process.env.GOOGLE_CLIENT_SECRET = "test-secret";
  process.env.GOOGLE_REDIRECT_URI =
    "https://adus.example.com/api/google/callback";
  process.env.JWT_SECRET = "test-jwt-secret";
  mocks.getDb.mockResolvedValue(null);
  mocks.getUserByOpenId.mockReset();
  mocks.upsertUser.mockReset();
  mocks.authenticateRequest.mockReset();
  mocks.createSessionToken.mockResolvedValue("session-token");
});

afterEach(() => {
  process.env = { ...originalEnv };
});

describe("Google authentication scaffold", () => {
  it("reports missing configuration without exposing secrets", async () => {
    delete process.env.GOOGLE_CLIENT_SECRET;
    expect(isGoogleConfigured()).toBe(false);

    await withServer(async server => {
      const response = await request(
        server,
        "/api/google/start?returnTo=/workspace"
      );
      expect(response.status).toBe(503);
      expect(response.body).toBe('{"error":"google_not_configured"}');
      expect(response.body).not.toContain("test-secret");
    });
  });

  it("rejects state mismatch before any token exchange", async () => {
    await withServer(async server => {
      const start = await request(
        server,
        "/api/google/start?returnTo=/workspace"
      );
      expect(start.status).toBe(302);
      const cookie = start.headers["set-cookie"]?.[0];
      expect(cookie).toContain(`${GOOGLE_STATE_COOKIE}=`);
      expect(cookie).toContain("HttpOnly");
      expect(cookie).toContain("Secure");
      expect(cookie).toContain("SameSite=Lax");
      expect(cookie).toContain("Max-Age=600");

      const callback = await request(
        server,
        "/api/google/callback?state=attacker-controlled&code=one-time-code",
        { cookie }
      );
      expect(callback.status).toBe(302);
      expect(callback.headers.location).toBe("/sign-in?googleError=invalid_state");
    });
  });

  it("accepts only same-origin relative return routes", () => {
    expect(safeGoogleReturnTo("/workspace?tab=ideas#top")).toBe(
      "/workspace?tab=ideas#top"
    );
    expect(safeGoogleReturnTo("https://evil.example/phish")).toBe("/");
    expect(safeGoogleReturnTo("//evil.example/phish")).toBe("/");
    expect(safeGoogleReturnTo("/sign-in?returnTo=/workspace")).toBe("/");
    expect(safeGoogleReturnTo("not-a-path")).toBe("/");
  });

  it("rejects malformed and unverified Google claims", () => {
    expect(() =>
      __googleAuthInternals.validateClaims(
        {
          sub: "123",
          email: "bad-email",
          email_verified: true,
        },
        "nonce"
      )
    ).toThrow("Invalid Google email");

    expect(() =>
      __googleAuthInternals.validateClaims(
        {
          sub: "123",
          email: "person@example.com",
          email_verified: false,
        },
        "nonce"
      )
    ).toThrow("Google email is not verified");
  });

  it("does not claim an existing same-email account during Google login", async () => {
    const createdGoogleUser = {
      id: 22,
      openId: "google:google-sub-1",
      name: "Google Person",
      email: "person@example.com",
      loginMethod: "google",
      role: "user" as const,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };
    mocks.getUserByOpenId
      .mockResolvedValueOnce(undefined)
      .mockResolvedValueOnce(createdGoogleUser);

    const user = await __googleAuthInternals.completeGoogleLogin(
      {} as never,
      {
        sub: "google-sub-1",
        email: "person@example.com",
        email_verified: true,
        nonce: "nonce",
      },
      {
        state: "state",
        nonce: "nonce",
        codeVerifier: "verifier",
        returnTo: "/",
        mode: "login",
      }
    );

    expect(user).toEqual(createdGoogleUser);
    expect(mocks.upsertUser).toHaveBeenCalledWith(
      expect.objectContaining({
        openId: "google:google-sub-1",
        email: "person@example.com",
        loginMethod: "google",
      })
    );
    expect(mocks.upsertUser).not.toHaveBeenCalledWith(
      expect.objectContaining({ openId: "manus-existing" })
    );
  });

  it("requires an authenticated account and matching email for explicit linking", async () => {
    mocks.authenticateRequest.mockResolvedValue({
      id: 7,
      openId: "manus-existing",
      email: "different@example.com",
      name: "Existing",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    });

    await expect(
      __googleAuthInternals.completeGoogleLogin(
        {} as never,
        {
          sub: "google-sub-2",
          email: "person@example.com",
          email_verified: true,
          nonce: "nonce",
        },
        {
          state: "state",
          nonce: "nonce",
          codeVerifier: "verifier",
          returnTo: "/",
          mode: "link",
          linkOpenId: "manus-existing",
        }
      )
    ).rejects.toThrow("does not match the authenticated account");
    expect(mocks.authenticateRequest).toHaveBeenCalledTimes(1);
    expect(mocks.upsertUser).not.toHaveBeenCalled();
  });
});
