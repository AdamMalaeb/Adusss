import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
import {
  businessInputSchema,
  businessPlanSchema,
  calculateFeasibilityScore,
} from "../shared/business";

const mocks = vi.hoisted(() => ({
  invokeLLM: vi.fn(),
  collectChatResearch: vi.fn(),
  saveRecord: vi.fn(),
  getRecord: vi.fn(),
  listRecords: vi.fn(),
}));

vi.mock("./_core/llm", async importOriginal => ({
  ...(await importOriginal<typeof import("./_core/llm")>()),
  invokeLLM: mocks.invokeLLM,
  selectChatModel: vi.fn(() => "gpt-5.5"),
}));
vi.mock("./chatResearch", () => ({
  collectChatResearch: mocks.collectChatResearch,
}));
vi.mock("./workspaceStore", () => ({
  saveRecord: mocks.saveRecord,
  getRecord: mocks.getRecord,
  listRecords: mocks.listRecords,
}));

import { businessRouter } from "./businessRouter";

const baseInput = {
  idea: "A subscription service that helps small restaurants reduce food waste.",
  countryOrMarket: "Beirut, Lebanon",
  budget: 5000,
  currency: "USD",
  customer: "Independent restaurants with 5–30 staff and a chef-owner.",
  experience:
    "I have worked in restaurant operations and can interview local owners.",
  researchLocalMarket: true,
} as const;

function plan(overrides: Record<string, unknown> = {}) {
  return {
    title: "Restaurant waste pilot",
    executiveSummary:
      "Start with a narrow paid pilot and measure avoided waste before building software.",
    strategy: {
      overview: "Lead with a service-led pilot.",
      actions: ["Interview ten owners."],
    },
    customer: {
      overview: "Chef-owners are the first segment.",
      actions: ["Ask about current waste logs."],
    },
    market: {
      overview: "The local market needs verification.",
      actions: ["Map existing suppliers and alternatives."],
    },
    competitors: [
      {
        name: "Existing workflows",
        positioning: "Spreadsheets and manual checks.",
        watchout: "Could be good enough for some customers.",
      },
    ],
    swot: {
      strengths: ["Founder domain access"],
      weaknesses: ["No paid validation yet"],
      opportunities: ["Pilot with one neighborhood"],
      threats: ["Low switching urgency"],
    },
    operatingStructure: {
      overview: "Founder runs discovery and delivery first.",
      actions: ["Document a repeatable weekly review."],
    },
    marketing: {
      overview: "Use referrals and direct interviews.",
      actions: ["Offer a measurable pilot."],
    },
    milestones: [
      {
        horizon: "0–30 days",
        objective: "Validate the problem",
        checks: ["Complete ten interviews", "Secure two pilots"],
      },
    ],
    risks: [
      {
        risk: "Owners may not pay",
        mitigation: "Ask for a paid pilot early",
        signal: "Repeated interest without commitment",
      },
    ],
    practicalAdvice: ["Do not build software before observing the workflow."],
    assumptions: ["Restaurant owners can be reached through founder network."],
    missingInformation: [
      "Actual willingness to pay",
      "Baseline waste per restaurant",
    ],
    rubricFactors: [
      {
        key: "problemClarity",
        label: "Problem clarity",
        score: 80,
        weight: 99,
        evidence: "A concrete waste problem is described.",
        missingInfo: [],
      },
      {
        key: "customerSpecificity",
        label: "Customer specificity",
        score: 70,
        weight: 99,
        evidence: "The first segment is named.",
        missingInfo: ["Interview evidence"],
      },
      {
        key: "marketAccess",
        label: "Market access",
        score: 40,
        weight: 99,
        evidence: "Access is a hypothesis.",
        missingInfo: ["Channel confirmation"],
      },
      {
        key: "differentiation",
        label: "Differentiation",
        score: 45,
        weight: 99,
        evidence: "The pilot is testable but not defensible yet.",
        missingInfo: ["Alternative comparison"],
      },
      {
        key: "operationalReadiness",
        label: "Operational readiness",
        score: 75,
        weight: 99,
        evidence: "Relevant experience supplied.",
        missingInfo: [],
      },
      {
        key: "economics",
        label: "Economics",
        score: 20,
        weight: 99,
        evidence: "No unit economics were supplied.",
        missingInfo: ["Price and cost inputs"],
      },
      {
        key: "validationEvidence",
        label: "Validation evidence",
        score: 10,
        weight: 99,
        evidence: "No paid pilot evidence supplied.",
        missingInfo: ["Paid pilot"],
      },
    ],
    feasibilityScore: 99,
    unitEconomics: {
      currency: "USD",
      pricePerCustomer: 999,
      customersPerMonth: 99,
      variableCostPerCustomer: 1,
      fixedCostsPerMonth: 2,
      note: "Model must not supply numeric economics.",
    },
    sources: [
      {
        title: "Hallucinated",
        url: "https://not-retrieved.example/",
        excerpt: "Should be replaced.",
      },
    ],
    researchStatus: "verified",
    generatedAt: "2026-10-11T00:00:00.000Z",
    ...overrides,
  };
}

function caller(userId = 7) {
  return businessRouter.createCaller({
    user: { id: userId, email: `user-${userId}@example.com` },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}

beforeEach(() => {
  vi.clearAllMocks();
  mocks.collectChatResearch.mockResolvedValue({
    status: "verified",
    context:
      "Retrieved public source excerpts are available. [1] Public market evidence. URL: https://public.example/market",
    sources: [
      {
        title: "Public market source",
        url: "https://public.example/market",
        excerpt: "A retrieved public excerpt.",
      },
    ],
  });
  mocks.invokeLLM.mockResolvedValue({
    model: "gpt-5.5",
    choices: [{ message: { content: JSON.stringify(plan()) } }],
  });
  mocks.saveRecord.mockImplementation(
    async (_userId: number, _kind: string, payload: unknown, id?: string) => ({
      id: id ?? "business-1",
      payload,
      createdAt: 1,
      updatedAt: 1,
    })
  );
  mocks.getRecord.mockResolvedValue(undefined);
  mocks.listRecords.mockResolvedValue([]);
});

describe("business contracts", () => {
  it("uses a deterministic weighted average, independent of array order", () => {
    expect(
      calculateFeasibilityScore([
        { score: 100, weight: 1 },
        { score: 0, weight: 1 },
      ])
    ).toBe(50);
    expect(
      calculateFeasibilityScore([
        { score: 0, weight: 1 },
        { score: 100, weight: 3 },
      ])
    ).toBe(75);
    expect(
      calculateFeasibilityScore([
        { score: -100, weight: 1 },
        { score: 200, weight: 1 },
      ])
    ).toBe(50);
  });

  it("rejects blank required fields and invalid budget/currency bounds", () => {
    expect(
      businessInputSchema.safeParse({ ...baseInput, idea: "no" }).success
    ).toBe(false);
    expect(
      businessInputSchema.safeParse({ ...baseInput, budget: -1 }).success
    ).toBe(false);
    expect(
      businessInputSchema.safeParse({ ...baseInput, currency: "dollars" })
        .success
    ).toBe(false);
  });

  it("requires a complete strict plan shape", () => {
    expect(
      businessPlanSchema.safeParse({ ...plan(), unexpected: true }).success
    ).toBe(false);
  });

  it("defaults language and known facts for legacy-shaped records", () => {
    const parsedInput = businessInputSchema.parse(baseInput);
    const parsedPlan = businessPlanSchema.parse(plan());
    expect(parsedInput.language).toBe("auto");
    expect(parsedPlan.language).toBe("auto");
    expect(parsedPlan.knownFacts).toEqual([]);
  });
});

describe("business router", () => {
  it("keeps the idea private from public market research and replaces unsupported model values", async () => {
    const result = await caller().generate(baseInput);
    expect(mocks.collectChatResearch).toHaveBeenCalledWith(
      "research Beirut, Lebanon"
    );
    expect(
      JSON.stringify(mocks.collectChatResearch.mock.calls[0])
    ).not.toContain(baseInput.idea);
    expect(
      JSON.stringify(mocks.collectChatResearch.mock.calls[0])
    ).not.toContain(baseInput.customer);
    expect(result.plan.sources).toEqual([
      {
        title: "Public market source",
        url: "https://public.example/market",
        excerpt: "A retrieved public excerpt.",
      },
    ]);
    expect(result.plan.unitEconomics.pricePerCustomer).toBeNull();
    expect(result.plan.feasibilityScore).toBe(50.5);
    expect(result.score).toBe(50.5);
    expect(mocks.invokeLLM.mock.calls[0][0].response_format).toEqual({
      type: "json_object",
    });
    expect(mocks.invokeLLM.mock.calls[0][0].reasoning).toEqual({
      effort: "low",
    });
    expect(result.plan.executiveSummary).not.toContain(
      "https://not-retrieved.example"
    );
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      7,
      "businessPlan",
      expect.objectContaining({ score: 50.5 })
    );
  });

  it("does not research by default and clearly preserves missing-information language", async () => {
    const input = { ...baseInput, researchLocalMarket: false };
    const result = await caller().generate(input);
    expect(mocks.collectChatResearch).not.toHaveBeenCalled();
    expect(result.plan.researchStatus).toBe("not_requested");
    expect(result.plan.missingInformation).toContain(
      "Actual willingness to pay"
    );
  });

  it("passes an explicit supported language through the prompt and saved plan", async () => {
    const input = { ...baseInput, language: "es-MX" as const };
    const result = await caller().generate(input);
    expect(result.input.language).toBe("es-MX");
    expect(result.plan.language).toBe("es-MX");
    expect(mocks.invokeLLM.mock.calls[0][0].messages[0].content).toContain(
      "Spanish"
    );
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      7,
      "businessPlan",
      expect.objectContaining({
        input: expect.objectContaining({ language: "es-MX" }),
      })
    );
  });

  it("requires authentication for history and restores only an owned record", async () => {
    const unauthenticated = businessRouter.createCaller({
      user: null,
      req: { headers: {} },
      res: {},
    } as TrpcContext);
    await expect(unauthenticated.history()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
    mocks.getRecord.mockResolvedValue({
      id: "business-1",
      payload: {
        input: baseInput,
        plan: businessPlanSchema.parse({
          ...plan(),
          sources: [
            {
              title: "Public market source",
              url: "https://public.example/market",
              excerpt: "A retrieved public excerpt.",
            },
          ],
          unitEconomics: {
            currency: "USD",
            pricePerCustomer: null,
            customersPerMonth: null,
            variableCostPerCustomer: null,
            fixedCostsPerMonth: null,
            note: "No inputs.",
          },
        }),
        score: 50.5,
        generatedAt: "2026-10-11T00:00:00.000Z",
        model: "gpt-5.5",
      },
    });
    const restored = await caller(7).restore({ id: "business-1" });
    expect(restored.id).toBe("business-1");
    expect(mocks.getRecord).toHaveBeenCalledWith(
      7,
      "businessPlan",
      "business-1"
    );
  });

  it("creates a new revision and leaves the previous record untouched", async () => {
    mocks.getRecord.mockResolvedValue({
      id: "business-old",
      payload: {
        input: { ...baseInput, researchLocalMarket: false },
        plan: businessPlanSchema.parse({
          ...plan(),
          researchStatus: "not_requested",
          sources: [],
          unitEconomics: {
            currency: "USD",
            pricePerCustomer: null,
            customersPerMonth: null,
            variableCostPerCustomer: null,
            fixedCostsPerMonth: null,
            note: "No inputs.",
          },
        }),
        score: 49.25,
        generatedAt: "2026-10-11T00:00:00.000Z",
        model: "gpt-5.5",
      },
    });
    const result = await caller().revise({
      id: "business-old",
      instruction: "Focus on a low-cost service pilot first.",
      language: "fr",
    });
    expect(result.revisionOf).toBe("business-old");
    expect(result.input.language).toBe("fr");
    expect(result.plan.language).toBe("fr");
    expect(mocks.invokeLLM.mock.calls[0][0].messages[0].content).toContain(
      "French"
    );
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      7,
      "businessPlan",
      expect.objectContaining({ revisionOf: "business-old" })
    );
  });
});
