import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { getRecord, saveRecord } from "./workspaceStore";
import { storagePut, storageGetSignedUrl } from "./storage";
import { probeVideo, type VideoProbe } from "./videoEditing";
import {
  detectVideoMime,
  MAX_SOURCE_BYTES,
  MAX_SOURCE_DURATION_SECONDS,
  normalizeDeclaredVideoMime,
  safeVideoName,
  type SupportedVideoMime,
} from "./videoValidation";

export { MAX_SOURCE_BYTES } from "./videoValidation";
export const MAX_BASE64_SOURCE_BYTES = 12 * 1024 * 1024;

export const VIDEO_KIND = "videos" as const;
export const SOURCE_FETCH_TIMEOUT_MS = 30_000;

export type VideoSourcePayload = {
  type: "source";
  status: "completed";
  name: string;
  mimeType: SupportedVideoMime;
  bytes: number;
  duration: number;
  key: string;
  url: string;
};

export type PublicVideoSource = Omit<VideoSourcePayload, "key"> & { id: string };

function badRequest(message: string): TRPCError {
  return new TRPCError({ code: "BAD_REQUEST", message });
}

function serviceUnavailable(message: string): TRPCError {
  return new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}

export function publicVideoSource(id: string, payload: VideoSourcePayload): PublicVideoSource {
  return {
    id,
    type: payload.type,
    status: payload.status,
    name: payload.name,
    mimeType: payload.mimeType,
    bytes: payload.bytes,
    duration: payload.duration,
    url: payload.url,
  };
}

/** Validate bytes and actual media metadata before storage or provider upload. */
export async function validateVideoSource(input: {
  bytes: Buffer;
  name: string;
  mimeType?: string | null;
}): Promise<{ bytes: Buffer; name: string; mimeType: SupportedVideoMime; probe: VideoProbe }> {
  if (!input.bytes.length) throw badRequest("The video upload is empty.");
  if (input.bytes.length > MAX_SOURCE_BYTES)
    throw badRequest("Source videos must be 80 MB or smaller.");

  let detectedMime: SupportedVideoMime;
  try {
    detectedMime = detectVideoMime(input.bytes, input.mimeType);
  } catch (error) {
    throw badRequest(error instanceof Error ? error.message : "Choose a real MP4, MOV, or WEBM video file.");
  }

  let probe: VideoProbe;
  try {
    probe = await probeVideo(input.bytes, detectedMime);
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    throw badRequest("Choose a playable MP4, MOV, or WEBM video.");
  }
  if (probe.duration > MAX_SOURCE_DURATION_SECONDS)
    throw badRequest("Source videos must be 120 seconds or shorter.");

  // A browser can claim a MIME type that conflicts with the container. The
  // detected container and ffprobe result are authoritative; MIME aliases such
  // as video/x-m4v and an empty recorder MIME are intentionally accepted.
  const declared = normalizeDeclaredVideoMime(input.mimeType);
  if (declared && !["video/mp4", "video/quicktime", "video/webm"].includes(declared))
    throw badRequest("Choose an MP4, MOV, or WEBM video.");

  return {
    bytes: input.bytes,
    name: safeVideoName(input.name),
    mimeType: detectedMime,
    probe,
  };
}

export async function storeVideoSource(userId: number, input: {
  bytes: Buffer;
  name: string;
  mimeType?: string | null;
}): Promise<PublicVideoSource> {
  const validated = await validateVideoSource(input);
  const id = randomUUID();
  let stored: { key: string; url: string };
  try {
    stored = await storagePut(`videos/${userId}/${id}-${validated.name}`, validated.bytes, validated.mimeType);
  } catch {
    throw serviceUnavailable("The video passed validation but could not be saved to workspace storage.");
  }
  const payload: VideoSourcePayload = {
    type: "source",
    status: "completed",
    name: validated.name,
    mimeType: validated.mimeType,
    bytes: validated.bytes.length,
    duration: validated.probe.duration,
    key: stored.key,
    url: stored.url,
  };
  await saveRecord(userId, VIDEO_KIND, payload, id);
  return publicVideoSource(id, payload);
}

export async function loadStoredVideoSource(userId: number, sourceId: string): Promise<{
  id: string;
  payload: VideoSourcePayload;
  bytes: Buffer;
  probe: VideoProbe;
}> {
  const record = await getRecord(userId, VIDEO_KIND, sourceId);
  const payload = record?.payload as VideoSourcePayload | undefined;
  if (!record || payload?.type !== "source" || !payload.key || !payload.mimeType)
    throw new TRPCError({ code: "NOT_FOUND", message: "That uploaded source video is not available to this account." });

  let signedUrl: string;
  try {
    signedUrl = await storageGetSignedUrl(payload.key);
  } catch {
    throw serviceUnavailable("The stored source could not be opened.");
  }
  let response: Response;
  try {
    response = await fetch(signedUrl, { signal: AbortSignal.timeout(SOURCE_FETCH_TIMEOUT_MS) });
  } catch {
    throw serviceUnavailable("The stored source could not be downloaded.");
  }
  if (!response.ok) throw serviceUnavailable("The stored source could not be downloaded.");
  const length = Number(response.headers.get("content-length") ?? "0");
  if (length > MAX_SOURCE_BYTES) throw badRequest("The stored source is larger than 80 MB.");
  const bytes = Buffer.from(await response.arrayBuffer());
  if (!bytes.length || bytes.length > MAX_SOURCE_BYTES)
    throw badRequest("The stored source is empty or larger than 80 MB.");
  const validated = await validateVideoSource({ bytes, name: payload.name, mimeType: payload.mimeType });
  return { id: sourceId, payload: { ...payload, mimeType: validated.mimeType, bytes: bytes.length, duration: validated.probe.duration }, bytes, probe: validated.probe };
}
