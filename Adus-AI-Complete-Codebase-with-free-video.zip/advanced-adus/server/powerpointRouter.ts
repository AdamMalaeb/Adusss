import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import {
  createPowerPointTask,
  checkManusReadiness,
  generatePowerPointTaskFromRequest,
  generatePowerPointDraft,
  pollPowerPointTask,
  revisePowerPointDraft,
  sendPowerPointMessage,
} from "./powerpointService";
import { getRecord, listRecords, saveRecord } from "./workspaceStore";
import {
  POWERPOINT_DRAFT_KIND,
  POWERPOINT_KIND,
  POWERPOINT_TASK_KIND,
  powerpointDraftSchema,
  powerpointGenerationRequestSchema,
  powerpointLanguageSchema,
  powerpointSourceSchema,
  powerpointStyleSchema,
  type PowerPointDraft,
} from "../shared/powerpoint";

const draftRequestSchema = z.object({
  topic: z.string().trim().min(2).max(240),
  audience: z.string().trim().min(2).max(240),
  language: powerpointLanguageSchema,
  style: powerpointStyleSchema,
  slideCount: z.number().int().min(4).max(12),
  source: powerpointSourceSchema.optional(),
  sourceFacts: z.array(z.string().trim().min(1).max(600)).max(40).optional(),
});

function requireDraft(input: { draft: PowerPointDraft }): PowerPointDraft {
  try {
    return powerpointDraftSchema.parse(input.draft);
  } catch {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Review every slide before continuing. A slide needs a title and the deck needs 4–12 slides.",
    });
  }
}

export const powerpointRouter = router({
  readiness: protectedProcedure.query(() => checkManusReadiness()),

  generate: protectedProcedure
    .input(powerpointGenerationRequestSchema)
    .mutation(({ ctx, input }) =>
      generatePowerPointTaskFromRequest(ctx.user.id, input)
    ),

  outline: protectedProcedure
    .input(draftRequestSchema)
    .mutation(async ({ ctx, input }) => {
      const result = await generatePowerPointDraft(input);
      const saved = await saveRecord(ctx.user.id, POWERPOINT_DRAFT_KIND, result.draft);
      return {
        id: saved.id,
        draft: result.draft,
        sourceOutline: result.sourceOutline,
      };
    }),

  reviseOutline: protectedProcedure
    .input(
      z.object({
        draft: powerpointDraftSchema,
        instruction: z.string().trim().min(2).max(2000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const draft = requireDraft(input);
      const revised = await revisePowerPointDraft({ draft, instruction: input.instruction });
      const saved = await saveRecord(ctx.user.id, POWERPOINT_DRAFT_KIND, revised);
      return { id: saved.id, draft: revised };
    }),

  saveDraft: protectedProcedure
    .input(z.object({ draft: powerpointDraftSchema, id: z.string().trim().min(1).max(64).optional() }))
    .mutation(async ({ ctx, input }) => {
      const draft = requireDraft(input);
      const saved = await saveRecord(ctx.user.id, POWERPOINT_DRAFT_KIND, draft, input.id);
      return { id: saved.id, draft: saved.payload as PowerPointDraft };
    }),

  create: protectedProcedure
    .input(z.object({ draft: powerpointDraftSchema, source: powerpointSourceSchema.optional() }))
    .mutation(async ({ ctx, input }) => {
      const draft = requireDraft(input);
      return createPowerPointTask(ctx.user.id, { draft, source: input.source });
    }),

  poll: protectedProcedure
    .input(z.object({ taskRecordId: z.string().trim().min(1).max(64) }))
    .mutation(({ ctx, input }) => pollPowerPointTask(ctx.user.id, input.taskRecordId)),

  sendMessage: protectedProcedure
    .input(
      z.object({
        taskRecordId: z.string().trim().min(1).max(64),
        content: z.string().trim().min(1).max(5000),
      })
    )
    .mutation(({ ctx, input }) => sendPowerPointMessage(ctx.user.id, input.taskRecordId, input.content)),

  history: protectedProcedure.query(async ({ ctx }) => {
    const [tasks, outputs, drafts] = await Promise.all([
      listRecords(ctx.user.id, POWERPOINT_TASK_KIND, 50),
      listRecords(ctx.user.id, POWERPOINT_KIND, 50),
      listRecords(ctx.user.id, POWERPOINT_DRAFT_KIND, 20),
    ]);
    return { tasks, outputs, drafts };
  }),

  getTask: protectedProcedure
    .input(z.object({ taskRecordId: z.string().trim().min(1).max(64) }))
    .query(async ({ ctx, input }) => {
      const record = await getRecord(ctx.user.id, POWERPOINT_TASK_KIND, input.taskRecordId);
      if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "That PowerPoint task was not found in your workspace." });
      return record;
    }),
});

export default powerpointRouter;
