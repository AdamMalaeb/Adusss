import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";
import {
  languageLabel,
  languageSpeechName,
  normalizeLanguage,
  type LanguageSelection,
  type SupportedLanguageCode,
} from "../shared/languages";

/** Provider-supported language code, with old IDs accepted at API boundaries. */
export type NaturalSpeechLanguage = LanguageSelection;
/** Live calls may let Gemini detect the language from each response's text. */
export type NaturalSpeechCallLanguage = NaturalSpeechLanguage | "auto";
export type NaturalSpeechGender = "man" | "woman";
export type NaturalSpeechMode = "study" | "call";

export type NaturalSpeechOptions = {
  /** Test-only injection; production always uses GEMINI_API_KEY. */
  apiKey?: string;
  fetchImpl?: typeof fetch;
  voice?: string;
  gender?: NaturalSpeechGender;
  speechMode?: NaturalSpeechMode;
  storagePrefix?: string;
  style?: string;
  signal?: AbortSignal;
};

export type NaturalSpeechResult = {
  audio: Buffer;
  contentType: "audio/wav";
  sampleRate: 24000;
};

export type StoredNaturalSpeech = {
  key: string;
  url: string;
  audio: Buffer;
  contentType: "audio/wav";
};

const GEMINI_INTERACTIONS_URL =
  "https://generativelanguage.googleapis.com/v1beta/interactions";
const DEFAULT_MODEL = "gemini-3.8-flash-tts";
const DEFAULT_VOICE = "Kore";
const VOICE_BY_GENDER: Record<NaturalSpeechGender, string> = {
  woman: "Kore",
  man: "Charon",
};
const SAMPLE_RATE = 24_000;
const CHANNELS = 1;
const BITS_PER_SAMPLE = 16;
export const NATURAL_SPEECH_QUEUE_MAX_WAIT_MS = 15_000;
export const NATURAL_SPEECH_MIN_PACING_MS = 250;
const NATURAL_SPEECH_MAX_RETRIES = 2;

function languageInstruction(
  language: NaturalSpeechCallLanguage,
  speechMode: NaturalSpeechMode | undefined
): string {
  if (language === "auto")
    return speechMode === "call"
      ? "Speak in the language used by this response, preserving natural mixed-language speech when appropriate. Use a calm, courteous professional delivery. Sound like a thoughtful human assistant: concise, warm, and clear, with a brief justification when one is useful. Do not translate a non-English response into English. Do not sound childish, theatrical, or robotic."
      : "Speak in the language used by this lesson, preserving formulas, names, and words from other languages rather than translating them.";
  const label = languageLabel(language);
  const speechName = languageSpeechName(language);
  if (speechMode === "call")
    return `Speak this response in natural ${speechName} (${label}) with a calm, courteous professional delivery. Sound like a thoughtful human assistant: concise, warm, and clear, with a brief justification when one is useful. Preserve words from other languages in the response rather than translating them. Do not sound childish, theatrical, or robotic.`;
  return `Speak this lesson in natural ${speechName} (${label}) with a warm, encouraging classroom-teacher delivery and a brisk but intelligible pace. Preserve formulas, names, and words from other languages rather than translating them.`;
}

function precondition(message: string): TRPCError {
  return new TRPCError({ code: "PRECONDITION_FAILED", message });
}

function serviceUnavailable(message: string): TRPCError {
  return new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}

function resolveApiKey(explicit?: string): string {
  // Deliberately do not fall back to OPENAI_API_KEY. Gemini TTS is a separate
  // provider and using a sandbox proxy credential in production would be unsafe.
  const key = explicit?.trim() || process.env.GEMINI_API_KEY?.trim();
  if (!key) {
    throw precondition(
      "Natural narration is unavailable: GEMINI_API_KEY is not configured. Add a Gemini API key; no robotic or silent fallback is used."
    );
  }
  return key;
}

function cleanText(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}

function voiceFor(options: NaturalSpeechOptions): string {
  return (
    options.voice?.trim() ||
    (options.gender ? VOICE_BY_GENDER[options.gender] : DEFAULT_VOICE)
  );
}

/**
 * Builds the exact Gemini Interactions request documented at
 * https://ai.google.dev/gemini-api/docs/speech-generation?hl=en.
 */
export function buildGeminiSpeechRequest(
  text: string,
  language: NaturalSpeechCallLanguage,
  voice = DEFAULT_VOICE,
  style = languageInstruction(language, undefined)
): Record<string, unknown> {
  const spokenText = cleanText(text);
  if (!spokenText)
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Narration cannot be empty.",
    });
  return {
    model: DEFAULT_MODEL,
    input: [
      {
        type: "user_input",
        content: [
          {
            type: "text",
            text: spokenText,
            annotations: [
              {
                type: "speech_metadata",
                style,
              },
            ],
          },
        ],
      },
    ],
    response_format: { type: "audio" },
    generation_config: {
      speech_config: [{ voice: voice.trim() || DEFAULT_VOICE }],
    },
  };
}

function base64ToBuffer(value: string): Buffer {
  const encoded = value.replace(/^data:[^;]+;base64,/, "").trim();
  if (!encoded) throw new Error("Gemini returned empty audio data");
  return Buffer.from(encoded, "base64");
}

function looksLikeWav(bytes: Buffer): boolean {
  return (
    bytes.length >= 12 &&
    bytes.subarray(0, 4).toString("ascii") === "RIFF" &&
    bytes.subarray(8, 12).toString("ascii") === "WAVE"
  );
}

/** Gemini may return a complete WAV or raw 24 kHz mono 16-bit PCM. */
export function pcmToWav(pcm: Buffer): Buffer {
  const header = Buffer.alloc(44);
  const byteRate = SAMPLE_RATE * CHANNELS * (BITS_PER_SAMPLE / 8);
  const blockAlign = CHANNELS * (BITS_PER_SAMPLE / 8);
  header.write("RIFF", 0, "ascii");
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8, "ascii");
  header.write("fmt ", 12, "ascii");
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(CHANNELS, 22);
  header.writeUInt32LE(SAMPLE_RATE, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(BITS_PER_SAMPLE, 34);
  header.write("data", 36, "ascii");
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

function audioDataFromInteraction(body: unknown): string | undefined {
  if (!body || typeof body !== "object") return undefined;
  const record = body as Record<string, unknown>;
  const direct = [record.output_audio, record.outputAudio]
    .map(value => {
      if (!value || typeof value !== "object") return undefined;
      const data = (value as Record<string, unknown>).data;
      return typeof data === "string" ? data : undefined;
    })
    .find(Boolean);
  if (direct) return direct;

  // REST responses expose audio in the last model_output step.
  const steps = Array.isArray(record.steps) ? record.steps : [];
  for (let stepIndex = steps.length - 1; stepIndex >= 0; stepIndex -= 1) {
    const step = steps[stepIndex];
    if (!step || typeof step !== "object") continue;
    const content = (step as Record<string, unknown>).content;
    if (!Array.isArray(content)) continue;
    for (
      let contentIndex = content.length - 1;
      contentIndex >= 0;
      contentIndex -= 1
    ) {
      const item = content[contentIndex];
      if (!item || typeof item !== "object") continue;
      const itemRecord = item as Record<string, unknown>;
      if (itemRecord.type !== "audio") continue;
      const data = itemRecord.data;
      if (typeof data === "string" && data.trim()) return data;
    }
  }
  return undefined;
}

function retryAfterMilliseconds(headers: Headers): number | undefined {
  const value = headers.get("retry-after")?.trim();
  if (!value) return undefined;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000);
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp)
    ? Math.max(0, timestamp - Date.now())
    : undefined;
}

function wait(milliseconds: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted)
    return Promise.reject(
      new DOMException("The narration was cancelled.", "AbortError")
    );
  if (milliseconds <= 0) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timer = globalThis.setTimeout(() => {
      signal?.removeEventListener("abort", abort);
      resolve();
    }, milliseconds);
    const abort = () => {
      globalThis.clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      reject(new DOMException("The narration was cancelled.", "AbortError"));
    };
    signal?.addEventListener("abort", abort, { once: true });
  });
}

function cancelledNarration(): TRPCError {
  return new TRPCError({
    code: "TIMEOUT",
    message: "Natural narration was cancelled. You can retry this turn.",
  });
}

let speechQueue: Promise<void> = Promise.resolve();
let nextSpeechAt = 0;
let speechCooldownAt = 0;
let queuedSpeechCount = 0;

/**
 * Keep study chapters and live calls from issuing overlapping TTS requests.
 * The queue deliberately has a finite wait so a rate-limited provider never
 * turns a call into an unbounded spinner.
 */
async function enqueueNaturalSpeech<T>(
  operation: () => Promise<T>,
  signal?: AbortSignal
): Promise<T> {
  if (signal?.aborted) throw cancelledNarration();
  if (queuedSpeechCount >= 4)
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message:
        "Natural narration is busy. Please retry shortly; your completed work stays saved.",
    });
  queuedSpeechCount += 1;
  const queuedAt = Date.now();
  let started = false;
  let queueExpired = false;
  const run = speechQueue.then(async () => {
    if (signal?.aborted) throw cancelledNarration();
    const delay = Math.max(
      0,
      nextSpeechAt - Date.now(),
      speechCooldownAt - Date.now()
    );
    if (Date.now() - queuedAt + delay > NATURAL_SPEECH_QUEUE_MAX_WAIT_MS)
      throw new TRPCError({
        code: "TOO_MANY_REQUESTS",
        message:
          "Natural narration is cooling down. Wait a moment before retrying; completed work stays saved.",
      });
    try {
      await wait(delay, signal);
    } catch (error) {
      if (signal?.aborted) throw cancelledNarration();
      throw error;
    }
    if (queueExpired)
      throw new TRPCError({
        code: "TOO_MANY_REQUESTS",
        message:
          "This queued narration expired before starting. Retry when narration is available.",
      });
    started = true;
    try {
      return await operation();
    } finally {
      nextSpeechAt = Date.now() + NATURAL_SPEECH_MIN_PACING_MS;
    }
  });
  speechQueue = run.then(
    () => undefined,
    () => undefined
  );
  let timer: ReturnType<typeof setTimeout> | undefined;
  let abort: (() => void) | undefined;
  const expired = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      if (!started) {
        queueExpired = true;
        reject(
          new TRPCError({
            code: "TOO_MANY_REQUESTS",
            message:
              "Natural narration is busy. Retry shortly; no duplicate speech request was made.",
          })
        );
      }
    }, NATURAL_SPEECH_QUEUE_MAX_WAIT_MS);
  });
  const cancelled = new Promise<never>((_, reject) => {
    abort = () => {
      queueExpired = true;
      reject(cancelledNarration());
    };
    signal?.addEventListener("abort", abort, { once: true });
  });
  // Timeout limits queue waiting, not an operation that has already started.
  const guardedRun = run;
  try {
    return await Promise.race([guardedRun, expired, cancelled]);
  } finally {
    if (timer) clearTimeout(timer);
    if (abort) signal?.removeEventListener("abort", abort);
    queuedSpeechCount -= 1;
  }
}

/** Test helper for deterministic queue tests; not needed by production callers. */
export function resetNaturalSpeechQueueForTests() {
  speechQueue = Promise.resolve();
  nextSpeechAt = 0;
  speechCooldownAt = 0;
  queuedSpeechCount = 0;
}

export async function synthesizeNaturalSpeech(
  text: string,
  language: NaturalSpeechCallLanguage,
  options: NaturalSpeechOptions = {}
): Promise<NaturalSpeechResult> {
  const apiKey = resolveApiKey(options.apiKey);
  let normalizedLanguage: NaturalSpeechCallLanguage;
  try {
    normalizedLanguage =
      language === "auto" ? "auto" : normalizeLanguage(language);
  } catch {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Unsupported narration language.",
    });
  }
  const fetchImpl = options.fetchImpl ?? fetch;
  const style =
    options.style ??
    languageInstruction(normalizedLanguage, options.speechMode);
  const request = buildGeminiSpeechRequest(
    text,
    normalizedLanguage,
    voiceFor(options),
    style
  );

  return enqueueNaturalSpeech(async () => {
    let attempt = 0;
    while (true) {
      let response: Response;
      try {
        response = await fetchImpl(GEMINI_INTERACTIONS_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": apiKey,
          },
          body: JSON.stringify(request),
          signal: options.signal ?? AbortSignal.timeout(120000),
        });
      } catch (error) {
        if (options.signal?.aborted) throw cancelledNarration();
        throw serviceUnavailable(
          "Natural narration could not be reached. Your lesson is saved; retry this chapter."
        );
      }

      if (!response.ok) {
        const retryAfter = retryAfterMilliseconds(response.headers);
        const errorBody = await response.text().catch(() => "");
        if (
          response.status === 429 &&
          /limit[\s\S]{0,20}0\b|quota[\s\S]{0,40}(exhausted|exceeded)|usage exhausted/i.test(
            errorBody
          )
        ) {
          speechCooldownAt =
            Date.now() + Math.max(retryAfter ?? 30_000, 30_000);
          throw new TRPCError({
            code: "TOO_MANY_REQUESTS",
            message:
              "The narration project has no available quota right now. Check the Google project limits; completed lessons stay saved.",
          });
        }
        if (response.status === 429 && attempt < NATURAL_SPEECH_MAX_RETRIES) {
          const backoff = Math.min(8_000, 500 * 2 ** attempt);
          const retryDelay = retryAfter ?? backoff;
          if (retryDelay > NATURAL_SPEECH_QUEUE_MAX_WAIT_MS) {
            speechCooldownAt = Date.now() + retryDelay;
            throw new TRPCError({
              code: "TOO_MANY_REQUESTS",
              message:
                "The narration provider asked us to wait longer than this call can hold. Please retry shortly.",
            });
          }
          attempt += 1;
          await wait(retryDelay, options.signal);
          continue;
        }
        if (response.status === 429) {
          speechCooldownAt =
            Date.now() + Math.max(retryAfter ?? 10_000, 10_000);
          throw new TRPCError({
            code: "TOO_MANY_REQUESTS",
            message:
              "The narration provider is temporarily rate-limiting requests. Wait a moment, then retry. Completed chapters stay saved.",
          });
        }
        if (response.status === 401 || response.status === 403)
          throw precondition(
            "The narration provider rejected the project credential or model access. Check the secure Gemini project configuration."
          );
        throw serviceUnavailable(
          "Natural narration could not finish. Your chapter is saved; please retry."
        );
      }

      let body: unknown;
      try {
        body = await response.json();
      } catch {
        throw serviceUnavailable(
          "Gemini natural narration returned invalid JSON."
        );
      }
      const encoded = audioDataFromInteraction(body);
      if (!encoded)
        throw serviceUnavailable("Gemini natural narration returned no audio.");
      const returnedBytes = base64ToBuffer(encoded);
      if (!returnedBytes.length)
        throw serviceUnavailable(
          "Gemini natural narration returned empty audio."
        );
      const audio = looksLikeWav(returnedBytes)
        ? returnedBytes
        : pcmToWav(returnedBytes);
      return { audio, contentType: "audio/wav", sampleRate: SAMPLE_RATE };
    }
  }, options.signal);
}

/** Generate exactly one chapter narration and persist it as a reusable WAV. */
export async function createNaturalSpeechAudio(
  userId: number,
  id: string,
  text: string,
  language: NaturalSpeechCallLanguage,
  options: NaturalSpeechOptions = {}
): Promise<StoredNaturalSpeech> {
  const result = await synthesizeNaturalSpeech(text, language, options);
  const stored = await storagePut(
    `${options.storagePrefix ?? "whiteboard"}/${userId}/${id}-narration.wav`,
    result.audio,
    result.contentType
  );
  return { ...stored, audio: result.audio, contentType: result.contentType };
}

export const naturalSpeechDefaults = {
  endpoint: GEMINI_INTERACTIONS_URL,
  model: DEFAULT_MODEL,
  voice: DEFAULT_VOICE,
  sampleRate: SAMPLE_RATE,
} as const;
