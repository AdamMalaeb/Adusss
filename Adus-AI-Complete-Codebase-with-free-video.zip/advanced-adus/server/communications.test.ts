import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getRecord: vi.fn(),
  listRecords: vi.fn(),
  saveRecord: vi.fn(),
  compareAndSwapRecord: vi.fn(),
  invokeLLM: vi.fn(),
  verifySmtpCredentials: vi.fn(),
  transportForCredentials: vi.fn(),
  sendSingleMessage: vi.fn(),
}));

vi.mock("./workspaceStore", () => ({
  getRecord: mocks.getRecord,
  listRecords: mocks.listRecords,
  saveRecord: mocks.saveRecord,
  compareAndSwapRecord: mocks.compareAndSwapRecord,
}));
vi.mock("./_core/llm", async importOriginal => ({
  ...(await importOriginal<typeof import("./_core/llm")>()),
  invokeLLM: mocks.invokeLLM,
}));
vi.mock("./communicationsEmail", async importOriginal => ({
  ...(await importOriginal<typeof import("./communicationsEmail")>()),
  verifySmtpCredentials: mocks.verifySmtpCredentials,
  transportForCredentials: mocks.transportForCredentials,
  sendSingleMessage: mocks.sendSingleMessage,
}));

import { communicationsRouter } from "./communicationsRouter";
import {
  decryptCredentials,
  encryptCredentials,
  assertPublicHost,
} from "./communicationsEmail";
import {
  extractPublicEmails,
  extractSearchResults,
} from "./communicationsContacts";

function caller(userId = 1) {
  return communicationsRouter.createCaller({
    user: {
      id: userId,
      openId: `user-${userId}`,
      email: `user-${userId}@example.test`,
      name: "Test User",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}
function unauthenticatedCaller() {
  return communicationsRouter.createCaller({
    user: null,
    req: { headers: {} },
    res: {},
  } as TrpcContext);
}
const mailbox = {
  type: "mailbox" as const,
  status: "connected" as const,
  encryptedCredentials: "ciphertext",
  host: "smtp.public.test",
  port: 587,
  email: "owner@public.test",
  username: "owner@public.test",
  secure: false,
  verifiedAt: 1,
  verifiedAliases: [],
};

describe("communications security helpers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.JWT_SECRET = "test-secret-long-enough-for-encryption";
  });
  it("encrypts credentials and never exposes plaintext in the encrypted record", () => {
    const encrypted = encryptCredentials({
      host: "smtp.public.test",
      port: 587,
      email: "owner@public.test",
      username: "owner@public.test",
      password: "super-secret-app-password",
      secure: false,
    });
    expect(encrypted).not.toContain("super-secret-app-password");
    expect(decryptCredentials(encrypted)).toMatchObject({
      password: "super-secret-app-password",
    });
  });
  it.each([
    "127.0.0.1",
    "10.0.0.1",
    "169.254.169.254",
    "localhost",
    "metadata.google.internal",
  ])("rejects private or metadata SMTP target %s", async host => {
    await expect(assertPublicHost(host)).rejects.toThrow(
      /public|private|reserved/i
    );
  });
  it("extracts only literal emails and ignores placeholders", () => {
    expect(
      extractPublicEmails(
        "Contact Alice@Public.org or hello@example.com; never infer first.last@domain.test"
      )
    ).toEqual(["alice@public.org", "first.last@domain.test"]);
  });
  it("does not accept search-engine links as contact sources", () => {
    const results = extractSearchResults(
      '<a class="result__a" href="//duckduckgo.com/?q=internal">Internal</a>' +
        '<a class="result__a" href="https://example.org/contact">Public</a>'
    );
    expect(results).toEqual([
      { url: "https://example.org/contact", title: "Public", snippet: "" },
    ]);
  });
});

describe("communications protected procedures", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.getRecord.mockResolvedValue(undefined);
    mocks.compareAndSwapRecord.mockResolvedValue(true);
    mocks.listRecords.mockResolvedValue([]);
    mocks.saveRecord.mockImplementation(
      async (
        _userId: number,
        _kind: string,
        payload: unknown,
        id = "saved"
      ) => ({ id, payload })
    );
  });
  it("requires authentication for mailbox and draft mutations", async () => {
    await expect(
      unauthenticatedCaller().mailbox.status()
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(
      unauthenticatedCaller().drafts.save({
        title: "Draft",
        objective: "Objective",
        subject: "Hello",
        body: "Body",
        sources: [],
      })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("persists a draft scoped to the authenticated user and never sends it", async () => {
    const result = await caller(42).drafts.save({
      title: "Reviewed outreach",
      objective: "Request a meeting",
      recipientEmail: "person@public.test",
      subject: "A reviewed subject",
      body: "A reviewed body",
      sources: [{ url: "https://public.test/contact", title: "Contact" }],
    });
    expect(result).toMatchObject({ subject: "A reviewed subject" });
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      42,
      "communicationsDraft",
      expect.objectContaining({ body: "A reviewed body" }),
      expect.any(String)
    );
    expect(mocks.sendSingleMessage).not.toHaveBeenCalled();
  });
  it("requires an exact mailbox sender and rejects sender spoofing", async () => {
    mocks.getRecord.mockResolvedValue({ id: "mailbox", payload: mailbox });
    await expect(
      caller(7).campaigns.create({
        title: "Spoof attempt",
        from: "other@public.test",
        subject: "Subject",
        text: "Body",
        recipients: [{ email: "recipient@public.test" }],
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mocks.saveRecord).not.toHaveBeenCalled();
  });
  it("does not send if another server wins the durable delivery claim", async () => {
    const credentials = encryptCredentials({
      host: "smtp.public.test",
      port: 587,
      email: "owner@public.test",
      username: "owner@public.test",
      password: "secret",
      secure: false,
    });
    mocks.getRecord.mockImplementation(async (_userId, kind, id) => ({
      id,
      payload:
        kind === "communicationsMailbox"
          ? { ...mailbox, encryptedCredentials: credentials }
          : {
              type: "campaign",
              title: "QA",
              from: "owner@public.test",
              subject: "QA",
              text: "Body",
              status: "review",
              recipients: [
                { id: "one", email: "one@public.test", status: "pending" },
              ],
            },
    }));
    mocks.compareAndSwapRecord.mockResolvedValue(false);
    await expect(
      caller(5).campaigns.send({
        id: "11111111-1111-4111-8111-111111111111",
        confirmed: true,
      })
    ).rejects.toMatchObject({ code: "CONFLICT" });
    expect(mocks.sendSingleMessage).not.toHaveBeenCalled();
    expect(mocks.transportForCredentials).not.toHaveBeenCalled();
  });
  it("uses a distinct mailbox record for each account and exposes no password", async () => {
    const input = {
      host: "smtp.public.test",
      port: 587,
      email: "owner@public.test",
      username: "owner@public.test",
      password: "secret",
      secure: false,
    };
    mocks.verifySmtpCredentials.mockResolvedValue(input);
    const result = await caller(42).mailbox.connect(input);
    expect(mocks.saveRecord).toHaveBeenCalledWith(
      42,
      "communicationsMailbox",
      expect.objectContaining({ encryptedCredentials: expect.any(String) }),
      "mailbox-42"
    );
    expect(JSON.stringify(result)).not.toContain("secret");
    expect(result).not.toHaveProperty("encryptedCredentials");
  });
  it("sends each recipient separately and skips already-sent recipients on retry", async () => {
    const encryptedCredentials = encryptCredentials({
      host: "smtp.public.test",
      port: 587,
      email: "owner@public.test",
      username: "owner@public.test",
      password: "secret",
      secure: false,
    });
    mocks.getRecord.mockImplementation(
      async (_userId: number, kind: string, id?: string) => {
        if (kind === "communicationsMailbox")
          return {
            id: "mailbox",
            payload: { ...mailbox, encryptedCredentials },
          };
        if (kind === "communicationsCampaign") {
          return {
            id,
            payload: {
              type: "campaign",
              title: "Campaign",
              from: "owner@public.test",
              subject: "Subject",
              text: "Body",
              status: "review",
              createdAt: 1,
              updatedAt: 1,
              recipients: [
                {
                  id: "one",
                  email: "one@public.test",
                  status: "sent",
                  sentAt: 2,
                },
                { id: "two", email: "two@public.test", status: "pending" },
              ],
            },
          };
        }
        return undefined;
      }
    );
    mocks.verifySmtpCredentials.mockResolvedValue({
      host: "smtp.public.test",
      port: 587,
      email: "owner@public.test",
      username: "owner@public.test",
      password: "secret",
      secure: false,
    });
    mocks.transportForCredentials.mockReturnValue({ close: vi.fn() });
    mocks.sendSingleMessage.mockResolvedValue({ messageId: "id" });
    const result = await caller(5).campaigns.send({
      id: "11111111-1111-4111-8111-111111111111",
      confirmed: true,
    });
    expect(result.recipients).toHaveLength(2);
    expect(mocks.sendSingleMessage).toHaveBeenCalledTimes(1);
    expect(mocks.sendSingleMessage).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ to: "two@public.test" })
    );
    expect(mocks.sendSingleMessage).not.toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ to: "one@public.test" })
    );
  });
});
