import { and, desc, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { getDb } from "./db";
import { workspaceRecords } from "../drizzle/schema";
import { TRPCError } from "@trpc/server";
export async function saveRecord(
  userId: number,
  kind: string,
  payload: unknown,
  id: string = randomUUID()
) {
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "SERVICE_UNAVAILABLE",
      message: "Workspace storage is unavailable. Please try again.",
    });
  const existing = await getRecord(userId, kind, id);
  if (existing) {
    await db
      .update(workspaceRecords)
      .set({ payload: JSON.stringify(payload), updatedAt: Date.now() })
      .where(
        and(
          eq(workspaceRecords.id, id),
          eq(workspaceRecords.userId, userId),
          eq(workspaceRecords.kind, kind)
        )
      );
  } else {
    await db.insert(workspaceRecords).values({
      id,
      userId,
      kind,
      payload: JSON.stringify(payload),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  }
  return (await getRecord(userId, kind, id))!;
}
export async function getRecord(userId: number, kind: string, id: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(workspaceRecords)
    .where(
      and(
        eq(workspaceRecords.id, id),
        eq(workspaceRecords.userId, userId),
        eq(workspaceRecords.kind, kind)
      )
    )
    .limit(1);
  return rows[0]
    ? {
        id: rows[0].id,
        payload: JSON.parse(rows[0].payload) as any,
        createdAt: rows[0].createdAt,
        updatedAt: rows[0].updatedAt,
      }
    : undefined;
}
/** Compare-and-swap a durable payload; only one server can claim a send. */
export async function compareAndSwapRecord(
  userId: number,
  kind: string,
  id: string,
  expected: unknown,
  next: unknown
) {
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "SERVICE_UNAVAILABLE",
      message: "Workspace storage is unavailable.",
    });
  const result = await db
    .update(workspaceRecords)
    .set({ payload: JSON.stringify(next), updatedAt: Date.now() })
    .where(
      and(
        eq(workspaceRecords.id, id),
        eq(workspaceRecords.userId, userId),
        eq(workspaceRecords.kind, kind),
        eq(workspaceRecords.payload, JSON.stringify(expected))
      )
    );
  return result[0].affectedRows === 1;
}
export async function listRecords(userId: number, kind: string, limit = 30) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(workspaceRecords)
    .where(
      and(eq(workspaceRecords.userId, userId), eq(workspaceRecords.kind, kind))
    )
    .orderBy(desc(workspaceRecords.updatedAt))
    .limit(Math.min(10000, Math.max(1, limit)));
  return rows.map(row => ({
    id: row.id,
    payload: JSON.parse(row.payload) as any,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  }));
}
