import { describe, expect, it, vi } from "vitest";
import { z } from "zod";
import {
  applySourceProposal,
  buildExactUnifiedDiff,
  getSourceUpgradeConfig,
  getSourceUpgradeConfigStatus,
  GitHubSourceClient,
  isAllowedSourcePath,
  isSourceUpgradeOwner,
  parseStructuredJson,
  parseGitHubRepository,
  validateSourceModelProposal,
  type SourceUpgradeConfig,
} from "./sourceUpgrade";

const configured: SourceUpgradeConfig = {
  rawRepository: "owner/private-adus",
  repository: {
    owner: "owner",
    name: "private-adus",
    slug: "owner/private-adus",
  },
  token: "server-only-test-token",
  baseBranch: "main",
};

const snapshot = {
  repository: "owner/private-adus",
  baseBranch: "main",
  baseCommit: "a".repeat(40),
  files: [
    {
      path: "client/src/example.tsx",
      content: "export const value = 1;\n",
      sha: "b".repeat(40),
      size: 25,
    },
  ],
  knownPaths: new Set(["client/src/example.tsx"]),
};

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

describe("source upgrade safety boundaries", () => {
  it("parses only GitHub owner/repository values", () => {
    expect(
      parseGitHubRepository("https://github.com/owner/private-adus.git")
    ).toEqual({
      owner: "owner",
      name: "private-adus",
      slug: "owner/private-adus",
    });
    expect(parseGitHubRepository("github.com/owner/private-adus")).toBeNull();
    expect(parseGitHubRepository("owner/private adus")).toBeNull();
  });

  it("reports missing deployment settings without claiming connectivity", () => {
    const config = getSourceUpgradeConfig({
      ADUS_SOURCE_REPO: "",
      ADUS_GITHUB_TOKEN: "",
    });
    const status = getSourceUpgradeConfigStatus(config);
    expect(status.configured).toBe(false);
    expect(status.missing).toEqual(["ADUS_SOURCE_REPO", "GITHUB_SOURCE_TOKEN"]);
    expect(status.message).toContain("no source mutation is attempted");
  });

  it("prefers the canonical source token while accepting the migration alias", () => {
    expect(
      getSourceUpgradeConfig({
        ADUS_SOURCE_REPO: "owner/private-adus",
        GITHUB_SOURCE_TOKEN: "canonical",
        ADUS_GITHUB_TOKEN: "legacy",
      }).token
    ).toBe("canonical");
    expect(
      getSourceUpgradeConfig({
        ADUS_SOURCE_REPO: "owner/private-adus",
        ADUS_GITHUB_TOKEN: "legacy",
      }).token
    ).toBe("legacy");
  });

  it("repairs fenced or lightly malformed JSON and still enforces the schema", () => {
    const schema = z.object({
      title: z.string(),
      changedFiles: z.array(z.string()),
    });
    expect(
      parseStructuredJson(
        '```json\n{"title":"Draft","changedFiles":["server/a.ts",]}\n```',
        schema,
        "Test proposal"
      )
    ).toEqual({ title: "Draft", changedFiles: ["server/a.ts"] });
    expect(() => parseStructuredJson("{}", schema, "Test proposal")).toThrow(
      "did not match the required schema"
    );
  });

  it("allows bounded application source but rejects control-plane and secret paths", () => {
    expect(isAllowedSourcePath("client/src/pages/Home.tsx")).toBe(true);
    expect(isAllowedSourcePath("server/feature.ts")).toBe(true);
    expect(isAllowedSourcePath(".env")).toBe(false);
    expect(isAllowedSourcePath(".github/workflows/ci.yml")).toBe(false);
    expect(isAllowedSourcePath("server/_core/context.ts")).toBe(false);
    expect(isAllowedSourcePath("server/upgradeRouter.ts")).toBe(false);
    expect(isAllowedSourcePath("server/workspaceExtensions.ts")).toBe(false);
    expect(isAllowedSourcePath("client/src/pages/Upgrade.tsx")).toBe(false);
    expect(isAllowedSourcePath("client/src/pages/WorkspaceExtension.tsx")).toBe(
      false
    );
    expect(
      isAllowedSourcePath("client/src/components/DashboardLayout.tsx")
    ).toBe(false);
    expect(isAllowedSourcePath("client/src/App.tsx")).toBe(false);
    expect(isAllowedSourcePath("client/src/../../.env")).toBe(false);
    expect(isAllowedSourcePath("package.json")).toBe(true);
    expect(isAllowedSourcePath("pnpm-lock.yaml")).toBe(false);
  });

  it("accepts only the authenticated owner email, not roles or legacy open ids", () => {
    expect(
      isSourceUpgradeOwner({ email: "adammalaeb30@gmail.com", role: "user" })
    ).toBe(true);
    expect(isSourceUpgradeOwner({ email: " ADAMMALAEB30@GMAIL.COM " })).toBe(
      true
    );
    expect(
      isSourceUpgradeOwner(
        { role: "admin", openId: "owner-open-id" },
        "owner-open-id"
      )
    ).toBe(false);
    expect(
      isSourceUpgradeOwner({ email: "malaebadam8@gmail.com", role: "admin" })
    ).toBe(false);
    expect(isSourceUpgradeOwner({ email: "another@example.com" })).toBe(false);
  });

  it("produces an exact reviewable replacement diff and rejects files outside the snapshot", () => {
    const proposal = validateSourceModelProposal(
      {
        title: "Update example",
        summary: "Make the example value two.",
        changedFiles: [
          {
            path: "client/src/example.tsx",
            content: "export const value = 2;\n",
            reason: "Updates the example value.",
          },
        ],
        tests: ["Run the focused regression test."],
      },
      snapshot
    );
    expect(proposal.changedFiles[0]?.diff).toBe(
      buildExactUnifiedDiff(
        "client/src/example.tsx",
        "export const value = 1;\n",
        "export const value = 2;\n"
      )
    );
    expect(() =>
      validateSourceModelProposal(
        {
          title: "Out of scope",
          summary: "No.",
          changedFiles: [
            {
              path: "client/src/existing-unread.ts",
              content: "export const x = 1;",
              reason: "Existing unread file.",
            },
          ],
          tests: [],
        },
        {
          ...snapshot,
          knownPaths: new Set([
            ...snapshot.knownPaths,
            "client/src/existing-unread.ts",
          ]),
        }
      )
    ).toThrow("outside the bounded snapshot");
  });
  it("allows a reviewed new specialist agent module with complete contents", () => {
    const result = validateSourceModelProposal(
      {
        title: "Add teaching agent",
        summary: "A new bot specialist module.",
        changedFiles: [
          {
            path: "server/agents/teachingAgent.ts",
            content: "export const teachingAgent = {name: 'Teacher'};\n",
            reason: "Adds a new specialist agent.",
          },
        ],
        tests: ["Run focused agent tests."],
      },
      snapshot
    );
    expect(result.changedFiles[0].originalContent).toBe("");
    expect(result.changedFiles[0].diff).toContain(
      "+export const teachingAgent"
    );
  });

  it("allows only dependency fields when a reviewed package manifest is in the snapshot", () => {
    const original = JSON.stringify({
      name: "adus",
      scripts: { test: "vitest run" },
      dependencies: { react: "19.0.0" },
    });
    const packageSnapshot = {
      ...snapshot,
      files: [
        ...snapshot.files,
        {
          path: "package.json",
          content: original,
          sha: "c".repeat(40),
          size: original.length,
        },
      ],
      knownPaths: new Set([...snapshot.knownPaths, "package.json"]),
    };
    const updated = JSON.stringify({
      name: "adus",
      scripts: { test: "vitest run" },
      dependencies: { react: "19.0.0", zod: "4.1.12" },
    });
    expect(
      validateSourceModelProposal(
        {
          title: "Add safe parser dependency",
          summary: "Add a runtime dependency used by the feature.",
          changedFiles: [
            {
              path: "package.json",
              content: updated,
              reason: "Adds the reviewed dependency.",
            },
          ],
          tests: ["Run focused tests."],
        },
        packageSnapshot
      ).changedFiles[0]?.path
    ).toBe("package.json");
    expect(() =>
      validateSourceModelProposal(
        {
          title: "Unsafe manifest change",
          summary: "Changes a script.",
          changedFiles: [
            {
              path: "package.json",
              content: JSON.stringify({
                name: "adus",
                scripts: { test: "rm -rf /" },
                dependencies: { react: "19.0.0" },
              }),
              reason: "Changes scripts.",
            },
          ],
          tests: [],
        },
        packageSnapshot
      )
    ).toThrow("limited to dependencies");
  });
});

describe("GitHub source client API contract", () => {
  it("uses server authorization and real Git database/PR endpoint shapes", async () => {
    const calls: Array<{ url: string; init: RequestInit }> = [];
    const responses: Record<string, unknown> = {
      "/repos/owner/private-adus": {
        full_name: "owner/private-adus",
        private: true,
        default_branch: "main",
      },
      "/repos/owner/private-adus/git/ref/heads/main": {
        object: { sha: "a".repeat(40), type: "commit" },
      },
      "/repos/owner/private-adus/git/commits/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa":
        {
          sha: "a".repeat(40),
          tree: { sha: "c".repeat(40) },
        },
      "/repos/owner/private-adus/git/commits": { sha: "f".repeat(40) },
      "/repos/owner/private-adus/git/blobs": { sha: "d".repeat(40) },
      "/repos/owner/private-adus/git/trees": { sha: "e".repeat(40) },
      "/repos/owner/private-adus/git/refs": { sha: "f".repeat(40) },
      "/repos/owner/private-adus/pulls": {
        number: 7,
        html_url: "https://github.com/owner/private-adus/pull/7",
        draft: true,
      },
      "/repos/owner/private-adus/commits/ffffffffffffffffffffffffffffffffffffffff/check-runs":
        {
          total_count: 1,
          check_runs: [
            {
              name: "CI",
              status: "completed",
              conclusion: "success",
              html_url: "https://github.com/owner/private-adus/actions/runs/1",
            },
          ],
        },
    };
    const fetchMock = vi.fn(async (url: string, init: RequestInit = {}) => {
      calls.push({ url, init });
      const path = new URL(url).pathname;
      return jsonResponse(responses[path] ?? {}, 200);
    });
    const client = new GitHubSourceClient(
      configured,
      fetchMock as typeof fetch
    );
    const result = await applySourceProposal(
      {
        title: "Update example",
        summary: "Make the example value two.",
        changedFiles: [
          {
            path: "client/src/example.tsx",
            content: "export const value = 2;\n",
            reason: "Updates the example value.",
            originalContent: "export const value = 1;\n",
            diff: "--- a/client/src/example.tsx\n+++ b/client/src/example.tsx",
          },
        ],
        tests: ["Run CI."],
        baseCommit: "a".repeat(40),
        baseBranch: "main",
        repository: "owner/private-adus",
      },
      configured,
      { client, id: "proposal-1", now: () => 1_700_000_000_000 }
    );
    expect(result).toMatchObject({
      branch: "adus/upgrade/1700000000000-proposal-1",
      commitSha: "f".repeat(40),
      pullRequestNumber: 7,
      pullRequestUrl: "https://github.com/owner/private-adus/pull/7",
      draft: true,
      ci: { status: "passed" },
    });
    expect(fetchMock).toHaveBeenCalled();
    const authHeader =
      calls[0]?.init.headers instanceof Headers
        ? calls[0].init.headers.get("authorization")
        : undefined;
    expect(authHeader).toBe("Bearer server-only-test-token");
    const prCall = calls.find(call => call.url.endsWith("/pulls"));
    expect(JSON.parse(String(prCall?.init.body))).toMatchObject({
      draft: true,
      base: "main",
      head: "adus/upgrade/1700000000000-proposal-1",
    });
  });

  it("rejects a stale base commit before creating any write request", async () => {
    const methods: string[] = [];
    const fetchMock = vi.fn(async (url: string, init: RequestInit = {}) => {
      methods.push(init.method ?? "GET");
      const path = new URL(url).pathname;
      if (path === "/repos/owner/private-adus")
        return jsonResponse({
          full_name: "owner/private-adus",
          private: true,
          default_branch: "main",
        });
      if (path.endsWith("/git/ref/heads/main"))
        return jsonResponse({ object: { sha: "9".repeat(40) } });
      return jsonResponse({});
    });
    const client = new GitHubSourceClient(
      configured,
      fetchMock as typeof fetch
    );
    await expect(
      applySourceProposal(
        {
          title: "Stale",
          summary: "Stale proposal.",
          changedFiles: [
            {
              path: "client/src/example.tsx",
              content: "export const value = 2;",
              reason: "Change.",
              originalContent: "export const value = 1;",
              diff: "diff",
            },
          ],
          tests: [],
          baseCommit: "a".repeat(40),
          baseBranch: "main",
          repository: "owner/private-adus",
        },
        configured,
        { client }
      )
    ).rejects.toThrow("base branch changed");
    expect(methods).toEqual(["GET", "GET"]);
    expect(methods.some(method => method === "POST")).toBe(false);
  });
});

describe("optional live source repository validation", () => {
  it.skipIf(process.env.ADUS_SOURCE_UPGRADE_LIVE_TEST !== "1")(
    "reads the configured private repository without mutating it",
    async () => {
      const config = getSourceUpgradeConfig();
      const status = getSourceUpgradeConfigStatus(config);
      expect(status.configured).toBe(true);
      const client = new GitHubSourceClient(config);
      const repository = await client.getRepository();
      expect(repository.full_name).toBe(config.repository?.slug);
      expect(repository.private).toBe(true);
    }
  );
});
