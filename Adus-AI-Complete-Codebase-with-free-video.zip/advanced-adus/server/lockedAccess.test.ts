import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { isLockedOwner } from "../shared/accessPolicy";
import type { TrpcContext } from "./_core/context";

function caller(email: string, role = "admin") {
  return appRouter.createCaller({ user: { id: 33, email, role, openId: "previous-owner" }, req: { headers: {} }, res: {} } as TrpcContext);
}

describe("locked owner areas", () => {
  it("uses only the exact authenticated owner email", () => {
    expect(isLockedOwner({email: "adammalaeb30@gmail.com"})).toBe(true);
    expect(isLockedOwner({email: "ADAMMALAEB30@GMAIL.COM"})).toBe(true);
    expect(isLockedOwner({email: "malaebadam8@gmail.com"})).toBe(false);
    expect(isLockedOwner({email: "adammalaeb30@gmail.com.evil.test"})).toBe(false);
  });
  it.each(["malaebadam8@gmail.com", "another@example.com"])("rejects every restricted route for %s even with an admin role", async email => {
    const c = caller(email);
    await expect(c.adus.integrations.list()).rejects.toMatchObject({code: "FORBIDDEN"});
    await expect(c.adus.automations.list()).rejects.toMatchObject({code: "FORBIDDEN"});
    await expect(c.adus.videos.list()).rejects.toMatchObject({code: "FORBIDDEN"});
    await expect(c.adus.videoEdits.plan({sourceId: "test", prompt: "Mute"})).rejects.toMatchObject({code: "FORBIDDEN"});
    await expect(c.adus.upgrade.history()).rejects.toMatchObject({code: "FORBIDDEN"});
    await expect(c.adus.upgrade.propose({prompt: "Add a tab"})).rejects.toMatchObject({code: "FORBIDDEN"});
    await expect(c.adus.workspaceExtensions.propose({prompt: "Add tab named Test"})).rejects.toMatchObject({code: "FORBIDDEN"});
  });
});
