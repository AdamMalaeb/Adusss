import {
  boardDrawingPath,
  boardActionOpacity,
  BOARD_SHAPES,
} from "../shared/boardDrawing";
import { randomUUID } from "node:crypto";
import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { execFile } from "node:child_process";
import sharp from "sharp";
import { TRPCError } from "@trpc/server";
import {
  createNaturalSpeechAudio,
  type NaturalSpeechOptions,
  type NaturalSpeechLanguage,
} from "./naturalSpeech";
import { storageGetSignedUrl, storagePut } from "./storage";
import {
  buildLessonTiming,
  buildPhraseCues,
  whiteboardRevealAt,
  whiteboardErasePhase,
  boardActionProgressAt,
  type LessonBoardAction,
  type LessonBoardPoint,
  type LessonPhraseCue,
} from "../shared/lessonTiming";

export type WhiteboardLanguage = NaturalSpeechLanguage;

export type WhiteboardVisual = {
  kind?: "diagram" | "process" | "comparison" | "photo" | string;
  labels?: string[];
  imagePrompt?: string;
  sourceImageUrl?: string;
};

export type WhiteboardScene = {
  title: string;
  bullets: string[];
  narration: string;
  visual?: WhiteboardVisual;
  boardActions?: LessonBoardAction[];
};

export type WhiteboardLessonPayload = {
  title?: string;
  summary?: string;
  scenes: WhiteboardScene[];
  language: WhiteboardLanguage;
  audioURL?: string;
};

export type WhiteboardSceneTimeline = {
  index: number;
  title: string;
  narration: string;
  start: number;
  end: number;
  duration: number;
  cues: LessonPhraseCue[];
  cueAlignment: "estimated";
};

export type WhiteboardLesson = {
  audioURL: string;
  audioDuration: number;
  language: WhiteboardLanguage;
  scenes: WhiteboardSceneTimeline[];
};

export type WhiteboardLessonOptions = {
  speech?: NaturalSpeechOptions;
  /** Reuse a previously stored narration instead of generating another TTS file. */
  audioURL?: string;
};

const WIDTH = 960;
const HEIGHT = 540;
const FPS = 12;
const MIN_SCENES = 1;
const MAX_SCENES = 12;
const MAX_CHAPTER_SECONDS = 300;
const MAX_NARRATION_CHARS = 3_000;
const MAX_OUTPUT_BYTES = 40 * 1024 * 1024;
const execFileAsync = promisify(execFile);
let whiteboardBusy = false;

function badRequest(message: string): TRPCError {
  return new TRPCError({ code: "BAD_REQUEST", message });
}

function serviceUnavailable(message: string): TRPCError {
  return new TRPCError({ code: "SERVICE_UNAVAILABLE", message });
}

function normalizeScenes(payload: WhiteboardLessonPayload): WhiteboardScene[] {
  if (!payload || !Array.isArray(payload.scenes))
    throw badRequest("A whiteboard lesson must contain scenes.");
  if (payload.scenes.length < MIN_SCENES || payload.scenes.length > MAX_SCENES)
    throw badRequest(
      `A whiteboard lesson must contain ${MIN_SCENES} to ${MAX_SCENES} scenes.`
    );
  if (!["english", "french", "arabic"].includes(payload.language))
    throw badRequest(
      "Whiteboard narration language must be English, French, or Arabic."
    );
  return payload.scenes.map((source, index) => {
    if (!source || typeof source !== "object")
      throw badRequest(`Scene ${index + 1} is malformed.`);
    const title =
      typeof source.title === "string"
        ? source.title.replace(/\s+/g, " ").trim()
        : "";
    const narration =
      typeof source.narration === "string"
        ? source.narration.replace(/\s+/g, " ").trim()
        : "";
    if (!title) throw badRequest(`Scene ${index + 1} needs a title.`);
    if (!narration)
      throw badRequest(`Scene ${index + 1} needs complete narration.`);
    if (narration.length > MAX_NARRATION_CHARS)
      throw badRequest(
        `Scene ${index + 1} narration is ${MAX_NARRATION_CHARS} characters maximum.`
      );
    if (
      !Array.isArray(source.bullets) ||
      source.bullets.some(bullet => typeof bullet !== "string")
    )
      throw badRequest(`Scene ${index + 1} bullets are malformed.`);
    const visual =
      source.visual && typeof source.visual === "object"
        ? source.visual
        : undefined;
    return {
      title,
      narration,
      bullets: source.bullets
        .map(bullet => bullet.replace(/\s+/g, " ").trim())
        .filter(Boolean)
        .slice(0, 8),
      visual: visual
        ? {
            kind: typeof visual.kind === "string" ? visual.kind : "process",
            labels: Array.isArray(visual.labels)
              ? visual.labels
                  .filter((label): label is string => typeof label === "string")
                  .map(label => label.trim())
                  .filter(Boolean)
                  .slice(0, 6)
              : [],
            imagePrompt:
              typeof visual.imagePrompt === "string"
                ? visual.imagePrompt
                : undefined,
            sourceImageUrl:
              typeof visual.sourceImageUrl === "string"
                ? visual.sourceImageUrl
                : undefined,
          }
        : undefined,
      boardActions: normalizeBoardActions(source.boardActions),
    };
  });
}

/** Estimate timeline boundaries from narration, then normalize to real WAV duration. */
export function buildWhiteboardTimelines(
  scenes: WhiteboardScene[],
  audioDuration: number
): WhiteboardSceneTimeline[] {
  return buildLessonTiming(scenes, audioDuration).map(item => ({
    index: item.index,
    title: item.title,
    narration: item.narration,
    start: item.start,
    end: item.end,
    duration: item.duration,
    cues: item.cues,
    cueAlignment: item.cueAlignment,
  }));
}

function wavDuration(bytes: Buffer): number {
  if (bytes.length >= 44 && bytes.subarray(0, 4).toString("ascii") === "RIFF") {
    const byteRate = bytes.readUInt32LE(28);
    const dataSize = bytes.readUInt32LE(40);
    if (byteRate > 0 && dataSize > 0) return dataSize / byteRate;
  }
  // A guarded fallback for unusual WAV containers; audio is still not fabricated.
  return Math.max(0.1, bytes.length / (24_000 * 2));
}

async function loadStoredNarration(audioURL: string): Promise<Buffer> {
  const source = audioURL.trim();
  if (!source) throw badRequest("Saved narration URL cannot be empty.");
  let downloadURL = source;
  if (source.startsWith("/manus-storage/")) {
    const key = decodeURIComponent(source.slice("/manus-storage/".length));
    downloadURL = await storageGetSignedUrl(key);
  }
  let response: Response;
  try {
    response = await fetch(downloadURL, {
      signal: AbortSignal.timeout(120_000),
    });
  } catch {
    throw serviceUnavailable(
      "Saved narration could not be reached. Your chapter is saved; retry the video export."
    );
  }
  if (!response.ok)
    throw serviceUnavailable(
      "Saved narration could not be downloaded. Your chapter is saved; retry the video export."
    );
  const bytes = Buffer.from(await response.arrayBuffer());
  if (!bytes.length)
    throw serviceUnavailable(
      "Saved narration was empty; retry the video export."
    );
  return bytes;
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function wrapText(value: string, width: number): string[] {
  const words = value.trim().split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (line && next.length > width) {
      lines.push(line);
      line = word;
    } else line = next;
  }
  if (line) lines.push(line);
  return lines.length ? lines : [" "];
}

function clampUnit(value: number): number {
  return Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0.5));
}

function boardPoint(
  value: unknown,
  fallback: LessonBoardPoint
): LessonBoardPoint {
  if (!value || typeof value !== "object") return fallback;
  const point = value as Partial<LessonBoardPoint>;
  return {
    x: clampUnit(typeof point.x === "number" ? point.x : fallback.x),
    y: clampUnit(typeof point.y === "number" ? point.y : fallback.y),
  };
}

function normalizeBoardActions(value: unknown): LessonBoardAction[] {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 8).flatMap(item => {
    if (!item || typeof item !== "object") return [];
    const source = item as Record<string, unknown>;
    const type = source.type;
    if (
      type !== "write" &&
      type !== "draw" &&
      type !== "link" &&
      type !== "highlight" &&
      type !== "erase"
    )
      return [];
    const text = typeof source.text === "string" ? source.text.trim() : "";
    const target =
      typeof source.target === "string" ? source.target.trim() : "";
    return [
      {
        type,
        ...(BOARD_SHAPES.includes(source.shape as any)
          ? { shape: source.shape as LessonBoardAction["shape"] }
          : {}),
        ...(text ? { text: text.slice(0, 180) } : {}),
        ...(target ? { target: target.slice(0, 180) } : {}),
        ...(source.from
          ? { from: boardPoint(source.from, { x: 0.15, y: 0.48 }) }
          : {}),
        ...(source.to
          ? { to: boardPoint(source.to, { x: 0.78, y: 0.48 }) }
          : {}),
        ...(source.emphasis === "accent" || source.emphasis === "warning"
          ? { emphasis: source.emphasis }
          : {}),
      },
    ];
  });
}

function sourceLabels(scene: WhiteboardScene): string[] {
  const labels = scene.visual?.labels?.filter(Boolean).slice(0, 5) ?? [];
  return Array.from(new Set([...labels, ...scene.bullets])).slice(0, 5);
}

function drawBoardContent(scene: WhiteboardScene, reveal: number): string {
  const clamped = Math.max(0, Math.min(1, reveal));
  const titleOpacity = Math.min(1, clamped * 3.2);
  const labels = scene.boardActions?.length ? [] : sourceLabels(scene);
  const kind = scene.visual?.kind === "comparison" ? "comparison" : "diagram";
  const titleLines = wrapText(scene.title, 29).slice(0, 2);
  const title = titleLines
    .map(
      (line, lineIndex) =>
        `<text x="78" y="${106 + lineIndex * 39}" class="handTitle" opacity="${titleOpacity.toFixed(3)}">${escapeXml(line)}</text>`
    )
    .join("");
  const visibleCount = Math.min(
    labels.length,
    Math.max(0, Math.ceil(clamped * Math.max(1, labels.length)))
  );
  const items = labels.slice(0, visibleCount);
  const nodeWidth = kind === "comparison" ? 300 : 132;
  const gap = kind === "comparison" ? 76 : 18;
  const startX = kind === "comparison" ? 90 : 80;
  const y = 240;
  const nodes = items
    .map((label, index) => {
      const x =
        kind === "comparison"
          ? startX + index * (nodeWidth + gap)
          : startX + index * (nodeWidth + gap);
      const lines = wrapText(label, kind === "comparison" ? 24 : 14).slice(
        0,
        3
      );
      const text = lines
        .map(
          (line, lineIndex) =>
            `<text x="${x + nodeWidth / 2}" y="${y + 49 + lineIndex * 24}" text-anchor="middle" class="handText">${escapeXml(line)}</text>`
        )
        .join("");
      return `<g opacity="${Math.min(1, clamped * 4).toFixed(3)}"><rect x="${x}" y="${y}" width="${nodeWidth}" height="118" rx="12" class="boardNode"/><text x="${x + 18}" y="${y + 27}" class="nodeNumber">${index + 1}</text>${text}</g>`;
    })
    .join("");
  const arrows =
    scene.visual?.kind !== "process"
      ? ""
      : items
          .slice(1)
          .map((_, index) => {
            const x1 = startX + index * (nodeWidth + gap) + nodeWidth + 3;
            const x2 = x1 + gap - 6;
            return `<path d="M ${x1} ${y + 59} L ${x2} ${y + 59}" class="boardArrow" marker-end="url(#arrow)" opacity="${Math.min(1, clamped * 4).toFixed(3)}"/>`;
          })
          .join("");
  const compare =
    kind === "comparison" && items.length > 1
      ? `<text x="480" y="310" class="versus">VS</text>`
      : "";
  const bullet = scene.bullets.length
    ? `<text x="80" y="410" class="boardCaption" opacity="${Math.min(1, Math.max(0, clamped - 0.55) * 3).toFixed(3)}">${escapeXml(wrapText(scene.bullets[0]!, 54)[0] ?? "")}</text>`
    : "";
  return `${title}<text x="80" y="185" class="boardEyebrow" opacity="${titleOpacity.toFixed(3)}">${kind === "comparison" ? "COMPARE" : "CONNECT THE IDEAS"}</text>${arrows}${nodes}${compare}${bullet}`;
}

function boardActionMarkup(
  action: LessonBoardAction,
  progress: number,
  index: number
): string {
  const from = action.from ?? { x: 0.15, y: 0.48 };
  const to = action.to ?? { x: 0.78, y: 0.48 };
  const x = 80 + clampUnit(from.x) * 650;
  const y = 112 + clampUnit(from.y) * 290;
  const tx = 80 + clampUnit(to.x) * 650;
  const ty = 112 + clampUnit(to.y) * 290;
  const color =
    action.emphasis === "warning"
      ? "#c94d3d"
      : action.emphasis === "accent"
        ? "#2b8b73"
        : "#173f55";
  const label = action.text || action.target || "";
  const shown = label
    ? escapeXml(label.slice(0, Math.max(1, Math.ceil(label.length * progress))))
    : "";
  const opacity = Math.max(0.12, Math.min(1, progress));
  if (action.type === "draw" || action.type === "link") {
    return `<path d="${boardDrawingPath(action)}" pathLength="100" class="boardActionPath ${action.type === "link" ? "boardActionLink" : ""}" stroke="${color}" stroke-dasharray="100" stroke-dashoffset="${Math.round((1 - progress) * 100)}" opacity="${opacity.toFixed(3)}" marker-end="${action.type === "link" ? "url(#arrow)" : "none"}" data-action-index="${index}"/>${shown ? `<text x="${tx.toFixed(1)}" y="${(ty - 10).toFixed(1)}" class="boardActionText" fill="${color}" opacity="${opacity.toFixed(3)}">${shown}</text>` : ""}`;
  }
  if (action.type === "erase") {
    return `<path d="M ${x.toFixed(1)} ${y.toFixed(1)} L ${tx.toFixed(1)} ${ty.toFixed(1)}" class="actionErase" opacity="${opacity.toFixed(3)}" stroke-dasharray="18 10" stroke-dashoffset="${Math.round((1 - progress) * 140)}" data-action-index="${index}"/>`;
  }
  if (action.type === "highlight") {
    const width = Math.max(86, Math.min(420, (label.length + 4) * 12));
    return `<rect x="${(x - 10).toFixed(1)}" y="${(y - 29).toFixed(1)}" width="${width}" height="42" rx="9" class="actionHighlight" opacity="${(opacity * 0.72).toFixed(3)}" data-action-index="${index}"/><text x="${x.toFixed(1)}" y="${y.toFixed(1)}" class="boardActionText" fill="${color}" opacity="${opacity.toFixed(3)}">${shown}</text>`;
  }
  return `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" class="boardActionText" fill="${color}" opacity="${opacity.toFixed(3)}" data-action-index="${index}">${shown}</text>`;
}

function drawBoardActions(scene: WhiteboardScene, reveal: number): string {
  const actions = normalizeBoardActions(scene.boardActions);
  const state = boardActionProgressAt(actions, reveal);
  return actions
    .slice(0, state.visibleCount)
    .map(
      (action, index) =>
        `<g opacity="${boardActionOpacity(actions, index, reveal)}">` +
        boardActionMarkup(
          action,
          index === state.activeIndex ? state.activeProgress : 1,
          index
        ) +
        "</g>"
    )
    .join("");
}

function teacherMarkup(
  markerX: number,
  markerY: number,
  opacity: number,
  erasing: boolean
): string {
  const safeOpacity = Math.max(0, Math.min(1, opacity));
  return `<g opacity="${safeOpacity.toFixed(3)}" class="teacher"><circle cx="846" cy="150" r="27" class="teacherHead"/><path d="M 814 150 Q 846 111 878 150" class="teacherHair"/><path d="M 846 178 C 813 181 803 220 804 278 L 880 278 C 879 220 870 181 846 178Z" class="teacherBody"/><path d="M 815 213 Q ${markerX} ${markerY} ${markerX - 10} ${markerY + 8}" class="teacherArm"/><circle cx="${markerX}" cy="${markerY}" r="12" class="markerHand"/><rect x="${markerX - 4}" y="${markerY - 25}" width="8" height="30" rx="3" class="marker" transform="rotate(-24 ${markerX} ${markerY})"/>${erasing ? `<path d="M 75 ${markerY} L 730 ${markerY}" class="eraseSweep"/>` : ""}</g>`;
}

/** Render one deterministic animated SVG frame; no image or video generation model is used. */
export function whiteboardSvg(
  scene: WhiteboardScene,
  progress: number,
  sceneIndex = 0,
  sceneCount = 1,
  cues = buildPhraseCues(scene.narration, 1)
): string {
  const p = Math.max(0, Math.min(1, progress));
  const erasePhase = whiteboardErasePhase(cues);
  const erasing = p < erasePhase;
  const reveal = whiteboardRevealAt(cues, p);
  const clearX = 80 + 650 * Math.min(1, p / erasePhase);
  const markerX = erasing ? clearX : 120 + 560 * reveal;
  const markerY = erasing ? 230 : 230 + Math.sin(reveal * Math.PI * 3) * 52;
  const contentOpacity = erasing ? 1 - p / erasePhase : 1;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${WIDTH}" height="${HEIGHT}" viewBox="0 0 ${WIDTH} ${HEIGHT}"><defs><linearGradient id="paper" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fffef7"/><stop offset="1" stop-color="#e9f2ed"/></linearGradient><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#ee6c4d"/></marker></defs><rect width="960" height="540" fill="#142b3a"/><rect x="48" y="35" width="756" height="446" rx="18" fill="url(#paper)" stroke="#b8d2cb" stroke-width="5"/><path d="M 48 86 H 804" stroke="#d7e7e0" stroke-width="2"/><text x="78" y="67" class="lessonLabel">WHITEBOARD LESSON · SCENE ${sceneIndex + 1}/${sceneCount}</text><g opacity="${contentOpacity.toFixed(3)}">${drawBoardContent(scene, reveal)}${drawBoardActions(scene, reveal)}</g>${erasing ? `<path d="M 75 212 L ${clearX} 212" stroke="#f4c95d" stroke-width="13" stroke-linecap="round" opacity=".75"/>` : ""}${teacherMarkup(markerX, markerY, p < 0.03 ? 0.5 : 1, erasing)}<text x="78" y="507" class="timelineCaption">${escapeXml(scene.title)}</text><style>.lessonLabel{font:700 13px 'DejaVu Sans',sans-serif;letter-spacing:2px;fill:#4b706c}.handTitle{font:700 34px 'Comic Sans MS','DejaVu Sans',sans-serif;fill:#173f55}.boardEyebrow{font:700 12px 'DejaVu Sans',sans-serif;letter-spacing:2px;fill:#5b8d88}.boardNode{fill:#f9fbef;stroke:#ee6c4d;stroke-width:3}.handText{font:600 17px 'Comic Sans MS','DejaVu Sans',sans-serif;fill:#183f51}.nodeNumber{font:700 14px 'DejaVu Sans',sans-serif;fill:#ee6c4d}.boardArrow{fill:none;stroke:#ee6c4d;stroke-width:4;stroke-linecap:round;stroke-dasharray:8 5}.versus{font:700 24px 'DejaVu Sans',sans-serif;fill:#ee6c4d}.boardCaption{font:600 17px 'Comic Sans MS','DejaVu Sans',sans-serif;fill:#376b62}.boardActionPath{fill:none;stroke-width:5;stroke-linecap:round}.boardActionLink{stroke-width:4}.boardActionText{font:600 18px 'Comic Sans MS','DejaVu Sans',sans-serif}.actionHighlight{fill:#f4c95d;stroke:#d39b2a;stroke-width:2}.actionErase{fill:none;stroke:#d39b2a;stroke-width:12;stroke-linecap:round}.teacherHead{fill:#f8c9a6;stroke:#7c4939;stroke-width:3}.teacherHair{fill:none;stroke:#3e2c35;stroke-width:10;stroke-linecap:round}.teacherBody{fill:#6c8cff;stroke:#2c477b;stroke-width:3}.teacherArm{fill:none;stroke:#f8c9a6;stroke-width:16;stroke-linecap:round}.markerHand{fill:#f8c9a6;stroke:#7c4939;stroke-width:2}.marker{fill:#ee6c4d;stroke:#8f3324;stroke-width:2}.eraseSweep{stroke:#f4c95d;stroke-width:8;stroke-linecap:round;stroke-dasharray:10 10}.timelineCaption{font:600 15px 'DejaVu Sans',sans-serif;fill:#a7c4c5}</style></svg>`;
}

function frameCount(duration: number): number {
  // One frame per output tick keeps the erase/write trail distributed across
  // the full measured narration duration. A fixed cap made long scenes finish
  // drawing in the first couple of seconds and then hold a static board.
  return Math.max(2, Math.ceil(duration * FPS));
}

async function renderSceneFrames(
  workdir: string,
  scene: WhiteboardScene,
  timeline: WhiteboardSceneTimeline,
  sceneIndex: number,
  sceneCount: number
): Promise<string> {
  const dir = join(workdir, `scene-${sceneIndex}`);
  await execFileAsync("mkdir", ["-p", dir]);
  const count = frameCount(timeline.duration);
  for (let frame = 0; frame < count; frame += 1) {
    const progress = count === 1 ? 1 : frame / (count - 1);
    await sharp(
      Buffer.from(
        whiteboardSvg(scene, progress, sceneIndex, sceneCount, timeline.cues)
      )
    )
      .png()
      .toFile(join(dir, `frame-${String(frame).padStart(3, "0")}.png`));
  }
  const segmentPath = join(workdir, `scene-${sceneIndex}.mp4`);
  await execFileAsync(
    "ffmpeg",
    [
      "-y",
      "-hide_banner",
      "-loglevel",
      "error",
      "-framerate",
      String(FPS),
      "-i",
      join(dir, "frame-%03d.png"),
      "-t",
      timeline.duration.toFixed(3),
      "-c:v",
      "libx264",
      "-preset",
      "ultrafast",
      "-pix_fmt",
      "yuv420p",
      "-r",
      String(FPS),
      "-threads",
      "1",
      segmentPath,
    ],
    { maxBuffer: 64 * 1024 }
  );
  return segmentPath;
}

async function concatVideo(
  workdir: string,
  segments: string[],
  outputPath: string
): Promise<void> {
  const list = join(workdir, "segments.txt");
  await writeFile(
    list,
    segments
      .map(segment => `file '${segment.replace(/'/g, "'\\''")}'`)
      .join("\n") + "\n",
    "utf8"
  );
  await execFileAsync(
    "ffmpeg",
    [
      "-y",
      "-hide_banner",
      "-loglevel",
      "error",
      "-f",
      "concat",
      "-safe",
      "0",
      "-i",
      list,
      "-c",
      "copy",
      "-threads",
      "1",
      outputPath,
    ],
    { maxBuffer: 64 * 1024 }
  );
}

/**
 * Generate one chapter WAV and its normalized scene timeline. The speech API is
 * intentionally called once for the complete chapter, never once per scene.
 */
export async function createWhiteboardLesson(
  userId: number,
  id: string,
  payload: WhiteboardLessonPayload,
  options: WhiteboardLessonOptions = {}
): Promise<WhiteboardLesson & { audio: Buffer }> {
  const scenes = normalizeScenes(payload);
  const narration = scenes.map(scene => scene.narration).join("\n\n");
  const existingAudioURL = options.audioURL?.trim() || payload.audioURL?.trim();
  let audio: Buffer;
  let audioURL: string;
  if (existingAudioURL) {
    audio = await loadStoredNarration(existingAudioURL);
    audioURL = existingAudioURL;
  } else {
    const stored = await createNaturalSpeechAudio(
      userId,
      id,
      narration,
      payload.language,
      options.speech
    );
    audio = stored.audio;
    audioURL = stored.url;
  }
  const duration = wavDuration(audio);
  if (duration > MAX_CHAPTER_SECONDS)
    throw badRequest(
      "This whiteboard lesson exceeds the five-minute narration budget."
    );
  return {
    audioURL,
    audioDuration: duration,
    language: payload.language,
    scenes: buildWhiteboardTimelines(scenes, duration),
    audio,
  };
}

/** Create an animated MP4 with chapter-level neural narration and deterministic board motion. */
export async function createWhiteboardVideo(
  userId: number,
  id: string,
  payload: WhiteboardLessonPayload,
  options: WhiteboardLessonOptions = {}
): Promise<string> {
  if (whiteboardBusy)
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message:
        "Another whiteboard video is being prepared. Please retry in a moment.",
    });
  whiteboardBusy = true;
  let workdir: string | undefined;
  try {
    const scenes = normalizeScenes(payload);
    const lesson = await createWhiteboardLesson(
      userId,
      id,
      { ...payload, scenes },
      options
    );
    workdir = await mkdtemp(join(tmpdir(), "adus-whiteboard-"));
    const audioPath = join(workdir, "narration.wav");
    await writeFile(audioPath, lesson.audio);
    const segments: string[] = [];
    for (const timeline of lesson.scenes) {
      const scene = scenes[timeline.index]!;
      segments.push(
        await renderSceneFrames(
          workdir,
          scene,
          timeline,
          timeline.index,
          scenes.length
        )
      );
    }
    const silentVideo = join(workdir, "whiteboard-silent.mp4");
    await concatVideo(workdir, segments, silentVideo);
    const outputPath = join(workdir, "whiteboard-lesson.mp4");
    await execFileAsync(
      "ffmpeg",
      [
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        silentVideo,
        "-i",
        audioPath,
        "-map",
        "0:v:0",
        "-map",
        "1:a:0",
        "-c:v",
        "copy",
        "-c:a",
        "aac",
        "-b:a",
        "96k",
        "-shortest",
        "-movflags",
        "+faststart",
        "-threads",
        "1",
        outputPath,
      ],
      { maxBuffer: 64 * 1024 }
    );
    const outputStat = await stat(outputPath);
    if (outputStat.size > MAX_OUTPUT_BYTES)
      throw badRequest("The whiteboard lesson exceeds the 40 MB output limit.");
    const output = await readFile(outputPath);
    return (
      await storagePut(
        `whiteboard/${userId}/${id}-${randomUUID()}.mp4`,
        output,
        "video/mp4"
      )
    ).url;
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    throw serviceUnavailable(
      `Whiteboard video rendering failed: ${error instanceof Error ? error.message : "unknown error"}`
    );
  } finally {
    if (workdir)
      await rm(workdir, { recursive: true, force: true }).catch(
        () => undefined
      );
    whiteboardBusy = false;
  }
}

export function isWhiteboardVideoBusy(): boolean {
  return whiteboardBusy;
}
