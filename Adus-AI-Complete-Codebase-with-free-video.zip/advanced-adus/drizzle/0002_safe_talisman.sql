CREATE TABLE `workspaceRecords` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`kind` varchar(40) NOT NULL,
	`payload` text NOT NULL,
	`createdAt` bigint NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `workspaceRecords_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `workspace_user_kind_idx` ON `workspaceRecords` (`userId`,`kind`);