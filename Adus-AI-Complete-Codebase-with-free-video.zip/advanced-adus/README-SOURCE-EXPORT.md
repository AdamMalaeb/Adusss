# Adus AI — Complete Codebase

This ZIP contains the latest available Adus application source, exported at 2026-10-17T21:07:28.264257+00:00 from Git commit `f4c1474d167a7bde81e2a06d821390c1b5ca0eb3` (checkpoint `f4c1474d`). Original application files are copied unchanged. It includes the React frontend, Express/tRPC backend, shared code, every feature module, database schema and SQL migrations, tests, browser smoke-test scripts, GitHub CI workflow, package manifest and dependency lockfile, Dockerfile, and project documentation.

## Included features

The source includes chat and saved conversations, call and camera-call controllers, multilingual transcription and neural speech integration, attachments, shared file Translator, study summaries and professor-style videos, images and media saving, video generation and source editing integrations, website creation and hosting adapters, Business planning, PowerPoint integration, Operations, custom tabs and reviewed source-upgrade modules. The source also includes the Adus-branded sign-in page and prepared independent Google login implementation.

Having a feature's source is not a guarantee that its third-party service is configured or available. See `docs/oct12-release.md` for the latest saved verification results and limitations.

## Excluded for privacy and portability

API keys, passwords, filled environment files, private customer database records, account sessions, generated user media stored externally, installed dependencies (`node_modules`), compiled build output (`dist`), Git history, internal logs and deployment metadata are not bundled. Referenced object-storage media remains external. This is a complete application source export, not a backup of user data or provider accounts. Keep the ZIP private because it contains your application logic and attribution details.

## Setup

Use Node.js 22 and the pnpm version declared in `package.json`. The server imports `dotenv/config` and reads your locally configured `.env`.

```bash
cd advanced-adus
corepack enable
pnpm install --frozen-lockfile
cp .env.example .env
# Configure your own authorized services and database in .env.
pnpm check
pnpm test
pnpm dev
```

For production, run `pnpm build` followed by `pnpm start`. The default server port is 3000. See `Dockerfile` for the Linux runtime packages needed by PDF extraction, image processing, video editing and multilingual document export, including FFmpeg/FFprobe, Poppler, Chromium and fonts.

The test scripts are included as source. Some browser tests depend on separately created QA media fixtures, installed Playwright/Chromium or paths from the original workspace; prepare or adjust those fixtures and paths on another machine. Optional live-provider tests require their documented flags and real credentials.

## Database, authentication and services

Configure your own MySQL/TiDB database. Review the supplied SQL migrations in `drizzle/` before applying them. No production database contents are included.

Independent Google sign-in requires your own Google OAuth client ID, client secret and matching HTTPS callback configuration. Read `docs/google-sign-in.md`, including its explicit account-linking instructions. The labelled legacy Manus OAuth path remains available in the code.

Hosting elsewhere does not transfer existing keys, sessions, object storage or service access. Existing AI, transcription, storage, presentation and video adapters need authorized services or must be replaced. Configure server credentials separately; never expose them in the browser or commit a completed `.env`.

The latest saved release reports that full PowerPoint rendering needs a valid presentation-service credential, live research can be unavailable under provider limits, and Google video generation depends on provider access and quota. The Open Fliki button opens Fliki's external website; it is not a free API integration. Exporting the source does not repair or enable these third-party connections.

## Integrity

`SOURCE-MANIFEST.json` identifies the source commit and provides SHA-256 hashes for every original exported file. Packaging checks ZIP integrity, verifies original source bytes against their checksums, and scans for known execution-environment credential values and private-key blocks. No application code was changed while producing this archive.
