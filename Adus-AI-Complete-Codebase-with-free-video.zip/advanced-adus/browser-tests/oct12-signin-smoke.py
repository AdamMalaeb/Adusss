import asyncio, json, os
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  results=[]
  for width in [320,390,430]:
   page=await browser.new_page(viewport={'width':width,'height':844})
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.route('**/api/trpc/**',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps([{'result':{'data':{'json':None}}}])))
   await page.goto(BASE+'/sign-in?returnTo=/&googleError=invalid_state')
   button=page.get_by_role('button',name='Google sign-in setup required',exact=True)
   await button.wait_for(); assert await button.is_disabled()
   await page.get_by_role('alert').wait_for()
   assert 'Powered by Manus' not in await page.locator('body').inner_text()
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+2')
   await page.get_by_role('link',name='Back to workspace',exact=False).click()
   await page.wait_for_url(BASE+'/')
   assert not errors,errors
   results.append({'width':width,'brandedSignIn':True,'backReturnsToWorkspace':True,'missingCredentialsHonest':True,'noPageErrors':True})
   await page.close()
  await browser.close();print(json.dumps(results,indent=2))
asyncio.run(main())
