import asyncio,json,os
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':390,'height':844});errors=[];stage=0;paths_seen=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.route('**/qa-professor.mp4',lambda r:r.fulfill(status=200,content_type='video/mp4',body=Path('/tmp/adus-oct11-professor.mp4').read_bytes()))
  async def rpc(route):
   nonlocal stage
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',');values=[]
   for path in paths:
    paths_seen.append(path);r=[]
    if path=='auth.me':r={'id':999,'role':'user','name':'QA','email':'qa@example.com'}
    elif path=='adus.videos.professor.create':r={'id':'qa-prof','type':'professor','status':'pending','stage':'script','language':'french','prompt':'Explain waves'}
    elif path=='adus.videos.professor.status':
     stage+=1;r={'id':'qa-prof','type':'professor','status':'completed' if stage>=3 else 'pending','stage':['narration','render','done'][min(stage-1,2)],'language':'french','prompt':'Explain waves','title':'College professor lesson','url':'/qa-professor.mp4' if stage>=3 else None}
    values.append({'result':{'data':{'json':r}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(values))
  await page.route('**/api/trpc/**',rpc);await page.goto(BASE+'/videos')
  await page.get_by_role('textbox',name='Professor explainer topic').fill('Explain ocean waves like a college professor with diagrams and a worked example.')
  await page.get_by_role('combobox',name='Professor narration language').select_option('french')
  await page.get_by_role('button',name='Create professor explainer',exact=True).click()
  video=page.locator('video');await video.wait_for(timeout=25000);await video.evaluate('(v)=>v.load()');await page.wait_for_function("document.querySelector('video').readyState>=2")
  await video.evaluate('(v)=>v.play()');await page.wait_for_timeout(500);state=await video.evaluate('(v)=>({time:v.currentTime,duration:v.duration,paused:v.paused})');assert state['time']>0 and state['duration']>30
  assert 'adus.videos.generate' not in paths_seen
  assert stage==3 and not errors,(stage,errors)
  await page.screenshot(path='/tmp/adus-oct11-professor-studio.png',full_page=True)
  print(json.dumps({'independentProfessorWorkflow':True,'durableStages':stage,'realMp4Played':state,'noCinematicSubstitution':True,'errors':errors},indent=2));await browser.close()
asyncio.run(main())
