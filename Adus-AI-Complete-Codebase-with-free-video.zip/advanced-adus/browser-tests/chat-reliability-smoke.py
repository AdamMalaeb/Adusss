import asyncio, json, os
from urllib.parse import urlparse, parse_qs
from playwright.async_api import async_playwright
BASE = os.environ.get('ADUS_QA_BASE', 'http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser = await p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
  page = await browser.new_page(viewport={'width':390,'height':844})
  errors=[]; messages=[]; calls=[]; answer_calls=0
  page.on('pageerror', lambda e: errors.append(str(e)))
  async def rpc(route):
   nonlocal answer_calls
   request=route.request
   paths=request.url.split('/api/trpc/')[1].split('?')[0].split(',')
   data=request.post_data_json if request.method=='POST' else json.loads(parse_qs(urlparse(request.url).query).get('input',['{}'])[0])
   out=[]
   for i,path in enumerate(paths):
    inp=(data or {}).get(str(i),{}).get('json',{});calls.append((path,inp));result=[]
    if path=='auth.me': result={'id':999,'openId':'qa','name':'QA','email':'qa@example.com','role':'admin'}
    elif path=='adus.conversations.list':result=[]
    elif path=='adus.conversations.create':result={'id':'thread-1','title':'Colleges In Lebanon'}
    elif path=='adus.conversations.get':result={'id':'thread-1','messages':messages}
    elif path=='adus.conversations.append':messages.append(inp['message']);result={'appended':True}
    elif path=='adus.chat':
     answer_calls+=1
     if answer_calls==1:
      out.append({'error':{'json':{'message':'The AI service returned no answer even after recovery. Your question is kept; use Retry answer.','code':-32603,'data':{'code':'INTERNAL_SERVER_ERROR','httpStatus':500,'path':path}}}})
      continue
     result={'content':'Some universities in Lebanon include **Lebanese University**, AUB and LAU.\n\n**Sources checked**\n[University information](https://university.example.edu/about)','agent':'Adus','model':'qa'}
    out.append({'result':{'data':{'json':result}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(out))
  await page.route('**/api/trpc/**',rpc)
  await page.goto(BASE+'/')
  await page.locator('textarea').fill('Tell me colleges in lebanon')
  await page.locator('textarea').press('Enter')
  await page.get_by_role('button',name='Retry answer',exact=True).wait_for()
  assert len(messages)==1 and messages[0]['role']=='user',messages
  await page.get_by_role('button',name='Retry answer',exact=True).click()
  await page.get_by_text('Lebanese University',exact=True).wait_for()
  await page.wait_for_timeout(200)
  assert answer_calls==2
  assert len(messages)==2 and [m['role'] for m in messages]==['user','assistant'],messages
  assert not await page.get_by_role('button',name='Retry answer',exact=True).count()
  assert not await page.get_by_text('The AI service returned no answer even after recovery.',exact=False).count()
  assert await page.get_by_role('link',name='University information',exact=True).get_attribute('href')=='https://university.example.edu/about'
  assert not errors,errors
  await page.screenshot(path='/tmp/adus-chat-reliability-phone.png')
  print(json.dumps({'retryWithoutDuplicateMessages':True,'sourceLinksVisible':True,'questionKept':True,'pageErrors':errors},indent=2))
  await browser.close()
asyncio.run(main())
