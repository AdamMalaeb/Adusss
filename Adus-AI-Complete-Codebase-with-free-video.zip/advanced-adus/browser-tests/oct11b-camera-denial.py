import asyncio,json,os
from urllib.parse import urlparse,parse_qs
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
  page=await browser.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.add_init_script("""const original = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices); window.qaCameraRequests=0; navigator.mediaDevices.getUserMedia = (c)=>{ if(c.video){window.qaCameraRequests++;return Promise.reject(new DOMException('Blocked by user','NotAllowedError'));}return original(c);};""")
  async def rpc(route):
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',');values=[]
   for path in paths:
    r={'id':999,'name':'QA','email':'qa@example.com','role':'user'} if path=='auth.me' else []
    values.append({'result':{'data':{'json':r}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(values))
  await page.route('**/api/trpc/**',rpc);await page.goto(BASE+'/')
  await page.get_by_role('button',name='Open video call',exact=True).click()
  help=page.get_by_role('link',name='Open the full Adus page in Safari').last;await help.wait_for(timeout=15000)
  assert await help.get_attribute('href')=='https://aiworkspace-dyq23yap.manus.space/'
  assert await page.locator('video[aria-label="Live camera preview"]').count()==0
  assert await page.evaluate('window.qaCameraRequests')==1
  await page.get_by_role('button',name='End voice call',exact=True).click()
  assert not errors,errors
  print(json.dumps({'deniedPermissionNotRetried':True,'honestCameraRecoveryLink':True,'voiceRemainsSeparate':True,'errors':errors},indent=2));await browser.close()
asyncio.run(main())
