import asyncio, json, os
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from playwright.async_api import async_playwright, expect
BASE = os.environ.get('ADUS_QA_BASE', 'http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  results=[]
  for width in [320,390,430]:
   page=await browser.new_page(viewport={'width':width,'height':844},accept_downloads=True)
   calls=[];errors=[];messages=[]
   page.on('pageerror',lambda error:errors.append(str(error)))
   async def rpc(route):
    request=route.request
    paths=request.url.split('/api/trpc/')[1].split('?')[0].split(',')
    payload=request.post_data_json if request.method=='POST' else json.loads(parse_qs(urlparse(request.url).query).get('input',['{}'])[0])
    values=[]
    for i,path in enumerate(paths):
     inp=(payload or {}).get(str(i),{}).get('json',{});calls.append((path,inp));value=[]
     if path=='auth.me':value={'id':999,'openId':'qa-oct12','name':'QA','email':'qa@example.com','role':'admin'}
     elif path=='adus.translator.translate':value={'id':'translation-qa','text':'Bonjour. Les ondes transfèrent de l’énergie.','filename':'translation-fr.txt','sourceNames':['source.txt'],'sourceLanguage':'auto','targetLanguage':'fr','sourceLabel':'Auto-detect','targetLabel':'French','model':'qa','warnings':[],'createdAt':1791813600000,'downloadUrl':'/qa-translation.txt'}
     elif path=='adus.conversations.create':value={'id':'thread-qa','title':'Physics explanation'}
     elif path=='adus.conversations.get':value={'id':'thread-qa','messages':messages}
     elif path=='adus.conversations.append':messages.append(inp['message']);value={'appended':True}
     elif path=='adus.chat':value={'content':'Conservation of energy means the total remains unchanged.\n\n'+('VerylongunbrokenURL'+('x'*220))+'\n\n```python\n'+('long_code_expression = '+('value + '*80))+'\n```\n\n| Explanation | Example |\n|---|---|\n| '+('word'*120)+' | A stable law |','model':'qa','agent':'Adus'}
     elif path=='powerpoint.readiness':value={'available':True,'message':'QA presentation service is available.'}
     elif path=='powerpoint.history':value={'tasks':[],'outputs':[],'drafts':[]}
     elif path=='powerpoint.generate':value={'recordId':'ppt-qa','taskId':'remote-qa','taskUrl':'https://example.com/task','state':'completed','statusMessage':'QA task completed','output':{'url':'/qa-deck.pptx','filename':'waves.pptx'}}
     elif path=='adus.media.downloadTicket':value={'url':'/qa-deck.pptx','filename':'waves.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation'}
     values.append({'result':{'data':{'json':value}}})
    await route.fulfill(status=200,content_type='application/json',body=json.dumps(values))
   await page.route('**/api/trpc/**',rpc)
   await page.route('**/qa-translation.txt',lambda r:r.fulfill(status=200,body='Bonjour. Les ondes transfèrent de l’énergie.',headers={'Content-Type':'text/plain;charset=utf-8','Content-Disposition':'attachment; filename="translation-fr.txt"'}))
   await page.goto(BASE+'/translator')
   await page.get_by_role('button',name='Choose source files',exact=False).wait_for()
   assert 'Tab configuration' not in await page.locator('body').inner_text()
   await page.locator('input[type=file]').set_input_files({'name':'source.txt','mimeType':'text/plain','buffer':b'Waves transfer energy.'})
   await page.get_by_label('Translate into',exact=True).click()
   await page.get_by_role('option',name='French',exact=False).click()
   await page.get_by_role('button',name='Translate completely',exact=True).click()
   await page.get_by_text('Bonjour. Les ondes transfèrent de l’énergie.',exact=True).wait_for()
   t=next(data for path,data in calls if path=='adus.translator.translate');assert t['files'][0]['name']=='source.txt' and t['targetLanguage'] in ['fr','french']
   async with page.expect_download() as info:await page.get_by_role('button',name='Download .txt',exact=False).click()
   assert (await info.value).suggested_filename.endswith('.txt')
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),('translator overflow',width)
   for path in ['/videos','/operations','/upgrade']:
    await page.goto(BASE+path)
    await page.get_by_text('Locked',exact=False).first.wait_for()
    assert await page.locator('textarea:visible').count()==0
   await page.goto(BASE+'/')
   await page.locator('textarea').fill('Explain conservation of energy')
   await page.locator('textarea').press('Enter')
   await page.locator('pre').wait_for()
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),('chat overflow',width)
   assert await page.evaluate('document.querySelector(".adus-chat-shell").getBoundingClientRect().width>=innerWidth-35')
   await page.screenshot(path=f'/tmp/adus-oct12-chat-{width}.png')
   await page.goto(BASE+'/business')
   await page.get_by_label('Plan language',exact=True).wait_for()
   await page.get_by_label('Plan language',exact=True).select_option('french')
   await page.goto(BASE+'/powerpoint')
   await page.get_by_label('Presentation prompt',exact=True).fill('Explain ocean wave motion. Do not include images.')
   await page.get_by_label('Optional animations or effects',exact=True).fill('Subtle fade transitions')
   await page.get_by_label('Slide count',exact=True).evaluate("e=>{Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,'5');e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}")
   await page.get_by_role('button',name='Generate PPTX',exact=True).click()
   await page.get_by_text('Editable PPTX saved',exact=True).wait_for()
   gen=next(data for path,data in calls if path=='powerpoint.generate');assert gen['slideCount']==5 and not gen['allowPictures'] and not gen['pictures']
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),('powerpoint overflow',width)
   assert not errors,errors
   results.append({'width':width,'translatorFileUpload':True,'translatedFileDownload':True,'lockedOwnerAreas':True,'chatContained':True,'businessLanguage':True,'oneStepPowerPoint':True,'noPageErrors':True})
   await page.close()
  print(json.dumps(results,indent=2));await browser.close()
asyncio.run(main())
