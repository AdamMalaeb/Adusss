import asyncio,json,os
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required'])
  context=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,permissions=['microphone','camera'])
  await context.add_init_script("""const original = AudioContext.prototype.createAnalyser; AudioContext.prototype.createAnalyser = function(){const analyser=original.call(this);analyser.getFloatTimeDomainData=(samples)=>samples.fill(0);return analyser;};""")
  page=await context.new_page();errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)))
  # Serve a real WAV over HTTP while API response bodies are simulated.
  await page.route('**/qa-neural.wav',lambda route:route.fulfill(status=200,content_type='audio/wav',body=Path('/tmp/adus-oct11-neural-call.wav').read_bytes()))
  async def rpc(route):
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',')
   request=route.request.post_data_json if route.request.method=='POST' else json.loads(parse_qs(urlparse(route.request.url).query).get('input',['{}'])[0]);values=[]
   for i,path in enumerate(paths):
    data=(request or {}).get(str(i),{}).get('json',{});calls.append({'path':path,'input':data});r=[]
    if path=='auth.me':r={'id':999,'name':'QA','email':'qa@example.com','role':'user'}
    elif path=='adus.transcribeVoice':r={'text':'Explain what you can see in this camera frame.','language':'en'}
    elif path=='adus.chat':r={'content':'Certainly. The camera frame shows a test pattern. I can describe this current image, but I do not continuously monitor your video.','model':'test','agent':'Voice Agent'}
    elif path=='adus.callSpeech.synthesize':r={'url':'/qa-neural.wav','key':'qa-neural.wav','duration':10}
    values.append({'result':{'data':{'json':r}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(values))
  await page.route('**/api/trpc/**',rpc)
  await page.goto(BASE+'/');await page.get_by_role('button',name='Open video call',exact=True).click()
  camera=page.locator('video[aria-label="Live camera preview"]');await camera.wait_for(timeout=15000)
  await page.wait_for_function("document.querySelector('video').videoWidth>0")
  await page.wait_for_timeout(300)
  rect=await camera.bounding_box();assert rect['width']>=340 and rect['height']>=240,rect
  await page.get_by_role('button',name='Done speaking · Answer now',exact=True).click()
  await page.wait_for_function('document.body.innerText.includes("Adus is answering…")')
  await page.get_by_role('button',name='Mute microphone',exact=True).click()
  assert await page.get_by_text('Your microphone is muted · Bot audio stays on',exact=True).count()==1
  camera_live=await camera.evaluate('(v)=>v.srcObject.getVideoTracks()[0].readyState');assert camera_live=='live'
  await page.get_by_role('button',name='End voice call',exact=True).scroll_into_view_if_needed()
  await page.screenshot(path='/tmp/adus-oct11-large-camera.png')
  reply=next(x['input'] for x in calls if x['path']=='adus.chat');assert reply['voiceMode'] and reply['cameraMode'];assert reply['cameraFrame']['dataUrl'].startswith('data:image/jpeg;base64,')
  assert len([x for x in calls if x['path']=='adus.callSpeech.synthesize'])==1
  assert await page.get_by_text('Certainly. The camera frame shows a test pattern.',exact=False).count()==0
  await page.get_by_role('button',name='Unmute microphone',exact=True).click()
  await page.get_by_role('button',name='Stop answer and listen',exact=True).click()
  await page.get_by_text('Listening… speak naturally',exact=True).first.wait_for()
  assert await camera.evaluate('(v)=>v.srcObject.getVideoTracks()[0].readyState')=='live'
  await page.get_by_role('button',name='Done speaking · Answer now',exact=True).click()
  await page.wait_for_function('document.body.innerText.includes("Adus is answering…")')
  replies=[x['input'] for x in calls if x['path']=='adus.chat']
  assert len(replies)==2 and any(t['role']=='user' and 'camera frame' in t['content'] for t in replies[1]['history']),replies
  await page.get_by_role('button',name='End voice call',exact=True).click();assert await camera.count()==0
  assert not errors,errors
  print(json.dumps({'largeCamera':rect,'neuralAudioFetched':True,'muteLeavesCameraAndBotActive':True,'currentSnapshotSent':True,'noCallChatBubbles':True,'errors':errors},indent=2));await browser.close()
asyncio.run(main())
