import asyncio,json,os
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=await b.new_page(viewport={'width':390,'height':844});errors=[];calls=[];threads={};tabs=[];chapters=[];counter=0
  page.on('pageerror',lambda e:errors.append(str(e)))
  tab={'id':'00000000-0000-4000-8000-000000000001','label':'Translator','slug':'translator','path':'/workspace/translator','createdAt':1,'updatedAt':1,'functionConfig':{'type':'translator','sourceLanguage':'auto','targetLanguage':'fr'}}
  action={'id':'act','operation':'add','summary':'Add Translator tool','before':None,'after':tab,'status':'proposed','proposedAt':1}
  async def rpc(route):
   nonlocal counter
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',');data=route.request.post_data_json if route.request.method=='POST' else json.loads(parse_qs(urlparse(route.request.url).query).get('input',['{}'])[0]);out=[]
   for i,path in enumerate(paths):
    inp=(data or {}).get(str(i),{}).get('json',{});calls.append((path,inp));r=[]
    if path=='auth.me':r={'id':999,'openId':'qa-test','name':'QA','email':'qa@example.com','role':'admin'}
    elif path=='adus.conversations.list':r=[{'id':k,'title':v['title'],'preview':v['messages'][-1]['content'] if v['messages'] else '', 'messageCount':len(v['messages']),'createdAt':1,'updatedAt':2} for k,v in threads.items()]
    elif path=='adus.conversations.create':
     counter+=1;tid='chat-'+str(counter);threads[tid]={'id':tid,'title':'Math Tutoring' if 'math' in inp.get('firstMessage','').lower() else 'New conversation','messages':[]};r=threads[tid]
    elif path=='adus.conversations.get':r=threads.get(inp.get('id'),{})
    elif path=='adus.conversations.append':
     threads[inp['id']]['messages'].append(inp['message']);r={'appended':True,'message':inp['message'],'conversation':threads[inp['id']]}
    elif path=='adus.chat':r={'content':'Result: $3x+5=14 \\Rightarrow x=3$. Reaction: $C+O_2 \\rightarrow CO_2$.','model':'qa','agent':'Adus'}
    elif path=='adus.workspaceExtensions.status':r={'owner':True}
    elif path=='adus.workspaceExtensions.list':r=tabs
    elif path=='adus.workspaceExtensions.propose':r=action
    elif path=='adus.workspaceExtensions.activate':tabs.append(tab);r={**action,'status':'applied'}
    elif path=='adus.workspaceExtensions.get':r=tab
    elif path=='adus.workspaceExtensions.translate':r={'text':'Bonjour. Comment puis-je vous aider ?','targetLanguage':'fr'}
    elif path=='adus.upgrade.source.status':r={'owner':True,'configured':False,'message':'Source setup required'}
    elif path=='adus.study.courses':r=[]
    elif path=='adus.study.createCourse':r={'id':'course'}
    elif path=='adus.study.getCourse':r={'id':'course','title':'QA lesson','mode':'summary','language':'english','units':[{'label':'Page 1'}],'chapters':chapters,'warnings':[]}
    elif path=='adus.study.analyzeChapter':
     await asyncio.sleep(1.5);r={'id':'chapter','index':0,'title':'Energy transfer','summary':'Wave energy moves through particles. $x=3 \\Rightarrow y=4$.','sourceLabel':'Page 1','scenes':[],'warnings':[],'sources':[]};chapters.append(r)
    elif path=='adus.study.summaryPdf':r={'url':'/manus-storage/qa-summary.pdf'}
    elif path=='adus.videos.list':r=[]
    elif path=='adus.videoEdits.plan':r={'id':'plan','status':'review','sourceId':'source','plan':{'supported':True,'summary':'Keep first second','segments':[{'start':0,'end':1}],'mute':[],'speed':[],'crop':None,'rotate':0},'source':{'duration':2},'estimatedDuration':1}
    elif path=='adus.videoEdits.applyPlan':r={'plan':{'id':'plan','status':'applied','sourceId':'source','source':{'duration':2,'width':64,'height':64,'hasAudio':False},'plan':{'supported':True,'summary':'Keep first second','segments':[{'start':0,'end':1}],'mute':[],'speed':[],'crop':None,'rotate':0}},'result':{'id':'result','url':'/qa.mp4','name':'edited.mp4','duration':1}}
    out.append({'result':{'data':{'json':r}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(out))
  await page.route('**/qa.mp4',lambda route:route.fulfill(status=200,content_type='video/mp4',body=Path('/tmp/adus-mobile-qa-video.mp4').read_bytes()))
  await page.route('**/api/trpc/**',rpc)
  await page.route('**/api/videos/upload',lambda route:route.fulfill(status=200,content_type='application/json',body=json.dumps({'id':'source','type':'source','name':'phone.MOV','duration':2,'url':'/qa.mp4'})))
  await page.goto(BASE+'/');await page.locator('textarea').fill('Help me in my math');await page.locator('textarea').press('Enter');await page.locator('.katex').first.wait_for();assert len(threads['chat-1']['messages'])==2
  await page.get_by_role('button',name='New chat',exact=True).first.click();await page.wait_for_timeout(300);await page.get_by_role('button',name='Math Tutoring',exact=False).first.click();await page.get_by_text('Help me in my math',exact=True).wait_for();await page.reload();await page.get_by_text('Help me in my math',exact=True).wait_for()
  await page.goto(BASE+'/upgrade');await page.get_by_label('Workspace tab change prompt').fill('Add a new tab named Translator');await page.get_by_role('button',name='Review tab change',exact=True).click();await page.get_by_role('button',name='Apply reviewed change',exact=True).click();await page.locator('a[href="/workspace/translator"]').last.click();await page.get_by_label('Translator input').fill('Good morning');await page.get_by_role('button',name='Translate',exact=True).click();await page.get_by_text('Bonjour. Comment puis-je vous aider ?',exact=True).wait_for()
  await page.goto(BASE+'/studying');summary=page.get_by_role('region',name='Summary workspace');await summary.locator('input[type=file]').set_input_files({'name':'lesson.txt','mimeType':'text/plain','buffer':b'Waves carry energy.'});await summary.get_by_role('button',name='Generate summary',exact=True).click();await page.wait_for_timeout(250)
  await page.evaluate("history.pushState(null,'','/chat');window.dispatchEvent(new PopStateEvent('popstate'))");await page.get_by_role('heading',name='Chat Only',exact=True).wait_for();await page.wait_for_timeout(2200);assert any(c[0]=='adus.study.summaryPdf' for c in calls)
  await page.evaluate("history.pushState(null,'','/studying');window.dispatchEvent(new PopStateEvent('popstate'))");await page.get_by_text('Energy transfer',exact=True).wait_for();await page.get_by_text('Your summary and PDF are ready.',exact=True).wait_for()
  await page.goto(BASE+'/videos');assert not await page.get_by_text('Professor explainer',exact=False).count();await page.get_by_role('button',name='Edit source',exact=False).click();await page.locator('input[type=file]').set_input_files({'name':'phone.MOV','mimeType':'','buffer':b'QA MOV source'});await page.get_by_label('Describe local video edit').fill('Keep first second');await page.get_by_role('button',name='Preview edit plan',exact=True).click();await page.get_by_role('button',name='Apply reviewed plan',exact=True).click();await page.get_by_text('Edited MP4 ready',exact=True).wait_for();await page.wait_for_function('Array.from(document.querySelectorAll("video")).some(v=>v.readyState>=2)');
  async with page.expect_download() as download_event:
   await page.get_by_role('button',name='Download',exact=True).click()
  download=await download_event.value;await download.save_as('/tmp/adus-oct11c-downloaded.mp4');assert Path('/tmp/adus-oct11c-downloaded.mp4').read_bytes()==Path('/tmp/adus-mobile-qa-video.mp4').read_bytes()
  assert not errors,errors;await page.screenshot(path='/tmp/adus-oct11c-workspace-phone.png');print(json.dumps({'savedChatReopenReload':True,'translatorRuns':True,'studyFinishesOffPage':True,'professorRemovedFromVideos':True,'multipartEditingUI':True,'realMP4PlaybackAndDownload':True,'pageErrors':errors},indent=2));await b.close()
asyncio.run(main())
