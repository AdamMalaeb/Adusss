// Development-only isolated mocked-API test; never sends credentials or changes real accounts.
export default async function workspaceUiSmoke() {
  const sources = await Promise.all(
    ["/src/main.tsx", "/src/pages/Home.tsx"].map(async path =>
      (await fetch(path)).text()
    )
  );
  const modules = sources
    .join("\n")
    .match(/\/@fs\/[^"']+\/deps\/[^"']+\.js\?v=[^"']+/g);
  const load = name =>
    import(
      /* @vite-ignore */ modules.find(url => url.includes("/" + name + ".js?"))
    );
  const React = (await load("react")).default;
  const dom = await load("react-dom_client");
  const createRoot = dom.createRoot ?? dom.default.createRoot;
  const { QueryClient, QueryClientProvider } = await load(
    "@tanstack_react-query"
  );
  const { httpBatchLink } = await load("@trpc_client");
  const sj = (await load("superjson")).default;
  const { trpc } = await import("/src/lib/trpc.ts");
  const host = document.createElement("div");
  host.id = "workspace-smoke";
  host.style.cssText =
    "position:fixed;inset:0;z-index:100;background:#0a0d14;overflow:auto";
  document.body.append(host);
  const savedInfo = localStorage.getItem("manus-runtime-user-info");
  const calls = [];
  const checks = {};
  let root;
  const image =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aK8sAAAAASUVORK5CYII=";
  const lesson = {
    id: "study-test",
    title: "Understanding waves",
    summary: "Waves transfer energy. Frequency is 2.5 Hz.",
    scenes: Array.from({ length: 4 }, (_, i) => ({
      title: "Idea " + (i + 1),
      bullets: ["Energy moves through the medium."],
      narration: "The medium oscillates while energy travels.",
    })),
    sources: ["notes.txt"],
    warnings: [],
  };
  const delay = ms => new Promise(r => setTimeout(r, ms));
  const button = label =>
    [...host.querySelectorAll("button")].find(
      b =>
        b.textContent.trim() === label ||
        b.textContent.includes(label) ||
        b.getAttribute("aria-label") === label
    );
  const setInput = (element, value) => {
    const proto =
      element.tagName === "TEXTAREA"
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(element, value);
    element.dispatchEvent(new Event("input", { bubbles: true }));
  };
  const responses = (path, input) => {
    calls.push({ path, input });
    if (path === "auth.me")
      return { id: 999, name: "Workspace Test", email: "test@example.com" };
    if (path.endsWith(".list") || path.endsWith(".history")) return [];
    if (path === "adus.upgrade.current") return null;
    if (path === "adus.chat")
      return { content: "Your files describe wave motion.", agent: "Adus" };
    if (path === "adus.study.analyze") return lesson;
    if (path === "adus.study.courses") return [];
    if (path === "adus.study.createCourse")
      return {
        id: lesson.id,
        title: lesson.title,
        language: "english",
        units: [{ source: "notes.txt", label: "notes.txt" }],
        warnings: [],
      };
    if (path === "adus.study.analyzeChapter")
      return {
        ...lesson,
        index: 0,
        courseId: lesson.id,
        sourceLabel: "notes.txt",
      };
    if (path === "adus.study.renderChapter")
      return { index: 0, url: "/manus-storage/test-study.mp4" };
    if (path === "adus.study.generateVideo")
      return { id: lesson.id, url: "/manus-storage/test-study.mp4" };
    if (path === "adus.images.generateOne")
      return { index: input.index, url: image };
    if (path === "adus.images.resize")
      return {
        url: image,
        width: input.width,
        height: input.height,
        format: input.format,
      };
    if (path === "adus.website.build")
      return {
        id: "website-test",
        title: "Test travel website",
        summary: "A complete static page.",
        html: "<!doctype html><html><body><h1>Travel calmly</h1></body></html>",
      };
    if (path === "adus.hosting.publish")
      return {
        id: "deploy-test",
        state: "published",
        url: "https://test-site.netlify.app",
      };
    if (path === "adus.upgrade.propose")
      return {
        id: "upgrade-test",
        title: "Simple tutor",
        instructions: "Use simple examples.",
        changes: ["Clearer explanation"],
        checks: ["Use an example"],
        requiresEngineering: false,
        engineeringNotes: "",
      };
    if (path === "adus.upgrade.activate")
      return {
        applied: true,
        scope: "Assistant behaviour only",
        requiresEngineering: false,
      };
    return null;
  };
  const fakeFetch = async (url, init) => {
    const parsed = new URL(url, location.origin);
    const paths = parsed.pathname.split("/").at(-1).split(",");
    let payload = init?.body
      ? JSON.parse(init.body)
      : JSON.parse(parsed.searchParams.get("input") || "{}");
    return new Response(
      JSON.stringify(
        paths.map((path, i) => ({
          result: {
            data: sj.serialize(
              responses(path, payload[String(i)]?.json ?? payload.json ?? {})
            ),
          },
        }))
      ),
      { headers: { "content-type": "application/json" } }
    );
  };
  async function mount(name) {
    root?.unmount();
    host.innerHTML = "";
    const Page = (
      await import(/* @vite-ignore */ "/src/pages/" + name + ".tsx")
    ).default;
    const query = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });
    const client = trpc.createClient({
      links: [
        httpBatchLink({
          url: location.origin + "/api/trpc",
          transformer: sj,
          fetch: fakeFetch,
        }),
      ],
    });
    root = createRoot(host);
    root.render(
      React.createElement(
        trpc.Provider,
        { client, queryClient: query },
        React.createElement(
          QueryClientProvider,
          { client: query },
          React.createElement(Page)
        )
      )
    );
    await delay(600);
  }
  function upload(selector, file) {
    const input = host.querySelector(selector);
    const data = new DataTransfer();
    data.items.add(file);
    Object.defineProperty(input, "files", {
      configurable: true,
      value: data.files,
    });
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  try {
    await mount("Home");
    checks.navigation =
      ["Chat Only", "Studying", "Images", "Websites", "Upgrade Adus"].every(
        text => host.innerText.includes(text)
      ) && !host.innerText.includes("Creative studio");
    upload(
      "input[type=file]",
      new File(["Waves transfer energy."], "notes.txt", { type: "text/plain" })
    );
    await delay(200);
    checks.chatAttachment = host.innerText.includes("notes.txt");
    setInput(host.querySelector("textarea"), "Explain my files");
    await delay(20);
    host
      .querySelector("form")
      .dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    await delay(200);
    checks.chatOnly = calls.some(
      c =>
        c.path === "adus.chat" &&
        c.input.chatOnly === true &&
        c.input.attachments?.length === 1
    );
    await mount("Studying");
    upload(
      "input[type=file]",
      new File(["Waves transfer energy."], "notes.txt", { type: "text/plain" })
    );
    await delay(180);
    button("Analyze & make complete course").click();
    await delay(900);
    checks.study =
      host.innerText.includes("Understanding waves") &&
      !!host.querySelector("video") &&
      calls.some(c => c.path === "adus.study.renderChapter");
    await mount("Images");
    setInput(host.querySelector("textarea"), "Four travel photos");
    await delay(20);
    host
      .querySelector("form")
      .dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    await delay(400);
    checks.images =
      calls.filter(c => c.path === "adus.images.generateOne").length === 4 &&
      host.innerText.includes("4 of 4 complete");
    await mount("BuildLab");
    button("Create website").click();
    await delay(250);
    button("Publish").click();
    await delay(80);
    checks.hostQuestion =
      host.innerText.toLowerCase().includes("host") &&
      calls.filter(c => c.path === "adus.hosting.publish").length === 0;
    checks.websitePreview =
      !!host.querySelector("iframe") &&
      host
        .querySelector("iframe")
        .getAttribute("srcdoc")
        .includes("Travel calmly");
    await mount("Upgrade");
    button("Draft upgrade").click();
    await delay(250);
    checks.upgradeReview =
      host.innerText.includes("Use simple examples.") &&
      calls.filter(c => c.path === "adus.upgrade.activate").length === 0;
    button("Apply behaviour upgrade").click();
    await delay(250);
    checks.upgradeApplied = calls.some(
      c => c.path === "adus.upgrade.activate" && c.input.confirmed === true
    );
    return {
      passed: Object.values(checks).every(Boolean),
      checks,
      mutations: calls
        .filter(
          c =>
            !c.path.endsWith(".list") &&
            !c.path.endsWith(".history") &&
            c.path !== "auth.me"
        )
        .map(c => c.path),
    };
  } finally {
    root?.unmount();
    host.remove();
    if (savedInfo === null) localStorage.removeItem("manus-runtime-user-info");
    else localStorage.setItem("manus-runtime-user-info", savedInfo);
  }
}
