import asyncio, json, os
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  original=Path('/tmp/adus-saved-site-0.html').read_text()
  async def rpc(route):
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',');result=[]
   for path in paths:
    value=[]
    if path=='auth.me':value={'id':999,'email':'qa@example.com','name':'QA','role':'user'}
    elif path=='adus.website.build':value={'id':'saved-qa','title':'Actual saved website','summary':'Real navigation reproduction','html':original}
    elif path=='adus.media.websiteTicket':value={'url':'/test-download'}
    result.append({'result':{'data':{'json':value}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(result))
  await page.route('**/api/trpc/**',rpc)
  await page.goto(BASE+'/build');await page.get_by_role('button',name='Create website',exact=True).click()
  iframe=page.locator('iframe[title="Adus website preview"]');await iframe.wait_for();await page.wait_for_timeout(700)
  frame=await iframe.element_handle();content=await frame.content_frame()
  await content.locator('#hero-title').wait_for()
  hrefs=await content.locator('a[href^="#"]').evaluate_all('(links)=>links.map(a=>a.getAttribute("href"))')
  tested=[]
  for href in hrefs:
   # Test programmatic click so all desktop-only navigation targets are exercised at phone size.
   await content.evaluate('(href)=>Array.from(document.querySelectorAll("a")).find(a=>a.getAttribute("href")===href).click()',href)
   await page.wait_for_timeout(80)
   assert await content.locator('#hero-title').count()==1,href
   assert 'This page is not live' not in await content.locator('body').inner_text(),href
   assert await content.locator('script[data-adus-preview-navigation]').count()==1,href
   tested.append(href)
  await content.evaluate('()=>{const a=document.createElement("a");a.href="/not-created";a.textContent="Missing page";document.body.appendChild(a);a.click()}')
  assert await content.get_by_role('status').count()==1
  assert await content.locator('#hero-title').count()==1
  await page.get_by_role('button',name='Desktop overview',exact=True).click();await page.wait_for_timeout(250)
  rect=await iframe.bounding_box();assert rect['width']<=390
  await page.screenshot(path='/tmp/adus-private-navigation-fixed.png')
  assert not errors,errors
  print(json.dumps({'actualSavedHtml':True,'internalLinksTested':tested,'allLinksKeepDraftVisible':True,'missingPageExplainedWithoutBlanking':True,'privateSandboxPreserved':await iframe.get_attribute('sandbox'),'desktopFitsPhone':rect,'errors':errors},indent=2))
  await browser.close()
asyncio.run(main())
