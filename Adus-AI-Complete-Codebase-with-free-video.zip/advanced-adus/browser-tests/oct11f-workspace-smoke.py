import asyncio, json, os
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from playwright.async_api import async_playwright, expect
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
PLAN=json.loads(Path('/tmp/adus-business-browser-fixture.json').read_text())
DRAFT={'title':'Understanding wave motion','topic':'Wave motion','audience':'High-school learners','language':'English','style':'Executive clarity','slideCount':4,'sourceFacts':['Transverse motion is perpendicular to propagation.'],'outline':[{'id':f'slide-{i}','title':f'Wave lesson {i}','summary':'Particles oscillate while the disturbance transfers energy.','bullets':['Use a diagram and one concrete example.'],'sourceFacts':[]} for i in range(1,5)]}
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  results=[]
  for width in [320,390,430]:
   page=await b.new_page(viewport={'width':width,'height':844},accept_downloads=True)
   errors=[];messages=[];calls=[];draft=json.loads(json.dumps(DRAFT))
   page.on('pageerror',lambda e:errors.append(str(e)))
   async def rpc(route):
    req=route.request;paths=req.url.split('/api/trpc/')[1].split('?')[0].split(',')
    data=req.post_data_json if req.method=='POST' else json.loads(parse_qs(urlparse(req.url).query).get('input',['{}'])[0])
    out=[]
    for i,path in enumerate(paths):
     inp=(data or {}).get(str(i),{}).get('json',{});calls.append((path,inp));result=[]
     if path=='auth.me':result={'id':999,'openId':'qa','name':'QA','email':'qa@example.com','role':'admin'}
     elif path=='adus.conversations.create':result={'id':'thread-1','title':'Lebanon universities'}
     elif path=='adus.conversations.get':result={'id':'thread-1','messages':messages}
     elif path=='adus.conversations.append':messages.append(inp['message']);result={'appended':True}
     elif path=='adus.chat':result={'content':'Lebanon has universities including the Lebanese University. \ue200cite\ue202turn0search1\ue201 [University information](https://university.example.edu/about)','model':'gpt-5-mini','agent':'Research Agent','research':{'status':'retrieved','engine':'Google Search','checkedAt':1791745200000,'sources':[{'title':'University information','url':'https://university.example.edu/about'}]}}
     elif path=='powerpoint.readiness':result={'available':False,'credentialEnv':'MANUS_API_KEY','message':'The configured presentation credential was rejected. Editable outlines remain available.'}
     elif path=='powerpoint.history':result={'drafts':[],'tasks':[],'outputs':[]}
     elif path=='powerpoint.outline':result={'id':'ppt-draft','draft':draft,'sourceOutline':[]}
     elif path=='powerpoint.reviseOutline':
      draft['outline'][0]['title']='A clearer opening';result={'id':'ppt-revised','draft':draft}
     elif path=='powerpoint.saveDraft':result={'id':'ppt-saved','draft':inp['draft']}
     elif path=='business.generate':result=PLAN
     elif path=='business.history':result=[]
     else:result=[]
     out.append({'result':{'data':{'json':result}}})
    await route.fulfill(status=200,content_type='application/json',body=json.dumps(out))
   await page.route('**/api/trpc/**',rpc)
   print(f"Testing phone width {width}: citations",flush=True)
   await page.goto(BASE+'/')
   await page.locator('textarea').fill('Tell me universities in Lebanon in 2026')
   await page.locator('textarea').press('Enter')
   await page.get_by_role('link',name='University information',exact=True).wait_for()
   assert 'turn0search' not in await page.locator('body').inner_text()
   assert await page.get_by_role('link',name='University information',exact=True).get_attribute('href')=='https://university.example.edu/about'
   print(f'Testing phone width {width}: outline controls',flush=True)
   await page.goto(BASE+'/powerpoint')
   await page.get_by_label('Topic',exact=True).fill('Understanding wave motion')
   await page.get_by_label('Audience',exact=True).fill('High-school learners')
   await page.locator('#ppt-count').focus()
   await page.locator('#ppt-count').press('Home')
   await page.get_by_role('button',name='Draft outline',exact=True).click()
   await expect(page.get_by_label('Slide 1 title',exact=True)).to_have_value('Wave lesson 1')
   await page.get_by_label('Slide 1 title',exact=True).fill('Manually improved opening')
   await page.get_by_role('button',name='Save draft',exact=True).click()
   await page.get_by_label('Ask for a revision',exact=True).fill('Make the opening clearer')
   await page.get_by_role('button',name='Revise with AI',exact=True).click()
   await expect(page.get_by_label('Slide 1 title',exact=True)).to_have_value('A clearer opening')
   await expect(page.get_by_role('button',name='Generate editable PPTX',exact=True)).to_be_disabled()
   assert 'credential was rejected' in await page.locator('body').inner_text()
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),('powerpoint overflow',width)
   await page.screenshot(path=f'/tmp/adus-powerpoint-phone-{width}.png')
   print(f'Testing phone width {width}: Business charts and export',flush=True)
   await page.goto(BASE+'/business')
   await page.get_by_label('Business idea',exact=True).fill('Weekend bicycle repair service')
   await page.get_by_label('Country / market',exact=True).fill('Local neighborhood')
   await page.get_by_label('Target customer',exact=True).fill('Adult commuters')
   await page.get_by_label('Your experience / resources',exact=True).fill('Experienced mechanic with tools')
   await page.get_by_role('button',name='Generate plan',exact=True).click()
   await page.get_by_text('Readiness rubric',exact=True).wait_for()
   await expect(page.locator('.recharts-surface')).to_have_count(1)
   await page.get_by_label('Price / customer / month (USD)',exact=True).fill('40')
   await page.get_by_label('Customers / month',exact=True).fill('25')
   await page.get_by_label('Variable cost / customer (USD)',exact=True).fill('8')
   await page.get_by_label('Fixed costs / month (USD)',exact=True).fill('500')
   await expect(page.locator('.recharts-surface')).to_have_count(2)
   assert '15.6 customers / month' in await page.locator('body').inner_text()
   async with page.expect_download() as info:
    await page.get_by_role('button',name='Download .md',exact=True).click()
   download=await info.value
   path=await download.path();content=Path(path).read_text()
   assert 'not a success probability' in content
   assert PLAN['plan']['title'] in content
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),('business overflow',width)
   await page.screenshot(path=f'/tmp/adus-business-phone-{width}.png')
   assert not errors,errors
   results.append({'width':width,'cleanCitations':True,'editableOutlineAndRevision':True,'credentialGateHonest':True,'businessCharts':2,'planDownloaded':True,'noHorizontalOverflow':True,'pageErrors':errors})
   await page.close()
  print(json.dumps(results,indent=2));await b.close()
asyncio.run(main())
