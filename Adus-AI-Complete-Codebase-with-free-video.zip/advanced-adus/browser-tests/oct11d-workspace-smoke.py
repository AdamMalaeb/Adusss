import asyncio,json,os
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.async_api import async_playwright, expect
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':390,'height':844});errors=[];calls=[];archived=False;campaigns=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('dialog',lambda dialog:asyncio.create_task(dialog.accept()))
  tab={'id':'00000000-0000-4000-8000-000000000001','label':'Business Ideas','slug':'business-ideas','path':'/workspace/business-ideas','createdAt':1,'updatedAt':1,'functionConfig':{'type':'aiTool','name':'Business Ideas','instructions':'Generate practical business ideas with steps and reasons.','inputControls':[{'name':'input','label':'Business context','type':'textarea','required':True}],'sourceLanguage':'auto','targetLanguage':'en'}}
  thread={'id':'thread-qa','title':'Math Tutoring','preview':'Solve equations','messageCount':1,'createdAt':1,'updatedAt':2}
  async def rpc(route):
   nonlocal archived,campaigns
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',')
   data=route.request.post_data_json if route.request.method=='POST' else json.loads(parse_qs(urlparse(route.request.url).query).get('input',['{}'])[0]);out=[]
   for i,path in enumerate(paths):
    inp=(data or {}).get(str(i),{}).get('json',{});calls.append((path,inp));r=[]
    if path=='auth.me':r={'id':999,'openId':'qa-test','name':'QA','email':'qa@example.com','role':'admin'}
    elif path=='adus.conversations.list':r=[] if archived else [thread]
    elif path=='adus.conversations.get':r={**thread,'messages':[{'id':'message','requestId':'message','role':'assistant','content':'Equation: $3x + 5 = 14 \\Rightarrow x = 3$.','createdAt':1}]}
    elif path=='adus.conversations.archive':archived=True;r={'id':inp['id'],'archived':True}
    elif path=='adus.conversations.restore':archived=False;r=thread
    elif path=='adus.workspaceExtensions.list':r=[tab]
    elif path=='adus.workspaceExtensions.status':r={'owner':True}
    elif path=='adus.workspaceExtensions.get':r=tab
    elif path=='adus.workspaceExtensions.execute':r={'tabId':tab['id'],'name':'Business Ideas','text':'Offer cafe loyalty kits. Start with three pilot clients and a small subscription.','model':'qa'}
    elif path=='adus.hosting.configuration':r={}
    elif path=='adus.communications.mailbox.status':r={'status':'connected','email':'sender@public.test','host':'smtp.public.test','port':587,'secure':False,'verifiedAliases':[]}
    elif path=='adus.communications.drafts.list':r=[]
    elif path=='adus.communications.campaigns.list':r=campaigns
    elif path=='adus.communications.campaigns.create':
     r={**inp,'id':'00000000-0000-4000-8000-000000000002','status':'review','recipients':[{**recipient,'id':str(n),'status':'pending'} for n,recipient in enumerate(inp['recipients'])]};campaigns=[r]
    elif path=='adus.communications.campaigns.send':campaigns=[{**campaigns[0],'status':'completed','recipients':[{**recipient,'status':'sent'} for recipient in campaigns[0]['recipients']]}];r=campaigns[0]
    out.append({'result':{'data':{'json':r}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(out))
  await page.route('**/api/trpc/**',rpc)
  await page.goto(BASE+'/');await page.locator('.katex').first.wait_for()
  remove=page.get_by_role('button',name='Remove Math Tutoring',exact=True);await remove.wait_for();assert await remove.evaluate('(el)=>getComputedStyle(el).opacity')=='1'
  await remove.click();await page.get_by_role('button',name='Undo',exact=True).click();await page.get_by_role('button',name='Math Tutoring',exact=False).first.wait_for();assert not archived
  await page.goto(BASE+'/workspace/business-ideas');await page.get_by_label('Business context',exact=True).fill('Low-budget cafe');await page.get_by_role('button',name='Run Business Ideas',exact=True).click();await page.get_by_text('Offer cafe loyalty kits.',exact=False).wait_for()
  await page.goto(BASE+'/build');await page.get_by_role('button',name='Create website',exact=True).wait_for();assert await page.locator('textarea').first.input_value()==''
  await page.goto(BASE+'/videos');await page.get_by_label('Video resolution').select_option('1080p');await expect(page.get_by_label('Video duration').locator('option[value="4"]')).to_have_attribute('disabled','');assert await page.get_by_label('Video duration').input_value()=='8'
  await page.goto(BASE+'/communications');await page.get_by_label('Email subject').fill('Partnership discussion');body='Dear team,\n'+('\nPlease review this proposal.'*8)+'\nFINAL REVIEW LINE';await page.get_by_label('Email body').fill(body)
  await page.get_by_placeholder('person@company.com',exact=True).last.fill('recipient@public.test');await page.get_by_role('button',name='Add',exact=True).click()
  await page.get_by_role('checkbox',name='I reviewed the exact subject',exact=False).check();await page.get_by_role('button',name='Save reviewed campaign',exact=True).click()
  approve=page.get_by_label('Approve saved campaign for sending');await approve.wait_for();send=page.get_by_role('button',name='Send exact reviewed payload',exact=True);assert await send.is_disabled()
  await page.get_by_text('From: sender@public.test',exact=True).wait_for();full=page.locator('p').filter(has_text='FINAL REVIEW LINE');assert 'FINAL REVIEW LINE' in await full.inner_text();assert await full.evaluate('(el)=>getComputedStyle(el).webkitLineClamp')=='none'
  await approve.check();await send.click();await page.wait_for_timeout(500)
  sent=[inp for path,inp in calls if path=='adus.communications.campaigns.send'];assert len(sent)==1 and sent[0]['confirmed'] is True
  assert campaigns[0]['text']==body;assert not errors,errors
  await page.screenshot(path='/tmp/adus-oct11d-communications-phone.png',full_page=True)
  print(json.dumps({'phoneChatRemoveUndo':True,'businessToolRuns':True,'websiteBriefBlank':True,'fullHDUsesSupportedDuration':True,'exactSavedEmailReview':True,'mockedSingleSend':True,'pageErrors':errors},indent=2));await browser.close()
asyncio.run(main())
