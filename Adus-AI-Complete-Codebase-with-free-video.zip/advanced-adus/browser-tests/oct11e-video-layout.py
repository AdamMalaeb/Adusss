import asyncio,json,os
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  results=[]
  for width in [320,390,430]:
   page=await browser.new_page(viewport={'width':width,'height':844});errors=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   async def rpc(route):
    paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',');out=[]
    for path in paths:
     r={'id':999,'openId':'qa-test','name':'QA','email':'qa@example.com','role':'admin'} if path=='auth.me' else []
     out.append({'result':{'data':{'json':r}}})
    await route.fulfill(status=200,content_type='application/json',body=json.dumps(out))
   await page.route('**/api/trpc/**',rpc)
   await page.route('**/api/videos/upload',lambda route:route.fulfill(status=200,content_type='application/json',body=json.dumps({'id':'source','type':'source','name':'phone.MOV','duration':2})))
   await page.goto(BASE+'/videos');await page.get_by_label('Video duration').wait_for()
   await page.get_by_role('checkbox').check();await page.get_by_label('Generated video narration script').fill('A calm, natural voiceover.')
   await page.get_by_label('Narration language',exact=True).select_option('auto')
   async def bounds(stage):
    failures=await page.evaluate('''()=>Array.from(document.querySelectorAll('input,textarea,select,button,[role="alert"]')).filter(e=>e.getClientRects().length&&e.closest('main')).map(e=>({name:e.getAttribute('aria-label')||e.textContent.trim().slice(0,50),x:e.getBoundingClientRect().x,right:e.getBoundingClientRect().right,width:e.getBoundingClientRect().width})).filter(e=>e.width>0&&(e.x<-1||e.right>innerWidth+1))''')
    dimensions=await page.evaluate('({viewport:innerWidth,document:document.documentElement.scrollWidth})')
    assert not failures,(width,stage,failures)
    assert dimensions['document']<=width+1,(width,stage,dimensions)
    results.append({'width':width,'stage':stage,'controlsFit':True})
   await bounds('generate-with-narration')
   assert not await page.locator('a[href="/communications"]').count()
   await page.get_by_role('button',name='Edit source',exact=False).click()
   await page.locator('input[type=file]').set_input_files({'name':'phone.MOV','mimeType':'video/quicktime','buffer':b'QA source upload boundary'})
   await page.get_by_label('Describe local video edit').wait_for();await page.get_by_role('checkbox').check()
   await page.get_by_label('Narration script',exact=True).fill('Explain this clip clearly.')
   await page.get_by_label('Narration language',exact=True).select_option('auto')
   await bounds('source-edit-with-narration')
   assert not errors,errors
   if width==390:await page.screenshot(path='/tmp/adus-oct11e-video-controls.png',full_page=True)
   await page.close()
  print(json.dumps(results,indent=2));await browser.close()
asyncio.run(main())
