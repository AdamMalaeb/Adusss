import asyncio,json
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await browser.new_page();await page.goto('http://127.0.0.1:3000/');await page.wait_for_timeout(1000)
  result=await page.evaluate("async()=>await (await import('/@fs/home/ubuntu/advanced-adus/browser-tests/voice-ui-smoke.js')).default()")
  print(json.dumps(result,indent=2));await browser.close()
asyncio.run(main())
