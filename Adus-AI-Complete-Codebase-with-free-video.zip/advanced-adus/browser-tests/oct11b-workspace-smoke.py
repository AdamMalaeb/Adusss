import asyncio,json,os
from urllib.parse import urlparse,parse_qs
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=await b.new_page(viewport={'width':390,'height':844});errors=[];calls=[];tabs=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  tab={'id':'test','label':'Test','slug':'test','path':'/workspace/test','createdAt':1,'updatedAt':1}
  action={'id':'act','operation':'add','summary':'Add tab Test','before':None,'after':tab,'status':'proposed','proposedAt':1}
  plan={'id':'plan','status':'review','sourceId':'source','prompt':'Keep 0 to 1 second','source':{'duration':2,'width':64,'height':64,'hasAudio':False},'plan':{'version':1,'supported':True,'summary':'Keep the first second','unsupportedReason':'','segments':[{'start':0,'end':1}],'mute':[],'speed':[],'crop':None,'rotate':0},'estimatedDuration':1}
  async def rpc(route):
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',');data=route.request.post_data_json if route.request.method=='POST' else json.loads(parse_qs(urlparse(route.request.url).query).get('input',['{}'])[0]);out=[]
   for i,path in enumerate(paths):
    calls.append(path);r=[]
    if path=='auth.me':r={'id':999,'name':'QA','email':'qa@example.com','role':'admin'}
    elif path=='adus.chat':r={'content':r'$3x + 5 = 14 \Rightarrow x = 3$. Reaction: $C + O_2 \rightarrow CO_2$.','model':'qa'}
    elif path=='adus.workspaceExtensions.status':r={'owner':True,'scope':'This user only'}
    elif path=='adus.workspaceExtensions.list':r=tabs
    elif path=='adus.workspaceExtensions.propose':r=action
    elif path=='adus.workspaceExtensions.activate':tabs.append(tab);r={**action,'status':'applied'}
    elif path=='adus.workspaceExtensions.get':r=tab
    elif path=='adus.upgrade.source.status':r={'owner':True,'configured':False,'message':'Private source repository setup required','missing':['ADUS_SOURCE_REPO']}
    elif path=='adus.videos.upload':r={'id':'source','name':'video.mp4','type':'source','duration':2,'url':'/qa-video.mp4'}
    elif path=='adus.videoEdits.plan':r=plan
    elif path=='adus.videoEdits.applyPlan':r={'plan':{**plan,'status':'applied'},'result':{'id':'result','url':'/qa-video.mp4','name':'edited.mp4','duration':1}}
    out.append({'result':{'data':{'json':r}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(out))
  await page.route('**/api/trpc/**',rpc)
  await page.goto(BASE+'/');await page.locator('textarea').first.fill('Explain equations');await page.locator('textarea').first.press('Enter');await page.locator('.katex').first.wait_for();assert await page.locator('.katex').count()>=2
  visible=' '.join(await page.locator('.katex-html').all_inner_texts());assert '$3x' not in visible and '\\rightarrow' not in visible
  await page.goto(BASE+'/upgrade');await page.get_by_role('button',name='Review tab change',exact=True).click();await page.get_by_role('button',name='Apply reviewed change',exact=True).click();await page.locator('a[href="/workspace/test"]').first.wait_for();await page.locator('a[href="/workspace/test"]').first.click();await page.get_by_role('heading',name='Test',exact=True).first.wait_for();assert not await page.get_by_role('button',name='Draft behaviour upgrade').count()
  await page.goto(BASE+'/videos');await page.get_by_role('button',name='Edit source',exact=False).click();await page.locator('input[type=file]').first.set_input_files({'name':'video.mp4','mimeType':'video/mp4','buffer':b'QA bytes'});await page.get_by_label('Describe local video edit').fill('Keep the first second');await page.get_by_role('button',name='Preview edit plan',exact=True).click();await page.get_by_role('button',name='Apply reviewed plan',exact=True).click();await page.get_by_text('Edited MP4 ready',exact=True).wait_for();assert 'adus.videoEdits.applyPlan' in calls;assert 'adus.videos.edit' not in calls
  assert not errors,errors;await page.screenshot(path='/tmp/adus-oct11b-video-edit-phone.png');print(json.dumps({'mathVisibleNotRawLaTex':True,'reviewedTestTabRouted':True,'sourceEditsNoVeo':True,'pageErrors':errors},indent=2));await b.close()
asyncio.run(main())
