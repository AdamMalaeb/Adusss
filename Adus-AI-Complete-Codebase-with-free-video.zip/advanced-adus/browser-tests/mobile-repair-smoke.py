import asyncio,json
import os
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:3000'
IMAGE='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aK8sAAAAASUVORK5CYII='
if os.environ.get('ADUS_QA_STORAGE_FIXTURE'):
 IMAGE=json.loads(Path(os.environ['ADUS_QA_STORAGE_FIXTURE']).read_text())['url']
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True,accept_downloads=True)
  page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  async def rpc(route):
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',')
   responses=[]
   for path in paths:
    result=[]
    if path=='auth.me':result={'id':999,'name':'Mobile UI Test','email':'qa@example.com','role':'user'}
    elif path=='adus.images.generateOne':result={'index':0,'url':IMAGE}
    responses.append({'result':{'data':{'json':result}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(responses))
  await page.route('**/api/trpc/**',rpc)
  await page.goto(BASE+'/studying');await page.get_by_role('heading',name='Create a full study course').wait_for()
  width=await page.evaluate('({viewport:innerWidth,scroll:document.documentElement.scrollWidth})')
  await page.get_by_role('button',name='Toggle Sidebar').click();await page.wait_for_timeout(400)
  panel=page.locator('[data-sidebar="sidebar"][data-mobile="true"]')
  color=await panel.evaluate('(e)=>getComputedStyle(e).backgroundColor')
  rect=await panel.bounding_box();await page.screenshot(path='/tmp/adus-mobile-opaque-menu.png')
  await panel.get_by_role('button',name='Images',exact=True).click();await page.get_by_role('heading',name='Image workspace').wait_for(timeout=10000)
  closed=await page.locator('[data-sidebar="sidebar"][data-mobile="true"]').count()==0
  await page.locator('textarea').fill('Four travel photos')
  await page.locator('form').evaluate('(e)=>e.dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}))')
  await page.get_by_role('button',name='Preview generated image 1',exact=True).wait_for();await page.get_by_role('button',name='Preview generated image 1',exact=True).click()
  download=page.get_by_role('button',name='Download',exact=True);await download.wait_for();await page.wait_for_timeout(500)
  await page.screenshot(path='/tmp/adus-mobile-image-viewer.png')
  async with page.expect_download() as download_info:await download.click()
  downloaded=await download_info.value
  await downloaded.save_as('/tmp/adus-ui-download.png')
  print(json.dumps({'mobileWidth':width,'sidebarBackground':color,'sidebarRect':rect,'closedAfterNavigation':closed,'downloadFilename':downloaded.suggested_filename,'downloadBytes':Path('/tmp/adus-ui-download.png').stat().st_size,'ResizeObserverErrors':[e for e in errors if 'ResizeObserver' in e],'otherErrors':errors},indent=2))
  await browser.close()
asyncio.run(main())
