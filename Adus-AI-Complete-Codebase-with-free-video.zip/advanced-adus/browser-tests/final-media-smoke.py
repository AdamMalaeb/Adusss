import asyncio,json,base64,os
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.environ.get('ADUS_QA_BASE','http://127.0.0.1:3000')
fixture=json.loads(Path('/tmp/adus-mobile-fixture.json').read_text())
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
  context=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
  page=await context.new_page();errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)))
  async def rpc(route):
   paths=route.request.url.split('/api/trpc/')[1].split('?')[0].split(',');values=[]
   request=route.request.post_data_json if route.request.method=='POST' else None
   if not request:
    from urllib.parse import urlparse,parse_qs
    query=parse_qs(urlparse(route.request.url).query);request=json.loads(query.get('input',['{}'])[0])
   for i,path in enumerate(paths):
    input=(request or {}).get(str(i),{}).get('json',{});calls.append({'path':path,'input':input});r=[]
    if path=='auth.me':r={'id':999,'name':'QA','email':'qa@example.com','role':'user'}
    elif path=='adus.upgrade.current':r=None
    elif path=='adus.upgrade.source.status':r={'owner':False,'configured':False,'missing':[],'message':'Owner only'}
    elif path=='adus.study.createCourse':r={'id':input.get('mode','video'),'title':'Waves','language':input.get('language','english'),'mode':input.get('mode'),'units':[{'source':'notes.txt','label':'notes.txt'}],'warnings':[]}
    elif path=='adus.study.analyzeChapter':r={'id':input['id']+':c0','index':0,'courseId':input['id'],'title':'Understanding waves','sourceLabel':'notes.txt','summary':'## Main idea\nA wave transfers energy, while water particles oscillate.','scenes':[{'title':'Wave energy','bullets':['Energy travels','Water oscillates'],'narration':'A wave transfers energy. The water moves around its resting position, while the wave travels onward.','visual':{'kind':'diagram','labels':['Water','Energy']}}],'sources':['notes.txt'],'warnings':[]}
    elif path=='adus.study.prepareChapterVoice':r={'audioURL':fixture['audioURL'],'audioDuration':7.28}
    elif path=='adus.study.summaryPdf':r={'url':fixture['pdfURL'],'filename':'adus-study-summary.pdf'}
    elif path=='adus.images.generateOne':r={'index':input['index'],'url':fixture['imageURL']}
    elif path=='adus.media.ticket':r={'url':fixture['pdfDownload'] if input['filename'].endswith('.pdf') else fixture['videoDownload'] if input['filename'].endswith('.mp4') else fixture['imageDownload']}
    elif path=='adus.website.build':r={'id':'web1','title':'Wide website','summary':'Responsive page','html':'<!doctype html><html><head><style>body{margin:0}header{display:flex;justify-content:space-between;background:#003747;color:white;padding:30px}h1{font-size:clamp(28px,7vw,80px)}</style></head><body><header><b>MY SITE</b><span>MENU</span></header><h1>The entire page should be visible</h1><p>Content on the right side.</p></body></html>'}
    elif path=='adus.videos.generate':r={'id':'video1','operation':'generate','status':'completed','url':fixture['videoURL']}
    values.append({'result':{'data':{'json':r}}})
   await route.fulfill(status=200,content_type='application/json',body=json.dumps(values))
  await page.route('**/api/trpc/**',rpc)
  await page.goto(BASE+'/studying');await page.get_by_role('heading',name='Studying',exact=True).wait_for()
  summary=page.get_by_role('region',name='Summary workspace');video=page.get_by_role('region',name='Lesson video workspace')
  await summary.locator('input[type=file]').set_input_files({'name':'notes.txt','mimeType':'text/plain','buffer':b'A wave transfers energy.'})
  await summary.get_by_role('combobox',name='Summary language').select_option('arabic')
  await summary.get_by_role('button',name='Generate summary',exact=True).click();await summary.get_by_role('button',name='Download',exact=True).wait_for(timeout=15000)
  async with page.expect_download() as info:await summary.get_by_role('button',name='Download',exact=True).click()
  down=await info.value;await down.save_as('/tmp/adus-mobile-summary.pdf');assert Path('/tmp/adus-mobile-summary.pdf').read_bytes().startswith(b'%PDF-')
  await video.locator('input[type=file]').set_input_files({'name':'notes.txt','mimeType':'text/plain','buffer':b'A wave transfers energy.'})
  await video.get_by_role('button',name='Generate lesson video',exact=True).click();await video.get_by_role('button',name='Play whiteboard lesson',exact=True).wait_for(timeout=15000)
  await video.locator('audio').evaluate('(e)=>e.load()');await page.wait_for_timeout(500)
  await video.get_by_role('button',name='Play whiteboard lesson',exact=True).click();await page.wait_for_timeout(500);first=await video.locator('svg[role=img]').inner_html();await page.wait_for_timeout(1200);second=await video.locator('svg[role=img]').inner_html();assert first!=second
  playing=await video.locator('audio').evaluate('(e)=>({paused:e.paused,time:e.currentTime})');assert playing['time']>0
  await page.screenshot(path='/tmp/adus-new-study-mobile.png',full_page=True)
  width=await page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth})');assert width['scroll']<=width['width']
  await page.goto(BASE+'/images');await page.get_by_role('heading',name='Image workspace').wait_for();await page.locator('textarea').fill('Generate one bird image');await page.locator('form').evaluate('(e)=>e.dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}))')
  await page.get_by_role('button',name='Preview generated image 1',exact=True).wait_for();await page.get_by_role('button',name='Preview generated image 1',exact=True).click();await page.get_by_role('button',name='Download',exact=True).wait_for()
  await page.wait_for_timeout(700)
  async with page.expect_download() as info:await page.get_by_role('button',name='Download',exact=True).click()
  down=await info.value;await down.save_as('/tmp/adus-mobile-photo.png');assert Path('/tmp/adus-mobile-photo.png').read_bytes().startswith(b'\x89PNG')
  await page.goto(BASE+'/build');await page.get_by_role('button',name='Create website',exact=True).click();await page.locator('iframe[title="Adus website preview"]').wait_for();await page.wait_for_timeout(500)
  frame=page.locator('iframe[title="Adus website preview"]');rect=await frame.bounding_box();await page.get_by_role('button',name='Desktop overview',exact=True).click();await page.wait_for_timeout(300);desktop=await frame.bounding_box();width=await page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth})');assert width['scroll']<=width['width'];assert desktop['width']<=390
  await page.screenshot(path='/tmp/adus-full-width-mobile-site.png')
  await page.get_by_role('button',name='Actual size',exact=True).click();await page.wait_for_timeout(200);actual=await frame.bounding_box();assert actual['width']==1280
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await page.get_by_role('button',name='Fit whole width',exact=True).click()
  await page.get_by_role('button',name='Fullscreen',exact=True).click();full=page.locator('iframe[title="Adus full website preview"]');await full.wait_for();await page.wait_for_timeout(200);fullrect=await full.bounding_box();assert fullrect['width']<=390 and fullrect['width']>rect['width']
  await page.get_by_role('button',name='Close',exact=True).click()
  await page.get_by_role('button',name='Publish',exact=True).click();github=page.get_by_text('GitHub Pages',exact=True);assert await github.count()>0
  await page.goto(BASE+'/videos');await page.get_by_role('heading',name='Video studio',exact=True).wait_for();await page.locator('textarea').first.fill('A blue ball rolls over a desk');await page.get_by_role('button',name='Generate video',exact=True).click();await page.get_by_role('button',name='Download',exact=True).wait_for();await page.wait_for_timeout(700)
  async with page.expect_download() as info:await page.get_by_role('button',name='Download',exact=True).click()
  down=await info.value;await down.save_as('/tmp/adus-mobile-downloaded-video.mp4');assert Path('/tmp/adus-mobile-downloaded-video.mp4').read_bytes()[4:8]==b'ftyp'
  await page.get_by_role('button',name='Edit source').click();await page.get_by_role('button',name='Choose source').wait_for();await page.screenshot(path='/tmp/adus-video-studio-mobile.png')
  for round in range(2):
   for path in ['/','/studying','/images','/build','/videos','/upgrade','/operations']:
    await page.goto(BASE+path)
    if path in ['/', '/upgrade']:await page.locator('textarea').first.wait_for(timeout=10000)
    elif path=='/build':await page.get_by_role('button',name='Create website',exact=True).wait_for(timeout=10000)
    else:await page.get_by_role('heading').first.wait_for(timeout=10000)
    text=await page.locator('body').inner_text();assert text and 'Something went wrong' not in text;assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  print(json.dumps({'independentUploads':True,'summaryIsPdf':True,'imageDownloadIsPng':True,'animatedBoardChanges':first!=second,'naturalAudio':playing,'mobileSiteRect':rect,'desktopFitRect':desktop,'pageWidth':width,'githubHostAvailable':True,'videoModesSeparate':True,'mp4DownloadValid':True,'errors':errors},indent=2));assert not errors
  await browser.close()
asyncio.run(main())
