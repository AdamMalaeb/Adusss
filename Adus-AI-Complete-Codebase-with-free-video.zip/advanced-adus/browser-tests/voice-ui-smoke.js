// Run in the development preview console:
// (await import('/browser-tests/voice-ui-smoke.js')).default()
// Only mocked API responses are used; real authentication/access is unchanged.
export default async function voiceUiSmoke() {
  const main = await (await fetch("/src/main.tsx")).text();
  const dep = main.match(
    /\/@fs\/[^"']+\/deps\/react_jsx-dev-runtime\.js\?v=[^"']+/
  )[0];
  const home = await (await fetch("/src/pages/Home.tsx")).text();
  const modules = (main + home).match(
    /\/@fs\/[^"']+\/deps\/[^"']+\.js\?v=[^"']+/g
  );
  const load = name =>
    import(
      /* @vite-ignore */ modules.find(url =>
        url.includes("/" + name + ".js?")
      ) ?? dep.replace("react_jsx-dev-runtime.js", name + ".js").split("?")[0]
    );
  const React = (await load("react")).default;
  const ReactDOM = await load("react-dom_client");
  const createRoot = ReactDOM.createRoot ?? ReactDOM.default.createRoot;
  const { QueryClient, QueryClientProvider } = await load(
    "@tanstack_react-query"
  );
  const { httpBatchLink } = await load("@trpc_client");
  const sj = (await load("superjson")).default;
  const { trpc } = await import("/src/lib/trpc.ts");
  const Home = (await import("/src/pages/Home.tsx")).default;
  const saved = {
    synth: Object.getOwnPropertyDescriptor(window, "speechSynthesis"),
    recorder: window.MediaRecorder,
    audio: window.AudioContext,
    media: navigator.mediaDevices.getUserMedia,
    info: localStorage.getItem("manus-runtime-user-info"),
  };
  const host = document.createElement("div");
  host.style.cssText =
    "position:fixed;inset:0;z-index:100;background:#0a0d14;overflow:auto";
  document.body.append(host);
  let root;
  let cancels = 0;
  const spoken = [];
  const track = { enabled: true, stop() {} };
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const button = label =>
    [...host.querySelectorAll("button")].find(
      b =>
        b.getAttribute("aria-label") === label || b.textContent.includes(label)
    );
  try {
    Object.defineProperty(window, "speechSynthesis", {
      configurable: true,
      value: {
        cancel() {
          cancels++;
        },
        resume() {},
        getVoices() {
          return [];
        },
        speak(u) {
          spoken.push(u);
        },
      },
    });
    window.AudioContext = undefined;
    window.MediaRecorder = class {
      static isTypeSupported() {
        return true;
      }
      state = "inactive";
      mimeType = "audio/webm";
      start() {
        this.state = "recording";
      }
      stop() {
        this.state = "inactive";
        this.ondataavailable?.({ data: new Blob(["audio"]) });
        this.onstop?.();
      }
    };
    navigator.mediaDevices.getUserMedia = async () => ({
      getAudioTracks: () => [track],
      getTracks: () => [track],
    });
    const fakeFetch = async url =>
      new Response(
        JSON.stringify(
          new URL(url, location.origin).pathname
            .split("/")
            .at(-1)
            .split(",")
            .map(name => ({
              result: {
                data: sj.serialize(
                  name === "auth.me"
                    ? { id: 999, name: "Call Test", email: "test@example.com" }
                    : name === "adus.capabilities"
                      ? { modules: [], availableModelCount: 1 }
                      : name === "adus.transcribeVoice"
                        ? { text: "Hello" }
                        : name === "adus.chat"
                          ? {
                              content:
                                "I continue speaking while you mute yourself.",
                              agent: "Voice Agent",
                            }
                          : null
                ),
              },
            }))
        ),
        { headers: { "content-type": "application/json" } }
      );
    const query = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });
    const client = trpc.createClient({
      links: [
        httpBatchLink({
          url: location.origin + "/api/trpc",
          transformer: sj,
          fetch: fakeFetch,
        }),
      ],
    });
    root = createRoot(host);
    root.render(
      React.createElement(
        trpc.Provider,
        { client, queryClient: query },
        React.createElement(
          QueryClientProvider,
          { client: query },
          React.createElement(Home)
        )
      )
    );
    await delay(800);
    button("Open voice call").click();
    await delay(100);
    button("Start call").click();
    await delay(150);
    button("Done speaking").click();
    await delay(500);
    const utterance = spoken.at(-1);
    utterance.onstart?.({});
    await delay(50);
    const before = cancels;
    button("Mute microphone").click();
    await delay(80);
    const muted = {
      speaking: host.innerText.includes("Adus is answering"),
      mutedLabel: host.innerText.includes(
        "Your microphone is muted · Bot audio stays on"
      ),
      microphoneEnabled: track.enabled,
      cancelled: cancels !== before,
      chatLeak: host
        .querySelector(".adus-scroll")
        ?.innerText.includes("I continue speaking"),
    };
    utterance.onend?.({});
    await delay(100);
    button("Unmute microphone").click();
    await delay(100);
    const unmuted = {
      listening: !!button("Done speaking"),
      microphoneEnabled: track.enabled,
    };
    button("End voice call").click();
    await delay(100);
    const ended = !button("End voice call");
    return {
      passed:
        muted.speaking &&
        muted.mutedLabel &&
        !muted.microphoneEnabled &&
        !muted.cancelled &&
        !muted.chatLeak &&
        unmuted.listening &&
        unmuted.microphoneEnabled &&
        ended,
      muted,
      unmuted,
      ended,
    };
  } finally {
    root?.unmount();
    host.remove();
    if (saved.synth)
      Object.defineProperty(window, "speechSynthesis", saved.synth);
    else delete window.speechSynthesis;
    window.MediaRecorder = saved.recorder;
    window.AudioContext = saved.audio;
    navigator.mediaDevices.getUserMedia = saved.media;
    if (saved.info === null) localStorage.removeItem("manus-runtime-user-info");
    else localStorage.setItem("manus-runtime-user-info", saved.info);
  }
}
