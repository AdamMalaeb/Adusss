export function chatFailureMessage(error: unknown): string {
  const value = error instanceof Error ? error.message : String(error ?? "");
  if (
    /^(The AI service (has reached its usage limit|is busy right now|returned no answer even after recovery|could not answer right now)|The answer took too long to arrive|Your sign-in session needs to be refreshed)\./.test(
      value
    )
  ) {
    return value;
  }
  if (
    /usage exhausted|insufficient_quota|quota[_ ]exceeded|quota exhausted|billing_hard_limit/i.test(
      value
    )
  ) {
    return "The AI service has reached its usage limit. Your question is kept in this conversation; retry when the service is available.";
  }
  if (/429|rate.?limit|too many requests/i.test(value)) {
    return "The AI service is busy right now. Your question is kept; please retry shortly.";
  }
  if (/timed? ?out|timeout|abort|cancelled/i.test(value)) {
    return "The answer took too long to arrive. Your question is kept; use Retry answer to try again.";
  }
  if (/empty|no.*response/i.test(value)) {
    return "The AI service returned no answer even after recovery. Your question is kept; use Retry answer.";
  }
  if (/UNAUTHORIZED|sign.?in|session|not authenticated/i.test(value)) {
    return "Your sign-in session needs to be refreshed. Sign in again; your saved conversation is unchanged.";
  }
  if (
    /attachment|cannot be read|could not read|unsupported image|combined uploads|processing/i.test(
      value
    ) &&
    !/LLM invoke|Bearer|https?:|api[_ -]?key/i.test(value)
  ) {
    return value;
  }
  return "The AI service could not answer right now. Your question is kept; use Retry answer. No external action was performed.";
}
