const navigationGuard = String.raw`<script data-adus-preview-navigation>
(function(){
  function notice(text){
    var box=document.getElementById('adus-preview-notice');
    if(!box){box=document.createElement('div');box.id='adus-preview-notice';box.setAttribute('role','status');box.style.cssText='position:fixed;bottom:16px;left:16px;right:16px;z-index:2147483647;padding:14px 18px;border-radius:12px;background:#102226;color:white;font:14px/1.5 system-ui;box-shadow:0 4px 20px #0003';document.body.appendChild(box);}
    box.textContent=text;clearTimeout(window.__adusNoticeTimer);window.__adusNoticeTimer=setTimeout(function(){box.remove()},5000);
  }
  function targetFor(href){
    var hash=href.indexOf('#');var key=hash>=0?href.slice(hash+1):href.replace(/^(?:\.\/|\/)+/,'').replace(/(?:\.html?|\/)$/,'');
    try{key=decodeURIComponent(key)}catch(e){}
    if(!key||/^(?:index|home|top)$/i.test(key))return document.body;
    return document.getElementById(key)||Array.from(document.querySelectorAll('[id]')).find(function(e){return e.id.toLowerCase()===key.toLowerCase()})||null;
  }
  document.addEventListener('click',function(event){
    var link=event.target&&event.target.closest?event.target.closest('a[href]'):null;if(!link)return;
    var href=(link.getAttribute('href')||'').trim();
    if(/^(?:mailto:|tel:)/i.test(href)){event.preventDefault();event.stopImmediatePropagation();notice('Contact links become available when you open the published website.');return;}
    event.preventDefault();event.stopImmediatePropagation();
    var external=/^(?:https?:)?\/\//i.test(href);var target=href.indexOf('#')>=0||!external?targetFor(href):null;
    if(target){target.scrollIntoView({behavior:'auto',block:'start'});if(target!==document.body){target.setAttribute('tabindex','-1');target.focus({preventScroll:true})}return;}
    notice(external?'External links are kept inside this private preview. Open them from the published site.':'This page is not part of this single-page draft. Ask Adus to add this section before publishing.');
  },true);
  document.addEventListener('submit',function(e){e.preventDefault();notice('Form submission is disabled in this private preview.')},true);
})();
</script>`;

/** Preview-only behavior. Never used to replace or publish the user's saved HTML. */
export function prepareInteractivePreview(html: string) {
  if (/<script\b[^>]*data-adus-preview-navigation/i.test(html)) return html;
  if (/<head\b[^>]*>/i.test(html))
    return html.replace(/<head\b[^>]*>/i, opening => opening + navigationGuard);
  return navigationGuard + html;
}
