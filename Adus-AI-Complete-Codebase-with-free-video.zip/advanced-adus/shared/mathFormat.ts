const ARROW_COMMANDS: Record<string, string> = {
  to: "→",
  rightarrow: "→",
  longrightarrow: "⟶",
  Rightarrow: "⇒",
  Longrightarrow: "⟹",
  implies: "⇒",
  leftarrow: "←",
  longleftarrow: "⟵",
  Leftarrow: "⇐",
  Longleftarrow: "⟸",
  leftrightarrow: "↔",
  longleftrightarrow: "⟷",
  Leftrightarrow: "⇔",
  Longleftrightarrow: "⟺",
  rightleftarrows: "⇄",
  leftrightarrows: "⇆",
  rightleftharpoons: "⇌",
  leftrightharpoons: "⇋",
};

// These are the commands most often damaged by JSON/string escaping in saved
// assistant responses. Restricting the list avoids changing Windows paths or
// prose containing an intentional pair of backslashes.
const COMMON_TEX_COMMANDS = new Set([
  ...Object.keys(ARROW_COMMANDS),
  "alpha",
  "beta",
  "gamma",
  "delta",
  "epsilon",
  "theta",
  "lambda",
  "mu",
  "pi",
  "sigma",
  "phi",
  "omega",
  "infty",
  "cdot",
  "times",
  "pm",
  "mp",
  "leq",
  "geq",
  "neq",
  "approx",
  "equiv",
  "sqrt",
  "frac",
  "dfrac",
  "tfrac",
  "sum",
  "prod",
  "int",
  "partial",
  "nabla",
  "mathrm",
  "mathbf",
  "mathbb",
  "text",
  "left",
  "right",
]);

function normalizeDoubleEscapedTeX(source: string): string {
  let text = source
    // A response serialized as "\\\\[...\\\\]" should still become a
    // display-math delimiter after code spans have been protected.
    .replace(/\\{2,}(\[|\]|\(|\))/g, "\\$1")
    .replace(/\\{2,}([A-Za-z]+)(?![A-Za-z])/g, (match, command: string) =>
      COMMON_TEX_COMMANDS.has(command) ? `\\${command}` : match
    );
  return text;
}

const CURRENCY_SEQUENCE =
  /\$\s?\d[\d,]*(?:\.\d{1,2})?(?:\s*(?:and|or|to|[-–—/])\s*\$?\s?\d[\d,]*(?:\.\d{1,2})?)+/gi;

function restorePlaceholders(text: string, saved: string[]): string {
  return text.replace(
    /\uE000(\d+)\uE001/g,
    (_, index: string) => saved[Number(index)] ?? ""
  );
}

function replaceStandaloneArrows(source: string): string {
  return source.replace(
    /\\+([A-Za-z]+)(?![A-Za-z])/g,
    (match, command: string) => ARROW_COMMANDS[command] ?? match
  );
}

function isEscaped(source: string, index: number): boolean {
  let slashes = 0;
  for (let cursor = index - 1; cursor >= 0 && source[cursor] === "\\"; cursor--)
    slashes++;
  return slashes % 2 === 1;
}

function hasMathSignal(inner: string): boolean {
  const trimmed = inner.trim();
  if (!trimmed || /\r?\n/.test(trimmed)) return false;
  if (/[=+*/^_{}[\]<>]/.test(trimmed) || /\\[A-Za-z]+/.test(trimmed))
    return true;
  if (/^(?:\d[\d,.]*[A-Za-z][A-Za-z\d]*|[A-Za-z][A-Za-z\d]*)$/.test(trimmed))
    return true;
  return /^\d[\d,.]*$/.test(trimmed);
}

function looksLikeCurrencyText(inner: string): boolean {
  const trimmed = inner.trim();
  return (
    /^\d[\d,.]*(?:\s|[;:,.!?])/.test(trimmed) &&
    /[A-Za-z]/.test(trimmed) &&
    !/[=+*/^_{}[\]<>\\]/.test(trimmed)
  );
}

function normalizeSingleDollarMath(
  source: string,
  protect: (value: string) => string
): string {
  let output = "";
  let index = 0;
  while (index < source.length) {
    if (source[index] !== "$" || isEscaped(source, index)) {
      output += source[index];
      index++;
      continue;
    }
    let close = -1;
    for (let cursor = index + 1; cursor < source.length; cursor++) {
      if (source[cursor] === "$" && !isEscaped(source, cursor)) {
        close = cursor;
        break;
      }
    }
    if (close < 0) {
      output += "\\$";
      index++;
      continue;
    }
    const inner = source.slice(index + 1, close);
    if (hasMathSignal(inner) && !looksLikeCurrencyText(inner)) {
      output += protect(source.slice(index, close + 1));
      index = close + 1;
    } else {
      output += "\\$";
      index++;
    }
  }
  return output;
}

/**
 * Normalize assistant/source markdown for both React KaTeX and the PDF
 * renderer without changing fenced/inline code or literal currency.
 *
 * Delimited math stays delimited so KaTeX can render it. Arrow commands that
 * are not inside math are converted to Unicode because a raw `\\rightarrow`
 * is otherwise displayed as source text in tables, saved equations, and chat.
 */
export function normalizeMathMarkdown(source: string): string {
  const saved: string[] = [];
  const protect = (value: string) => `\uE000${saved.push(value) - 1}\uE001`;
  let text = source.replace(/```[\s\S]*?```|`[^`\n]*`/g, protect);
  text = text.replace(CURRENCY_SEQUENCE, match => match.replace(/\$/g, "\\$"));
  text = normalizeDoubleEscapedTeX(text);

  text = text.replace(/\\\[([\s\S]*?)\\\]/g, (_, inner: string) =>
    protect(`\n\n$$${inner.trim()}$$\n\n`)
  );
  text = text.replace(/\\\(([^\n]*?)\\\)/g, (_, inner: string) =>
    protect(`$${inner}$`)
  );
  text = text.replace(/(?<!\\)\$\$[\s\S]*?\$\$/g, protect);
  text = normalizeSingleDollarMath(text, protect);

  // Escape any remaining dollar followed by a number. Existing escaped
  // dollars and code placeholders are left alone; a closing dollar from a
  // real math span was already protected above.
  text = text.replace(/(?<![\\$])\$(?!\$)(?=\s?\d)/g, "\\$");
  text = replaceStandaloneArrows(text);
  return restorePlaceholders(text, saved);
}

/** Normalize text rendered by the SVG whiteboard, which cannot host KaTeX. */
export function normalizeStandaloneMathText(source: string): string {
  const saved: string[] = [];
  const protect = (value: string) => `\uE000${saved.push(value) - 1}\uE001`;
  let text = source.replace(/```[\s\S]*?```|`[^`\n]*`/g, protect);
  text = normalizeDoubleEscapedTeX(text);
  text = replaceStandaloneArrows(text);
  return restorePlaceholders(text, saved);
}
export function languageDirection(language: string): "rtl" | "ltr" {
  if (/-Latn(?:-|$)/i.test(language)) return "ltr";
  return /-Arab(?:-|$)/i.test(language) ||
    /^(?:ar|fa|he|ur|ps|sd|ug|yi)(?:-|$)/i.test(language) ||
    /^(?:arabic|persian|hebrew|urdu|pashto|sindhi|uyghur|yiddish)$/i.test(
      language
    )
    ? "rtl"
    : "ltr";
}
export function escapeAttribute(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
