/**
 * The only identity allowed to enter the locked Videos, Operations, and Upgrade
 * areas. This is intentionally email-based on the server's authenticated user
 * record, never on client input, localStorage, or a role flag.
 */
export const LOCKED_OWNER_EMAIL = "adammalaeb30@gmail.com";

export function normalizeEmail(value: unknown): string {
  return typeof value === "string" ? value.trim().toLowerCase() : "";
}

export function isLockedOwnerEmail(value: unknown): boolean {
  return normalizeEmail(value) === LOCKED_OWNER_EMAIL;
}

export type AuthenticatedIdentity = {
  email?: string | null;
};

export function isLockedOwner(identity: AuthenticatedIdentity | null | undefined): boolean {
  return isLockedOwnerEmail(identity?.email);
}
