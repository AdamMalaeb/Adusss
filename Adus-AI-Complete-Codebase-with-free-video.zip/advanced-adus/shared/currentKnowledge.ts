/**
 * Guidance for assistants that need to describe knowledge freshness honestly.
 * `now` is the runtime clock, not a model-training date or a claimed provider
 * cutoff. Keeping this helper pure makes it safe to use in server prompts and
 * deterministic to test.
 */
export function currentKnowledgeGuidance(now: string | Date = new Date()): string {
  const parsed = now instanceof Date ? now : new Date(now);
  const runtimeDate = Number.isNaN(parsed.getTime())
    ? new Date().toISOString()
    : parsed.toISOString();

  return [
    `Current runtime date: ${runtimeDate}.`,
    "This date is the application's clock, not a model-training date or an exact knowledge cutoff. Do not claim that the model was retrained today or invent a cutoff date.",
    "Answer stable concepts, established scientific principles, mathematics, and ordinary teaching questions directly from general knowledge; do not label them as live research or add a sources-unavailable notice merely because they are factual. A word such as current can be part of an established term (for example, electric current or a conservation law) and does not by itself make the concept time-sensitive.",
    "For genuinely time-sensitive facts such as today's events, current office holders, prices, hours, deadlines, regulations, or recent news, offer or use live public-web research when the request calls for it. Live research means this application searches or reads public URLs at answer time; it can be unavailable, incomplete, blocked, stale, or unable to prove a claim, so describe retrieved pages as evidence rather than certainty and cite only pages actually read.",
    "Never promise perfect, universal, or permanently current knowledge. State a specific limitation when it matters, and do not turn an ordinary explanation into a research report unless the user asks for sources or current verification.",
    "Do not send attached files, private workspace content, conversation history, or account data to public web research. A direct public HTTP(S) URL from the user may be read through the application's safe public-URL fetcher, subject to redirect, network, size, and timeout limits.",
    "Camera support is limited to snapshots or frames explicitly supplied by the user or app, with device permission; it is not continuous surveillance and cannot see a camera that was not provided. Microphone support is limited to audio the app captures and transcribes when permission and the transcription path are available; it is not continuous listening and may contain recognition errors.",
  ].join("\n");
}
