export type TimingAlignment = "estimated";

export type LessonBoardActionType =
  | "write"
  | "draw"
  | "link"
  | "highlight"
  | "erase";

export type LessonBoardPoint = {
  /** Board-relative coordinate, normalized to the range 0..1. */
  x: number;
  /** Board-relative coordinate, normalized to the range 0..1. */
  y: number;
};

/**
 * Content-specific instructions for the deterministic board renderer. The
 * narration remains the timing authority; actions are visual annotations, not
 * a second script. Coordinates are normalized so the browser and MP4 renderer
 * stay in lockstep at different sizes.
 */
export type LessonBoardAction = {
  type: LessonBoardActionType;
  shape?:
    | "line"
    | "wave"
    | "circle"
    | "rectangle"
    | "triangle"
    | "axis"
    | "curve";
  text?: string;
  from?: LessonBoardPoint;
  to?: LessonBoardPoint;
  /** Text or label that a highlight/erase action refers to. */
  target?: string;
  emphasis?: "normal" | "accent" | "warning";
};

export type LessonPhraseCue = {
  text: string;
  start: number;
  end: number;
  /** This project has no provider word timestamps; these cues are proportional estimates. */
  alignment: TimingAlignment;
};

export type LessonTimingScene = {
  start: number;
  end: number;
  duration: number;
  cues: LessonPhraseCue[];
  cueAlignment: TimingAlignment;
};

export type LessonTimingInput = {
  narration: string;
};

const MIN_TIMELINE_SECONDS = 0.1;
const MIN_CUE_SECONDS = 0.001;

function clamp(value: number, min = 0, max = 1): number {
  return Math.max(min, Math.min(max, value));
}

function cleanText(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

/** Split spoken text into readable phrase-sized units without pretending they are word alignments. */
export function splitNarrationPhrases(narration: string): string[] {
  const text = cleanText(narration);
  if (!text) return [];

  // Keep punctuation with its phrase without relying on lookbehind or newer
  // RegExp flags: this project also type-checks with the default ES target.
  const phrases: string[] = [];
  let phraseStart = 0;
  for (let index = 0; index < text.length; index += 1) {
    if (!/[.!?؟。！？;；:]/.test(text[index]!)) continue;
    let next = index + 1;
    while (/\s/.test(text[next] ?? "")) next += 1;
    if (next > index + 1 && next < text.length) {
      phrases.push(text.slice(phraseStart, index + 1).trim());
      phraseStart = next;
      index = next - 1;
    }
  }
  phrases.push(text.slice(phraseStart).trim());
  return phrases.length ? phrases : [text];
}

function phraseWeight(phrase: string): number {
  // Character weight prevents a long unspaced Arabic phrase from receiving a
  // near-zero cue while words keep ordinary prose proportional to speech.
  const words = phrase.split(/\s+/).filter(Boolean).length;
  return Math.max(1, words, Math.ceil(phrase.length / 18));
}

export function narrationWeight(narration: string): number {
  return Math.max(
    1,
    splitNarrationPhrases(narration).reduce(
      (sum, phrase) => sum + phraseWeight(phrase),
      0
    )
  );
}

export function buildPhraseCues(
  narration: string,
  duration: number
): LessonPhraseCue[] {
  const phrases = splitNarrationPhrases(narration);
  if (!phrases.length) return [];
  const safeDuration = Math.max(
    MIN_TIMELINE_SECONDS,
    Number.isFinite(duration) ? duration : MIN_TIMELINE_SECONDS
  );
  const totalWeight = phrases.reduce(
    (sum, phrase) => sum + phraseWeight(phrase),
    0
  );
  let start = 0;
  return phrases.map((text, index) => {
    const end =
      index === phrases.length - 1
        ? safeDuration
        : start + (safeDuration * phraseWeight(text)) / totalWeight;
    const cue = {
      text,
      start,
      end: Math.max(start + MIN_CUE_SECONDS, end),
      alignment: "estimated" as const,
    };
    start = cue.end;
    return cue;
  });
}

/**
 * Build one timeline for both the browser and deterministic exporter.
 * Scene boundaries are proportional to narration weight and then normalized to
 * the measured audio duration. The cue metadata is explicitly estimated until
 * a provider supplies real alignment timestamps.
 */
export function buildLessonTiming<T extends LessonTimingInput>(
  scenes: T[],
  audioDuration?: number
): Array<T & LessonTimingScene & { index: number }> {
  const estimatedWeights = scenes.map(scene =>
    narrationWeight(scene.narration)
  );
  const totalWeight =
    estimatedWeights.reduce((sum, value) => sum + value, 0) || 1;
  const safeDuration = Math.max(
    MIN_TIMELINE_SECONDS,
    Number.isFinite(audioDuration) && (audioDuration ?? 0) > 0
      ? (audioDuration as number)
      : estimatedWeights.reduce(
          (sum, value) => sum + Math.max(2.25, value / 2.65),
          0
        ) || MIN_TIMELINE_SECONDS
  );

  let start = 0;
  return scenes.map((scene, index) => {
    const end =
      index === scenes.length - 1
        ? safeDuration
        : start + (safeDuration * estimatedWeights[index]!) / totalWeight;
    const duration = Math.max(MIN_CUE_SECONDS, end - start);
    const cues = buildPhraseCues(scene.narration, duration);
    const item = {
      ...scene,
      index,
      start,
      end,
      duration,
      cues,
      cueAlignment: "estimated" as const,
    };
    start = end;
    return item;
  });
}

export function sceneProgressAt(
  scene: Pick<LessonTimingScene, "start" | "duration">,
  time: number
): number {
  if (!Number.isFinite(time)) return 0;
  return clamp(
    (time - scene.start) / Math.max(MIN_CUE_SECONDS, scene.duration)
  );
}

export function findLessonScene<T extends LessonTimingScene>(
  timeline: T[],
  time: number
): { scene: T | undefined; index: number; local: number } {
  if (!timeline.length) return { scene: undefined, index: 0, local: 0 };
  const safeTime = Math.max(0, Number.isFinite(time) ? time : 0);
  const index = timeline.findIndex(item => safeTime < item.end);
  const selectedIndex = index === -1 ? timeline.length - 1 : index;
  const scene = timeline[selectedIndex];
  return {
    scene,
    index: selectedIndex,
    local: sceneProgressAt(scene, safeTime),
  };
}

export function cueProgressAt(
  cues: LessonPhraseCue[],
  localProgress: number
): { cueIndex: number; phraseProgress: number } {
  if (!cues.length)
    return { cueIndex: 0, phraseProgress: clamp(localProgress) };
  const safe = clamp(localProgress);
  const time = safe * (cues.at(-1)?.end ?? 0);
  const index = cues.findIndex(cue => time < cue.end);
  const cueIndex = index === -1 ? cues.length - 1 : index;
  const cue = cues[cueIndex]!;
  return {
    cueIndex,
    phraseProgress: clamp(
      (time - cue.start) / Math.max(MIN_CUE_SECONDS, cue.end - cue.start)
    ),
  };
}

/** Convert scene-local audio progress into the board's erase/write reveal. */
export function whiteboardErasePhase(cues: LessonPhraseCue[]): number {
  const seconds = cues.at(-1)?.end ?? 6;
  return Math.min(0.04, 0.25 / Math.max(0.1, seconds));
}

export function whiteboardRevealAt(
  cues: LessonPhraseCue[],
  localProgress: number
): number {
  const progress = clamp(localProgress);
  const erasePhase = whiteboardErasePhase(cues);
  if (progress < erasePhase) return 0;
  // Complete writing early so explanations never end on a half-written board.
  const writingProgress = clamp((progress - erasePhase) / (0.85 - erasePhase));
  if (!cues.length) return writingProgress;
  const cue = cueProgressAt(cues, writingProgress);
  return clamp((cue.cueIndex + cue.phraseProgress) / cues.length);
}

/**
 * Turn the audio-clock-derived board reveal into progressive action state.
 * This intentionally does not invent word timestamps: the caller supplies
 * progress from the measured audio clock and this helper only distributes the
 * finite visual actions across that already-estimated reveal.
 */
export function boardActionProgressAt(
  actions: readonly LessonBoardAction[],
  reveal: number
): { visibleCount: number; activeIndex: number; activeProgress: number } {
  if (!actions.length)
    return { visibleCount: 0, activeIndex: -1, activeProgress: 0 };
  const scaled = clamp(reveal) * actions.length;
  const visibleCount = Math.min(actions.length, Math.ceil(scaled));
  const activeIndex = Math.min(actions.length - 1, Math.floor(scaled));
  return {
    visibleCount,
    activeIndex,
    activeProgress: scaled >= actions.length ? 1 : clamp(scaled - activeIndex),
  };
}

export function timelineDuration(
  timeline: Array<Pick<LessonTimingScene, "end">>
): number {
  return timeline.at(-1)?.end ?? 0;
}
