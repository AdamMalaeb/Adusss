import { z } from "zod";
import { languageSelectionSchema } from "./languages";

/** User-provided brief used to generate a business plan. Never store private data in public research queries. */
export const businessInputSchema = z.object({
  idea: z.string().trim().min(4).max(4000),
  countryOrMarket: z.string().trim().min(2).max(160),
  budget: z.number().finite().nonnegative().max(1_000_000_000_000).optional(),
  currency: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{3}$/, "Currency must be a 3-letter ISO code")
    .default("USD"),
  customer: z.string().trim().min(2).max(1200),
  experience: z.string().trim().min(2).max(1200),
  researchLocalMarket: z.boolean().default(false),
  /** Auto follows the language used in the brief; supported catalogue values are explicit alternatives. */
  language: z.union([z.literal("auto"), languageSelectionSchema]).default("auto"),
});
export type BusinessInput = z.infer<typeof businessInputSchema>;

export const planSectionSchema = z.object({
  overview: z.string().min(1).max(4000),
  actions: z.array(z.string().min(1).max(500)).min(1).max(8),
}).strict();

export const competitorSchema = z.object({
  name: z.string().min(1).max(160),
  positioning: z.string().min(1).max(600),
  watchout: z.string().min(1).max(600),
}).strict();

export const swotSchema = z.object({
  strengths: z.array(z.string().min(1).max(400)).min(1).max(8),
  weaknesses: z.array(z.string().min(1).max(400)).min(1).max(8),
  opportunities: z.array(z.string().min(1).max(400)).min(1).max(8),
  threats: z.array(z.string().min(1).max(400)).min(1).max(8),
}).strict();

export const milestoneSchema = z.object({
  horizon: z.string().min(1).max(100),
  objective: z.string().min(1).max(500),
  checks: z.array(z.string().min(1).max(400)).min(1).max(6),
}).strict();

export const riskSchema = z.object({
  risk: z.string().min(1).max(500),
  mitigation: z.string().min(1).max(600),
  signal: z.string().min(1).max(400),
}).strict();

export const rubricFactorKeySchema = z.enum([
  "problemClarity",
  "customerSpecificity",
  "marketAccess",
  "differentiation",
  "operationalReadiness",
  "economics",
  "validationEvidence",
]);
export type RubricFactorKey = z.infer<typeof rubricFactorKeySchema>;

export type RubricFactorDefinition = {
  key: RubricFactorKey;
  label: string;
  weight: number;
  anchor: string;
};

/** Weights sum to 100; scores are rubric observations, not probabilities. */
export const RUBRIC_FACTOR_DEFINITIONS: readonly RubricFactorDefinition[] = [
  {
    key: "problemClarity",
    label: "Problem clarity",
    weight: 15,
    anchor: "Specific, urgent problem with a clear outcome and user pain.",
  },
  {
    key: "customerSpecificity",
    label: "Customer specificity",
    weight: 15,
    anchor: "Reachable customer segment and credible buying context.",
  },
  {
    key: "marketAccess",
    label: "Market access",
    weight: 15,
    anchor: "Plausible channels, geography fit, and permission to reach buyers.",
  },
  {
    key: "differentiation",
    label: "Differentiation",
    weight: 15,
    anchor: "Defensible or testable reason to choose this offer over alternatives.",
  },
  {
    key: "operationalReadiness",
    label: "Operational readiness",
    weight: 15,
    anchor: "Founder capability, delivery process, and manageable first scope.",
  },
  {
    key: "economics",
    label: "Economics",
    weight: 15,
    anchor: "A path to contribution margin and cash discipline; unknowns reduce score.",
  },
  {
    key: "validationEvidence",
    label: "Validation evidence",
    weight: 10,
    anchor: "Evidence from interviews, pilots, pre-orders, or retrieved public context.",
  },
] as const;

export const rubricFactorSchema = z.object({
  key: rubricFactorKeySchema,
  label: z.string().min(1).max(120),
  score: z.number().finite().min(0).max(100),
  weight: z.number().finite().positive().max(100),
  evidence: z.string().min(1).max(600),
  missingInfo: z.array(z.string().min(1).max(300)).max(6),
}).strict();

/** Unit economics deliberately starts with nulls unless the user supplies assumptions. */
export const unitEconomicsSchema = z.object({
  currency: z.string().regex(/^[A-Z]{3}$/),
  pricePerCustomer: z.number().finite().nonnegative().nullable(),
  customersPerMonth: z.number().finite().nonnegative().nullable(),
  variableCostPerCustomer: z.number().finite().nonnegative().nullable(),
  fixedCostsPerMonth: z.number().finite().nonnegative().nullable(),
  note: z.string().min(1).max(600),
}).strict();

export const sourceSchema = z.object({
  title: z.string().min(1).max(240),
  url: z.string().url().max(2000),
  excerpt: z.string().min(1).max(1400),
}).strict();

export const businessPlanSchema = z.object({
  title: z.string().min(1).max(180),
  executiveSummary: z.string().min(1).max(1600),
  strategy: planSectionSchema,
  customer: planSectionSchema,
  market: planSectionSchema,
  competitors: z.array(competitorSchema).min(1).max(8),
  swot: swotSchema,
  operatingStructure: planSectionSchema,
  marketing: planSectionSchema,
  milestones: z.array(milestoneSchema).min(1).max(8),
  risks: z.array(riskSchema).min(1).max(8),
  practicalAdvice: z.array(z.string().min(1).max(600)).min(1).max(10),
  /** Facts supplied by the brief or retrieved sources; never mix these with assumptions. */
  knownFacts: z.array(z.string().min(1).max(500)).max(12).default([]),
  assumptions: z.array(z.string().min(1).max(500)).min(1).max(12),
  missingInformation: z.array(z.string().min(1).max(400)).max(12),
  rubricFactors: z.array(rubricFactorSchema).length(7),
  feasibilityScore: z.number().finite().min(0).max(100),
  unitEconomics: unitEconomicsSchema,
  sources: z.array(sourceSchema).max(8),
  researchStatus: z.enum(["not_requested", "verified", "unavailable"]),
  /** Output choice is persisted on the plan as well as the input for restore/revision continuity. */
  language: z.union([z.literal("auto"), languageSelectionSchema]).default("auto"),
  generatedAt: z.string().datetime({ offset: true }),
}).strict();
export type BusinessPlan = z.infer<typeof businessPlanSchema>;

export const businessRecordSchema = z.object({
  input: businessInputSchema,
  plan: businessPlanSchema,
  score: z.number().finite().min(0).max(100),
  generatedAt: z.string().datetime({ offset: true }),
  model: z.string().min(1).max(160),
  revisionOf: z.string().max(64).optional(),
  reviseInstruction: z.string().max(4000).optional(),
}).strict();
export type BusinessRecord = z.infer<typeof businessRecordSchema>;

export type BusinessHistoryItem = {
  id: string;
  title: string;
  score: number;
  generatedAt: string;
  idea: string;
  countryOrMarket: string;
  revisionOf?: string;
  createdAt?: number;
  updatedAt?: number;
};

const clampScore = (value: number) =>
  Math.min(100, Math.max(0, Number.isFinite(value) ? value : 0));

/**
 * Deterministic weighted average used by the server and tests. Weights are
 * normalized, so callers may pass a subset or custom weights without changing
 * the 0–100 score scale. This is never a success probability.
 */
export function calculateFeasibilityScore(
  factors: ReadonlyArray<{ score: number; weight: number }>
): number {
  const valid = factors.filter(
    factor =>
      Number.isFinite(factor.score) &&
      Number.isFinite(factor.weight) &&
      factor.weight > 0
  );
  if (!valid.length) return 0;
  const totalWeight = valid.reduce((sum, factor) => sum + factor.weight, 0);
  const weighted = valid.reduce(
    (sum, factor) => sum + clampScore(factor.score) * factor.weight,
    0
  );
  return Math.round((weighted / totalWeight) * 100) / 100;
}

export function rubricFactorsWithFixedWeights(
  factors: ReadonlyArray<z.infer<typeof rubricFactorSchema>>
) {
  const byKey = new Map(factors.map(factor => [factor.key, factor]));
  return RUBRIC_FACTOR_DEFINITIONS.map(definition => {
    const source = byKey.get(definition.key);
    return {
      key: definition.key,
      label: definition.label,
      score: clampScore(source?.score ?? 0),
      weight: definition.weight,
      evidence:
        source?.evidence ??
        "Not enough information was supplied to assess this factor.",
      missingInfo: source?.missingInfo ?? ["Collect evidence before relying on this factor."],
    };
  });
}
