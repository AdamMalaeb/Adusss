import { z } from "zod";

export const POWERPOINT_KIND = "powerpoint" as const;
export const POWERPOINT_DRAFT_KIND = "powerpointDraft" as const;
export const POWERPOINT_TASK_KIND = "powerpointTask" as const;
export const MAX_PPTX_BYTES = 20 * 1024 * 1024;
export const MAX_DATA_URL_CHARS = 28_000_000;
export const MAX_PICTURE_DATA_URL_CHARS = 12_000_000;
export const MAX_OUTLINE_ENTRIES = 12;
export const MAX_PICTURES = 6;

export const powerpointLanguageSchema = z.enum([
  "English",
  "Spanish",
  "French",
  "Arabic",
  "German",
  "Portuguese",
  "Japanese",
  "Korean",
  "Chinese",
]);
export type PowerPointLanguage = z.infer<typeof powerpointLanguageSchema>;

export const powerpointStyleSchema = z.enum([
  "Executive clarity",
  "Editorial narrative",
  "Modern minimal",
  "Warm workshop",
  "Technical briefing",
]);
export type PowerPointStyle = z.infer<typeof powerpointStyleSchema>;

export const powerpointOutlineEntrySchema = z.object({
  id: z.string().regex(/^[a-z0-9][a-z0-9_-]{0,47}$/i),
  title: z.string().trim().min(1).max(160),
  summary: z.string().trim().max(600).default(""),
  bullets: z.array(z.string().trim().min(1).max(240)).max(5).default([]),
  sourceFacts: z.array(z.string().trim().min(1).max(400)).max(8).default([]),
});
export type PowerPointOutlineEntry = z.infer<
  typeof powerpointOutlineEntrySchema
>;

export const powerpointOutlineSchema = z
  .array(powerpointOutlineEntrySchema)
  .min(4)
  .max(MAX_OUTLINE_ENTRIES);
export type PowerPointOutline = z.infer<typeof powerpointOutlineSchema>;

export const powerpointPictureSchema = z.object({
  filename: z.string().trim().min(1).max(255),
  mimeType: z
    .string()
    .trim()
    .regex(/^image\/(?:png|jpe?g|webp|gif)$/i, "Choose a PNG, JPEG, WebP, or GIF image."),
  dataUrl: z.string().min(1).max(MAX_PICTURE_DATA_URL_CHARS),
});
export type PowerPointPicture = z.infer<typeof powerpointPictureSchema>;

/**
 * The one-step UI contract. `allowPictures` is deliberately false by default:
 * a picture may be used only when this toggle or an explicit prompt request opts in.
 */
export const powerpointGenerationRequestSchema = z.object({
  prompt: z.string().trim().min(2).max(12_000),
  slideCount: z.number().int().min(4).max(MAX_OUTLINE_ENTRIES),
  effectsPrompt: z.string().trim().max(2_000).default(""),
  allowPictures: z.boolean().default(false),
  pictures: z.array(powerpointPictureSchema).max(MAX_PICTURES).default([]),
});
export type PowerPointGenerationRequest = z.infer<
  typeof powerpointGenerationRequestSchema
>;

export const powerpointDraftSchema = z.object({
  title: z.string().trim().min(1).max(200),
  topic: z.string().trim().min(1).max(240),
  audience: z.string().trim().min(1).max(240),
  language: powerpointLanguageSchema,
  style: powerpointStyleSchema,
  slideCount: z.number().int().min(4).max(12),
  outline: powerpointOutlineSchema,
  sourceFacts: z.array(z.string().trim().min(1).max(600)).max(40).default([]),
  /** Original user request retained so the Slides agent receives the exact intent. */
  prompt: z.string().trim().max(12_000).default(""),
  effectsPrompt: z.string().trim().max(2_000).default(""),
  allowPictures: z.boolean().default(false),
  pictureFilenames: z.array(z.string().trim().min(1).max(255)).max(MAX_PICTURES).default([]),
});
export type PowerPointDraft = z.infer<typeof powerpointDraftSchema>;

/** Legacy source contract retained for existing reviewed-deck callers. */
export const powerpointSourceSchema = z.object({
  filename: z.string().trim().min(1).max(255),
  mimeType: z.literal(
    "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  ),
  dataUrl: z.string().min(1).max(MAX_DATA_URL_CHARS),
  outline: z
    .array(powerpointOutlineEntrySchema)
    .max(MAX_OUTLINE_ENTRIES)
    .optional(),
});
export type PowerPointSource = z.infer<typeof powerpointSourceSchema>;

export const powerpointTaskStateSchema = z.enum([
  "queued",
  "running",
  "waiting_input",
  "waiting_action",
  "completed",
  "failed",
  "unknown",
]);
export type PowerPointTaskState = z.infer<typeof powerpointTaskStateSchema>;

export type PowerPointAttachment = {
  filename?: string;
  path?: string;
  url?: string;
  content_type?: string;
  file_uid?: string;
  version_uid?: string;
};

export type PowerPointTaskRecord = {
  /** Workspace record ID, not the Manus task ID. Used to poll the owned record. */
  recordId?: string;
  taskId: string;
  taskUrl: string;
  title: string;
  draft: PowerPointDraft;
  sourceFilename?: string;
  sourceFileId?: string;
  pictureFilenames?: string[];
  pictureFileIds?: string[];
  skillId?: string;
  state: PowerPointTaskState;
  statusMessage?: string;
  waitingForEventType?: string;
  waitingForEventId?: string;
  output?: {
    filename: string;
    url: string;
    key: string;
    bytes: number;
    createdAt: number;
  };
  updatedAt: number;
};

export type PowerPointOutputRecord = {
  taskRecordId: string;
  taskId: string;
  filename: string;
  url: string;
  key: string;
  bytes: number;
  createdAt: number;
};

export type PowerPointHistoryItem = {
  id: string;
  kind: typeof POWERPOINT_TASK_KIND | typeof POWERPOINT_KIND;
  payload: PowerPointTaskRecord | PowerPointOutputRecord;
  updatedAt: number;
};

export function normalizeOutlineEntry(
  entry: Partial<PowerPointOutlineEntry>,
  index: number
): PowerPointOutlineEntry {
  return powerpointOutlineEntrySchema.parse({
    id: entry.id?.trim() || `slide-${index + 1}`,
    title: entry.title?.trim() || `Slide ${index + 1}`,
    summary: entry.summary?.trim() || "",
    bullets: (entry.bullets ?? []).map(value => value.trim()).filter(Boolean),
    sourceFacts: (entry.sourceFacts ?? [])
      .map(value => value.trim())
      .filter(Boolean),
  });
}

export function safeTaskUrl(taskId: string): string {
  return `https://manus.im/app/${encodeURIComponent(taskId)}`;
}
