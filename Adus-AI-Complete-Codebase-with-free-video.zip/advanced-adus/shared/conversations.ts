export type ConversationRole = "user" | "assistant";

export type ConversationAttachment = {
  name: string;
  mimeType: string;
  size?: number;
  key?: string;
  url?: string;
  reference?: string;
};

export type ConversationMessage = {
  id: string;
  /** Stable client-generated key; repeated appends with the same id are no-ops. */
  requestId?: string;
  role: ConversationRole;
  content: string;
  createdAt: number;
  imageUrl?: string;
  openBuilder?: boolean;
  builderBrief?: string;
  attachmentName?: string;
  attachmentUrl?: string;
  agent?: string;
  research?: {
    status: "retrieved" | "unavailable";
    checkedAt: number;
    engine: string;
    searchSuggestions?: string;
  };
  attachments?: ConversationAttachment[];
};

export type ConversationPayload = {
  version: 1;
  title: string;
  messages: ConversationMessage[];
  createdAt: number;
  updatedAt: number;
  /** Soft-deleted conversations remain restorable but are hidden from normal reads. */
  archived?: boolean;
  archivedAt?: number;
};

export type ConversationSummary = {
  id: string;
  title: string;
  preview: string;
  messageCount: number;
  createdAt: number;
  updatedAt: number;
};

export const EMPTY_CONVERSATION_TITLE = "New conversation";
export const MAX_CONTEXT_MESSAGES = 25;
