/**
 * Free video mode: pure helpers shared by server, client and tests.
 * No relative imports on purpose, so this file stays trivially testable.
 */

export const FREE_VIDEO_MIN_SECONDS = 15;
export const FREE_VIDEO_MAX_SECONDS = 60;
export const FREE_VIDEO_MAX_INPUT_CHARS = 2_000;
export const FREE_VIDEO_MAX_SCENES = 8;
export const FREE_VIDEO_DEFAULT_DAILY_LIMIT = 3;
/** Average reading/speaking pace used only to size silent videos and scenes. */
export const WORDS_PER_SECOND = 2.6;

export type FreeVideoGender = "woman" | "man";

export type EdgeVoice = {
  ShortName: string;
  Gender: string;
  Locale: string;
};

/** Number of words, treating CJK/Thai/etc. (no spaces) as ~2 chars per word. */
export function countWords(text: string): number {
  const clean = text.trim();
  if (!clean) return 0;
  const spaced = clean.split(/\s+/).filter(Boolean).length;
  const noSpaceScript =
    /[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af\u0e00-\u0e7f\u0e80-\u0eff\u1000-\u109f\u1780-\u17ff]/.test(
      clean
    );
  return noSpaceScript
    ? Math.max(spaced, Math.ceil(clean.replace(/\s+/g, "").length / 2))
    : spaced;
}

export function estimateSeconds(text: string): number {
  return countWords(text) / WORDS_PER_SECOND;
}

export function clampDuration(seconds: number): number {
  if (!Number.isFinite(seconds)) return FREE_VIDEO_MIN_SECONDS;
  return Math.min(
    FREE_VIDEO_MAX_SECONDS,
    Math.max(FREE_VIDEO_MIN_SECONDS, Math.round(seconds))
  );
}

/** Split text into sentences, keeping CJK and Arabic/Devanagari terminators. */
export function splitSentences(text: string): string[] {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return [];
  const parts = clean.match(/[^.!?。！？؟।\n]+[.!?。！？؟।]*/g) ?? [clean];
  return parts.map(part => part.trim()).filter(Boolean);
}

/**
 * Group sentences into 1..FREE_VIDEO_MAX_SCENES scenes of roughly equal length.
 * Never drops text: every sentence lands in exactly one scene.
 */
export function splitIntoScenes(text: string, targetSceneSeconds = 8): string[] {
  const sentences = splitSentences(text);
  if (!sentences.length) return [];
  const total = estimateSeconds(sentences.join(" "));
  const wanted = Math.min(
    FREE_VIDEO_MAX_SCENES,
    sentences.length,
    Math.max(1, Math.round(total / targetSceneSeconds))
  );
  const perScene = total / wanted;
  const scenes: string[] = [];
  let current: string[] = [];
  let currentSeconds = 0;
  sentences.forEach((sentence, index) => {
    current.push(sentence);
    currentSeconds += estimateSeconds(sentence);
    const remainingSentences = sentences.length - index - 1;
    const remainingScenes = wanted - scenes.length - 1;
    const mustClose = remainingSentences === remainingScenes;
    if (
      remainingScenes > 0 &&
      (currentSeconds >= perScene || mustClose) &&
      remainingSentences >= remainingScenes
    ) {
      scenes.push(current.join(" "));
      current = [];
      currentSeconds = 0;
    }
  });
  if (current.length) scenes.push(current.join(" "));
  return scenes;
}

/**
 * Split total video seconds across scenes proportionally to their text size.
 * Result always sums to `totalSeconds` (within float rounding) and each scene
 * gets at least 1.5 seconds.
 */
export function allocateSceneSeconds(
  scenes: string[],
  totalSeconds: number
): number[] {
  if (!scenes.length) return [];
  const weights = scenes.map(scene => Math.max(1, countWords(scene)));
  const weightSum = weights.reduce((a, b) => a + b, 0);
  const minEach = 1.5;
  const spare = Math.max(0, totalSeconds - minEach * scenes.length);
  return weights.map(w => minEach + (spare * w) / weightSum);
}

const CODE_ALIASES: Record<string, string> = {
  english: "en",
  french: "fr",
  arabic: "ar",
  "ar-EG": "ar",
  "fa-IR": "fa",
  yue: "zh",
  "yue-Hant": "zh",
  fil: "fil",
};

/** Primary language subtag, e.g. "zh" for "zh-Hant", "ar" for "ar-EG". */
export function primaryLanguage(code: string): string {
  const alias = CODE_ALIASES[code];
  if (alias) return alias;
  return code.split("-")[0]!.toLowerCase();
}

/**
 * Pick a free Edge neural voice for a language and gender. Prefers an exact
 * locale match (e.g. "ar-EG"), then any locale with the same primary subtag.
 * If the language has voices but none of the requested gender, the first
 * voice of that language is returned (check `voiceMatchesGender`). Returns
 * undefined when Edge has no voice for the language at all: the caller must
 * say so rather than silently using another language.
 */
export function pickEdgeVoice(
  voices: EdgeVoice[],
  languageCode: string,
  gender: FreeVideoGender
): EdgeVoice | undefined {
  const wantGender = gender === "man" ? "male" : "female";
  const primary = primaryLanguage(languageCode);
  const sameLanguage = voices.filter(
    v =>
      /Neural$/i.test(v.ShortName) &&
      v.Locale.split("-")[0]!.toLowerCase() === primary
  );
  const exact = sameLanguage.filter(
    v => v.Locale.toLowerCase() === languageCode.toLowerCase()
  );
  const ordered = [...exact, ...sameLanguage];
  return (
    ordered.find(v => v.Gender.toLowerCase() === wantGender) ?? ordered[0]
  );
}

export function voiceMatchesGender(
  voice: EdgeVoice,
  gender: FreeVideoGender
): boolean {
  return voice.Gender.toLowerCase() === (gender === "man" ? "male" : "female");
}

/** UTC day key used for the per-user daily limit. */
export function dayKey(now = Date.now()): string {
  return new Date(now).toISOString().slice(0, 10);
}

export function parseDailyLimit(raw: string | undefined): number {
  const value = Number(raw);
  return Number.isInteger(value) && value > 0 && value <= 100
    ? value
    : FREE_VIDEO_DEFAULT_DAILY_LIMIT;
}

/** Escape text for placement inside SVG/XML. */
export function escapeXml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Greedy word wrap by approximate character width (works for spaced scripts). */
export function wrapText(text: string, maxChars: number): string[] {
  const tokens = /\s/.test(text.trim())
    ? text.trim().split(/\s+/)
    : Array.from(text.trim());
  const joiner = /\s/.test(text.trim()) ? " " : "";
  const lines: string[] = [];
  let line = "";
  for (const token of tokens) {
    const next = line ? `${line}${joiner}${token}` : token;
    if (next.length > maxChars && line) {
      lines.push(line);
      line = token;
    } else {
      line = next;
    }
  }
  if (line) lines.push(line);
  return lines;
}
