import type { LessonBoardAction } from "./lessonTiming";

export const BOARD_SHAPES = [
  "line",
  "wave",
  "circle",
  "rectangle",
  "triangle",
  "axis",
  "curve",
] as const;
export type BoardShape = (typeof BOARD_SHAPES)[number];
const unit = (v: number) =>
  Math.max(0, Math.min(1, Number.isFinite(v) ? v : 0.5));

/** Source-specific geometry, expressed only as normalized coordinates, never raw SVG. */
export function boardDrawingPath(action: LessonBoardAction): string {
  const from = action.from ?? { x: 0.08, y: 0.3 };
  const to = action.to ?? { x: 0.86, y: 0.6 };
  const x = 80 + unit(from.x) * 650,
    y = 112 + unit(from.y) * 290;
  const tx = 80 + unit(to.x) * 650,
    ty = 112 + unit(to.y) * 290;
  const w = tx - x,
    h = ty - y;
  switch (action.shape) {
    case "wave": {
      const mid = (y + ty) / 2,
        amplitude = Math.max(15, Math.abs(h) / 2);
      const quarter = w / 4;
      return `M ${x} ${mid} Q ${x + quarter / 2} ${mid - amplitude * 2} ${x + quarter} ${mid} Q ${x + quarter * 1.5} ${mid + amplitude * 2} ${x + quarter * 2} ${mid} Q ${x + quarter * 2.5} ${mid - amplitude * 2} ${x + quarter * 3} ${mid} Q ${x + quarter * 3.5} ${mid + amplitude * 2} ${tx} ${mid}`;
    }
    case "circle": {
      const rx = Math.max(14, Math.abs(w) / 2),
        ry = Math.max(14, Math.abs(h) / 2),
        cx = (x + tx) / 2,
        cy = (y + ty) / 2;
      return `M ${cx - rx} ${cy} A ${rx} ${ry} 0 1 1 ${cx + rx} ${cy} A ${rx} ${ry} 0 1 1 ${cx - rx} ${cy}`;
    }
    case "rectangle":
      return `M ${x} ${y} L ${tx} ${y} L ${tx} ${ty} L ${x} ${ty} Z`;
    case "triangle":
      return `M ${(x + tx) / 2} ${y} L ${tx} ${ty} L ${x} ${ty} Z`;
    case "axis":
      return `M ${x} ${y} L ${x} ${ty} L ${tx} ${ty}`;
    case "curve":
      return `M ${x} ${y} C ${x + w * 0.2} ${ty} ${x + w * 0.8} ${y} ${tx} ${ty}`;
    default:
      return `M ${x} ${y} L ${tx} ${ty}`;
  }
}

/** Fade matching prior marks as the eraser moves, and keep them erased afterward. */
export function boardActionOpacity(
  actions: readonly LessonBoardAction[],
  index: number,
  reveal: number
): number {
  const action = actions[index];
  if (!action || action.type === "erase") return 1;
  let opacity = 1;
  for (let i = index + 1; i < actions.length; i++) {
    const erase = actions[i]!;
    if (erase.type !== "erase") continue;
    const target = (erase.target ?? "").trim().toLowerCase();
    const label = (action.text ?? action.target ?? "").trim().toLowerCase();
    if (target && target !== "all" && target !== label) continue;
    const progress = unit(reveal * actions.length - i);
    opacity *= 1 - progress;
  }
  return opacity;
}
