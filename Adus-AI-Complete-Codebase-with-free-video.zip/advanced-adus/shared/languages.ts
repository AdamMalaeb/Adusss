import { z } from "zod";

/**
 * Languages published by the configured Gemini 3.8 Flash TTS provider.  The
 * values are display/selection tags (BCP-47 where the provider distinguishes a
 * script or region); the provider detects the spoken language from the text.
 * Keep this list deliberately finite: it is not a claim of universal TTS
 * coverage.
 */
export const LANGUAGE_CATALOGUE = [
  ["ace-Arab", "Acehnese (Arabic script)", "Aceh (Arab)", "Acehnese"],
  ["af", "Afrikaans", "Afrikaans", "Afrikaans"],
  ["ak", "Akan", "Akan", "Akan"],
  ["am", "Amharic", "አማርኛ", "Amharic"],
  ["hy", "Armenian", "Հայերեն", "Armenian"],
  ["as", "Assamese", "অসমীয়া", "Assamese"],
  ["awa", "Awadhi", "अवधी", "Awadhi"],
  ["ban", "Balinese", "Basa Bali", "Balinese"],
  ["bjn-Arab", "Banjarese (Arabic script)", "بهاسا بنجر", "Banjarese"],
  ["bjn-Latn", "Banjarese (Latin script)", "Basa Banjar", "Banjarese"],
  ["ba", "Bashkir", "Башҡортса", "Bashkir"],
  ["eu", "Basque", "Euskara", "Basque"],
  ["be", "Belarusian", "Беларуская", "Belarusian"],
  ["bem", "Bemba", "Ichibemba", "Bemba"],
  ["bho", "Bhojpuri", "भोजपुरी", "Bhojpuri"],
  ["bs", "Bosnian", "Bosanski", "Bosnian"],
  ["bug", "Buginese", "ᨅᨔ ᨕᨘᨁᨗ", "Buginese"],
  ["bg", "Bulgarian", "Български", "Bulgarian"],
  ["my", "Burmese", "မြန်မာ", "Burmese"],
  ["yue", "Cantonese", "粵語", "Cantonese"],
  ["ca", "Catalan", "Català", "Catalan"],
  ["ceb", "Cebuano", "Cebuano", "Cebuano"],
  ["ku", "Central Kurdish", "کوردی ناوەندی", "Central Kurdish"],
  ["hne", "Chhattisgarhi", "छत्तीसगढ़ी", "Chhattisgarhi"],
  ["yue-Hant", "Chinese (traditional characters)", "繁體中文", "Chinese"],
  ["zh", "Chinese (simplified characters)", "简体中文", "Chinese"],
  ["crh", "Crimean Tatar", "Къырымтатарджа", "Crimean Tatar"],
  ["hr", "Croatian", "Hrvatski", "Croatian"],
  ["cs", "Czech", "Čeština", "Czech"],
  ["da", "Danish", "Dansk", "Danish"],
  ["nl", "Dutch", "Nederlands", "Dutch"],
  ["dyu", "Dyula", "Julakan", "Dyula"],
  ["dz", "Dzongkha", "རྫོང་ཁ", "Dzongkha"],
  ["ar-EG", "Egyptian Arabic", "العربية المصرية", "Egyptian Arabic"],
  ["en", "English", "English", "English"],
  ["et", "Estonian", "Eesti", "Estonian"],
  ["fil", "Filipino", "Filipino", "Filipino"],
  ["fi", "Finnish", "Suomi", "Finnish"],
  ["fr", "French", "Français", "French"],
  ["gl", "Galician", "Galego", "Galician"],
  ["lg", "Ganda", "Luganda", "Ganda"],
  ["ka", "Georgian", "ქართული", "Georgian"],
  ["de", "German", "Deutsch", "German"],
  ["el", "Greek", "Ελληνικά", "Greek"],
  ["gn", "Guarani", "Avañe'ẽ", "Guarani"],
  ["gu", "Gujarati", "ગુજરાતી", "Gujarati"],
  ["ht", "Haitian Creole", "Kreyòl ayisyen", "Haitian Creole"],
  ["ha", "Hausa", "Hausa", "Hausa"],
  ["he", "Hebrew", "עברית", "Hebrew"],
  ["hi", "Hindi", "हिन्दी", "Hindi"],
  ["hu", "Hungarian", "Magyar", "Hungarian"],
  ["is", "Icelandic", "Íslenska", "Icelandic"],
  ["ig", "Igbo", "Igbo", "Igbo"],
  ["ilo", "Ilocano", "Ilokano", "Ilocano"],
  ["id", "Indonesian", "Bahasa Indonesia", "Indonesian"],
  ["fa-IR", "Iranian Persian", "فارسی", "Iranian Persian"],
  ["it", "Italian", "Italiano", "Italian"],
  ["ja", "Japanese", "日本語", "Japanese"],
  ["jv", "Javanese", "Basa Jawa", "Javanese"],
  ["kab", "Kabyle", "Taqbaylit", "Kabyle"],
  ["kam", "Kamba", "Kikamba", "Kamba"],
  ["kn", "Kannada", "ಕನ್ನಡ", "Kannada"],
  ["ks-Arab", "Kashmiri (Arabic script)", "کٲشُر", "Kashmiri"],
  ["ks-Deva", "Kashmiri (Devanagari script)", "कॉशुर", "Kashmiri"],
  ["kk", "Kazakh", "Қазақша", "Kazakh"],
  ["km", "Khmer", "ខ្មែរ", "Khmer"],
  ["ki", "Kikuyu", "Gĩkũyũ", "Kikuyu"],
  ["rw", "Kinyarwanda", "Ikinyarwanda", "Kinyarwanda"],
  ["kon", "Kongo", "Kikongo", "Kongo"],
  ["ko", "Korean", "한국어", "Korean"],
  ["ky", "Kyrgyz", "Кыргызча", "Kyrgyz"],
  ["lo", "Lao", "ລາວ", "Lao"],
  ["lv", "Latvian", "Latviešu", "Latvian"],
  ["ln", "Lingala", "Lingála", "Lingala"],
  ["lt", "Lithuanian", "Lietuvių", "Lithuanian"],
  ["ltz", "Luxembourgish", "Lëtzebuergesch", "Luxembourgish"],
  ["mk", "Macedonian", "Македонски", "Macedonian"],
  ["mag", "Magahi", "मगही", "Magahi"],
  ["mai", "Maithili", "मैथिली", "Maithili"],
  ["ml", "Malayalam", "മലയാളം", "Malayalam"],
  ["mt", "Maltese", "Malti", "Maltese"],
  ["mni", "Manipuri", "মৈতৈলোন", "Manipuri"],
  ["mr", "Marathi", "मराठी", "Marathi"],
  ["min-Arab", "Minangkabau (Arabic script)", "ميناڠكاباو", "Minangkabau"],
  ["min-Latn", "Minangkabau (Latin script)", "Baso Minangkabau", "Minangkabau"],
  ["lus", "Mizo", "Mizo ṭawng", "Mizo"],
  ["ne", "Nepali", "नेपाली", "Nepali"],
  ["ff", "Nigerian Fulfulde", "Fulfulde", "Nigerian Fulfulde"],
  ["az", "Northern Azerbaijani", "Azərbaycanca", "Northern Azerbaijani"],
  ["nso", "Northern Sotho", "Sepedi", "Northern Sotho"],
  ["uz", "Northern Uzbek", "O'zbekcha", "Northern Uzbek"],
  ["nb", "Norwegian Bokmål", "Norsk bokmål", "Norwegian Bokmål"],
  ["nn", "Norwegian Nynorsk", "Norsk nynorsk", "Norwegian Nynorsk"],
  ["ny", "Nyanja", "Chichewa", "Nyanja"],
  ["oc", "Occitan", "Occitan", "Occitan"],
  ["or", "Odia", "ଓଡ଼ିଆ", "Odia"],
  ["pag", "Pangasinan", "Pangasinan", "Pangasinan"],
  [
    "fa-AF",
    "Persian (Afghanistan)",
    "فارسی افغانستان",
    "Persian (Afghanistan)",
  ],
  ["pl", "Polish", "Polski", "Polish"],
  ["pt", "Portuguese", "Português", "Portuguese"],
  ["pa", "Punjabi", "ਪੰਜਾਬੀ", "Punjabi"],
  ["ro", "Romanian", "Română", "Romanian"],
  ["ru", "Russian", "Русский", "Russian"],
  ["sat", "Santali", "ᱥᱟᱱᱛᱟᱲᱤ", "Santali"],
  ["sr", "Serbian", "Српски", "Serbian"],
  ["sd", "Sindhi", "سنڌي", "Sindhi"],
  ["si", "Sinhala", "සිංහල", "Sinhala"],
  ["sk", "Slovak", "Slovenčina", "Slovak"],
  ["sl", "Slovenian", "Slovenščina", "Slovenian"],
  ["so", "Somali", "Soomaali", "Somali"],
  ["az-Iran", "Southern Azerbaijani", "تۆرکی", "Southern Azerbaijani"],
  ["ps", "Southern Pashto", "پښتو", "Southern Pashto"],
  ["st", "Southern Sotho", "Sesotho", "Southern Sotho"],
  ["es-MX", "Spanish (Mexican)", "Español (México)", "Spanish"],
  ["ar", "Standard Arabic", "العربية الفصحى", "Modern Standard Arabic"],
  [
    "ar-Latn",
    "Standard Arabic (Latin script)",
    "al-ʿarabiyyah",
    "Standard Arabic",
  ],
  ["ms", "Standard Malay", "Bahasa Melayu", "Standard Malay"],
  ["sw", "Swahili", "Kiswahili", "Swahili"],
  ["ss", "Swati", "SiSwati", "Swati"],
  ["sv", "Swedish", "Svenska", "Swedish"],
  ["tg", "Tajik", "Тоҷикӣ", "Tajik"],
  ["ta", "Tamil", "தமிழ்", "Tamil"],
  ["te", "Telugu", "తెలుగు", "Telugu"],
  ["th", "Thai", "ไทย", "Thai"],
  ["ti", "Tigrinya", "ትግርኛ", "Tigrinya"],
  ["sq", "Tosk Albanian", "Shqip", "Tosk Albanian"],
  ["tr", "Turkish", "Türkçe", "Turkish"],
  ["ug", "Uyghur", "ئۇيغۇرچە", "Uyghur"],
  ["vi", "Vietnamese", "Tiếng Việt", "Vietnamese"],
] as const;

export type SupportedLanguageCode = (typeof LANGUAGE_CATALOGUE)[number][0];
export type LanguageOption = {
  code: SupportedLanguageCode;
  label: string;
  nativeLabel: string;
  speechName: string;
};
export type LegacyLanguageId = "english" | "french" | "arabic";
export type LanguageSelection = SupportedLanguageCode | LegacyLanguageId;
export type VoiceLanguage = "auto" | LanguageSelection;

export const LANGUAGE_OPTIONS: readonly LanguageOption[] =
  LANGUAGE_CATALOGUE.map(([code, label, nativeLabel, speechName]) => ({
    code,
    label,
    nativeLabel,
    speechName,
  }));

const byCode = new Map<SupportedLanguageCode, LanguageOption>(
  LANGUAGE_OPTIONS.map(option => [option.code, option])
);
const legacyToCode: Record<LegacyLanguageId, SupportedLanguageCode> = {
  english: "en",
  french: "fr",
  arabic: "ar",
};

export const LANGUAGE_CODES = LANGUAGE_OPTIONS.map(option => option.code) as [
  SupportedLanguageCode,
  ...SupportedLanguageCode[],
];
export const LANGUAGE_SELECTION_VALUES = [
  ...LANGUAGE_CODES,
  "english",
  "french",
  "arabic",
] as const;

/** A zod input schema shared by all language selectors and server procedures. */
export const languageSelectionSchema = z.enum(LANGUAGE_SELECTION_VALUES);

export function isSupportedLanguageCode(
  value: string
): value is SupportedLanguageCode {
  return byCode.has(value as SupportedLanguageCode);
}

export function isLanguageSelection(
  value: unknown
): value is LanguageSelection {
  return (
    typeof value === "string" &&
    (isSupportedLanguageCode(value) || Object.hasOwn(legacyToCode, value))
  );
}

export function normalizeLanguage(
  value: LanguageSelection
): SupportedLanguageCode {
  return Object.hasOwn(legacyToCode, value)
    ? legacyToCode[value as LegacyLanguageId]
    : (value as SupportedLanguageCode);
}

/** True for the RTL scripts represented in the provider catalogue. */
export function isRtl(value: LanguageSelection): boolean {
  const code = normalizeLanguage(value);
  return [
    "ace-Arab",
    "ar",
    "ar-EG",
    "az-Iran",
    "bjn-Arab",
    "fa-AF",
    "fa-IR",
    "he",
    "ks-Arab",
    "min-Arab",
    "ps",
    "sd",
    "ug",
  ].includes(code);
}

export function languageOption(value: LanguageSelection): LanguageOption {
  const option = byCode.get(normalizeLanguage(value));
  if (!option) throw new Error(`Unsupported speech language: ${value}`);
  return option;
}

export function languageLabel(value: LanguageSelection): string {
  return languageOption(value).label;
}

export function languageNativeLabel(value: LanguageSelection): string {
  return languageOption(value).nativeLabel;
}

export function languageSpeechName(value: LanguageSelection): string {
  return languageOption(value).speechName;
}

/** Convert a Whisper/BCP-47 result such as fr-FR or ar to a provider code. */
export function matchDetectedLanguage(
  value: unknown
): SupportedLanguageCode | undefined {
  if (typeof value !== "string") return undefined;
  const normalized = value.trim().replace(/_/g, "-").toLowerCase();
  if (!normalized) return undefined;
  const exact = LANGUAGE_OPTIONS.find(
    option =>
      option.code.toLowerCase() === normalized ||
      option.label.toLowerCase() === normalized ||
      option.speechName.toLowerCase() === normalized ||
      option.nativeLabel.toLowerCase() === normalized
  );
  if (exact) return exact.code;
  const base = normalized.split("-")[0];
  const baseMatch = LANGUAGE_OPTIONS.find(
    option =>
      option.code.toLowerCase().split("-")[0] === base ||
      option.label.toLowerCase().split(" ")[0] === base ||
      option.speechName.toLowerCase().split(" ")[0] === base
  );
  return baseMatch?.code;
}

/**
 * Whisper accepts ISO-639-1 hints for common languages. For catalogue entries
 * without a safe two-letter hint, leave the field unset and let Whisper detect
 * the language rather than sending a misleading dialect/script code.
 */
export function whisperLanguageHint(
  value: LanguageSelection | "auto"
): string | undefined {
  if (value === "auto") return undefined;
  const base = normalizeLanguage(value).split("-")[0];
  return /^[a-z]{2}$/.test(base) ? base : undefined;
}

/** Alias for callers that use the provider's display-language wording. */
export const languageName = languageLabel;

export function languageTag(value: LanguageSelection): string {
  return normalizeLanguage(value);
}

export const defaultLanguage: SupportedLanguageCode = "en";
