# Repair 2 report: upgrade

## Implemented

- Fixed `activeProfile()` to return `null` when no saved profile exists instead of `undefined`, preventing React Query consumers from receiving an unexpected undefined current value.
- Preserved ordinary user behavior customization and rollback semantics.
- Added an owner-only `adus.upgrade.source` tRPC surface:
  - `status`: reports owner access and whether the deployed server has source-upgrade configuration; never claims connectivity when settings are absent.
  - `history`: lists source proposals/PR results for the owner.
  - `propose`: reads a bounded private GitHub source snapshot server-side, requests a structured complete-file proposal from the server-side LLM, validates paths/sizes, and persists exact unified diffs as `proposed`.
  - `approve`: requires exact confirmation, rechecks the base commit, creates a private branch, commit, and **draft** PR, then reports current check-run status. It never merges, deploys, publishes, deletes, changes permissions, or executes model-generated code.
- Added `client/src/pages/Upgrade.tsx` source-code review UI separately from behavior upgrades: setup-needed state, exact diff review, requested checks, explicit branch/draft-PR approval, stale-base explanation, PR/CI links, and source history. Non-owners see owner-only messaging and retain behavior customization.
- Added bounded protections in `server/sourceUpgrade.ts`: allowed roots/extensions, no path traversal, no `.env`, secrets, auth/permissions/roles, billing/payment, workflows, framework internals, lockfiles, or upgrade control-plane files; max 32 files, 64 KB readable files, 260 KB snapshot, 8 changed files, 80 KB/file and 240 KB total replacement content. Reviewed new API, specialist-agent, component and test modules are allowed under approved application roots. Existing files that were not read remain rejected. Parent also fixed the code model to the verified GPT deep mode and prevented approving a proposal against a different repository.

## Deployment environment and public contract

Configure these **server-only** variables in the deployed environment:

- `ADUS_SOURCE_REPO`: private GitHub `owner/repository` or `https://github.com/owner/repository`.
- `ADUS_GITHUB_TOKEN`: a fine-grained token scoped only to that private repository; recommended permissions are Contents read/write, Pull requests read/write, and Checks read. Never expose it to Vite/browser code.
- Optional `ADUS_SOURCE_BASE_BRANCH`: branch override; otherwise GitHub default branch is used.
- Existing owner identity remains `OWNER_OPEN_ID`; source access is `ctx.user.role === "admin"` or matching configured `OWNER_OPEN_ID`, never a user-provided email.

If repo/token is missing or invalid, `source.status` returns `configured: false`, missing variable names, and an actionable setup message. Proposal/approval does not attempt GitHub mutation. `ADUS_SOURCE_UPGRADE_LIVE_TEST=1` enables the optional test that performs a read-only private-repository validation; it does not write.

## Verification

- `pnpm vitest run server/sourceUpgrade.test.ts --reporter=dot`: **passed — 7 passed, 1 skipped**. The skipped test is the opt-in live repository read (`ADUS_SOURCE_UPGRADE_LIVE_TEST=1`) and was skipped because deployment GitHub settings were not present in this sandbox.
- `pnpm exec prettier --check server/upgradeRouter.ts server/sourceUpgrade.ts server/sourceUpgrade.test.ts client/src/pages/Upgrade.tsx`: **passed**.
- `pnpm check`: **blocked by unrelated parent-worker error** in `client/src/components/WhiteboardPlayer.tsx` (`Property 'cues' is missing`, current line 510). No upgrade/source file was reported by TypeScript.
- Combined existing `server/workspaceFeatures.test.ts` run was also blocked by an unrelated mock drift: its `./_core/llm` mock does not export the newly used `selectChatModel` from the parent worker's router changes. The new source suite is isolated and passing.

## Caveat

No GitHub repository/token was available during this sandbox run, and the parent agent reported that creating a repository via the available credential failed for lack of `CreateRepository` permission. Therefore no live repo mutation, branch, commit, or PR is claimed. Once the owner supplies a private repository and server-only fine-grained token, the status endpoint and opt-in read-only test provide the honest setup/validation path.

## Final integration

The complete integrated suite passed 134 tests, two opt-in live tests skipped; TypeScript and production build passed. Internal query failures are handled in the Upgrade page, absent profiles return null. GitHub setup remains pending the private repository and repository-scoped server credential. No GitHub branch or PR was created. CI checks are included in the source tree but have not run on GitHub.
