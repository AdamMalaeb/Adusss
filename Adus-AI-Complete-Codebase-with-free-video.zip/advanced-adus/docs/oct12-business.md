# Business plan language and evidence update

## Scope

Owned files updated:

- `shared/business.ts`
- `server/businessRouter.ts`
- `server/business.test.ts`
- `client/src/pages/Business.tsx`

Parent-owned integration remains unchanged: mount and route wiring stay in the parent-owned files.

## Language behavior

- The brief now has an explicit **Plan language** selector using the existing shared catalogue and legacy aliases.
- `auto` is the default and asks the planner to follow the dominant language used in the user's brief instead of silently defaulting to English.
- Supported language values are passed to the backend, included in the LLM instruction, and persisted on both `input.language` and `plan.language`.
- Revision has its own language selector. It defaults to the current plan language and may create a new version in another supported language while preserving the prior record.
- No changes were made to `shared/languages.ts`, the existing selector component, main routes, or `App`.

## Evidence and wording boundaries

- `knownFacts` is a separate plan field for details explicitly supplied by the user or supported by retrieved source excerpts.
- `assumptions` and `missingInformation` remain separate and are explicitly described as such in the prompt and UI.
- Prompt guidance rejects invented competitor names, market sizes, prices, customer counts, or source facts; unsupported alternatives remain hypotheses.
- The readiness score remains a deterministic weighted rubric and is repeatedly labeled as **not a success probability, forecast, confidence, or chance of success**.
- Numeric unit-economics values remain null in saved plans; the client sandbox calculates only from user-entered assumptions. No random graph data was added.
- Output language applies to all prose fields while source URLs are preserved unchanged.

## Backward compatibility

Legacy stored inputs without `language` parse as `auto`; legacy plans without `knownFacts` or `language` parse with empty known facts and `auto` defaults. No database migration or destructive storage change is required. Existing revision callers may omit the optional revision language and retain the stored input language.

## Verification

```bash
cd /home/ubuntu/advanced-adus
pnpm vitest run server/business.test.ts --reporter=verbose
```

Result: **9 tests passed**.

The focused suite covers deterministic score math, validation boundaries, strict plan output, legacy defaults, private research queries, explicit Spanish-language propagation, no-research behavior, authentication/owned restore, and French-language revision lineage.

Prettier was run on all four owned source/test files. Full project typecheck/build and whole-app browser testing were intentionally not run because other shared workers were editing unrelated files; the parent owns integration and browser verification. Existing unrelated diagnostics in the shared worktree should not be attributed to this feature.
