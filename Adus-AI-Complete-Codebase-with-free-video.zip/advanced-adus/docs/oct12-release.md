# Adus — October 12 update

## Implemented

- **Translator for every signed-in account:** a built-in Translator navigation item and `/translator` page independent of owner-created custom tabs. Supports uploaded PDF, images, DOCX and text-based documents with supported target languages/custom language codes. Extracted text is translated in ordered chunks; unsupported/truncated source coverage is reported instead of silently claiming a complete translation. Saved translations can be downloaded as UTF-8 text. The old Tab configuration panel is not present on the built-in Translator page.
- **Owner-only areas:** Videos, Operations and Upgrade Adus show Locked for other users and are guarded in both UI and APIs. Only the authenticated email `adammalaeb30@gmail.com` is allowed; a legacy admin role alone is insufficient. Existing records are retained.
- **Calls and recorded chat dictation:** recorder-container normalization, original-language transcription instructions, bounded non-authoritative vocabulary hints, and improved capture/lifecycle safeguards. Call and video-call Stop cancels the current answer and returns to listening while preserving conversation context. Microphone mute leaves bot playback and camera active.
- **Mobile chat:** larger full-width chat, wrapped long text, contained code/table scrolling, compact history controls, and safe browser-storage handling. No claim that all answers are error-free or universally correct.
- **Research:** established educational concepts are answered directly, without unnecessary live-source warnings. Current facts and explicit research still request live retrieval. Only mapped/retrieved source excerpts are used as citation evidence; irrelevant/unmapped results are excluded. Failed research remains honestly unverified.
- **Business:** plan-language and revision-language selectors; more professional and substantive planning instructions. Known facts remain separate from assumptions and missing information. The score is a feasibility rubric, not a statistical probability of success.
- **PowerPoint:** simplified prompt, slide count, optional animation/effects request, optional pictures and one Generate PPTX action, plus phone save controls. Explicit “no images” requests take precedence. The rendering service still needs a valid credential; requested effects depend on the renderer, not merely their presence in the prompt.
- **Independent Google sign-in prepared:** Adus-branded sign-in page, working Back link, verified OpenID Connect/PKCE flow, local signed sessions and safe explicit account linking. Existing Manus login remains labelled as fallback until Google credentials are supplied.

## Verified

- TypeScript check passed.
- **384 regression tests passed**, 6 optional live tests skipped (63 passing test files; 3 optional live-test files skipped).
- Production build passed.
- Actual compiled-runtime browser tests at **320, 390 and 430 px** checked translation upload/download controls, owner locks, long-message containment, Business language selection, simplified presentation flow and branded sign-in Back navigation. Provider responses in these UI tests are simulated; this does not certify live presentation rendering.
- Video-call browser test used simulated microphone/camera/API responses and real WAV playback: large camera, current frame transmission, microphone-only mute, Stop-to-listening and prior-context preservation passed.
- Real synthetic French and Arabic audio requests produced original-language transcripts. Recognition can still make mistakes, particularly with dialect, background noise or microphone quality; no all-language accuracy guarantee.
- Real synthetic file translation returned clean French text after correcting attachment metadata that had caused unwanted commentary. The test did not write to a user's saved account.
- Managed preview and separate compiled runtime returned HTTP 200. Temporary compiled QA server is stopped after validation; it is not an application runtime dependency.

## Not yet activated / external blockers

1. **Google login:** no `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` or `GOOGLE_REDIRECT_URI` is configured in the deployment. The implementation is ready, but a live OAuth sign-in cannot be tested or enabled until these are supplied. Follow `docs/google-sign-in.md`.
2. **PowerPoint rendering:** the current presentation-service credential returned **HTTP 401** on its identity check. The form and one-step flow are implemented, but a downloadable real deck cannot be promised until authentication succeeds.
3. **Live research:** the configured Google Search test returned **HTTP 429**. The tested public fallback also returned no usable evidence within its limits. Routing/citation fixes do not remove provider availability limits or certify current information. No invented verification/citations are shown.
4. **Independence:** Google sign-in replaces the login path only. Existing hosting, model, transcription, storage and presentation providers remain. This release is not a complete migration away from Manus infrastructure.

## Links

- Updated workspace preview: https://3000-i046182k6gpdnog8grrc6-c75434d4.sg2.manus.computer
- Existing published domain: https://aiworkspace-dyq23yap.manus.space

The saved checkpoint contains this release. Use the project's Publish control to update the published domain if it is not configured to auto-publish.
