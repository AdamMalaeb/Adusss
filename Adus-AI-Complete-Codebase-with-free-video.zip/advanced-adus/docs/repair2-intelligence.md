# Repair 2 — Intelligence

## Scope

Server-side chat/LLM reliability, model routing, output validation, and browser call turn detection. Existing study voices/languages, call mute lifecycle, and chat opening design were preserved.

## Implemented

- **Verified model routing:** chat now supports `auto`, `fast`, and `deep` modes. Fast/voice uses `gpt-5-mini`; deep text/code/study uses `gpt-5.5`; multimodal uses `gemini-3-flash-preview` or `gemini-3.1-pro-preview` according to mode/complexity.
- **Voice latency:** voice requests use the fast GPT model, a low reasoning setting, and a 500-token visible-output cap. The existing concise spoken prompt and man/woman browser voice selection remain unchanged.
- **Family-correct token parameters:** `server/_core/llm.ts` maps GPT output limits to `max_completion_tokens` and Gemini/other provider limits to `max_tokens`, preventing the known Gemini null-content failure caused by the GPT key.
- **Bounded retry/quota behavior:** only transient statuses (408/409/425/429/5xx) and network errors receive one retry with capped jittered backoff. Non-retryable auth/validation/model errors are returned immediately; there are no duplicate fallback retries.
- **Nonempty output gate:** null, blank, or content-less assistant responses now fail explicitly rather than becoming a fabricated success. Tool-call-only responses remain valid for future callers.
- **Stable client payload:** Home sends an explicit `modelMode` field and exposes a compact Answer mode selector; voice calls do not send this selector and retain their original lifecycle.
- **Shorter VAD without a fixed 12-second turn:** speech requires 220 ms above RMS 0.018, trailing silence ends a turn after 850 ms, and 12 seconds remains only a maximum safety cap. Mute still disables only user microphone tracks and never cancels bot speech.

## Live catalog and benchmark evidence

Live `BUILT_IN_FORGE_API_URL/v1/models` was queried on 2026-10-10. Verified IDs included `gpt-5-mini`, `gpt-5`, `gpt-5.5`, `gemini-3-flash-preview`, and `gemini-3.1-pro-preview`. Claude IDs were present but reported `status: temporarily_unavailable` by the live catalog, so no new routing uses Claude.

At most two minimal calls were benchmarked as requested:

| Model | HTTP | Measured elapsed | Result |
|---|---:|---:|---|
| `gpt-5-mini` | 200 | 1.508 s | Provider returned `content: null` with `max_completion_tokens: 16` and `reasoning.effort=minimal`; usage was zero. |
| `gpt-5` | 200 | 1.550 s | Same null/zero-token behavior under the intentionally tiny minimal benchmark. |

The null result is not treated as success. The new output gate rejects it and the regression suite covers that behavior. These timings are request-level sandbox measurements, not a promise of production latency or model superiority.

## Verification

- `pnpm test`: **121 passed, 2 skipped** across 19 test files; duration **11.68 s**. The skipped test is the existing live Gemini credential test.
- Focused intelligence suite: **28 passed** (`server/llm.test.ts`, `server/voiceCall.test.ts`, `server/voiceRouting.test.ts`); duration **1.55 s**.
- `pnpm check`: **passed** (`tsc --noEmit`).
- `git diff --check`: passed.
- New deterministic tests cover null/default responses, GPT and Gemini token-key normalization, one-retry exhaustion, explicit fast/deep model routing, reasoning parameter presence, voice VAD timing, and existing mute/speech lifecycle.

## Remaining blockers / caveats

- The minimal live benchmark exposed provider null output at an extremely small 16-token budget; a normal production call still needs provider availability and adequate output budget. No fabricated live answer is claimed.
- Provider quotas/status may still cause transient 429s; the client makes one safe retry only and then reports failure. The existing live video-generation 429 blocker is outside this intelligence patch.
- `pnpm` emitted a warning that the repository `pnpm` config keys are ignored by the installed pnpm version; this did not block tests or type-checking.
- Other workers had concurrent changes in shared files. This worker only intentionally changed the assigned intelligence files and the dedicated routing test/report; parent should integrate/check the shared worktree before checkpointing.

## Final normal-budget verification

A real gpt-5-mini voice-style response at a normal 500-token budget returned a correct transverse/longitudinal-wave explanation in 1.939 seconds. This is one measurement, not a latency guarantee. Exhausted quota now returns immediately without retry; transient rate-limit responses retain at most one retry. Fast-mode multimodal requests select Gemini Flash. Final integrated suite: 134 passed, 2 opt-in live checks skipped, TypeScript and production build passed.
