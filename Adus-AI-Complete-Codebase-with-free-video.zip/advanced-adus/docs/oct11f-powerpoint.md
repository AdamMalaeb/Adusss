# PowerPoint studio

PowerPoint studio is a reviewed-outline editor backed by the Manus API **Slides** skill. It does not hand-build PPTX files. The only production deck creation/edit path is a Manus task with a resolved Slides skill ID forced in `message.force_skills`; the resulting editable PPTX is downloaded from a validated task attachment and stored in workspace storage.

## Parent integration

The parent application mounts the new router at top level:

```ts
import powerpointRouter from "./powerpointRouter";

export const appRouter = router({
  // ...existing routes
  powerpoint: powerpointRouter,
});
```

The parent also registers `/powerpoint` to render `client/src/pages/PowerPoint.tsx` and may add a sidebar entry. No existing files are changed by this feature bundle.

## Server contracts

### `trpc.powerpoint.readiness`

Protected query. Performs a short-cache `GET https://api.manus.ai/v2/user.me` check with the server-only `MANUS_API_KEY`. Presence of an environment variable is **not** treated as availability. A 401 returns `available: false` with an honest replacement/setup message.

### `trpc.powerpoint.outline`

Protected mutation. Accepts:

- `topic`, `audience`
- `language`: English, Spanish, French, German, Portuguese, Japanese, Korean, or Chinese
- `style`: Executive clarity, Editorial narrative, Modern minimal, Warm workshop, or Technical briefing
- `slideCount`: integer 4–12
- optional `sourceFacts`
- optional validated `.pptx` `source` using the existing base64 transport

The built-in server LLM (`invokeLLM`) returns strict JSON for an editable outline. If a PPTX is supplied, bounded local preview extraction reads only `ppt/slides/slide*.xml` text from the ZIP. It never executes package content and does not use that extraction to create a deck.

### `trpc.powerpoint.reviseOutline`

Protected mutation. Accepts a current `draft` plus an instruction. It returns a new structured outline, preserving supplied source facts and avoiding invented statistics, citations, quotes, or authorities.

### `trpc.powerpoint.saveDraft`

Protected mutation. Persists the user-owned draft in workspace records.

### `trpc.powerpoint.create`

Protected mutation. Requires a validated server credential. Flow:

1. Authenticate with `user.me` (cached briefly).
2. Resolve the installed Slides skill with `skill.list` by matching its ID/name/description.
3. For an uploaded PPTX, reserve a Manus file via `file.upload`, then PUT the bytes to the returned presigned URL.
4. Create a private task with `task.create` and `message.force_skills: [resolvedSlidesSkillId]`.
5. Ask the Slides skill to create/edit a native editable PowerPoint, preserve useful existing content for edits, use only supplied source facts, and apply restrained transitions.
6. Persist the Manus task ID plus a separate workspace `recordId` for reload-safe ownership and polling.

### `trpc.powerpoint.poll`

Protected mutation. Looks up the task by `(ctx.user.id, taskRecordId)` before calling Manus, so one user cannot poll another user's record. It calls both `task.detail` and `task.listMessages` with `slides_format=pptx`. `stopped` is not treated as complete unless `has_running_background_jobs === false`; omitted background state remains unknown. Waiting states are separated into normal user input versus action confirmation. The server never auto-approves consequential actions.

When completed, output attachments are resolved from the current message context, matched by attachment path/metadata, restricted to an HTTPS allowlist, downloaded with byte limits, checked for a ZIP/PPTX signature, and stored with `storagePut`. The signed remote URL is not persisted as permanent identity; workspace records retain the stored object URL/key and task IDs.

### `trpc.powerpoint.sendMessage`

Protected mutation for a normal follow-up textbox. It sends `task.sendMessage` only to the known, user-owned Manus task and preserves the Slides force skill on that turn when available.

### `trpc.powerpoint.history` / `getTask`

Protected, user-scoped history and task lookup. The UI restores the latest draft/task after navigation or reload.

## Credentials and setup

Set this server/project secret only:

```text
MANUS_API_KEY=<valid Manus API v2 key>
```

Optional artifact host override for private installations:

```text
MANUS_ARTIFACT_HOSTS=private.manuscdn.com,.manuscdn.com
```

The default artifact allowlist is `private.manuscdn.com` and subdomains of `manuscdn.com`. Do not put `MANUS_API_KEY` in client code, browser storage, task text, or a user-facing form. The UI intentionally explains setup and provides a re-check action rather than asking the user to paste a secret.

The outline editor uses the project’s existing built-in LLM credentials through `server/_core/llm.ts`; no new LLM secret is introduced by this feature.

## UI behavior

- Topic, audience, language, visual style, and 4–12 slide controls.
- Optional existing `.pptx` upload, max 20 MB.
- Text preview outline extraction is bounded and only for editing context.
- Editable title, summary, bullets, add/remove/reorder controls.
- AI revision textbox using the existing server-side LLM.
- Generate button is disabled until readiness is true and the outline is reviewable.
- Task activity shows queued/running/awaiting input/awaiting action/completed/failed/unknown.
- Polling is bounded to ten minutes and only resumes a known task; it never creates a duplicate task after reload.
- Open-task link and normal follow-up textbox are available.
- Consequential confirmations are not automatically approved.
- No AI-detector or “undetectable” promises are made.

## Tests

`server/powerpoint.test.ts` contains no-live/billable tests for:

- `.pptx` base64 and ZIP signature/size validation
- task status parsing, including `stopped` plus unknown/true background jobs
- allowed artifact URL checks
- no-key failure behavior
- readiness 401 behavior
- user-scoped task lookup/isolation

The existing repository may have unrelated type-check/test failures from other feature work; PowerPoint tests do not call the live Manus API.
