# Oct 11c — Math integration handoff

## Completed

The owned math surfaces now share one normalization contract. `shared/mathFormat.ts` protects fenced/inline code and real currency, repairs common double-escaped TeX, preserves genuine `$...$` equations, and converts standalone TeX arrow commands to Unicode. `client/src/components/RichText.tsx` renders normalized content with GFM and KaTeX while keeping raw HTML disabled. `server/summaryPdf.ts` uses the same normalizer and visible KaTeX HTML with embedded fonts for no-network Chromium PDF generation. `client/src/components/WhiteboardPlayer.tsx` applies a math-only Unicode-arrow path to SVG/plain-text labels and transcript text. `shared/assistantStyle.ts` adds the professional instruction to use delimiters and not expose raw arrow commands.

## Exact integration

Production chat in `client/src/pages/Home.tsx` and study summaries in `client/src/pages/Studying.tsx` already call `RichText`; no changes to those files or to study/navigation backend code are needed. Summary PDF generation already flows through `summaryDocument`/`renderSummaryMarkdown`, so it inherits the shared normalizer automatically. Parent-owned `server/routers.ts` should continue using the existing shared style exports; no router change is required for math. There were no Studying or navigation edits to report to the navigation worker.

Do not route Markdown through `normalizeStandaloneMathText`; that helper is only for SVG/plain-text WhiteboardPlayer output that cannot host KaTeX. Do not reopen user screenshots. No media/model/storage calls were made.

## Validation

Focused command: `pnpm exec vitest run server/mathRendering.test.ts server/assistantStyle.test.ts --reporter=dot` — **2 files passed, 7 tests passed**. The math test generates a real Chromium PDF, checks `%PDF-`, extracts text with `pdftotext`, renders page 1 with `pdftoppm`, and checks the PNG signature/size. `pnpm exec tsc --noEmit` passed with no diagnostics in the final shared-tree state. Prettier check on all owned source/test files and `git diff --check` passed.

## Caveat

The generic unused `client/src/components/AIChatBox.tsx` still uses `Streamdown` and was intentionally not changed because it is outside the owned-file list; the production Home chat uses `RichText`. Full-suite/live-media verification was intentionally skipped per task constraints.
