# Website brief defaults

## Change

The Build Lab now opens with a **blank website brief** for a new account. It no longer invents a Safferni Tours brief or any other brand-specific content.

- A `brief` query parameter remains authoritative, including an explicitly empty value.
- A non-empty custom brief previously saved by the current account remains visible.
- Existing artifact previews and published deployment state remain untouched.
- The Create website action stays disabled until the user supplies a brief.

## Legacy local-storage migration

`client/src/lib/websiteArtifactStore.ts` recognizes the exact historical Safferni seed only as a migration value. On first read for an account, it removes that `brief` field from the account's `adus:website-workspace:<account>` record and writes the cleaned record back. It does **not** remove the account's saved artifact or deployment. Other brief text is preserved.

Storage remains namespaced by the authenticated workspace account. Switching accounts clears the in-memory cache and reloads only that account's record.

## Verification

Focused tests cover:

- blank first entry;
- explicit routed brief precedence;
- custom persisted brief preservation;
- exact legacy seed removal while retaining preview/published state;
- account isolation during migration.
