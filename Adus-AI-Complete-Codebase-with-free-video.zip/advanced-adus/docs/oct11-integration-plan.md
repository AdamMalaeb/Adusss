# Adus repair integration — October 11, 2026

The user requested continued implementation from checkpoint 68039518. The user’s `Pasted_content.txt` is authoritative for this request.

## Areas being implemented

- Neural spoken replies, larger camera view, front/rear camera handling, microphone-only mute, English/French/Arabic conversation, cleanup and permission recovery.
- Professor-style, source-grounded summaries and animated explanatory lessons with writing, drawing, highlighting and erasing aligned to narration.
- Distinct cinematic AI video generation and animated professor explainers; persistent status and honest provider errors.
- Code-upgrade-focused interface and reviewed owner-only source proposals instead of presenting engineering requests as behaviour personalization.
- HTML import and clear website hosting-account diagnostics while preserving the working website preview.

## Parent integration already verified

`adus.transcribeVoice` now accepts an optional language (`auto`, `en`, `fr`, `ar`) and preserves the detected original language. `adus.chat` accepts `callLanguage` (`auto`, `english`, `french`, `arabic`), requests mature professional plain spoken prose, and explains the answer proportionately. Existing camera frames remain bounded JPEG snapshots supplied with a spoken turn, not continuous background surveillance.

The unchanged baseline passed 149 tests with 2 optional live tests skipped. The parent’s style/language/camera/voice regression group passed 24 tests. Further final results will be recorded only after integration.

## External boundaries

Google video quota is controlled by the configured Google project, not by response-style prompts or Manus task continuation. Natural speech also has provider rate limits. Code changes may improve pacing and recovery but cannot grant provider quota.

The application must use its configured production credentials, not assistant-local connectors or browser sessions. The last known source repository was public even though the user wanted private; no source upload or account-privacy change is authorized until the repository choice is resolved. Hosting public sites and applying reviewed source proposals retain exact-payload review and approval.

No claim that Adus is smarter than every AI, or completely independent of hosting/model providers, will be made.
