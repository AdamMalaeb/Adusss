# October 11 source-video edit investigation

## Scope

This report covers only the deterministic **source-video editor**: upload a playable source, ask the LLM for a reviewable FFmpeg plan, then render a copy locally. It does **not** claim object removal, background replacement, restyling, inpainting, or other generative edits. Google cinematic/video-generation quota is a separate provider path and was not used here.

## Findings

- The existing focused suites were already green before the fix: `videoEditing.test.ts`, `videoUpload.test.ts`, and `videoUploadRoute.test.ts` passed 9 tests.
- The available live Forge catalog was fetched once. `selectChatModel({ mode: "fast" })` selected **`gpt-5-mini`**, and that model was present in the catalog. Claude entries were marked temporarily unavailable; the catalog also listed the GPT-5 and Gemini families.
- One minimal real planner request was made against a synthetic 2-second, 64×48 MP4 with AAC audio. It returned a valid deterministic plan for keeping `0–1.25s` and muting `0.25–0.5s`, with `estimatedDuration: 1.25`. No repeated planner/quota calls were made.
- Browser replay showed the upload, plan, and apply calls receiving HTTP 200 in the prior QA flow, but that flow used a QA source response (`/qa.mp4`) rather than proving a real stored output. The server log history also contains unrelated startup/router errors and old authentication misses, but no reproducible current FFmpeg or source-edit failure.
- The upload path is correctly authenticated server-side with `sdk.authenticateRequest`; the client sends cookies and, for preview/WebView cases, the session token as a Bearer header. Existing client and route tests cover this behavior. No upload-auth or upload-storage change was proven necessary.

## Implemented fixes

### `server/videoEditing.ts`

- Added finite, conservative planner normalization for provider variation:
  - accepts text content arrays and direct structured objects;
  - unwraps a top-level `plan` envelope;
  - accepts numeric strings for existing numeric fields;
  - strips surrounding Markdown fences and can extract one JSON object from brief surrounding prose.
- Normalization does **not** invent missing operations or silently turn an incomplete plan into a supported edit. Required fields still pass through the strict Zod plan schema; invalid or incomplete plans return the existing service-unavailable error and no media is changed.
- Added early guards for empty bytes and invalid source dimensions/duration.
- Added a specific actionable error when the `ffmpeg` executable is unavailable.
- Re-probes the rendered MP4 and returns its actual FFprobe duration instead of trusting only the estimate. This keeps stored route metadata aligned with the playable output.

### No upload/client changes

`server/videoEditRouter.ts`, `server/videoUpload.ts`, `server/videoUploadRoute.ts`, and `client/src/lib/videoUpload.ts` were inspected and left unchanged because the existing ownership, storage-key, multipart, cookie/Bearer, MIME detection, and playable-source validation behavior was covered and working. No provider credentials were changed.

## New end-to-end test

`server/videoEditActual.test.ts` adds two checks:

1. A planner normalization test uses a mocked planner response shaped like a real provider variation and verifies that only explicitly returned operations survive; it also asserts the request uses `gpt-5-mini` and strict JSON Schema.
2. An app-router `applyPlan` test uses a real synthetic MP4 source, real `ffmpeg`, real `ffprobe`, and the actual `videos/{userId}/{resultId}.mp4` storage path (storage/database/auth are mocked at the boundary as allowed). It verifies:
   - source bytes remain playable and are not overwritten;
   - output is MP4 with H.264 video and AAC audio;
   - crop changes 64×48 to 48×48;
   - duration is in the expected range for two kept ranges plus 1.5× speed-up;
   - the requested mute interval is silent while a neighboring unmuted interval remains audible.

## Verification

Passed on October 11, 2026:

```text
pnpm check
pnpm exec vitest run \
  server/videoEditActual.test.ts \
  server/videoEditing.test.ts \
  server/videoUpload.test.ts \
  server/videoUploadRoute.test.ts \
  server/videoUpload.client.test.ts \
  --reporter=verbose
```

Result: **5 test files, 13 tests passed**. FFmpeg 6.1.1 and FFprobe 6.1.1 were available in the sandbox. The modified implementation and new test were formatted with Prettier and passed `git diff --check`.

## Caveats

- The live planner request succeeded; therefore there is no live LLM/schema blocker to report for the deterministic planner. The app's normal one-plan/review/apply flow remains the quota-independent path.
- Google cinematic generation remains a separate externally reported project-quota blocker. This work neither retries that provider nor claims that generative source edits work.
- The end-to-end test deliberately mocks the storage/database/auth boundaries to avoid external side effects, while using real FFmpeg/FFprobe and the production storage-key convention.
