# Camera repair report — 2026-10-11

## What changed

- **`client/src/lib/cameraCall.ts`**
  - Added synchronous `getCameraCapabilities()` detection for `mediaDevices.getUserMedia`, secure context, embedded top-window state, and both real `permissionsPolicy.allowsFeature("camera")` plus legacy `featurePolicy/permissionsPolicy.allows("camera")` test doubles.
  - Added `CAMERA_STANDALONE_URL = https://aiworkspace-dyq23yap.manus.space/` for recovery links; no automatic redirect is performed.
  - `CameraCallController.start()` now preflights only known hard blocks, and still requests permission only when its caller invokes it (the caller must be a direct user click/tap handler).
  - Camera acquisition remains **video-only** (`audio: false`). The less restrictive `{ video: true, audio: false }` retry is limited to `NotFoundError` and `OverconstrainedError`; **`NotAllowedError`/`SecurityError` are never retried or bypassed**.
  - A `NotReadableError` lens-switch path releases the prior stream once, then reacquires; permission denials still never get a retry. Late streams are stopped when their request token is stale.
  - Preview attachment explicitly sets `muted`, `playsInline`, and `autoplay`, assigns `srcObject`, and attempts `play()` without unhandled rejection.
  - Embedded `NotAllowedError` copy says the denial is real and directs the user to Safari; it does not claim permission was granted.
- **`client/src/components/CameraAccessHelp.tsx`**
  - New reusable, accessible recovery component. It is a normal external link (new tab, no redirect) to the canonical standalone URL and tells the user to review Safari site camera permissions and choose Allow. It also states that voice can continue without video.
- **`server/cameraCall.test.ts`**
  - Extended reusable regression coverage for supported stream startup, denied permission, stale streams, constrained fallback, no-`NotAllowed` retry, `allowsFeature` Permissions Policy detection, embedded-denial copy, NotReadable switch reacquire, muted/inline preview, and stream cleanup.

## Exact integration contracts for parent/Home wiring

1. Import `CameraAccessHelp` from `@/components/CameraAccessHelp`.
2. Keep the existing controller construction with `browserCameraRuntime()` and `onChange: setCameraState`; do not call `getUserMedia` from render/effects.
3. `getCameraCapabilities()` is synchronous and side-effect free. Parent may call it while rendering the camera error/help area; it does **not** request permission. Prefer `const cameraCapabilities = getCameraCapabilities()` only in browser UI code (or pass `cameraControllerRef.current` runtime capability output when available).
4. Wire `<CameraAccessHelp capabilities={getCameraCapabilities()} />` beside camera errors when `cameraState.error` is present, especially for embedded iPhone denial. Keep the existing **Try again** button as an explicit user gesture; it must call `void getCameraController().start()` only from its `onClick`.
5. `CameraCallController.start(facingMode?)` is the permission boundary. It accepts `"user" | "environment"`; successful calls produce `cameraState.active === true`. Do not treat `pending`, a status string, or a resolved `getUserMedia` promise as permission success unless `active` is true.
6. The controller’s media contract is:
   - first attempt: `{ video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false }`;
   - fallback only for `NotFoundError`/`OverconstrainedError`: `{ video: true, audio: false }`;
   - no fallback for `NotAllowedError`, `SecurityError`, or any permission-denial path.
7. Keep the existing preview ref callback and JSX `autoPlay muted playsInline`; controller attachment re-applies these as DOM properties. Attach the stable preview ref after the camera call panel mounts; `attachPreview(null)` and `stop()` must remain part of call teardown.
8. Parent’s current Home wiring (read-only review): `Home.tsx` imports the controller at lines 9–13, stores `cameraState` at 212–213, attaches the preview via `attachCameraPreview` at 233–236, re-attaches on state/voice changes at 267–269, starts video from `openVideoCall` at 463–475, and renders camera errors/help points at 657–667 and 985–995. The active `<video>` at 829–835 already has `autoPlay`, `muted`, and `playsInline`. The parent should add the help component at those error surfaces without changing microphone-only mute behavior.

## Host / browser caveat

The user-visible failure is an iPhone Manus embedded-browser `NotAllowedError`. An app running inside an iframe cannot change the outer document’s HTTP `Permissions-Policy` header or the embedding iframe’s `allow="camera"` attribute from inside the child. If the host does not grant camera, this code intentionally reports the block and offers Safari; it cannot and must not bypass it. The repository’s `WebsitePreview.tsx` iframe is sandboxed with `allow-scripts` only, but it is not the camera-call host; changing host policy is outside this camera area and requires the embedding host/parent owner.

The real Permissions Policy API is queried via `allowsFeature("camera")`; the regression smoke uses that API shape. A real physical iPhone/Manus embedded-browser run was not available in this sandbox, so the Safari recovery path and denial behavior are covered by code and deterministic tests rather than claimed as device success.

## Verification

- `cd /home/ubuntu/advanced-adus && pnpm exec vitest run server/cameraCall.test.ts` — **13 tests passed**.
- `pnpm exec prettier --check client/src/lib/cameraCall.ts client/src/components/CameraAccessHelp.tsx server/cameraCall.test.ts` — passed.
- `git diff --check` — passed.
- Full type check/build was intentionally not run. The project watcher currently reports unrelated parent/shared changes (language type mismatch in `server/professorVideo.ts`, Home `VoiceLanguage` mismatch, and router reserved-word diagnostics); no success is claimed for those areas.
