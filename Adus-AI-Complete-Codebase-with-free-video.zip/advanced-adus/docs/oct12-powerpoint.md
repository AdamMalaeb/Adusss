# PowerPoint generator

## User flow

The PowerPoint page is a prompt-first generator for authenticated users. A user provides:

- A presentation prompt.
- A slide count from **4 to 12**.
- An optional request for animations or effects.
- Optional picture permission and user-uploaded picture references.

The slide outline is generated internally and is not a required manual editing step. The provider receives the original prompt, requested slide count, effects preference, and the internally generated outline.

## Picture policy

Pictures are **off by default**. The service uses a conservative policy:

1. An explicit prohibition in the prompt wins over every other input. This includes common English, French, Arabic, Spanish, Portuguese, German, Japanese, Korean, and Chinese wording.
2. Pictures are permitted when the user enables the picture toggle or explicitly asks for pictures/images/photos/visuals in the prompt.
3. Attached pictures are uploaded to Manus only when pictures are permitted. They are sent as user references.
4. When pictures are permitted and the prompt explicitly requests them, the Slides task may search for or generate relevant imagery. It must not add unrelated imagery.
5. When pictures are not permitted, the provider receives an explicit instruction not to search for, generate, or add pictures.

The provider may still lack a requested picture capability. The app does not promise unsupported imagery or effects.

## Slides execution

The server uses the existing Manus API v2 integration and forces the configured Slides skill. It does not hand-build PPTX files. Generation is asynchronous:

1. Validate the request server-side.
2. Generate an internal outline with the existing built-in LLM integration.
3. Resolve the Slides skill and create a private Manus task.
4. Persist the task record in `workspaceStore` under the authenticated user's ID.
5. Poll task detail and messages with a bounded ten-minute client window. A stopped main Agent run is not treated as complete while background work is unknown.
6. Resolve a real PPTX attachment, validate its ZIP signature and allowed artifact host, store it, and persist the workspace output record.

Effects are passed to Slides as a preference and are explicitly not promised as supported.

## Credential behavior

Readiness performs one server-side `GET /v2/user.me` identity check. Secrets are never sent to or requested from the browser. If `MANUS_API_KEY` is absent or rejected, the UI stays truthful: it does not claim that a PPTX is ready and generation remains blocked until the server credential is corrected.

## Downloads and access

Only authenticated users can create, poll, and download their own tasks. Stored PPTX output uses the existing `/manus-storage/` path and `MediaSaveActions`, which routes through the user-owned `mediaDownloads` ticket flow. No owner-only access check is used.
