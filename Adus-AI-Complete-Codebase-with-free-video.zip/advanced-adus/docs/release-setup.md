# Adus release setup

## Run independently of the assistant

Adus is a deployed React/Express application. Downloads, AI requests and stored files are handled by its browser/server and configured services; no assistant session or assistant-local computer is needed for normal use. Hosting, database, authentication, object storage and AI providers still need to remain available. This is not a claim of being dependency-free.

- Node.js 22 and pnpm (the version pinned in package.json).
- Install dependencies: `pnpm install --frozen-lockfile`.
- Validate: `pnpm check && pnpm test`.
- Build: `pnpm build`.
- Start: `NODE_ENV=production PORT=3000 pnpm start`.
- Debian runtime packages: ffmpeg, poppler-utils, chromium, fonts-dejavu-core, fonts-noto-core and ca-certificates. The supplied Dockerfile installs them.
- Keep all API keys, database credentials and OAuth secrets in server environment variables, not the repository or browser bundle. Existing managed-project configuration supplies the database, OAuth, storage and Forge credentials. Other hosts must configure these services explicitly.

## Phone saving

Download is a normal same-origin HTTP attachment served by the app. It saves into the browser's Files/downloads location. Where the browser supports file sharing, Save to Photos / Share opens the phone's native sheet. The website cannot bypass the OS to silently write into a gallery. Some embedded browsers restrict downloads; open the site directly in Safari or Chrome in that case.

## AI video generation

New clips use Google Veo 3.1 Fast through its asynchronous REST API; source edits use Gemini Omni. The app stores pending job IDs and can resume status checks after reopening the page without creating another generation. Clip length is currently 8 seconds; arbitrary long AI films are not implemented.

The live corrected Veo request on 2026-10-10 was rejected with HTTP 429 for no available video-generation quota. Earlier unsupported REST parameters have been removed. No generated clip or successful inference is claimed. Available model names alone do not prove available inference quota. Do not keep retrying a quota-exhausted key or substitute a fake result.

The approved study narration and English/French/Arabic settings remain unchanged. Teacher writing/erasing uses the real audio clock, begins promptly, and completes visual content before a scene's narration ends. Phrase alignment is estimated, not word-exact forced alignment.

## Owner-controlled code upgrades

The Upgrade page separates personal bot behavior from repository code changes. Code proposals are owner-only, read bounded source files, return full reviewed diffs, can add new API/specialist-agent modules, and create a branch plus draft pull request only after approval. They never execute generated scripts on the live server or automatically merge/deploy. Credentials, permissions and control-plane paths are protected. A changed base commit or repository requires a fresh proposal.

Configure in the deployed server:

- `ADUS_SOURCE_REPO`: the exact private GitHub `owner/repository`.
- `ADUS_GITHUB_TOKEN`: repository-scoped fine-grained token with Contents read/write, Pull requests read/write and Checks read. Never send it in chat or expose it to browser code.
- `ADUS_SOURCE_BASE_BRANCH`: optional branch, normally main.
- Existing `OWNER_OPEN_ID` or the application's admin role identifies the owner.

The included `.github/workflows/adus-ci.yml` checks types, deterministic tests and production build on PRs. It does not deploy or require provider secrets. A GitHub CI run is not claimed until the source is actually uploaded to a configured private repository.

As of verification, `AdamMalaeb/Advanced-adus` existed but reported Public and empty. No application source was uploaded. The user is changing it to Private. Repository access must be verified before copying source or enabling the code-upgrade connection.

## Verification

- TypeScript check and production build passed.
- 134 deterministic regression tests passed; two optional live credential checks were skipped.
- Production-mode phone viewport smoke used mocked user/provider responses and real stored download files: PNG, PDF and MP4 attachment bytes validated; natural narration played; board motion changed; full-width, actual-size and fullscreen site previews passed; repeated navigation across seven pages produced no JavaScript errors.
- Working call controls still pass: microphone mute does not cancel bot speech, unmute resumes listening, voice messages do not leak into text chat, ending the call cleans up.
- A real normal-budget GPT-5-mini voice-style answer returned successfully in 1.939 seconds. This is one measurement, not a universal latency guarantee or a claim to outrank every AI model.
