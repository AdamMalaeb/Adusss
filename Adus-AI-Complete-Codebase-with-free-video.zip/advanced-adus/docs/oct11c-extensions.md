# Adus workspace extensions integration — October 11, 2026

## Owned implementation

`server/workspaceExtensions.ts` remains the standalone router/helper already mounted by the parent under `adus.workspaceExtensions`. It now adds typed `functionConfig` to every tab, with supported functions `notes`, `summarizer`, `calculator`, and `translator`. Older stored tab payloads are accepted through the schema default and receive the safe notes default when parsed.

Workspace change prompts stay deliberately declarative. Supported forms include `Add a new tab named Test`, `Rename tab Test to Study`, `Remove tab Test`, and `Edit tab Test to use translator from fr to en`. A UUID may replace the label in rename/remove/edit prompts. `resolveWorkspaceTabTarget()` rejects duplicate label/slug matches with `WorkspaceExtensionError("AMBIGUOUS_TARGET", ...)`; it never guesses a deletion target. Apply and undo continue to compare durable before/after snapshots, so edits are isolated and reversible.

## Exact tRPC contracts

The parent does not need to change `server/routers.ts`; it already mounts `workspaceExtensionsRouter` as `adus.workspaceExtensions`.

```ts
trpc.adus.workspaceExtensions.list.useQuery();
// protected -> WorkspaceTab[]
// WorkspaceTab: { id, label, slug, path, createdAt, updatedAt,
//                 functionConfig: { type, sourceLanguage, targetLanguage } }

trpc.adus.workspaceExtensions.get.useQuery({ slug });
// protected -> WorkspaceTab | null

trpc.adus.workspaceExtensions.propose.useMutation();
// owner-only input: { prompt: string }
// output: { id, operation, prompt, summary, before, after,
//            status: "proposed", proposedAt }

trpc.adus.workspaceExtensions.activate.useMutation();
// owner-only input: { id: string, confirmed: true }
// applies a reviewed proposal; stale/ambiguous targets reject without mutation

trpc.adus.workspaceExtensions.undo.useMutation();
// owner-only input: { id: string, confirmed: true }
// reverses the currently applied proposal only
```

Tool contracts:

```ts
trpc.adus.workspaceExtensions.translate.useMutation();
// protected input: {
//   tabId: string; text: string (1..12000);
//   sourceLanguage: "auto" | supported language code;
//   targetLanguage: supported language code;
// }
// requires that tabId belongs to this user and has functionConfig.type === "translator"
// output: { tabId, text, sourceLanguage, targetLanguage,
//            sourceLabel, targetLabel, model }

trpc.adus.workspaceExtensions.summarize.useMutation();
// protected input: { tabId: string; text: string (1..12000) }
// requires active tab functionConfig.type === "summarizer"
// output: { tabId, text, model }

trpc.adus.workspaceExtensions.calculate.useMutation();
// protected input: { tabId: string; text: string (1..12000) }
// requires active tab functionConfig.type === "calculator"
// output: { tabId, expression, value }
```

Translation/summarization call the server-only configured `invokeLLM` helper with the live-catalog-verified available model `gpt-5-mini`; provider credentials never reach the browser. No media provider is called. Calculator is deterministic and accepts only bounded arithmetic syntax; no `eval` or generated code is executed.

## Client integration

`client/src/pages/WorkspaceExtension.tsx` reads the current route's durable tab and selects controls from its reviewed `functionConfig`. Translator input uses the existing `LanguageSelect` catalogue, has auto/source and target language state, invokes `translate`, shows loading/errors, and renders returned Markdown through the existing safe `RichText` component. Summarizer and calculator use the same typed input/result pattern. Notes remains a truthful configured destination rather than a fake generated result.

`client/src/pages/Upgrade.tsx` keeps the review/apply/undo flow and now shows active-tab controls for the owner: select an active tab by durable ID, choose a supported function, and prepare a reviewed edit or removal. The prompt sent for these controls contains the exact UUID, preventing duplicate-label guesswork. The page explicitly distinguishes workspace tab changes from the separate owner-only Repository code upgrade workflow for general code/API/quota requests.

## Verification

Focused command:

```text
pnpm exec vitest run server/workspaceExtensions.test.ts --reporter=verbose
1 file passed, 11 tests passed
```

The tests mock `invokeLLM` and cover translation output/model selection, ambiguous removal rejection, exact UUID resolution, typed language-aware edits, safe arithmetic, durable edit apply/undo, stale proposals, owner policy, account isolation, and existing add/rename/remove behavior. `pnpm check`, `pnpm build`, Prettier, and `git diff --check` passed for the final owned state. Full `pnpm test` was attempted but had 9 failures in concurrent LLM/voice-call files outside this area; the workspace extension suite stayed green.

## Parent handoff and caveats

No parent router edit is required for these extensions because the existing `workspaceExtensionsRouter` mount is present. Do not add a second translator label-only route. If the parent changes the tab schema or router namespace, preserve the exact contracts above and keep `server/routers.ts` and `server/creatorProfile.ts` under parent ownership.

Workspace persistence still requires the configured application database. Live translation/summarization was intentionally not invoked. The live Forge catalog on 2026-10-11 showed `gpt-5-mini`, `gpt-5`, `gpt-5.5`, `gpt-5-nano`, `gemini-3-flash-preview`, and `gemini-3.1-pro-preview` available; Claude IDs were temporarily unavailable.
