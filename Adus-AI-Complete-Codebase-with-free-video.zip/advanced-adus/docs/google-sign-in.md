# Independent Google sign-in for Adus

Adus now has its own branded `/sign-in` page and a wired Google OpenID Connect flow. Once Google OAuth credentials are configured, Google verifies users and Adus issues its own signed local session. It does not require a Manus OAuth exchange for standalone Google identities.

**Status:** implemented and tested with simulated Google responses; not activated or live-login-tested because the deployment does not yet contain the Google OAuth client credentials. Existing Manus login is retained as an explicitly labelled fallback so current users are not locked out.

## Activate Google login

1. Open [Google Auth Platform](https://console.cloud.google.com/auth/overview), create/select your project, and configure the consent screen. Use **Adus** as the application name.
2. Create an OAuth client of type **Web application**.
3. Register this exact authorized redirect URI for the current deployed site:

   `https://aiworkspace-dyq23yap.manus.space/api/google/callback`

4. Configure these server-side deployment variables through the secure secret form or deployment settings:

   - `GOOGLE_CLIENT_ID`: the Google OAuth web client ID, ending in `.apps.googleusercontent.com`.
   - `GOOGLE_CLIENT_SECRET`: the secret belonging to that same OAuth client. Do not send it in chat or put it in client code.
   - `GOOGLE_REDIRECT_URI`: the exact callback URL above.

5. Republish/restart the deployment. Adus's `/api/google/status` must report `{"configured":true}` before the button is enabled.
6. Test an actual Google sign-in and verify the email, account data, and owner-only navigation.

If the site domain changes, update both the Google Console registered URI and `GOOGLE_REDIRECT_URI`. `JWT_SECRET`, `VITE_APP_ID`, and `DATABASE_URL` remain existing runtime requirements; do not replace their established values.

## Existing accounts and history

New standalone Google users have a stable `google:<sub>` identity. They are **not automatically merged** with older accounts just because their email matches. This prevents account claiming.

An already signed-in user can explicitly link the matching Google identity with:

`/api/google/start?mode=link&returnTo=/`

The callback requires the same current signed-in account and the same verified Google email. Linking to another account's identity is rejected. Successful explicit linking preserves that account's user ID and saved workspace records. Do not sign out of the old account before initiating the linking flow.

## Security and recovery

- Verified Google ID-token signature, audience, issuer, nonce and verified email.
- Random state, nonce and S256 PKCE; signed 10-minute HttpOnly/Secure/SameSite=Lax state cookie.
- Bounded token exchange and UI configuration checks.
- No Google access/refresh token storage; server credentials are never returned by the status endpoint.
- Local seven-day application sessions and existing logout.
- Safe relative return routes, friendly expired/cancelled-login recovery, and a working Back to workspace link.
- Missing standalone Google accounts do not fall back to a Manus identity lookup.

## Tests

- `pnpm exec vitest run server/googleAuth.test.ts server/googleSession.test.ts`: eight deterministic tests for state, identity, credentials, safe redirects, explicit linking and local-session authentication.
- `python3 browser-tests/oct12-signin-smoke.py`: branded screen, disabled unconfigured state, safe retry and Back navigation at 320, 390 and 430-pixel widths.

These tests do not certify an unconfigured live Google OAuth client.

## Independence boundaries

Changing sign-in does not replace Adus's hosting, model, transcription, storage or presentation providers. The existing AI/media service integrations remain. Third-party Google consent UI cannot be renamed as if Adus operated it. Adus's own sign-in page has no “Powered by Manus” footer; optional legacy login is honestly labelled.

## Official references

- [Google OpenID Connect](https://developers.google.com/identity/openid-connect/openid-connect)
- [Google OAuth web-server flow](https://developers.google.com/identity/protocols/oauth2/web-server)
