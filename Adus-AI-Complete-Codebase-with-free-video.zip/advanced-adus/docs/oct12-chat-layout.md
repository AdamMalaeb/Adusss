# Chat layout repair — October 12

## Scope

This pass owns the reusable rich-text surface, conversation history, and global chat-layout safeguards. It does not change `Home.tsx`, `App.tsx`, `DashboardLayout.tsx`, the server, or persistence behavior.

## What changed

- `RichText` now uses scoped element overrides for markdown tables, fenced code, and inline code.
  - Tables render inside a keyboard-focusable `.rich-text-table-wrap` region with horizontal scrolling.
  - Fenced code keeps whitespace and scrolls horizontally inside the message; inline code may wrap.
  - Existing `remark-gfm`, KaTeX, math normalization, citation-token stripping, and raw-HTML blocking are preserved.
- `ConversationHistory` keeps the full history list on desktop but collapses to an opaque `Chats` + count control on mobile. The mobile list is an expandable drawer, so a long history cannot push the chat card below the fold. Selecting a chat closes the drawer.
- `index.css` adds only scoped `.adus-chat-*` and `.rich-text-*` rules. They enforce `min-width: 0`, `max-width: 100%`, multilingual/URL wrapping, contained table/code/math scroll, and mobile chat height (`calc(100dvh - 170px)` with a 420px floor). Existing non-chat tabs keep their current prose behavior.
- `client/src/lib/chatLayout.test.ts` covers the static class/selector contracts because this repository's Vitest environment is Node-only and has no DOM testing dependency.

## Exact Home integration replacements

Parent-owned `Home.tsx` should add the following classes without changing handlers or semantics:

1. Outer chat row/workspace wrapper:

   ```tsx
   <div className="adus-chat-workspace flex flex-col gap-4 lg:flex-row">
   ```

   If preserving the existing responsive utility order is preferred, append `adus-chat-workspace` to the current class string.

2. Main chat card/section:

   ```tsx
   <section className="adus-chat-shell adus-glass flex h-[calc(100dvh-170px)] min-h-[420px] min-w-0 flex-1 flex-col overflow-hidden rounded-[1.75rem] border border-white/[0.1] shadow-2xl shadow-black/25">
   ```

   On desktop, the scoped CSS restores `height: calc(100dvh - 135px)` and `min-height: 530px` at `640px+`. The mobile media query deliberately overrides the overly tall original `min-h-[530px]`.

3. Scrollable message region:

   ```tsx
   <div className="adus-chat-messages adus-scroll flex-1 min-h-0 space-y-4 overflow-y-auto px-3 py-4 sm:px-6 sm:py-6">
   ```

   This replaces the original `px-5 py-6 sm:px-8` padding and prevents nested cards from creating a horizontal page overflow.

4. Composer wrapper:

   ```tsx
   <div className="adus-chat-composer border-t border-white/[0.08] p-2 sm:p-4">
   ```

   This replaces `p-4 sm:p-5` to avoid a thin, over-padded composer inside the card. Keep the existing inner form and controls.

5. Message bubble outer/inner surface: append `adus-chat-bubble` to the bubble class string. Keep the role variants, but use these width rules:

   ```tsx
   // assistant surface
   "adus-chat-bubble w-full max-w-full rounded-2xl ...";

   // user surface
   "adus-chat-bubble max-w-[92%] rounded-2xl ...";
   ```

   The scoped CSS adds `overflow-wrap: anywhere` and `word-break: break-word`, so URLs, CJK text, provider output, and long identifiers cannot widen the page. The assistant bubble is full message width on mobile as requested.

6. If Home's current rich-text call remains wrapped in a parent prose class, adding `min-w-0 max-w-full` to that wrapper is safe. `RichText` itself now supplies `rich-text-content min-w-0`.

## Verification

- Targeted static test: `pnpm exec vitest run client/src/lib/chatLayout.test.ts`.
- Type check was run with `pnpm exec tsc --noEmit --pretty false`; no errors pointed to the owned RichText, ConversationHistory, index.css, or chat layout test files. Existing concurrent errors remained in `Business.tsx`, `Home.tsx`, `PowerPoint.tsx`, and `Translator.tsx`.
- Parent should run the whole-app/browser checks after integrating the Home classes, especially 320/390px viewport width and a response containing a long URL, a fenced code block, a wide table, and display math.
