# Free video mode (15–60 seconds)

Text in, captioned video out. Chosen per video: language, translate on/off,
narration on/off (and voice gender), shape (16:9 or 9:16), and length for
silent videos.

This is **not** generative AI footage (that is the Veo path, which is quota
limited). It renders animated text cards with ffmpeg, optionally with a free
neural voice. Do not describe it as equivalent to AI-generated footage.

## What is free, and what could change

| Piece | Tool | Notes |
| --- | --- | --- |
| Voice | `edge-tts` CLI (installed in the Dockerfile) | Free, no key, many languages. Unofficial: Microsoft can change or block it. |
| Translation | LibreTranslate (`LIBRETRANSLATE_URL`) | Self-hosting is free forever. Public instances usually need a key. |
| Picture | sharp + ffmpeg, in-process | No external service. |

Hosting is not free by default: rendering uses server CPU. One render runs at a
time per server instance; others wait and retry automatically.

## Behaviour

- Language = language of the voice and captions.
- Translate **on**: the text is translated into that language first.
  Translate **off**: the text is used exactly as written (write it in that
  language). Translation is refused with a clear message if it is not
  configured; it never silently falls back to a paid service. Setting
  `FREE_VIDEO_ALLOW_LLM_TRANSLATE=true` opts in to the app's LLM credential
  as a fallback (not free-forever).
- Narration **on**: each scene lasts as long as its speech. Videos under 15 s
  are padded to 15 s. If speech needs more than 60 s the request is refused
  with a "shorten the text" message; words are never cut silently.
- Narration **off**: captions only. Length is the slider (15–60 s) or an
  estimate from the text.
- Languages with no free voice return a clear error; use narration off.
- Daily limit per user: `FREE_VIDEO_DAILY_LIMIT` (default 3, resets 00:00 UTC).
  Failed videos do not count. Two simultaneous requests can exceed the limit
  by one.

## Access

Like the other video tools, the router uses `lockedProcedure` (approved
account only). To open it to all signed-in users, change the single
`const procedure = lockedProcedure;` line in `server/freeVideoRouter.ts`.

## Setup

1. Rebuild the image (adds Python, `edge-tts`, CJK fonts).
2. Set `LIBRETRANSLATE_URL` (e.g. a self-hosted
   `libretranslate/libretranslate` container) if you want translation.
3. Optionally set `FREE_VIDEO_DAILY_LIMIT`.

## Files

- `shared/freeVideo.ts`: limits, scene splitting, voice picking (pure).
- `server/freeVideoEngine.ts`: translate, speech, scene cards, ffmpeg.
- `server/freeVideoRouter.ts`: `adus.freeVideo.*` tRPC procedures.
- `client/src/components/FreeVideoPanel.tsx`: the controls, shown on Videos.
- `server/freeVideo.test.ts`: unit tests.
