# Adus update — live research, PowerPoint and Business

## Implemented

### Research and citations

- Google Search grounding is attempted for factual/current research questions, with bounded public-web retrieval as a fallback.
- The current date is injected at request time. Adus is instructed not to invent a training cutoff such as “June 2024,” or claim it has been retrained through the present.
- Source URLs come from retrieved evidence, not model-invented links. Unsupported citation numbers are removed; proprietary provider citation tokens are cleaned in both new responses and old message rendering.
- Search results are read before citation. Unrelated source pages are rejected by a conservative topical relevance check. Source excerpts remain limited, so users should still verify consequential claims against the linked originals.
- Research metadata and checked-at dates are saved with conversation messages.
- Safari, Chrome and Edge are browsers, not research sources. This update does not grant access to a user's browser sessions, private files or accounts.

### Business

- New Business tab with idea, location, budget, customer and founder-resource inputs.
- AI-generated strategy, customer and market analysis, operating structure, marketing, SWOT, milestones, risks, practical advice, assumptions and missing information.
- A transparent, fixed-weight readiness assessment out of 100. It is **not** a statistical probability of success and makes no promise about results.
- Readiness-factor chart and editable unit-economics chart. Financial numbers remain illustrative user-entered assumptions, not invented sourced forecasts.
- Account-scoped saved plans, restore, revision history and Markdown download.
- Public local-market research is opt-in. Only the market/location query is sent; private idea details are not included in public searches.

### PowerPoint

- New PowerPoint tab with topic, audience, language, design direction, slide-count controls and existing PPTX upload.
- Working AI outline drafting, manual edits, slide reordering/removal, AI revisions and private draft saving.
- An integration for native editable PPTX creation/editing through the supported presentation service, with exact documented task/file API shapes, bounded polling, authenticated readiness checks and account-scoped stored outputs/downloads.
- Bespoke layouts, restrained effects, original audience-specific wording and readable professional design are requested. No AI-detector result is promised.
- Full deck generation/editing is **not available yet**: the configured presentation-service credential was rejected. The button stays disabled until a valid server-side `MANUS_API_KEY` passes authentication. There is no fake PPTX output or claim of a successful real deck generation.

## Validation

- TypeScript and the production build passed. The final regression suite passed 347 tests; six opt-in live tests were skipped.
- Business planner passed a real model request with synthetic data; the server validates its complete schema and recomputes rubric scores.
- Google grounding, public source research and AI outline generation were live-tested with synthetic/public questions earlier in this update. Presentation-service authentication failed and is reported as an explicit blocker.
- Phone browser tests passed on both the development preview and standalone compiled production server at 320, 390 and 430 CSS pixels: clean visible citation links, editable/revisable PowerPoint outlines, honest credential gating, two Business charts, downloaded plan contents, no horizontal page overflow and no uncaught page errors. Browser workflows use mocked API responses; they do not prove a real PPTX can be generated with the rejected credential.
- Additional regression tests verify the exact presentation task creation envelopes, completed-task attachment extraction, private PPTX storage and ownership without sending service requests.
- Existing calls and video-generation providers were not replaced by this update. Their prior provider/account limitations remain unchanged.

## Next setup

A project administrator must configure a valid presentation-service credential in server-side project secrets, then use **PowerPoint → Re-check connection**. Do not paste an API key into chat or source code. No additional paid service has been purchased by this task.

The current saved project must be published through the app's publishing controls to replace any older production deployment. The development preview reflects these changes immediately.
