# InVideo connection for Adus

The user chose InVideo, not fal.ai or Runway. The screenshot's Python example was not used.

InVideo's official guide supports remote Streamable HTTP at `https://mcp.invideo.io/mcp`, OAuth account sign-in, and authenticated JSON-RPC calls. Its official tools cover timeline editing and image, video and audio generation. Generation uses the InVideo account's own available credits; it is not an override for Google's quota.

The older third-party listing's `https://mcp.invideo.io/sse` returned 404. Both official `/mcp` hosts responded with account sign-in challenges. No account tokens were sent.

The actual connection attempt failed at OAuth client registration: `invalid_client_metadata — client_name is not an allowed client; public registration is restricted to a hardcoded set of partner clients`. No InVideo connection was created and no InVideo video was generated. Do not claim connected, invent API-key endpoints, or use another authentication route to evade this registration failure. Next step is approved client access from InVideo, followed by supported account authorization and server-side integration in Adus. A Manus connector alone would not wire the deployed website.

Sources checked 11 October 2026:
- https://invideo.io/mcp/
- https://invideo.io/agents.md
- https://invideo.io/news/introducing-invideo-mcp/
- https://help.invideo.io/en/articles/17336887-which-platforms-support-invideo-mcp

Requested audio behavior: no new spoken voiceover unless requested; if requested, create natural-language narration with the chosen voice. Do not confuse disabling narration with automatically stripping all ambience, music or original source audio.
