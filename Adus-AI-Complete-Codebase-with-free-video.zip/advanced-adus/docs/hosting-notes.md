# Hosting integration notes

Netlify static deploy adapter is grounded in https://docs.netlify.com/api-and-cli-guides/api-guides/get-started-with-api/ and https://developers.netlify.com/guides/deploy-zip-file-to-production-website/ (consulted 2026-10-10).

A generated static HTML artifact is deployed by creating a site, uploading a ZIP to `/api/v1/sites/{site_id}/deploys`, and confirming readiness from `/api/v1/deploys/{deploy_id}`. `ready` means the deployment is live. Selecting a host is not deployment authorization; the final review button approves the exact artifact and host. Tokens are transient per-user inputs, never saved as shared environment credentials. Vercel and other hosts need their own deployment adapters. Custom domains require separate DNS authorization and are not configured by this release.

Runtime video rendering needs FFmpeg, espeak-ng and fonts (root Dockerfile). Study videos use synthetic English/French narration, not the call's browser voice. The default hosted runtime is request-bound; no in-process detached queue is used. Videos are capped and rendered within a request, with durable outputs in object storage.
