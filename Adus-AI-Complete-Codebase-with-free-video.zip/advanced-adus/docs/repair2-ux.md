# Phone UX and independent downloads

Downloads are served by the deployed app through authenticated ownership checks and short-lived same-origin attachment links. They read persistent object storage, not files from an assistant computer. Canonical URL decoding and stream-prefix buffering handle escaped storage keys, legacy storage URLs and PNG/PDF/MP4 signatures split across network chunks. One Download press works after a ticket is prepared; transient ticket delays fall back to a validated browser File.

Mobile previews use available width. Desktop overview defaults to fitting the complete 1280px page width, with an Actual size control for readable sideways scrolling. Fullscreen expands the preview. Generated scripts execute only in an opaque-origin iframe; they cannot access workspace cookies. Stable remounts, bounded widths and resize updates reduce blank previews and navigation clipping. The empty upgrade profile now returns null rather than undefined.

Browser Download saves to Files/downloads. Where supported, the native share sheet offers Save to Photos; a web app cannot silently bypass the phone OS and write directly into a gallery. Embedded browsers can impose their own download restrictions.

Deterministic UX tests passed 6/6. Baseline compiled production phone tests downloaded actual PNG/PDF/MP4 bytes and played stored narration without assistant browser modules. Final repaired production smoke remains required after the last fit-width change.
