# Teacher timing repair

The browser now drives animation from the playing audio element's real `currentTime` using requestAnimationFrame, rather than only coarse timeupdate events. Pausing, seeking, speed changes and scene changes use that same audio clock. Browser playback and the exported MP4 share scene boundaries and reveal functions normalized to measured narration duration.

Writing starts after a short erase transition capped at 250 ms, not after fourteen percent of an entire scene. All diagram content is written by 85% of the scene so the final explanation never waits for the board. Speech timbre and English/French/Arabic configuration are unchanged. Phrase cues are proportional estimates, not verified word-level forced alignment.

Focused timing/export/provider/source suites passed 30 tests, with one live GitHub test intentionally skipped. Whole-app tests passed 132 with two optional live tests skipped before the final minor reliability fixes; final release checks will be recorded separately. MP4 rendering can reuse saved narration instead of repeating the TTS request. Real browser playback is covered by the phone smoke test.
