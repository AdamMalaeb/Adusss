# Upgrade area — workspace extensions

## Delivered

- Removed the behavior-preference drafting workflow from the primary Upgrade page. A request such as **“Add new tab named test”** now goes to the declarative workspace-tab workflow, so it does not enter the preference title schema.
- Added deterministic parsing for three supported commands:
  - `Add a new tab named Test`
  - `Rename tab Test to Study`
  - `Remove tab Test`
- Added reviewed, durable, reversible tab actions. The server stores tabs and actions in the existing `workspaceRecords` store, scoped by authenticated `ctx.user.id`.
- Added owner-only mutations using the existing `isSourceUpgradeOwner` policy (admin or configured owner identity). Non-owner users can read only their own tab records; they cannot propose, activate, or undo changes.
- Added actual `/workspace/:slug` route/page and dynamic sidebar entries. The page renders only persisted tab metadata/content; it does not evaluate arbitrary code or HTML.
- Renamed the mutation endpoint from reserved `apply` to **`activate`**. The composed `appRouter` import succeeds.
- Expanded source-upgrade protected paths so the code-draft workflow cannot target the workspace extension control plane, `App.tsx`, dashboard navigation, or the dynamic workspace page. Source upgrades remain a reviewed private-repository draft-PR flow and do not pretend to rewrite the running app.

## Integration contract

Parent router registration (already mounted by the parent):

```ts
import { workspaceExtensionsRouter } from "./workspaceExtensions";

adus: router({
  // ...
  workspaceExtensions: workspaceExtensionsRouter,
});
```

Client procedures:

| Procedure | Auth/scope | Input | Result/behavior |
|---|---|---|---|
| `adus.workspaceExtensions.status` | protected; reports whether current user is owner | none | `{ owner, scope: "This user's workspace only" }` |
| `adus.workspaceExtensions.list` | protected; current user only | none | active `WorkspaceTab[]` |
| `adus.workspaceExtensions.get` | protected; current user only | `{ slug }` | matching tab or `null` |
| `adus.workspaceExtensions.history` | protected; current user only | none | validated action history |
| `adus.workspaceExtensions.propose` | owner-only | `{ prompt }` | `{ id, operation, summary, before, after, status: "proposed", ... }`; no tab mutation yet |
| `adus.workspaceExtensions.activate` | owner-only | `{ id, confirmed: true }` | applies the reviewed action; returns `{ applied, actionId, tab }` |
| `adus.workspaceExtensions.undo` | owner-only | `{ id, confirmed: true }` | reverses an applied action if the tab is unchanged; returns `{ undone, actionId, tab }` |

`WorkspaceTab` shape: `{ id, label, slug, path, createdAt, updatedAt }`, with paths constrained to `/workspace/<safe-slug>`. Actions reject unsupported commands, unsafe names, duplicate routes, stale proposals, and cross-owner IDs.

## Files

- `server/workspaceExtensions.ts` — parser, validated action planner, durable tab/action persistence, owner-gated router export.
- `server/workspaceExtensions.test.ts` — regression coverage for parsing, unsupported/unsafe requests, ownership, per-owner isolation, durable activation, undo, duplicate routes, and stale actions.
- `client/src/pages/Upgrade.tsx` — workspace-tab review/apply/undo UI plus the separate honest source-code section; no preference draft box.
- `client/src/pages/WorkspaceExtension.tsx` — actual dynamic tab destination.
- `client/src/App.tsx` — `/workspace/:slug` route.
- `client/src/components/DashboardLayout.tsx` — persisted tabs appended to sidebar navigation.
- `server/sourceUpgrade.ts` / `server/sourceUpgrade.test.ts` — control-plane path protections and regressions.

## Verification and caveats

- `pnpm exec vitest run server/workspaceExtensions.test.ts --reporter=dot`: **6 passed**.
- `pnpm exec vitest run server/sourceUpgrade.test.ts --reporter=dot`: **11 passed, 1 skipped**.
- Combined focused run: **17 passed, 1 skipped**.
- `pnpm exec tsx -e 'import("./server/routers.ts").then(() => console.log("appRouter import ok"))'`: **passed** after renaming `apply` to `activate`.
- `git diff --check` passed for the owned files; no reserved workspace endpoint (`apply`, `then`, or `call`) remains.
- A full TypeScript check was not clean because of unrelated pre-existing `server/professorVideo.ts` diagnostics (and other shared worktree diagnostics observed during development). No full build was run.
- GitHub source-code creation is still intentionally setup-required without private `ADUS_SOURCE_REPO` + server-only `GITHUB_SOURCE_TOKEN`; no `.env`, credentials, account privacy, authorization policy, push, purchase, or source publish was changed.
