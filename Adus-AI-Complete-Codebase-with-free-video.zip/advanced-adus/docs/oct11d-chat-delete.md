# Chat delete / restore

## Delivered

- Added protected `conversations.archive` and `conversations.restore` mutations.
- Conversation records use a soft-delete marker (`archived` plus `archivedAt`) inside the existing JSON payload stored in `workspaceRecords`; no destructive row deletion or schema migration is needed.
- Normal `list`, `get`, `rename`, `append`, and `getConversationContext` paths hide/reject archived conversations with `NOT_FOUND`.
- Archive and restore are idempotent for the owning account. Cross-user access remains indistinguishable from a missing conversation.
- Per-user/per-conversation mutation serialization prevents an attachment upload or pending append from overwriting an archive marker.
- Chat history now exposes a keyboard-accessible remove button. Home confirms removal, clears the active thread immediately, blocks stale pending saves/replies from resurfacing it, and provides an Undo action that restores the saved messages.

## Files

- `server/conversations.ts`
- `server/conversations.test.ts`
- `shared/conversations.ts`
- `client/src/components/ConversationHistory.tsx`
- `client/src/pages/Home.tsx`

## Verification

- `pnpm exec vitest run server/conversations.test.ts --reporter=verbose`: **10 tests passed**.
- `pnpm exec prettier --check server/conversations.ts server/conversations.test.ts shared/conversations.ts client/src/components/ConversationHistory.tsx client/src/pages/Home.tsx`: **passed**.
- `pnpm check`: existing unrelated failures remain in `server/communicationsContacts.ts` and `server/communicationsRouter.ts` (downlevel `Set` iteration, mailbox typing, and campaign typing); no conversation-file error was reported.

No live model/media calls, real user records, emails, purchases, commits, or pushes were performed.
