# Research routing and grounding report — 2026-10-12

## Implemented behavior

Stable concepts and ordinary teaching questions are now answered directly. The research classifier no longer treats every factual question as a live-search request. In particular, `Explain the current conservation law in physics` and `What is the current conservation law in physics?` return `false` from both `shouldResearchChat` and `shouldResearchQuery`; the word “current” is allowed inside an established scientific term. An explicit request such as `Research the current conservation law in physics` still returns `true`.

Live research remains enabled for explicit research/source requests, public URLs, directory requests, genuinely current facts (for example, current leaders, prices, hours, deadlines, regulations, recent news), and dated requests such as 2026 visa rules. Private files, history, attachments, mathematical expressions, and ordinary explanations remain excluded.

The public fallback now requires the fetched page body to contain query terms. For multi-concept queries it requires at least two distinct signals, with title/URL corroboration allowed for one body term. A search result is not treated as evidence merely because the provider returned it.

Google grounding parsing now retains a source only when a grounding support maps it to an actual excerpt. It accepts either the provider's support text or a bounded `startIndex`/`endIndex` slice of the generated answer, ignores malformed/out-of-range mappings, validates HTTPS URLs, sanitizes titles, and emits explicit evidence-versus-proof language. `formatCitationEvidence` is shared by the Google and public fallback contexts.

Shared prompts now say to answer established knowledge directly, avoid an unnecessary sources-unavailable notice for stable teaching questions, preserve the latest request's language/dialect, give substantive prose rather than unnecessary code, and never promise permanent or universal correctness. Citation guidance says that an excerpt supports only the claims it actually contains.

## Real configured provider verification

One synthetic current request was sent through the configured Google Search path with the existing `GEMINI_API_KEY` present. The request used the configured default model (`gemini-3.8-flash`) and the actual `tools: [{"google_search": {}}]` Generate Content request shape. The provider returned HTTP **429**, so the result was safely reported as `status: "unavailable"`, with zero sources and no invented citations. The key itself was never printed.

The public fallback was then exercised once with a synthetic current request. Both search/read paths produced no usable source within the bounded safety/time limits, so it returned `status: "unavailable"` with engine `bing-rss`, zero sources, and the existing explicit instruction to say that live verification was unavailable. Search snippets were not cited.

This is an availability failure, not evidence that the routing or grounding contract is incorrect. The application must not claim that current details were verified when both providers fail.

## Official grounding references

Google's official documentation states that Generate Content grounding uses `tools: [{ "google_search": {} }]`; successful responses include `groundingMetadata`, `groundingChunks`, and `groundingSupports`, where supports map answer segments to source chunk indices. The parser follows that contract and keeps only mapped source excerpts.

- [1]: https://ai.google.dev/gemini-api/docs/generate-content/google-search "Grounding with Google Search — Generate Content API"
- [2]: https://ai.google.dev/gemini-api/docs/google-search "Grounding with Google Search — Gemini API"

## Parent integration contract

The parent-owned `server/routers.ts` can continue importing the backwards-compatible `shouldResearchChat` export. It may also import `shouldResearchQuery` when the clearer name is preferred; both are equivalent. `collectGoogleResearch` remains the configured first provider and `collectChatResearch` remains the public fallback. `formatCitationEvidence` is available from `shared/chatCitations.ts` for any other server prompt that needs to serialize already-retrieved excerpts. No router changes were made by this worker.

## Verification

- Focused tests: `pnpm exec vitest run server/chatResearch.test.ts server/googleResearch.test.ts server/currentKnowledge.test.ts server/assistantStyle.test.ts --reporter=dot` — **4 files, 22 tests passed**.
- TypeScript: `pnpm exec tsc --noEmit --pretty false` — passed after the owned changes.
- Direct routing probe confirmed stable conservation-law teaching prompts are `false`, explicit research/current leader/dated visa/directory prompts are `true`, and ordinary photosynthesis is `false`.

No training cutoff, 100% accuracy, or forever-current guarantee is made. Retrieved pages remain evidence that must match the specific claim, not proof of every answer statement.
