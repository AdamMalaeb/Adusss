# Adus — saved conversations and functional workspace release

## Completed

- Creator questions return only **Adam Nabih Malah**. Further biography is supplied only when requested, using the approved biography and date-aware age. Attribution remains truthful about AI tooling.
- Removed Professor Explainer from Videos; educational professor-style lessons remain in Studying.
- Saved, titled conversations have a New chat action and account-scoped history. Reopening and reloading restore the conversation. The model receives recent context plus relevant older messages from that thread; this is bounded retrieval, not a guarantee of flawless unlimited recall. Attachments are saved as storage references, not database file bytes.
- Chat, website, image and video workspaces remain mounted when switching app sections. Hidden calls release microphone and camera; pending text replies can still be saved. Study processing is owned by a single app-scoped runner with per-account/task identity guards and resumable course IDs.
- Study processing continues when navigating to Chat Only in the same open app. Closing the browser suspends request-driven work; saved chapters can resume on return. No assistant-local process is required by the deployed application.
- Functional translator tabs provide text input, source/target language controls, Translate, and rendered output. Summarizer and arithmetic calculator functions are also available. Natural translator-tab requests are accepted; legacy translator records receive the correct function. Selected-tab configure/remove controls use durable IDs rather than guessing names.
- Chat, study summaries, PDF exports and custom tool results render formulas and arrows with shared KaTeX/Unicode normalization while preserving actual currency and code.
- Video sources use authenticated multipart uploads instead of base64 RPC transport. MP4, MOV, M4V and WebM containers are byte/probe validated. The source cap is 80 MB and 120 seconds; rendered download output is capped at 64 MB.
- Deterministic source-video editing supports reviewed cuts, mute, speed, crop and rotation on the app server, without Google cinematic quota.
- Response paths avoid unnecessary automatic fallback chains, bound network waits, and preserve explicit Fast/Deep model selection. Speech queue and per-turn timeouts remain bounded; no claim is made that Adus is smarter than every model or can eliminate provider latency.

## Verification

- `pnpm check`: passed.
- `pnpm test`: 260 passed, 2 skipped; 43 passing test files, 1 skipped live-credential file.
- `pnpm build`: passed.
- `git diff --check`: passed.
- One live translator test returned French through the configured app model in approximately 3.2 seconds; this is one observation, not a latency guarantee.
- Real FFmpeg container/edition and PDF/math tests are included in the suite.
- HTTP multipart route test accepted a 13 MB upload and rejected unauthenticated/malformed requests (storage mocked for isolation).
- Standalone compiled production server passed phone-sized browser tests with isolated mocked accounts/provider responses: saved chat reopen/reload, translator operation, summary finishing off-page, professor removal from Videos, source edit-plan progression, real MP4 playback/download, enlarged camera, snapshot forwarding and microphone-only mute. No page errors occurred.

## Remaining boundaries

1. **Cinematic generation and generative restyling:** the configured Google project previously returned HTTP 429 for unavailable video quota. Application code cannot grant that quota. No new generation was represented as successful and no repeated quota-blocked media requests were issued in this release.
2. **Arbitrary new features/source rewrites:** translator/summarizer/calculator tabs work immediately through the supported function system. General source changes still require a configured private source repository, server-only GitHub credential, reviewed code proposal and deployment. The app does not pretend that adding a database tab rewrites its own source.
3. **Phone permissions and gallery:** camera/microphone access must be allowed by the device/browser. Download writes to browser Files/Downloads; native Save to Photos/Share is exposed where the phone supports file sharing. A website cannot bypass OS permissions or silently write into Photos.
4. **Memory and unattended work:** stored thread history is account-scoped, retrieval context is bounded, and request-driven study work resumes rather than continuing after the browser is completely closed.

Publish the saved checkpoint through the project's Publish control to update the existing live domain. Preview and production verification above do not themselves publish the app.
