# Current video-generation blocker

The configured Google project returned HTTP 429 with no available video-generation quota. Both the previous corrected real test and the user's latest screenshot report this same provider rejection. No video operation was created. Do not retry automatically or pretend this is fixable by UI changes. Narration uses separate speech models and remains working.

Official Google documentation: https://ai.google.dev/gemini-api/docs/rate-limits . Quotas apply per project, not per API key; model-specific active limits are visible in Google AI Studio. A replacement key for the same project does not create more project quota. Account billing/limit changes require user action and must never be made automatically. No additional generation test is needed until project access/quota changes.
