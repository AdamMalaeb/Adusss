# Adus — October 11 verified release

## Implemented

- Larger camera-call stage, current-turn JPEG visual context, front/rear switching and camera cleanup. Microphone mute disables only the user microphone; camera and pending/playing bot audio remain active. The assistant sees a current snapshot per spoken turn, not a continuous video feed.
- Professional, kind, mature response instructions for calls, chat, source-grounded summaries and professor scripts. Calls receive natural neural audio in English, French or Arabic, with male/female voices and a browser fallback only when explicitly selected. Safari audio uses the element unlocked by Start Call.
- Bounded recovery for empty model replies; no duplicate retry for permanently exhausted quota. No claim to surpass every AI or to guarantee latency.
- Source-grounded professor lessons include definitions, formulas, worked reasoning and common pitfalls. Board actions support real geometric waves/circles/axes/curves, progressive writing, highlights and clearing earlier marks; the audio clock controls motion. Phrase timestamps are estimated, not forced alignment.
- Videos has a separate Professor explainer workflow with durable script/narration/render stages, saved progress and retry of the missing stage. A real 31.24-second H.264/AAC MP4 was generated from a real AI script and neural narration. This is an animated instructor and board, not a filmed or photorealistic professor.
- Exact HTML document import, preserved private navigation and fit-width phone previews. Reviewed HTML export remains independent of publishing.
- App-served, signed image/PDF/video downloads; professor videos are included in user ownership checks. Download saves to browser Files; Save/Share uses the OS sheet where supported. No website can silently force an iPhone gallery save.
- Upgrade makes repository code proposals the primary workflow and behavior preferences secondary. Code changes are reviewable branches/draft PRs, not automatic live-server rewriting.

## Verification

- TypeScript check, production build and diff whitespace checks passed.
- 190 deterministic tests passed; 2 optional live tests skipped.
- Phone call test used simulated auth/camera/microphone and real app UI: 348 x 253px camera, current snapshot sent, neural audio fetched, microphone-only mute, no call chat bubbles, no JS errors.
- Saved actual website HTML navigation test passed eight internal links without blanking; missing pages explain what is unavailable instead of nesting the workspace.
- Compiled production server (no Vite or assistant modules) passed phone PNG/PDF/MP4 download tests, board-motion/audio playback, width containment and repeated page navigation. Provider/account responses were mocked in browser tests; media bytes were real.
- Real professor video narration and MP4 output separately verified. Its staged phone UI played the actual MP4 after three mocked durable API stages, without calling the cinematic generation route.

## Remaining account boundaries

- Cinematic generation uses the catalog-visible `veo-3.1-generate-preview`; the earlier unavailable Fast default was corrected. The latest real cinematic request remains HTTP 429/no available project video quota. No successful cinematic inference is claimed. Model catalog visibility does not prove inference quota. Inspect the configured project in Google AI Studio; application code cannot increase project quota. Professor videos do not require Veo but still require speech/model availability.
- Source repository `AdamMalaeb/Advanced-adus` still reports Public. No private source was uploaded. Runtime `ADUS_SOURCE_REPO` and `GITHUB_SOURCE_TOKEN` are absent; real code-upgrade PRs require a private repository plus repository-scoped server credential (Contents and Pull Requests read/write, Checks read).
- Netlify publishing requires the user host token; no host credential was supplied and no public deployment was performed. GitHub Pages is an explicit public publishing flow, distinct from the private app source repository. Vercel remains unavailable rather than pretending to publish.
- Normal app use needs its configured hosting, auth, database, storage and AI providers, but no assistant session or assistant computer. These fixes must be published through the project Publish control to replace the existing live release.
