# Business tab implementation

## Scope

New files owned by this feature:

- `shared/business.ts` — strict Zod input, plan, rubric, source, unit-economics, and persisted-record contracts; fixed rubric definitions; deterministic weighted-average score.
- `server/businessRouter.ts` — protected tRPC router for generation, history, owned restore, and revision.
- `server/business.test.ts` — focused contract/router tests.
- `client/src/pages/Business.tsx` — dark `WorkspaceShell` page with the brief form, plan sections, charts, history, restore, revise, and Markdown export.

Parent integration remains intentionally outside this change: mount `businessRouter` at the requested top-level `trpc.business` key and route `/business` plus navigation.

## Contracts and API

`businessInputSchema` validates:

- idea: 4–4,000 characters;
- country / market: 2–160 characters;
- optional non-negative finite budget up to 1e12;
- three-letter uppercase currency code (default `USD`);
- customer and experience fields;
- `researchLocalMarket`, default `false`.

Protected procedures:

- `business.history` — lists up to 50 valid plans for the authenticated user.
- `business.get({ id })` — reads one owned plan.
- `business.restore({ id })` — read-only owned restore payload for the editor; it does not delete or overwrite versions.
- `business.generate(input)` — optionally retrieves public research, invokes the selected deep chat model with a strict JSON schema, validates the output, replaces unsupported unit-economics numbers with null, calculates the score, and persists a new record.
- `business.revise({ id, instruction })` — reads one owned plan, creates a new revision record, and leaves the prior version unchanged.

Persisted kind is `businessPlan`; all storage calls include `ctx.user.id`, and every endpoint is `protectedProcedure`.

## Research and citations

Research is off by default. When enabled, the server sends only `research <sanitized countryOrMarket>` to `collectChatResearch`. The idea, customer, budget, experience, and previous plan are not part of the public query. `collectChatResearch` is responsible for public URL validation and reading original pages. The plan receives only those returned source URLs/excerpts; `groundChatCitations` removes model-generated Markdown links that are not in the retrieved URL allow-list. When research is unavailable, the prompt requires an explicit caveat and no invented citations.

## Structured plan and score

The strict output includes strategy, customer, market, competitor alternatives, SWOT, operating structure, marketing, milestones, risks, practical advice, assumptions, missing information, seven rubric factors, sources, and research status. The model is explicitly told that the score is **not** a probability, forecast, confidence, or success chance.

Rubric weights are fixed and normalized to 100%:

| Factor | Weight |
| --- | ---: |
| Problem clarity | 15% |
| Customer specificity | 15% |
| Market access | 15% |
| Differentiation | 15% |
| Operational readiness | 15% |
| Economics | 15% |
| Validation evidence | 10% |

`calculateFeasibilityScore` clamps each factor to 0–100, ignores invalid/non-positive weights, computes the weighted mean, and rounds to two decimals. Model-provided labels/weights are replaced by these fixed server definitions. Missing evidence is represented in each factor’s `missingInfo` and in the plan-level `missingInformation`.

## Unit economics

The generated plan stores null unit-economics values unless the user supplied assumptions (this form does not supply them). The client chart appears only after the user enters non-negative price, customers/month, variable cost, and fixed costs. It shows formulas from those editable assumptions only:

- revenue = price × customers;
- variable cost = variable cost/customer × customers;
- net after costs = revenue − variable cost − fixed costs;
- break-even customers = fixed costs ÷ (price − variable cost), only when contribution per customer is positive.

The UI labels these as illustrative assumptions, not sourced values or a forecast. No random or fabricated chart data is used.

## UI behavior

The page is mobile-first with `min-w-0` on feature containers and uses the existing dark `WorkspaceShell`. It includes:

- idea, market, optional budget/currency, customer, and experience fields;
- opt-in public-market checkbox;
- loading/error states;
- executive summary and all required plan sections;
- Recharts vertical rubric factor bars;
- editable unit-economics scenario chart;
- saved-plan history with owned restore;
- focused revision instruction and new-version persistence;
- Markdown download with actual UTC generated date and only retrieved source links.

The page does not claim AI detection, business success, or completion of any external action.

## Verification

Focused command:

```bash
cd /home/ubuntu/advanced-adus
pnpm vitest run server/business.test.ts --reporter=verbose
```

The focused suite covers deterministic score math, validation bounds, strict output rejection, no-research default, private-idea/public-query separation, validated source grounding, null unit economics, missing-information handling, authentication, owned restore, and revision lineage.

At handoff, the focused Business tests pass 7/7. A full project typecheck cannot be clean until the parent mounts `businessRouter` in the root router; the page’s `trpc.business` hook errors are expected while that mount is absent. Existing unrelated repository typecheck/dev-server diagnostics may also appear in the shared worktree.
