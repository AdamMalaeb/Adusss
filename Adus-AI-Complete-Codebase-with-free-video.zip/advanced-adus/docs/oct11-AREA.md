# Oct 11 — Upgrade area report

## Scope

Owned upgrade-area work is limited to `server/sourceUpgrade.ts`, `server/upgradeRouter.ts`, `client/src/pages/Upgrade.tsx`, `server/sourceUpgrade.test.ts`, and this report. No application commit, checkpoint, push, privacy change, merge, deploy, or publish was performed.

## Changes

- Made **Repository code upgrade** the primary section on the Upgrade page; behavior preferences are explicitly optional and secondary.
- Kept code upgrades owner-only and bounded: server-only GitHub access, private repository requirement, allowlisted source roots, protected auth/control-plane paths, exact reviewable diffs, stale-base rejection, draft-PR-only approval, and no merge/deploy/publish claims.
- Added resilient structured-output handling for both behavior and source proposals: accepts text or text-part content, strips optional JSON fences, performs one bounded `jsonrepair` attempt, then validates against the existing Zod schemas. Empty, malformed, or schema-invalid responses return truthful no-change errors.
- Behavior proposal route continues to use the verified `gpt-5-mini` model and does not claim that engineering prompts changed code. It stores a preference proposal only after validation.
- Source proposal route continues to use the verified deep model selected by `selectChatModel({ mode: "deep" })`; the live catalog was rechecked by the parent and includes the configured model IDs.
- Canonical source-upgrade credential name is `GITHUB_SOURCE_TOKEN`; `ADUS_GITHUB_TOKEN` remains accepted as a migration alias. Neither token is returned to the browser or rendered in UI.

## Exact API contracts for parent

### `server/sourceUpgrade.ts`

- `getSourceUpgradeConfig(env)` reads `ADUS_SOURCE_REPO`, `GITHUB_SOURCE_TOKEN`, optional `ADUS_GITHUB_TOKEN` fallback, and optional `ADUS_SOURCE_BASE_BRANCH`.
- `getSourceUpgradeConfigStatus(config)` returns `{ configured, repository?, baseBranch?, missing: string[], message }`. Missing token is reported as `GITHUB_SOURCE_TOKEN`.
- `parseStructuredJson<T>(raw, schema, label): T` accepts a string or Forge text-part array, strips one optional markdown JSON fence, attempts strict `JSON.parse`, then one `jsonrepair` parse, and throws `SourceUpgradeError("INVALID_PROPOSAL", ...)` on empty/invalid/schema-invalid data.
- `createSourceProposal(request, config, options?)` still returns `ValidatedSourceProposal` with `{ title, summary, changedFiles[{ path, content, reason, originalContent, diff }], tests, baseCommit, baseBranch, repository }`; no GitHub write occurs.
- `applySourceProposal(proposal, config, options?)` still returns draft-only `{ branch, commitSha, pullRequestNumber, pullRequestUrl, draft: true, ci: { status, checks, url } }`, after private-repository and base-commit checks.

### `server/upgradeRouter.ts`

- `adus.upgrade.propose` input remains `{ prompt: string }` (4–4000 chars). Output remains `{ id, title, instructions, changes, checks, requiresEngineering, engineeringNotes }` after strict schema validation.
- On empty/malformed/schema-invalid behavior output, route throws a `BAD_GATEWAY` tRPC error beginning `The behavior proposal service ...`; no workspace record is saved and no preference changes.
- `adus.upgrade.source.status` remains owner-gated and reports truthful setup status; it does not perform GitHub writes.
- `adus.upgrade.source.propose` remains owner-only, input `{ prompt: string, branch?: string }`, and saves only a validated `status: "proposed"` record.
- `adus.upgrade.source.approve` remains owner-only and requires `{ id, confirmed: true }`; it is the only route that can request the server-side draft branch/PR flow.

### `client/src/pages/Upgrade.tsx`

- Uses existing tRPC hooks and preserves behavior/source history and download/auth navigation.
- Primary UI copy says code changes are proposed as bounded diffs and require owner review; source setup copy names `ADUS_SOURCE_REPO` and `GITHUB_SOURCE_TOKEN` only.
- Error displays preserve the server's truthful no-change message when available; no token or browser credential is displayed.

## Tests

- `pnpm exec vitest run server/sourceUpgrade.test.ts server/workspaceFeatures.test.ts --reporter=dot`
- Result: **2 files passed, 24 tests passed, 1 existing optional live test skipped**.
- Added mocked tests for canonical token/legacy alias resolution and fenced/lightly malformed JSON repair plus schema rejection.
- No real GitHub writes or live LLM calls were used.

## Blockers / parent action

- `gh repo view AdamMalaeb/Advanced-adus` read-only inspection reports `isPrivate: false`. User explicitly denied privacy changes/push/public upload. Make the repository private through the GitHub UI only after final confirmation; this worker did not change it.
- Deployed application runtime is not configured: `ADUS_SOURCE_REPO` is unset; `GITHUB_SOURCE_TOKEN` is unset; legacy `ADUS_GITHUB_TOKEN` is also unset. Parent may request these exact names once. Token must remain server-only and repository-scoped with Contents read/write, Pull requests read/write, and Checks read.
- No source proposal or draft PR can truthfully be created until the configured repository is private and those server environment values exist. UI intentionally reports setup required and disables proposal creation.
- A full project check was not treated as an area test because parent/other workers have concurrent unrelated files. Current non-area diagnostics include missing parent-owned router integration (`websiteImport`, `callSpeech`) and an existing/mutable camera-frame issue; parent owns final integration and release checks.

## Call / camera / neural speech worker update

### Owned files changed

- `client/src/lib/voiceCall.ts`: live-call playback now prefers server-returned neural WAV audio, with audio unlock on the Start Call gesture, robust `play`/`ended`/`error` handling, late-result/session cleanup, replay of the stored audio, and an explicitly labeled optional browser speech fallback. Mic mute only disables the user's audio tracks; it never cancels pending or playing bot audio. Added `VoiceLanguage`, conservative English/French/Arabic detection for Auto, and bounded audio playback state.
- `client/src/lib/cameraCall.ts`: preserved the existing video-only (`audio: false`) camera flow, front/rear switching, stale-stream stopping, current-turn JPEG snapshots only, and track cleanup; hardened permission-error classification across browser realms/test doubles so denied access remains recoverable without a leaked stream.
- `client/src/pages/Home.tsx`: wired call language (Auto/English/Français/العربية), neural call speech mutation, explicit `callLanguage` on voice chat, larger responsive camera stage (~60vw / up to 60vh), and an optional browser-voice fallback button that is never silent.
- `server/naturalSpeech.ts`: added `NaturalSpeechGender`, `NaturalSpeechMode`, gender voice mapping (`woman → Kore`, `man → Puck`), professional call style in English/French/Arabic, call storage prefix support, shared non-overlapping queue/pacing for study and call TTS, bounded max-2 429 retries, and `Retry-After` handling. `resetNaturalSpeechQueueForTests()` is test-only support.
- `server/callSpeechRouter.ts`: new isolated protected router for neural call audio.
- `server/cameraCall.test.ts`, `server/voiceCall.test.ts`, `server/callSpeechRouter.test.ts`, `server/whiteboardVideo.test.ts`: deterministic mocked camera permission recovery, neural playback, blank-audio, call contract/auth/error, and Retry-After coverage.

### Exact parent integration contract

Parent should add the imported router as `adus.callSpeech: callSpeechRouter` in `server/routers.ts`. The client contract is:

```ts
trpc.adus.callSpeech.synthesize.useMutation();
// input: { text: string, gender: "man" | "woman", language: "english" | "french" | "arabic" }
// success: { url: string, key: string, duration?: number }
// protected; provider key/audio bytes never reach the browser
```

Home also sends the parent-owned `transcribeVoice` input `{ dataUrl, mimeType, language: "auto" | "en" | "fr" | "ar" }` and `adus.chat` voice input `callLanguage: "auto" | "english" | "french" | "arabic"`.

### Test evidence

- `cd /home/ubuntu/advanced-adus && pnpm exec vitest run server/voiceCall.test.ts server/cameraCall.test.ts`: **2 files / 22 tests passed**.
- `cd /home/ubuntu/advanced-adus && pnpm exec vitest run server/callSpeechRouter.test.ts server/whiteboardVideo.test.ts`: **2 files / 13 tests passed**.
- Combined final focused run: **4 files / 35 tests passed** after the camera permission classifier fix.
- No live Gemini call, browser camera, user connector credential, storage credential, or secret was used. Audio provider behavior is fully mocked in tests.

### Blockers / parent action

- `Home.tsx` currently has one expected type diagnostic until parent wires `callSpeech` into `appRouter`; do not remove the Home integration—add the router at the parent-owned composition point.
- Do not run the full project check/build while concurrent workers are editing. Parent owns final router integration and release checks.
- Gemini direct TTS still requires the secure server-side `GEMINI_API_KEY`; it is not in this worker's environment/report and was not exposed or changed. If absent, the UI reports a recoverable natural-voice error rather than silently using robotic browser speech.


---

# Hosting area handoff — 2026-10-11

## Scope

Hosting/build-lab work completed at checkpoint `68039518`. No provider calls, public deployments, repository creation, source upload, purchases, credential changes, `.env` edits, or application commit/checkpoint/publish were performed. Existing private preview navigation guard, responsive preview scaling, signed HTML downloads, auth, and explicit public-publish confirmation remain in place.

## Changes

- `server/hostingRouter.ts` — added `adus.hosting.configuration` (protected, read-only); mapped Netlify HTTP errors to actionable account/token/slug/rate-limit messages; verified `/user` returns account details before creating a site; retained bounded polling and durable provider IDs.
- `server/websiteImport.ts` — new protected standalone router/helper for complete `.html`/`.htm` imports. Validates source size (max 200,000 characters), complete `<html>` + `<body>` document, null-character absence, and preserves the exact submitted HTML.
- `server/websiteImport.test.ts` — mocked tests for ownership, exact source preservation, title derivation/override, unsupported/fragment/oversize rejection, and unauthenticated access.
- `server/hosting.test.ts` — mocked tests for configuration shape, secret non-disclosure, and actionable Netlify 401 handling; existing Netlify ZIP, HTTPS-ready, GitHub Pages ownership, and polling tests remain.
- `client/src/pages/BuildLab.tsx` — file-picker and textarea HTML import UI; 200 KB client pre-check; preserves existing preview/exports/publish approval; host dialog now reads secret-safe adapter readiness and keeps Other as export-only; provider diagnostics are no longer collapsed when account/permission/rate-limit detail is safe to show.

## Exact parent integration contracts

Parent owns `server/routers.ts`. Wire the standalone router as:

```ts
import { websiteImportRouter } from "./websiteImport";

export const appRouter = router({
  // ...
  adus: router({
    // ... existing routes
    websiteImport: websiteImportRouter,
  }),
});
```

The Build Lab calls `trpc.adus.websiteImport.importHtml.useMutation()` with:

```ts
{
  filename: string; // must end in .html or .htm; max 255 chars
  html: string;     // 1..200,000 chars; complete <html> + <body>
  title?: string;   // optional, max 200 chars
}
```

Output:

```ts
{
  id: string;
  title: string;
  summary: string;
  html: string;       // exact submitted source, not preview scaffolding
  source: "imported";
  filename: string;
}
```

The procedure saves owner-scoped `kind: "website"` workspace records, so existing `websiteTicket` export and `hosting.publish` lookup can consume the returned `id`. Existing hosting publication rejects scripts, inline event handlers, javascript URLs, and forms; this remains intentionally stricter than private preview rendering.

The Build Lab also calls `trpc.adus.hosting.configuration.useQuery(undefined)`. The protected response contains no secret values:

```ts
{
  netlify: { host: "netlify", adapter: "ready", userTokenSupported: true,
             serverCredentialConfigured: boolean,
             credentialEnv: "NETLIFY_ACCESS_TOKEN" },
  github:  { host: "github", adapter: "ready", userTokenSupported: true,
             serverCredentialConfigured: boolean,
             credentialEnv: "GITHUB_PAGES_TOKEN" },
  vercel:  { host: "vercel", adapter: "coming-soon", userTokenSupported: false,
             serverCredentialConfigured: false, credentialEnv: null },
  other:   { host: "other", adapter: "export", userTokenSupported: false,
             serverCredentialConfigured: false, credentialEnv: null }
}
```

## Provider and environment requirements

- **Netlify:** current adapter uses the explicitly entered short-lived PAT for the publish/check operation. Official API semantics used: HTTPS `https://api.netlify.com/api/v1`, `Authorization: Bearer`, `POST /sites`, ZIP `POST /sites/{site_id}/deploys`, and readiness from `GET /deploys/{deploy_id}`. `ready` is published only when a valid HTTPS URL is returned. Source: [Netlify API docs](https://docs.netlify.com/api-and-cli-guides/api-guides/get-started-with-api/).
- **GitHub Pages:** current adapter creates a new **public** repository only after final confirmation, uploads exact `index.html` plus `.nojekyll`, configures Pages from the default branch root, then polls `/pages` until `status: built` and an HTTPS `html_url`. GitHub’s Pages API documents Pages write + Administration write for fine-grained tokens; repository creation needs appropriate repository permissions. Source: [GitHub Pages REST API](https://docs.github.com/rest/pages/pages).
- Optional server-side environment names recognized only for non-secret readiness reporting are `NETLIFY_ACCESS_TOKEN` and `GITHUB_PAGES_TOKEN`. **Both are absent in this sandbox.** Values were never printed, logged, or changed. The current UI still requires explicit per-operation token input and does not use these env credentials automatically.
- `ADUS_SOURCE_REPO` / `ADUS_GITHUB_TOKEN` are unrelated source-upgrade credentials and were not touched.
- Vercel remains explicitly non-functional/coming-soon; Other remains export-only. No deployment claim was made.

## Focused tests

```text
cd /home/ubuntu/advanced-adus && pnpm vitest run server/websiteImport.test.ts server/hosting.test.ts
Test Files 2 passed
Tests 16 passed
```

Only owned files were formatted with Prettier. `git diff --check` passed for the owned hosting files.

## Blockers and parent actions

- Parent must wire `websiteImportRouter` under `adus.websiteImport` in `server/routers.ts` before the Build Lab client type resolves. This was intentionally not edited because the parent owns router integration.
- The shared tree contains unrelated concurrent edits (voice/camera/study/source-upgrade files); no full `pnpm check`, build, or full suite was run here, per instruction. Parent should run release checks after integrating all routers.
- No live Netlify/GitHub call was made because tokens are absent and the task forbids public deployment/repository creation without final confirmation.
- GitHub Pages remains an explicit public-repository flow. There is no implicit use of `AdamMalaeb/Advanced-adus`, no source push, and no private-to-public change.


## Video area update — Professor explainer and cinematic separation

### Owned files changed

- `server/videoRouter.ts`: nested the protected `professor` router under the existing `adus.videos` namespace. Existing cinematic `generate`, source `upload`, `edit`, `status`, `list`, validated storage, ownership checks, and download behavior remain separate and unchanged in contract.
- `server/professorVideo.ts`: new helper that turns the learner prompt into a structured source-grounded script through the existing `analyzeStudyParts` contract, then calls the existing `createWhiteboardLesson` and `createWhiteboardVideo` pipeline. It produces natural neural narration plus deterministic animated board motion with writing/drawing/highlighting/erasing and a real MP4; it never claims a photorealistic teacher or silent text-only success. Error messages redact credential-like values.
- `server/professorVideoRouter.ts`: new protected owner-scoped durable job router. Records are stored as kind `professor-video` with stages `script`, `narration`, `render`, `done`; completed script/audio/output are reused on retry, concurrent calls are single-flight per user/job, and saved pending jobs self-resume on status polling after reload. Failed jobs preserve completed outputs and expose the failed step for resume.
- `server/professorVideo.test.ts`, `server/professorVideoRouter.test.ts`: fully mocked helper/router tests for prompt grounding, one reusable narration, render reuse, durable stage resume, owner scoping, and no duplicate script/narration work.
- `client/src/pages/Videos.tsx`: added a separate Professor explainer section below the existing cinematic Generate/Edit UI. It supports English/French/Arabic, prompt submission, saved-job polling, resume failed step, playable MP4, and `MediaSaveActions`. Copy explicitly distinguishes deterministic animated blackboard teaching from Veo cinematic generation and says no fake preview is used.
- `docs/oct11-AREA.md`: this report.

### Exact API contracts for parent

The parent does not need to edit `server/routers.ts` for this video integration: `videoRouter` now exports the nested `professor` router automatically through the existing `adus.videos: videoRouter` entry.

```ts
trpc.adus.videos.professor.create.useMutation();
// input: { prompt: string (3–12000 trimmed chars), language?: "english" | "french" | "arabic" }
// immediate success: { id, type: "professor", status: "pending", stage: "script", prompt, language }

trpc.adus.videos.professor.status.useQuery({ id });
// protected, owner scoped; pending status polling also resumes the saved job
// output: { id, type: "professor", status, stage, failedStep?, prompt, language,
//           title?, summary?, scenes?, sources?, warnings?, audioURL?, audioDuration?, url?, error? }

trpc.adus.videos.professor.retry.useMutation();
// input: { id }; protected owner scope; resumes first missing stage without
// regenerating saved script, saved narration, or saved playable MP4

trpc.adus.videos.professor.list.useQuery();
// protected owner scope; returns up to 30 durable Professor jobs
```

Helper procedure names for parent/other workers: `createProfessorScript(prompt, language)`, `prepareProfessorNarration(userId, jobId, script, language)`, `renderProfessorVideo(userId, jobId, script, language, audioURL)`, `professorErrorMessage(error, stage)`.

The Professor script uses `analyzeStudyParts([{ type: "text", text }], ["Learner educational brief"], language, "the learner's requested topic")`; this is the existing study analyzer export and remains compatible with the study worker's changes. Rendering reuses `createWhiteboardLesson` and `createWhiteboardVideo` from the whiteboard worker, including the stored narration URL so retry does not call TTS twice.

### Cinematic provider verification and Google evidence

- Official docs fetched: [Gemini video](https://ai.google.dev/gemini-api/docs/video), [Veo model page](https://aistudio.google.com/models/veo-3), and [Gemini rate limits](https://ai.google.dev/gemini-api/docs/rate-limits).
- Google’s current video guide says Gemini Omni Flash is the default for multimodal generation/editing, while Veo is for capabilities such as extension/frame control. The existing app intentionally keeps Veo for text-to-video and Omni for source editing; the two user workflows remain distinct.
- Current Google model catalog was checked once with the configured server credential without printing the key or starting generation. It returned only `models/veo-3.1-generate-preview` with `predictLongRunning` among video models. This proves catalog visibility, not quota, authorization, region support, or successful inference. Existing provider allowlisting still defaults to `veo-3.1-fast-generate-preview`; a later parent decision may be needed if the live deployment catalog differs from the earlier checkpoint catalog. No second generation was started because the known project state is HTTP 429 with zero available video quota.
- Google rate-limit docs state quotas are per project, not per API key; limits depend on model/tier and can return 429 `RESOURCE_EXHAUSTED`. User setup action is required in AI Studio/Google Cloud. No purchase, billing change, quota request, credential change, or public publishing was performed.

### Tests and verification

- `cd /home/ubuntu/advanced-adus && pnpm vitest run server/video.test.ts server/professorVideo.test.ts server/professorVideoRouter.test.ts --reporter=dot`: **3 files passed, 15 tests passed**. All provider and Professor tests are mocked; no live generation was used.
- Prettier check on owned files passed after formatting: `server/videoProvider.ts`, `server/videoRouter.ts`, `client/src/pages/Videos.tsx`, `server/professorVideo.ts`, `server/professorVideoRouter.ts`, `server/professorVideo.test.ts`.
- A full `pnpm exec tsc --noEmit` was run only for diagnostics; it currently reports four unrelated parent/other-worker integration errors for missing `websiteImport` and `callSpeech` router properties in `BuildLab.tsx`/`Home.tsx`. No video-area TypeScript error was reported. Parent owns final router integration and release check.
- No app commit, checkpoint, push, deploy, source upload, account permission change, or public publish was performed.

### Blockers / parent action

- Cinematic Google generation remains externally blocked by the known project HTTP 429/no available video-generation quota. Do not keep rerunning or claim a cinematic video was created. User must inspect the Google AI Studio usage/project limits and, if desired, configure the appropriate project tier/quota; app code cannot manufacture quota and changing keys within the same project does not increase it.
- Live catalog showed `veo-3.1-generate-preview` while the existing allowlist includes Fast/standard/Lite preview names. Before claiming cinematic generation works, parent should recheck the deployment project’s live catalog and either configure `GEMINI_VEO_MODEL` to an allowlisted available model or make a narrowly reviewed allowlist update. Do not change `.env` in this task.
- Professor mode needs both the existing Forge LLM runtime for script generation and the secure server-side Gemini TTS credential for narration. If TTS returns 429, the durable job records a failed `narration` step and Resume retries only that step; no silent robotic fallback or fake MP4 is used.
