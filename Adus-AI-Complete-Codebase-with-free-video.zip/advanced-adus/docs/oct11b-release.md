# Adus — camera, languages, math, video edits and tab upgrades

## Implemented

- **Camera calls:** larger preview, stable media attachment, lens constraint fallback, proper cleanup, microphone-only mute, current JPEG snapshot per spoken turn, and camera-permission recovery. A permission denial is respected rather than repeatedly retried. Camera audio is never used as microphone input.
- **Multilingual calls:** no forced-English transcription; explicit compatible language hints are sent when selected. Automatic calls use the detected source language or let neural speech infer the answer’s language, rather than defaulting all unknown text to English. Recorded chat dictation replaces English-only browser recognition.
- **Language selection:** shared supported-language catalog wired through speech, study summaries, lesson narration and professor-video generation. Support is provider-dependent, not a claim that every language or dialect has identical accuracy. Chat, image and editing prompts can be written naturally in the user's language.
- **Call recovery:** finite transcription, answer and speech-preparation waits; an eight-second audio-start watchdog offers replay instead of indefinite silence. Muting during bot speech or a pending answer disables only the user's microphone.
- **Equations and chemistry:** KaTeX/GFM rendering in chat, studying and exported summary PDFs. Actual arrows and subscripts replace raw dollar-delimited formulas and commands. Numeric equations, TeX delimiters and literal currency are treated separately. PDF math fonts are embedded rather than relying on external requests.
- **Source-video editing:** Videos → Edit source → Edit uploaded footage. Upload, describe the desired edit, review the AI plan, apply, then play/save a new MP4. Supported edits: keep/cut segments, mute, 0.5×–2× speed changes, normalized crop and rotation. The original is preserved. This workflow uses the deployed server’s FFmpeg rather than Veo video-generation quota.
- **Upgrade tab:** “Add a new tab named Test,” rename and remove operations are parsed into reviewed, reversible, durable tab changes. Applied tabs have real routes and appear in navigation. They no longer go through the behavior-preference schema that failed in the screenshot. This is a declarative workspace extension, not arbitrary live source-code execution.
- **Creator attribution:** Adam Nabil Malaeb’s approved biography is available when asked. Age is derived from the provided birth date rather than permanently saying 16. AI-assisted implementation is represented truthfully rather than claiming no AI tools were involved.

## Verified

- TypeScript check and production build.
- Full regression suite; final test totals recorded in the release tool output.
- Real FFmpeg fixtures produce H.264/AAC MP4, including silent-source compatibility; original bytes stay intact.
- Real summary PDF text extraction contains `3x + 5 = 14 ⇒ x = 3` and `C + O₂ → CO₂` rather than raw TeX.
- Phone-sized browser checks: large camera + current snapshot; real WAV playback; microphone-only mute; permission-denial help; no voice chat bubbles; rendered equations; reviewed Test-tab routing; source edit-plan review/apply. Authentication, provider replies and camera hardware in UI tests are isolated test fixtures, not changes to customer data. No physical iPhone hardware verification was possible.

## Not fixed by code / setup still required

1. **Cinematic generation and generative restyling:** the supplied screenshot reports Google HTTP 429 with unavailable project quota. No successful cinematic generation is claimed. No duplicate requests, alternate credential evasion, purchases or account changes were made. The configured Google project's limits must allow the requested model. Check https://aistudio.google.com/usage . Professor explainers and supported source edits use separate workflows; neither is presented as cinematic Veo output.
2. **Embedded camera denial:** a child page cannot override the containing browser’s camera permission or outer iframe Permissions Policy. Open https://aiworkspace-dyq23yap.manus.space/ directly in Safari/Chrome, allow camera and microphone, then start the call. The app includes recovery copy and a direct link.
3. **Repository self-upgrades:** arbitrary API/features/code changes remain a reviewed branch/draft-PR workflow and require a private source repository plus server-only `ADUS_SOURCE_REPO` and `GITHUB_SOURCE_TOKEN`. Tab changes do not require that setup. This release does not silently rewrite, merge or deploy source code.
4. **Publication:** a saved checkpoint updates the reviewable project version. Publish that version through the project’s Publish control to update the public domain unless auto-publish is enabled.

No promise of perfect language coverage, zero errors, or intelligence exceeding all other systems is made.
