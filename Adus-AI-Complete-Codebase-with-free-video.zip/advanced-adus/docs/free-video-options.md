# Free video replacement constraints

Checked 11 October 2026. The user requests a replacement provider capable of 1–5-minute videos with permanent free access. No provider satisfying duration, ongoing free usage, and a deployable integration was verified; do not promise one or replace the current provider with a limited trial without approval.

Runway's official credit guide says Free includes a one-time 125-credit deposit, not renewing video credits, and website-plan credits are separate from developer API credits. Its API pricing guide says each generation costs credits. InVideo's current pricing offers model generation through credit allocations. The earlier InVideo registration failure remains unresolved; no alternative auth attempt is authorized by a request for a free provider.

A different product mode could assemble 1–5-minute videos from uploaded/permitted stock footage, text and motion graphics without calling a generative-video provider. This does not produce arbitrary realistic AI footage and must not be represented as equivalent. Model scripting, human-like narration, storage and rendering can still incur charges. Obtain the user's choice before substituting this product behavior. Do not promise permanent no-cost infrastructure or provider pricing.

Sources:
- https://help.runwayml.com/hc/en-us/articles/15124877443219-How-do-credits-work
- https://docs.dev.runwayml.com/guides/pricing/
- https://invideo.io/pricing/
