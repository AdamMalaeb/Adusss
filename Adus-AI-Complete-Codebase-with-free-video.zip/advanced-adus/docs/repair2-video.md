# Repair 2 report — video

## Scope

- Moved new text-to-video generation from the rate-limited Gemini Omni Interactions endpoint to Google's asynchronous **Veo 3.1 Fast** endpoint (`veo-3.1-fast-generate-preview`).
- Kept the existing Gemini Omni path for source editing so edits remain focused and preserve untargeted content as before.
- Added durable provider/model metadata to pending records and reload recovery in the Videos page; status polling can resume from the saved operation ID without creating a duplicate job.
- Added official Veo operation parsing (`operations/*`, `done`, `response.generateVideoResponse.generatedSamples[0].video.uri`) and safe same-origin output download/validation.
- Added explicit HTTP 429 classification: quota exhaustion is distinguished from transient rate limiting, and neither is retried automatically or presented as a completed video.
- Kept the existing validated MP4 normalization, storage, ownership checks, and `MediaSaveActions` independent download/share controls.

## Evidence

- Official Google docs checked: [Gemini video](https://ai.google.dev/gemini-api/docs/video), [Veo](https://ai.google.dev/gemini-api/docs/veo), and [models](https://ai.google.dev/gemini-api/docs/models).
- Live model catalog previously queried for this repair reported `models/veo-3.1-fast-generate-preview` with `predictLongRunning`, plus Veo 3.1 and Lite variants. Catalog availability is not inference/quota success.
- The checkpoint's prior one permitted Omni live generation smoke returned HTTP 429. No second live generation smoke was started here; therefore this repair does **not** claim live Veo inference success.

## Verification

- `server/video.test.ts`: deterministic router/provider tests cover Veo request body and URI parsing, quota 429 messaging, HTML output rejection, authentication, ownership, pending persistence, and mocked completion.
- Focused tests and `pnpm check` must be reported with the actual output from the final run. Concurrent non-video worker changes may still produce unrelated type errors.

## Caveats

- Veo outputs are provider-limited short clips (configured here as 8 seconds at 720p), not arbitrary-length films.
- Source editing remains dependent on the configured Omni Interactions capability and account quota.
- Provider model availability does not guarantee project authorization, quota, region support, or successful inference.
