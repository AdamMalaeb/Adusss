# Communications — completed integration

## Available in the application

`/communications` is registered in the shared navigation and kept mounted during workspace navigation. The authenticated API is mounted as `adus.communications`; all client calls use inferred tRPC types. Nodemailer is included in project dependencies. The existing workspaceRecords table stores account-scoped mailbox settings, drafts and campaigns; no new migration is needed.

The workflow is: connect mailbox → research exact public contacts or enter recipients → draft or manually compose subject and message → save a campaign → review the complete saved sender, subject, body and recipients → approve and send that saved payload. Research, drafting and saving never send an email.

## Credentials and account boundaries

- SMTP credentials are verified and encrypted using AES-256-GCM with a key derived from the server-only JWT_SECRET. They are not returned by the API.
- Mailbox record IDs include the authenticated account ID. Record inserts/updates are owner-scoped; they do not use an unrestricted upsert that can overwrite another user's record.
- The From address must match the authenticated mailbox username. Alias verification is not implemented.
- SMTP hosts must resolve to public addresses; private, loopback, metadata and reserved networks are rejected. Transport timeouts are bounded and STARTTLS is required for non-implicit-TLS connections.
- Disconnect overwrites the stored credentials with a disconnected record.
- The user's Google Workspace connection to Manus is not automatically a credential for the deployed website. Users connect their own SMTP mailbox/app password inside Communications. Gmail OAuth is not implemented.

## Research and message review

Company research uses bounded DuckDuckGo HTML search and fetches source pages. It returns literal email addresses present on fetched public pages with source links and excerpts. It does not invent addresses. A matching email on a source is not proof of company ownership, current deliverability or recipient consent: recipients must be reviewed.

Saved campaigns cannot be overwritten through campaign creation. The full saved message is displayed without line clamping. Delivery approval is separate from composing/saving, and the sender and recipients remain those of the saved campaign even if the draft changes afterward.

## Delivery behavior

An atomic compare-and-swap claims the saved campaign before opening a transport. Competing processes cannot both claim the same unchanged campaign. Individual emails are sent sequentially so recipients do not see one another's addresses. Each recipient's sending/result status is persisted. Already-sent recipients are skipped; indeterminate sending states are not silently retried. This prevents common duplicates, but SMTP and database writes are not a distributed transaction and do not guarantee exactly-once delivery through crashes. SMTP acceptance is reported as acceptance by the email server, not proof of delivery to the recipient's inbox.

## Verification

Unit tests cover authentication, credential encryption, private-network rejection, literal address parsing, draft ownership, sender matching, individual delivery, skipping already-sent recipients, distinct mailbox IDs and a lost atomic delivery claim. Browser tests exercise complete saved-payload approval and one mocked send on a phone-sized viewport, including the compiled production app. No real customer email was sent, and no real mailbox was connected during QA.
