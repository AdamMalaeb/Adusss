import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Operations from "@/pages/Operations";
import BuildLab from "@/pages/BuildLab";
import Studying from "@/pages/Studying";
import Images from "@/pages/Images";
import Videos from "@/pages/Videos";
import Upgrade from "@/pages/Upgrade";
import PowerPoint from "@/pages/PowerPoint";
import Business from "@/pages/Business";
import Translator from "@/pages/Translator";
import WorkspaceExtension from "@/pages/WorkspaceExtension";
import SignIn from "@/pages/SignIn";
import { Redirect, Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import StudyTaskRunner from "./components/StudyTaskRunner";
import LockedArea from "./components/LockedArea";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import { useEffect, useState } from "react";
import { publishNavigation } from "./lib/navigationLifecycle";
import {
  setWorkspaceAccount,
  useWorkspaceAccount,
} from "./lib/workspaceAccount";
import { useAuth } from "./_core/hooks/useAuth";
import { isLockedOwner } from "@shared/accessPolicy";

function EmptyRoute() {
  return null;
}
function OwnerArea({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  const { user, loading } = useAuth();
  if (loading)
    return (
      <div role="status" className="p-6">
        Checking access…
      </div>
    );
  return isLockedOwner(user) ? children : <LockedArea title={title} />;
}
function Router() {
  const [location] = useLocation();
  const { user } = useAuth();
  const owner = isLockedOwner(user);
  const path = location.split("?")[0];
  const homeActive = path === "/" || path === "/chat";
  const buildActive = path === "/build";
  const videosActive = path === "/videos";
  const imagesActive = path === "/images";
  const powerpointActive = path === "/powerpoint";
  const businessActive = path === "/business";
  const translatorActive = path === "/translator";
  const [visited, setVisited] = useState({
    home: homeActive,
    build: buildActive,
    videos: videosActive,
    images: imagesActive,
    powerpoint: powerpointActive,
    business: businessActive,
    translator: translatorActive,
  });
  useEffect(() => {
    publishNavigation(location);
    setVisited(old => ({
      home: old.home || homeActive,
      build: old.build || buildActive,
      videos: old.videos || videosActive,
      images: old.images || imagesActive,
      powerpoint: old.powerpoint || powerpointActive,
      business: old.business || businessActive,
      translator: old.translator || translatorActive,
    }));
  }, [
    location,
    homeActive,
    buildActive,
    videosActive,
    imagesActive,
    powerpointActive,
    businessActive,
    translatorActive,
  ]);
  return (
    <>
      {(visited.home || homeActive) && (
        <div
          hidden={!homeActive}
          aria-hidden={!homeActive}
          data-workspace="chat"
        >
          <Home active={homeActive} />
        </div>
      )}
      {(visited.build || buildActive) && (
        <div
          hidden={!buildActive}
          aria-hidden={!buildActive}
          data-workspace="build"
        >
          <BuildLab />
        </div>
      )}
      {owner && (visited.videos || videosActive) && (
        <div hidden={!videosActive} aria-hidden={!videosActive}>
          <Videos />
        </div>
      )}
      {(visited.images || imagesActive) && (
        <div hidden={!imagesActive} aria-hidden={!imagesActive}>
          <Images />
        </div>
      )}
      {(visited.powerpoint || powerpointActive) && (
        <div hidden={!powerpointActive} aria-hidden={!powerpointActive}>
          <PowerPoint />
        </div>
      )}
      {(visited.business || businessActive) && (
        <div hidden={!businessActive} aria-hidden={!businessActive}>
          <Business />
        </div>
      )}
      {(visited.translator || translatorActive) && (
        <div hidden={!translatorActive} aria-hidden={!translatorActive}>
          <Translator />
        </div>
      )}
      <Switch>
        <Route path="/sign-in" component={SignIn} />
        <Route path="/" component={EmptyRoute} />
        <Route path="/chat" component={EmptyRoute} />
        <Route path="/build" component={EmptyRoute} />
        <Route path="/studying" component={Studying} />
        <Route path="/images" component={EmptyRoute} />
        <Route path="/translator" component={EmptyRoute} />
        <Route path="/workspace/translator">
          <Redirect to="/translator" />
        </Route>
        <Route path="/videos">{!owner && <LockedArea title="Videos" />}</Route>
        <Route path="/upgrade">
          <OwnerArea title="Upgrade Adus">
            <Upgrade />
          </OwnerArea>
        </Route>
        <Route path="/powerpoint" component={EmptyRoute} />
        <Route path="/business" component={EmptyRoute} />
        <Route path="/workspace/:slug" component={WorkspaceExtension} />
        <Route path="/operations">
          <OwnerArea title="Operations">
            <Operations />
          </OwnerArea>
        </Route>
        <Route component={NotFound} />
      </Switch>
    </>
  );
}
function AccountLifecycle() {
  const { user } = useAuth();
  useEffect(() => {
    setWorkspaceAccount(user ? user.openId || String(user.id) : null);
  }, [user?.id, user?.openId]);
  return null;
}
function AccountWorkspace() {
  const account = useWorkspaceAccount();
  return (
    <>
      <StudyTaskRunner />
      <Router key={account ?? "signed-out"} />
    </>
  );
}
function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <AccountLifecycle />
          <AccountWorkspace />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
export default App;
