import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";
import MediaSaveActions from "@/components/MediaSaveActions";
import {
  MAX_IMAGE_DOWNLOAD_BYTES,
  normalizeStoredMediaUrl,
} from "@/lib/downloadMedia";
import { useEffect, useMemo, useState, type ReactElement } from "react";

type ImagePreviewProps = {
  src: string;
  alt: string;
  filename: string;
  trigger: ReactElement;
};

export function ImagePreview({
  src,
  alt,
  filename,
  trigger,
}: ImagePreviewProps) {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [imageError, setImageError] = useState(false);
  const sourceURL = useMemo(() => normalizeStoredMediaUrl(src), [src]);

  useEffect(() => {
    setFile(null);
    setLoading(false);
    setImageError(false);
  }, [open, sourceURL]);

  const previewUrl = useMemo(() => {
    if (!file || typeof URL.createObjectURL !== "function") return sourceURL;
    return URL.createObjectURL(file);
  }, [file, sourceURL]);

  useEffect(() => {
    if (!file || previewUrl === sourceURL) return;
    return () => URL.revokeObjectURL(previewUrl);
  }, [file, previewUrl, sourceURL]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent
        showCloseButton
        className="max-h-[95dvh] max-w-[min(96vw,1200px)] overflow-y-auto border-white/15 bg-black p-4 text-white shadow-2xl sm:p-6"
      >
        <DialogTitle className="pr-10 text-sm font-medium text-white">
          {alt}
        </DialogTitle>
        <DialogDescription className="sr-only">
          Fullscreen image preview. On supported mobile devices, Save to Photos
          uses the native share sheet. Otherwise Download saves a local copy or
          Open image in browser opens the storage file directly.
        </DialogDescription>

        <div className="relative flex min-h-[min(55vh,560px)] items-center justify-center overflow-hidden rounded-xl bg-black">
          <img
            src={previewUrl}
            alt={alt}
            className="max-h-[min(60dvh,720px)] max-w-full object-contain"
            onError={() => setImageError(true)}
          />
          {imageError && (
            <div className="absolute inset-x-4 bottom-4 rounded-lg border border-red-300/30 bg-black/80 px-3 py-2 text-center text-xs leading-5 text-red-100">
              The image preview could not be decoded. Use Download to retry the
              stored bytes or open the file in your browser.
            </div>
          )}
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/65 text-sm text-white">
              <span className="inline-flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Preparing image…
              </span>
            </div>
          )}
        </div>

        <MediaSaveActions
          src={sourceURL}
          filename={filename}
          maxBytes={MAX_IMAGE_DOWNLOAD_BYTES}
          enabled={open}
          openLabel="Open image in browser"
          onFileReady={setFile}
          onLoadingChange={setLoading}
        />
      </DialogContent>
    </Dialog>
  );
}

export default ImagePreview;
