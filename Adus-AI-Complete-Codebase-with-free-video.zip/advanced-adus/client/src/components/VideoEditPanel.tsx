import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { LanguageSelect } from "@/components/LanguageSelect";
import MediaSaveActions from "@/components/MediaSaveActions";
import { trpc } from "@/lib/trpc";
import type { VoiceLanguage } from "@shared/languages";
import {
  Check,
  Clock3,
  Crop,
  Loader2,
  RotateCw,
  Scissors,
  VolumeX,
  WandSparkles,
} from "lucide-react";
import { useEffect, useState } from "react";

/**
 * Standalone source-edit UI for Videos. The parent mounts videoEditRouter under
 * `adus.videoEdits` and passes the id returned by `adus.videos.upload`.
 */
export type VideoEditPanelProps = {
  sourceId: string;
  sourceName?: string;
  sourceUrl?: string;
  className?: string;
  onApplied?: (result: VideoEditResult) => void;
};

type VideoEditPlan = {
  id: string;
  status: "review" | "applying" | "applied";
  sourceId: string;
  prompt: string;
  source: {
    duration: number;
    width: number;
    height: number;
    hasAudio: boolean;
  };
  plan: {
    supported: boolean;
    summary: string;
    unsupportedReason: string;
    segments: Array<{ start: number; end: number }>;
    mute: Array<{ start: number; end: number }>;
    speed: Array<{ start: number; end: number; factor: number }>;
    crop: { x: number; y: number; width: number; height: number } | null;
    rotate: 0 | 90 | 180 | 270;
  };
  estimatedDuration?: number;
  resultId?: string;
};

type VideoEditResult = {
  id: string;
  url?: string;
  name?: string;
  duration?: number;
  bytes?: number;
  mimeType?: string;
};

function errorMessage(error: unknown): string {
  if (error && typeof error === "object" && "message" in error)
    return String((error as { message?: unknown }).message ?? "");
  return "The local edit could not be completed. The original source was not changed.";
}

function seconds(value: number): string {
  return `${value.toFixed(2)}s`;
}

function rangeList(ranges: Array<{ start: number; end: number }>): string {
  return ranges
    .map(range => `${seconds(range.start)}–${seconds(range.end)}`)
    .join(", ");
}

export default function VideoEditPanel({
  sourceId,
  sourceName,
  sourceUrl,
  className = "",
  onApplied,
}: VideoEditPanelProps) {
  const [prompt, setPrompt] = useState("");
  const [plan, setPlan] = useState<VideoEditPlan | null>(null);
  const [result, setResult] = useState<VideoEditResult | null>(null);
  const [notice, setNotice] = useState("");
  const [narrationEnabled, setNarrationEnabled] = useState(false);
  const [narrationText, setNarrationText] = useState("");
  const [narrationLanguage, setNarrationLanguage] =
    useState<VoiceLanguage>("en");
  const [narrationGender, setNarrationGender] = useState<"woman" | "man">(
    "woman"
  );
  const planMutation = trpc.adus.videoEdits.plan.useMutation({
    meta: { handledError: true },
  });
  const applyMutation = trpc.adus.videoEdits.applyPlan.useMutation({
    meta: { handledError: true },
  });

  useEffect(() => {
    setPrompt("");
    setPlan(null);
    setResult(null);
    setNotice("");
    setNarrationEnabled(false);
    setNarrationText("");
    setNarrationLanguage("en");
    setNarrationGender("woman");
  }, [sourceId]);

  async function createPlan(event: React.FormEvent) {
    event.preventDefault();
    setNotice("");
    setResult(null);
    if (prompt.trim().length < 3) {
      setNotice("Describe a cut, mute, speed, crop, or rotation change.");
      return;
    }
    if (narrationEnabled && !narrationText.trim()) {
      setNotice(
        "Add a narration script or turn narration off. Source audio stays unchanged when narration is off."
      );
      return;
    }
    try {
      const next = (await planMutation.mutateAsync({
        sourceId,
        prompt: prompt.trim(),
        narration: {
          enabled: narrationEnabled,
          text: narrationText.trim(),
          language: narrationLanguage,
          gender: narrationGender,
        },
      })) as VideoEditPlan;
      setPlan(next);
    } catch (error) {
      setNotice(errorMessage(error));
    }
  }

  async function applyPlan() {
    if (!plan) return;
    setNotice("");
    try {
      const response = (await applyMutation.mutateAsync({
        planId: plan.id,
      })) as {
        plan: VideoEditPlan;
        result: VideoEditResult;
      };
      setPlan(response.plan);
      setResult(response.result);
      onApplied?.(response.result);
    } catch (error) {
      setNotice(errorMessage(error));
    }
  }

  const editing = planMutation.isPending || applyMutation.isPending;
  const supported = plan?.plan.supported !== false;

  return (
    <section
      className={`min-w-0 max-w-full rounded-2xl border border-primary/25 bg-card p-5 shadow-sm sm:p-6 ${className}`}
    >
      <div className="flex min-w-0 items-start gap-3">
        <WandSparkles className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
        <div className="min-w-0 max-w-full">
          <h2 className="font-semibold">Source editor</h2>
          <p className="mt-1 max-w-full break-words text-xs leading-5 text-muted-foreground">
            {sourceName ? `${sourceName} · ` : ""}Describe deterministic changes
            such as “keep 0–4s and 9–14s, mute 2–3s, crop to the center, and
            rotate 90 degrees.” The app shows the structured edit plan before
            anything is rendered.
          </p>
        </div>
      </div>

      {sourceUrl && (
        <video
          controls
          playsInline
          preload="metadata"
          src={sourceUrl}
          className="mt-5 aspect-video w-full max-w-full rounded-xl bg-black object-contain"
          aria-label={
            sourceName ? `Preview of ${sourceName}` : "Source video preview"
          }
        />
      )}

      <form onSubmit={createPlan} className="mt-5 min-w-0 max-w-full space-y-3">
        <Textarea
          value={prompt}
          onChange={event => setPrompt(event.target.value)}
          rows={3}
          maxLength={12_000}
          placeholder="Example: Keep 0–5 seconds and 12–18 seconds, mute 2–3 seconds, speed 4–5 seconds up 1.5x, crop to the center, and rotate 90 degrees."
          aria-label="Describe local video edit"
          className="min-w-0 w-full max-w-full"
        />
        <div className="flex min-w-0 flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="min-w-0 max-w-full break-words text-[11px] leading-5 text-muted-foreground">
            Object removal, background replacement, and restyling belong in the
            separately labeled Google Generative Restyling flow; this Source
            Editing panel never fakes those operations.
          </p>
          <Button
            type="submit"
            disabled={editing || !sourceId}
            className="w-full max-w-full gap-2 whitespace-normal break-words sm:w-auto"
          >
            {planMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <WandSparkles className="h-4 w-4" />
            )}
            {planMutation.isPending ? "Planning…" : "Preview edit plan"}
          </Button>
        </div>
      </form>

      {notice && (
        <p
          className="mt-4 min-w-0 max-w-full break-words rounded-lg border border-destructive/25 bg-destructive/5 px-3 py-2 text-xs leading-5 text-destructive"
          role="alert"
        >
          {notice}
        </p>
      )}

      <div className="mt-5 min-w-0 max-w-full rounded-xl border border-dashed border-primary/30 bg-primary/5 p-4">
        <label className="flex min-w-0 items-start gap-3 text-sm">
          <input
            type="checkbox"
            checked={narrationEnabled}
            onChange={event => setNarrationEnabled(event.target.checked)}
            className="mt-0.5 h-4 w-4 accent-primary"
          />
          <span className="min-w-0 max-w-full break-words">
            <span className="font-medium">
              Add natural narration (optional)
            </span>
            <span className="mt-1 block text-xs leading-5 text-muted-foreground">
              Off means no new voice is added. Existing source audio is
              preserved; turning this on mixes the requested neural voice onto
              the edited MP4.
            </span>
          </span>
        </label>
        {narrationEnabled && (
          <div className="mt-4 space-y-3">
            <Textarea
              value={narrationText}
              onChange={event => setNarrationText(event.target.value)}
              rows={3}
              maxLength={12_000}
              placeholder="Narration script / transcript to read aloud"
              aria-label="Narration script"
              className="min-w-0 w-full max-w-full"
            />
            <div className="grid min-w-0 max-w-full grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="flex min-w-0 max-w-full flex-col gap-1 text-xs text-muted-foreground">
                <span>Narration language</span>
                <LanguageSelect
                  value={narrationLanguage}
                  onChange={setNarrationLanguage}
                  label="Narration language"
                  includeAuto
                  className="h-9 w-full min-w-0 max-w-full rounded-lg border bg-background px-2 text-sm text-foreground"
                />
              </label>
              <label className="flex min-w-0 max-w-full flex-col items-start gap-1 text-xs text-muted-foreground sm:flex-row sm:items-center">
                <span>Voice</span>
                <select
                  value={narrationGender}
                  onChange={event =>
                    setNarrationGender(event.target.value as "woman" | "man")
                  }
                  aria-label="Narration voice"
                  className="h-9 w-full min-w-0 max-w-full rounded-lg border bg-background px-2 text-sm text-foreground sm:w-auto"
                >
                  <option value="woman">Woman</option>
                  <option value="man">Man</option>
                </select>
              </label>
            </div>
          </div>
        )}
      </div>

      {plan && (
        <div
          className="mt-5 min-w-0 max-w-full rounded-xl border bg-background/60 p-4"
          aria-live="polite"
        >
          <div className="flex min-w-0 flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 max-w-full">
              <div className="flex items-center gap-2 font-medium">
                <Check className="h-4 w-4 text-primary" />
                {plan.status === "applied"
                  ? "Edit applied"
                  : plan.status === "applying"
                    ? "Edit is being rendered"
                    : "Review before rendering"}
              </div>
              <p className="mt-1 text-xs leading-5 text-muted-foreground">
                {plan.plan.summary}
              </p>
            </div>
            {plan.estimatedDuration !== undefined && (
              <span className="inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[11px] text-muted-foreground">
                <Clock3 className="h-3.5 w-3.5" />{" "}
                {seconds(plan.estimatedDuration)} output
              </span>
            )}
          </div>

          {!supported ? (
            <p className="mt-4 min-w-0 max-w-full break-words rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs leading-5 text-amber-800 dark:text-amber-200">
              <strong>Google Generative Restyling required.</strong>{" "}
              {plan.plan.unsupportedReason ||
                "This request needs the cinematic provider; no source video was changed."}
            </p>
          ) : (
            <div className="mt-4 grid min-w-0 max-w-full grid-cols-1 gap-2 text-xs sm:grid-cols-2">
              <PlanItem
                icon={<Scissors className="h-3.5 w-3.5" />}
                label="Kept ranges"
                value={rangeList(plan.plan.segments)}
              />
              <PlanItem
                icon={<VolumeX className="h-3.5 w-3.5" />}
                label="Muted ranges"
                value={rangeList(plan.plan.mute) || "None"}
              />
              <PlanItem
                icon={<Clock3 className="h-3.5 w-3.5" />}
                label="Speed"
                value={
                  plan.plan.speed
                    .map(item => `${rangeList([item])} ×${item.factor}`)
                    .join(", ") || "Normal"
                }
              />
              <PlanItem
                icon={<Crop className="h-3.5 w-3.5" />}
                label="Crop"
                value={
                  plan.plan.crop
                    ? `${Math.round(plan.plan.crop.width * 100)}% × ${Math.round(plan.plan.crop.height * 100)}%`
                    : "None"
                }
              />
              <PlanItem
                icon={<RotateCw className="h-3.5 w-3.5" />}
                label="Rotation"
                value={`${plan.plan.rotate}°`}
              />
            </div>
          )}

          {plan.status === "review" && supported && (
            <div className="mt-4 flex min-w-0 flex-col items-start gap-3 border-t pt-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="min-w-0 max-w-full break-words text-[11px] leading-5 text-muted-foreground">
                The original source stays preserved. Applying creates a new
                private MP4 record.
              </p>
              <Button
                type="button"
                onClick={() => void applyPlan()}
                disabled={editing}
                className="w-full max-w-full gap-2 whitespace-normal break-words sm:w-auto"
              >
                {applyMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Check className="h-4 w-4" />
                )}
                {applyMutation.isPending
                  ? "Rendering locally…"
                  : "Apply reviewed plan"}
              </Button>
            </div>
          )}
        </div>
      )}

      {result?.url && (
        <div className="mt-5 min-w-0 max-w-full rounded-xl border bg-background/60 p-4">
          <h3 className="font-medium">Edited MP4 ready</h3>
          <video
            controls
            playsInline
            preload="metadata"
            src={result.url}
            className="mt-3 aspect-video w-full rounded-xl bg-black object-contain"
          />
          <MediaSaveActions
            src={result.url}
            filename={result.name ?? `adus-edited-${result.id}.mp4`}
            className="mt-4"
          />
        </div>
      )}
    </section>
  );
}

function PlanItem({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex min-w-0 items-start gap-2 rounded-lg border px-3 py-2">
      <span className="mt-0.5 text-primary">{icon}</span>
      <span className="min-w-0">
        <span className="font-medium">{label}</span>
        <span
          className="mt-0.5 block truncate text-muted-foreground"
          title={value}
        >
          {value}
        </span>
      </span>
    </div>
  );
}
