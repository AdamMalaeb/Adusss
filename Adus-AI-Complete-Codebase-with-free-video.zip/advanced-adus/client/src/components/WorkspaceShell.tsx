import DashboardLayout from "./DashboardLayout";
export default function WorkspaceShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <DashboardLayout>
      <div className="mx-auto w-full min-w-0 max-w-[1400px] px-1 py-4 sm:px-6">
        <header className="mb-8 min-w-0">
          <div className="mb-3 font-mono text-[10px] uppercase tracking-[.24em] text-cyan-200/70">
            Adus / Your workspace
          </div>
          <h1 className="max-w-full break-words text-3xl font-bold tracking-tight sm:text-4xl">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-3 max-w-3xl text-sm leading-7 text-muted-foreground">
              {subtitle}
            </p>
          )}
        </header>
        <div className="min-w-0 max-w-full">{children}</div>
      </div>
    </DashboardLayout>
  );
}
