import { useEffect, useState } from "react";
import {
  Check,
  ChevronDown,
  MessageSquare,
  Pencil,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import type { ConversationSummary } from "@shared/conversations";

type ConversationHistoryProps = {
  conversations: ConversationSummary[];
  activeConversationId?: string;
  isLoading?: boolean;
  onNewChat: () => void;
  onSelect: (id: string) => void;
  onRename: (id: string, title: string) => Promise<void> | void;
  onRemove: (id: string) => Promise<void> | void;
};

function formatConversationDate(timestamp: number) {
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
  }).format(date);
}

export default function ConversationHistory({
  conversations,
  activeConversationId,
  isLoading = false,
  onNewChat,
  onSelect,
  onRename,
  onRemove,
}: ConversationHistoryProps) {
  const [editingId, setEditingId] = useState<string>();
  const [draftTitle, setDraftTitle] = useState("");
  const [savingId, setSavingId] = useState<string>();
  const [removingId, setRemovingId] = useState<string>();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (editingId && !conversations.some(item => item.id === editingId)) {
      setEditingId(undefined);
    }
  }, [conversations, editingId]);

  function startRename(item: ConversationSummary) {
    setEditingId(item.id);
    setDraftTitle(item.title);
  }

  async function commitRename(id: string) {
    const title = draftTitle.trim();
    if (!title) return;
    setSavingId(id);
    try {
      await onRename(id, title);
      setEditingId(undefined);
    } finally {
      setSavingId(undefined);
    }
  }

  async function removeConversation(id: string) {
    setRemovingId(id);
    try {
      await onRemove(id);
    } finally {
      setRemovingId(undefined);
    }
  }

  function selectConversation(id: string) {
    onSelect(id);
    setMobileOpen(false);
  }

  const historyHeader = (
    <div className="mb-3 flex items-center justify-between gap-2 px-1">
      <div className="min-w-0">
        <div className="font-mono text-[9px] uppercase tracking-[0.18em] text-white/35">
          Conversations
        </div>
        <div className="mt-1 text-xs text-white/45">
          Private to your account
        </div>
      </div>
      <button
        type="button"
        onClick={onNewChat}
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-cyan-200/20 bg-cyan-200/[0.08] text-cyan-100 transition hover:bg-cyan-200/[0.16]"
        aria-label="Start a new chat"
        title="New chat"
      >
        <Plus size={15} />
      </button>
    </div>
  );

  const conversationList = (
    <div className="max-h-44 space-y-1 overflow-y-auto pr-1 lg:max-h-[calc(100dvh-230px)]">
      {isLoading && (
        <div className="px-2 py-3 text-[11px] text-white/35">
          Loading history…
        </div>
      )}
      {!isLoading && conversations.length === 0 && (
        <div className="rounded-xl border border-dashed border-white/10 px-3 py-4 text-[11px] leading-5 text-white/35">
          Your saved chats will appear here after your first message.
        </div>
      )}
      {conversations.map(item => {
        const selected = item.id === activeConversationId;
        const editing = editingId === item.id;
        return (
          <div
            key={item.id}
            className={`group min-w-0 rounded-xl border transition ${selected ? "border-cyan-200/25 bg-cyan-200/[0.09]" : "border-transparent hover:border-white/10 hover:bg-white/[0.04]"}`}
          >
            {editing ? (
              <div className="flex items-center gap-1 p-2">
                <input
                  value={draftTitle}
                  onChange={event => setDraftTitle(event.target.value)}
                  onKeyDown={event => {
                    if (event.key === "Enter") void commitRename(item.id);
                    if (event.key === "Escape") setEditingId(undefined);
                  }}
                  autoFocus
                  maxLength={80}
                  className="min-w-0 flex-1 rounded-md border border-cyan-200/25 bg-[#080b12] px-2 py-1.5 text-xs text-white outline-none"
                  aria-label={`Rename ${item.title}`}
                />
                <button
                  type="button"
                  onClick={() => void commitRename(item.id)}
                  disabled={savingId === item.id}
                  className="rounded-md p-1 text-emerald-200 hover:bg-emerald-200/10 disabled:opacity-40"
                  aria-label="Save conversation title"
                >
                  <Check size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => setEditingId(undefined)}
                  className="rounded-md p-1 text-white/40 hover:bg-white/10 hover:text-white"
                  aria-label="Cancel rename"
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <div className="flex min-w-0 items-start gap-1">
                <button
                  type="button"
                  onClick={() => selectConversation(item.id)}
                  className="min-w-0 flex-1 px-2.5 py-2 text-left"
                  aria-current={selected ? "page" : undefined}
                >
                  <div className="flex min-w-0 items-center gap-2">
                    <MessageSquare
                      size={13}
                      className={
                        selected
                          ? "shrink-0 text-cyan-100"
                          : "shrink-0 text-white/30"
                      }
                    />
                    <span className="min-w-0 truncate text-xs font-medium text-white/80">
                      {item.title}
                    </span>
                  </div>
                  <div className="mt-1 flex min-w-0 items-center justify-between gap-2 pl-5 text-[10px] text-white/30">
                    <span className="min-w-0 truncate">{item.preview}</span>
                    <span className="shrink-0">
                      {formatConversationDate(item.updatedAt)}
                    </span>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => startRename(item)}
                  className="mr-1 mt-2 rounded-md p-1 text-white/45 opacity-100 transition lg:opacity-0 hover:bg-white/10 hover:text-white group-hover:opacity-100 focus:opacity-100"
                  aria-label={`Rename ${item.title}`}
                  title="Rename conversation"
                >
                  <Pencil size={12} />
                </button>
                <button
                  type="button"
                  onClick={() => void removeConversation(item.id)}
                  disabled={removingId === item.id}
                  className="mr-1 mt-2 rounded-md p-1 text-white/45 opacity-100 transition lg:opacity-0 hover:bg-rose-300/10 hover:text-rose-200 group-hover:opacity-100 focus:opacity-100 disabled:opacity-40"
                  aria-label={`Remove ${item.title}`}
                  title="Remove conversation"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );

  return (
    <aside className="adus-conversation-history mb-2 min-w-0 rounded-2xl border border-white/[0.08] bg-black/15 p-2 lg:mb-0 lg:w-[238px] lg:shrink-0 lg:p-3">
      <div className="lg:hidden">
        <button
          type="button"
          onClick={() => setMobileOpen(open => !open)}
          className="flex min-h-10 w-full items-center justify-between gap-3 rounded-xl border border-white/[0.08] bg-[#0a0d14] px-3 py-2 text-left text-sm text-white/80"
          aria-expanded={mobileOpen}
          aria-controls="mobile-conversation-list"
        >
          <span className="flex min-w-0 items-center gap-2">
            <MessageSquare size={15} className="shrink-0 text-cyan-100/70" />
            <span>Chats</span>
            <span className="rounded-full bg-white/[0.08] px-1.5 py-0.5 text-[10px] text-white/45">
              {isLoading ? "…" : conversations.length}
            </span>
          </span>
          <ChevronDown
            size={16}
            className={`shrink-0 text-white/45 transition-transform ${mobileOpen ? "rotate-180" : ""}`}
            aria-hidden="true"
          />
        </button>
        {mobileOpen && (
          <div
            id="mobile-conversation-list"
            className="mt-2 rounded-xl border border-white/[0.08] bg-[#0a0d14] p-2 shadow-2xl shadow-black/40"
          >
            {historyHeader}
            {conversationList}
          </div>
        )}
      </div>
      <div className="hidden lg:block">
        {historyHeader}
        {conversationList}
      </div>
    </aside>
  );
}
