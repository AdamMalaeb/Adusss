import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

export default function FlikiShortcut() {
  return (
    <section
      aria-label="Free video option: Fliki"
      className="min-w-0 max-w-full rounded-2xl border border-primary/25 bg-primary/5 p-4 sm:p-5"
    >
      <h2 className="text-sm font-semibold">Create videos on Fliki</h2>
      <p className="mt-2 text-xs leading-5 text-muted-foreground">
        Fliki’s free website plan offers monthly credits, 720p videos with a
        watermark, moving stock footage and standard AI narration. Newly
        generated AI video clips are not included free.
      </p>
      <Button
        asChild
        className="mt-3 h-auto min-h-10 w-full max-w-full gap-2 whitespace-normal break-words py-2 sm:w-auto"
      >
        <a
          href="https://app.fliki.ai/"
          target="_blank"
          rel="noopener noreferrer"
          aria-describedby="fliki-shortcut-help"
        >
          <ExternalLink className="h-4 w-4 shrink-0" aria-hidden="true" />
          Open Fliki — Free Plan
        </a>
      </Button>
      <p
        id="fliki-shortcut-help"
        className="mt-2 text-xs leading-5 text-muted-foreground"
      >
        Opens Fliki in a new tab. Sign in there to create and download your
        video. This is a website shortcut, not automatic generation inside Adus.
      </p>
    </section>
  );
}
