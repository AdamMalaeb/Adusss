import { useEffect, useState } from "react";
import { Loader2, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { LanguageSelect } from "@/components/LanguageSelect";
import MediaSaveActions from "@/components/MediaSaveActions";
import { trpc } from "@/lib/trpc";
import type { VoiceLanguage } from "@shared/languages";

const free = trpc.adus.freeVideo;
const MAX_CHARS = 2000;

function Toggle({
  checked,
  onChange,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  hint: string;
}) {
  return (
    <label className="flex min-w-0 cursor-pointer items-start gap-3 rounded-xl border p-3">
      <input
        type="checkbox"
        checked={checked}
        onChange={event => onChange(event.target.checked)}
        className="mt-1 h-4 w-4"
      />
      <span className="min-w-0">
        <span className="block text-sm font-medium">{label}</span>
        <span className="block text-xs text-muted-foreground">{hint}</span>
      </span>
    </label>
  );
}

/** Free video: text to a 15-60 second video, in a language you choose. */
export default function FreeVideoPanel() {
  const utils = trpc.useUtils();
  const limits = free.limits.useQuery();
  const [text, setText] = useState("");
  const [language, setLanguage] = useState<VoiceLanguage>("en");
  const [translate, setTranslate] = useState(false);
  const [narrate, setNarrate] = useState(true);
  const [gender, setGender] = useState<"woman" | "man">("woman");
  const [aspect, setAspect] = useState<"16:9" | "9:16">("16:9");
  const [seconds, setSeconds] = useState(30);
  const [jobId, setJobId] = useState<string | null>(null);
  const [error, setError] = useState("");

  const create = free.create.useMutation({
    onSuccess: job => {
      setError("");
      setJobId(job.id);
      void utils.adus.freeVideo.limits.invalidate();
    },
    onError: e => setError(e.message),
  });
  const retry = free.retry.useMutation({
    onSuccess: () => void utils.adus.freeVideo.status.invalidate(),
    onError: e => setError(e.message),
  });
  const job = free.status.useQuery(
    { id: jobId ?? "" },
    {
      enabled: Boolean(jobId),
      refetchInterval: query =>
        query.state.data?.status === "pending" ? 2500 : false,
    }
  );

  const data = job.data;
  const working = create.isPending || data?.status === "pending";
  const remaining = limits.data?.remaining;

  useEffect(() => {
    if (data?.status === "completed" || data?.status === "failed")
      void utils.adus.freeVideo.limits.invalidate();
  }, [data?.status, utils]);

  const submit = () => {
    setError("");
    create.mutate({
      text,
      language: language === "auto" ? "en" : language,
      translate,
      narrate,
      gender,
      aspectRatio: aspect,
      durationSeconds: narrate ? undefined : seconds,
    });
  };

  return (
    <section className="min-w-0 max-w-full rounded-2xl border bg-card p-5 shadow-sm">
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Video className="h-4 w-4 text-primary" /> Free video · 15–60 seconds
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        Turns your text into a captioned video. No AI footage: animated text
        cards, with optional free neural narration.
        {limits.data
          ? ` ${limits.data.remaining} of ${limits.data.limit} left today.`
          : ""}
      </p>

      <Textarea
        value={text}
        onChange={event => setText(event.target.value)}
        placeholder="Write or paste what the video should say."
        rows={5}
        maxLength={MAX_CHARS}
        className="mt-4 min-w-0 w-full max-w-full resize-y"
      />

      <div className="mt-3 grid min-w-0 gap-3 sm:grid-cols-2">
        <label className="min-w-0 text-xs text-muted-foreground">
          Language of the video
          <LanguageSelect
            value={language}
            onChange={setLanguage}
            className="mt-1 h-9 rounded-lg border bg-background px-2 text-sm text-foreground"
          />
        </label>
        <label className="min-w-0 text-xs text-muted-foreground">
          Shape
          <select
            value={aspect}
            onChange={event => setAspect(event.target.value as "16:9" | "9:16")}
            className="mt-1 block h-9 w-full rounded-lg border bg-background px-2 text-sm text-foreground"
          >
            <option value="16:9">Wide 16:9</option>
            <option value="9:16">Vertical 9:16</option>
          </select>
        </label>
      </div>

      <div className="mt-3 grid min-w-0 gap-3 sm:grid-cols-2">
        <Toggle
          checked={translate}
          onChange={setTranslate}
          label="Translate my text"
          hint={
            translate
              ? "Your text is translated into the language above."
              : "Off: your text is used exactly as written."
          }
        />
        <Toggle
          checked={narrate}
          onChange={setNarrate}
          label="Narration (voice)"
          hint={
            narrate
              ? "Free neural voice reads the text. Length follows the speech."
              : "Off: captions only, no voice."
          }
        />
      </div>

      {narrate ? (
        <label className="mt-3 block text-xs text-muted-foreground">
          Voice
          <select
            value={gender}
            onChange={event =>
              setGender(event.target.value as "woman" | "man")
            }
            className="mt-1 block h-9 w-full rounded-lg border bg-background px-2 text-sm text-foreground sm:w-48"
          >
            <option value="woman">Woman</option>
            <option value="man">Man</option>
          </select>
        </label>
      ) : (
        <label className="mt-3 block text-xs text-muted-foreground">
          Length: {seconds} seconds
          <input
            type="range"
            min={15}
            max={60}
            step={1}
            value={seconds}
            onChange={event => setSeconds(Number(event.target.value))}
            className="mt-1 block w-full"
          />
        </label>
      )}

      <Button
        type="button"
        onClick={submit}
        disabled={working || text.trim().length < 3 || remaining === 0}
        className="mt-4 gap-2"
      >
        {working ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
        {working
          ? data?.stage === "translate"
            ? "Translating…"
            : "Making your video…"
          : "Make free video"}
      </Button>

      {error || data?.error ? (
        <div className="mt-3 rounded-lg border border-destructive/40 p-3 text-sm text-destructive">
          {error || data?.error}
          {data?.status === "failed" && jobId ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="ml-3"
              onClick={() => retry.mutate({ id: jobId })}
            >
              Retry
            </Button>
          ) : null}
        </div>
      ) : null}

      {data?.status === "completed" && data.url ? (
        <div className="mt-4 min-w-0">
          <video
            src={data.url}
            controls
            playsInline
            className="max-h-[70vh] w-full rounded-xl bg-black"
          />
          <p className="mt-2 text-xs text-muted-foreground">
            {data.seconds}s · {data.scenes} scenes
            {data.note ? ` · ${data.note}` : ""}
          </p>
          <MediaSaveActions
            src={data.url}
            filename="free-video.mp4"
            className="mt-3"
          />
        </div>
      ) : null}
    </section>
  );
}
