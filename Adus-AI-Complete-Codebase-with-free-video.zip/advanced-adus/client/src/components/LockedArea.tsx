import WorkspaceShell from "./WorkspaceShell";
import { LockKeyhole } from "lucide-react";

export default function LockedArea({ title }: { title: string }) {
  return (
    <WorkspaceShell
      title={`${title} · Locked`}
      subtitle="This area is available only to the approved Adus owner account."
    >
      <section className="mx-auto max-w-xl rounded-2xl border border-border bg-card p-6 text-card-foreground">
        <LockKeyhole className="mb-4 h-8 w-8 text-primary" />
        <h1 className="text-xl font-semibold">Locked</h1>
        <p className="mt-3 text-sm leading-7 text-muted-foreground">
          Sign in with the owner account to use {title}. Your other workspace
          tools remain available.
        </p>
        <a
          href="/"
          className="mt-5 inline-block text-sm text-primary underline"
        >
          Back to Chat Only
        </a>
      </section>
    </WorkspaceShell>
  );
}
