import { useEffect, useRef, useState } from "react";
import { prepareInteractivePreview } from "@shared/websitePreview";
export default function WebsitePreview({
  html,
  mode,
  title = "Adus website preview",
}: {
  html: string;
  mode: "mobile" | "desktop";
  title?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(320);
  const [viewportHeight, setViewportHeight] = useState(650);
  const [actualSize, setActualSize] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let frame: number | ReturnType<typeof setTimeout> | undefined;
    const cancelFrame = () => {
      if (frame === undefined) return;
      if (typeof cancelAnimationFrame === "function")
        cancelAnimationFrame(frame as number);
      else clearTimeout(frame);
    };
    const measure = () => {
      cancelFrame();
      const update = () => {
        const next = el.clientWidth;
        setWidth(old => (Math.abs(old - next) > 1 ? next : old));
      };
      frame =
        typeof requestAnimationFrame === "function"
          ? requestAnimationFrame(update)
          : setTimeout(update, 0);
    };
    measure();
    window.addEventListener("resize", measure, { passive: true });
    const observer =
      typeof ResizeObserver !== "undefined"
        ? new ResizeObserver(measure)
        : null;
    observer?.observe(el);
    return () => {
      observer?.disconnect();
      window.removeEventListener("resize", measure);
      cancelFrame();
    };
  }, []);
  useEffect(() => {
    const measure = () => {
      const height = window.visualViewport?.height ?? window.innerHeight;
      setViewportHeight(Math.max(500, Math.round(height - 160)));
    };
    measure();
    window.addEventListener("resize", measure, { passive: true });
    window.visualViewport?.addEventListener("resize", measure);
    return () => {
      window.removeEventListener("resize", measure);
      window.visualViewport?.removeEventListener("resize", measure);
    };
  }, []);
  useEffect(() => setActualSize(false), [mode]);
  const documentWidth = mode === "desktop" ? 1280 : Math.max(1, width);
  const scale =
    mode === "desktop" && !actualSize ? Math.min(1, width / documentWidth) : 1;
  return (
    <div className="w-full min-w-0 bg-white">
      {mode === "desktop" && width < 1280 && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 bg-slate-100 px-3 py-2 text-xs text-slate-800">
          <span>
            {actualSize
              ? "Swipe sideways to read at full size."
              : "Full website width. Switch to actual size for larger text."}
          </span>
          <button
            type="button"
            onClick={() => setActualSize(value => !value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-medium"
            aria-pressed={actualSize}
          >
            {actualSize ? "Fit whole width" : "Actual size"}
          </button>
        </div>
      )}
      <div
        ref={ref}
        className="relative w-full min-w-0 overflow-x-auto overflow-y-hidden bg-white"
        style={{ height: viewportHeight }}
      >
        <iframe
          key={`${mode}:${html}`}
          title={title}
          srcDoc={prepareInteractivePreview(html)}
          sandbox="allow-scripts"
          referrerPolicy="no-referrer"
          className="absolute left-0 top-0 border-0 bg-white"
          style={{
            width: documentWidth,
            height: viewportHeight / Math.max(0.01, scale),
            transform: `scale(${scale})`,
            transformOrigin: "top left",
          }}
        />
      </div>
    </div>
  );
}
