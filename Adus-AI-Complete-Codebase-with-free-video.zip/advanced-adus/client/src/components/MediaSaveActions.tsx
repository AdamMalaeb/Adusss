import { Button } from "@/components/ui/button";
import {
  Download,
  ExternalLink,
  FileDown,
  Loader2,
  Share2,
  TriangleAlert,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  fetchDownloadFile,
  MAX_DOWNLOAD_BYTES,
  downloadUrl,
  normalizeStoredMediaUrl,
  saveFile,
  shareFile,
} from "@/lib/downloadMedia";
import { cn } from "@/lib/utils";
import { trpc } from "@/lib/trpc";

type MediaSaveActionsProps = {
  /** Signed/public storage URL to preload and save. */
  src: string;
  /** Suggested name; the downloader corrects its extension from file bytes. */
  filename: string;
  /** Optional lower cap, such as the image preview cap. */
  maxBytes?: number;
  /** Disable preparation while the parent preview is closed. */
  enabled?: boolean;
  className?: string;
  openLabel?: string;
  onFileReady?: (file: File | null) => void;
  onLoadingChange?: (loading: boolean) => void;
};

type Action = "download" | "share" | null;

function errorMessage(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback;
}

/**
 * Save controls for images, videos, and PDFs. The File is prepared before the
 * click, so navigator.share is called directly from the user's click handler
 * rather than after a fetch. Native sharing is the primary option where the
 * platform supports file sharing; desktop browsers retain regular Download.
 */
export function MediaSaveActions({
  src,
  filename,
  maxBytes = MAX_DOWNLOAD_BYTES,
  enabled = true,
  className,
  openLabel = "Open file in browser",
  onFileReady,
  onLoadingChange,
}: MediaSaveActionsProps) {
  const sourceURL = normalizeStoredMediaUrl(src);
  const downloadTicket = trpc.adus.media.ticket.useQuery(
    { url: sourceURL, filename },
    {
      enabled: enabled && sourceURL.startsWith("/manus-storage/"),
      retry: false,
      staleTime: 120000,
      refetchInterval:
        enabled && sourceURL.startsWith("/manus-storage/") ? 240000 : false,
      meta: { handledError: true },
    }
  );
  const directURL = downloadTicket.data?.url;
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [actionError, setActionError] = useState("");
  const [action, setAction] = useState<Action>(null);

  useEffect(() => {
    let cancelled = false;
    setFile(null);
    setError("");
    setActionError("");
    setAction(null);
    setLoading(enabled);
    onFileReady?.(null);
    onLoadingChange?.(enabled);

    if (!enabled)
      return () => {
        cancelled = true;
      };

    void fetchDownloadFile(directURL ?? sourceURL, filename, maxBytes)
      .then(preparedFile => {
        if (cancelled) return;
        setFile(preparedFile);
        onFileReady?.(preparedFile);
      })
      .catch(downloadError => {
        if (cancelled) return;
        setError(
          errorMessage(
            downloadError,
            "The file could not be prepared for saving."
          )
        );
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
        onLoadingChange?.(false);
      });

    return () => {
      cancelled = true;
    };
  }, [
    directURL,
    enabled,
    filename,
    maxBytes,
    onFileReady,
    onLoadingChange,
    sourceURL,
  ]);

  const canShareFile = useMemo(() => {
    if (
      !file ||
      typeof navigator === "undefined" ||
      typeof navigator.share !== "function" ||
      typeof navigator.canShare !== "function"
    ) {
      return false;
    }
    try {
      return navigator.canShare({ files: [file] });
    } catch {
      return false;
    }
  }, [file]);

  const shareLabel =
    file?.type === "application/pdf" || file?.type.includes("presentationml")
      ? "Save to Files / Share"
      : "Save to Photos / Share";

  // Opening the original storage URL is an honest fallback when a browser or
  // in-app webview cannot download a blob URL. It does not claim to save it.
  const showOpenFallback = Boolean(
    error || actionError || (file && !canShareFile)
  );

  function handleDownload() {
    if (directURL) {
      downloadUrl(directURL, filename);
      return;
    }
    setAction("download");
    setActionError("");
    // A ticket or prefetch can be transiently late on a phone. Do not make
    // the user press Download a second time: prepare the validated bytes from
    // the same-origin storage URL and dispatch the local download in this
    // click's operation.
    void (async () => {
      try {
        const prepared =
          file ?? (await fetchDownloadFile(sourceURL, filename, maxBytes));
        if (!file) {
          setFile(prepared);
          onFileReady?.(prepared);
        }
        saveFile(prepared);
      } catch (downloadError) {
        setActionError(
          errorMessage(downloadError, "The file could not be downloaded.")
        );
      } finally {
        setAction(null);
      }
    })();
  }

  function handleShare() {
    if (!file) return;
    setAction("share");
    setActionError("");
    // shareFile invokes navigator.share before its first await. Keeping this
    // call directly in the click handler preserves the native user gesture.
    void shareFile(file)
      .catch(shareError => {
        setActionError(
          errorMessage(
            shareError,
            "The file could not be shared. Use Download instead."
          )
        );
      })
      .finally(() => setAction(null));
  }

  function openFile() {
    if (typeof window === "undefined") {
      setActionError("Opening files is only available in a browser.");
      return;
    }
    window.open(sourceURL, "_blank", "noopener,noreferrer");
  }

  return (
    <div className={cn("space-y-2", className)}>
      {loading && (
        <div
          className="flex items-center gap-2 text-xs text-muted-foreground"
          role="status"
        >
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          Preparing file…
        </div>
      )}
      {error && (
        <div
          role="alert"
          className="flex items-start gap-2 rounded-lg border border-red-300/30 bg-red-950/60 px-3 py-2 text-xs leading-5 text-red-100"
        >
          <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {actionError && (
        <div
          role="alert"
          className="rounded-lg border border-red-300/30 bg-red-950/60 px-3 py-2 text-xs leading-5 text-red-100"
        >
          {actionError}
        </div>
      )}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs leading-5 text-muted-foreground">
          {canShareFile
            ? "Use the native share sheet to save this file, or download it locally."
            : "Download saves to this browser’s Files/downloads location."}
        </p>
        <div className="flex flex-wrap justify-end gap-2">
          {canShareFile && (
            <Button
              type="button"
              variant="secondary"
              onClick={handleShare}
              disabled={loading || action !== null}
              className="gap-2"
            >
              {action === "share" ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Share2 className="h-4 w-4" />
              )}
              {shareLabel}
            </Button>
          )}
          <Button
            type="button"
            variant="outline"
            onClick={handleDownload}
            disabled={(!file && !directURL && !sourceURL) || action !== null}
            className="gap-2"
          >
            {action === "download" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            Download
          </Button>
          {showOpenFallback && (
            <Button
              type="button"
              variant="ghost"
              onClick={openFile}
              className="gap-2"
            >
              {error ? (
                <ExternalLink className="h-4 w-4" />
              ) : (
                <FileDown className="h-4 w-4" />
              )}
              {openLabel}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export default MediaSaveActions;
