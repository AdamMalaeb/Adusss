import { boardDrawingPath, boardActionOpacity } from "@shared/boardDrawing";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  buildLessonTiming,
  boardActionProgressAt,
  findLessonScene,
  narrationWeight,
  whiteboardRevealAt,
  whiteboardErasePhase,
  type LessonBoardAction,
  type LessonPhraseCue,
} from "@shared/lessonTiming";

import {
  languageNativeLabel,
  isRtl,
  type LanguageSelection,
} from "@shared/languages";
import { normalizeStandaloneMathText } from "@shared/mathFormat";
export type WhiteboardPlayerLanguage = LanguageSelection;

export type WhiteboardPlayerVisual = {
  kind?: "diagram" | "process" | "comparison" | "photo" | string;
  labels?: string[];
};

export type WhiteboardPlayerBoardAction = LessonBoardAction;

export type WhiteboardPlayerScene = {
  title: string;
  bullets: string[];
  narration: string;
  visual?: WhiteboardPlayerVisual;
  boardActions?: WhiteboardPlayerBoardAction[];
};

export type WhiteboardPlayerProps = {
  scenes: WhiteboardPlayerScene[];
  language: WhiteboardPlayerLanguage;
  audioURL?: string;
  className?: string;
};

export type WhiteboardTimelineItem = WhiteboardPlayerScene & {
  index: number;
  start: number;
  end: number;
  duration: number;
  cues: LessonPhraseCue[];
  cueAlignment: "estimated";
};

const WIDTH = 960;
const HEIGHT = 540;

/** The fallback preview uses a brisk teacher pace; audio metadata rescales this plan. */
export function estimateWhiteboardDuration(
  scene: WhiteboardPlayerScene
): number {
  return Math.max(2.25, narrationWeight(scene.narration) / 2.65);
}

export function buildWhiteboardTimeline(
  scenes: WhiteboardPlayerScene[],
  totalDuration?: number
): WhiteboardTimelineItem[] {
  return buildLessonTiming(scenes, totalDuration);
}

function languageLabel(language: WhiteboardPlayerLanguage): string {
  return languageNativeLabel(language);
}

function escapeText(value: string): string {
  // React renders text safely; this helper only keeps line splitting deterministic.
  return normalizeStandaloneMathText(value.replace(/\s+/g, " ").trim());
}

function wrapText(value: string, width: number): string[] {
  const words = escapeText(value).split(" ").filter(Boolean);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (line && next.length > width) {
      lines.push(line);
      line = word;
    } else line = next;
  }
  if (line) lines.push(line);
  return lines.length ? lines : [" "];
}

function sceneLabels(scene: WhiteboardPlayerScene): string[] {
  return Array.from(
    new Set([...(scene.visual?.labels ?? []), ...scene.bullets])
  )
    .map(escapeText)
    .filter(Boolean)
    .slice(0, 5);
}

function clamp(value: number, min = 0, max = 1): number {
  return Math.max(min, Math.min(max, value));
}

function boardActionText(action: WhiteboardPlayerBoardAction): string {
  return normalizeStandaloneMathText(
    (action.text ?? action.target ?? "").replace(/\s+/g, " ").trim()
  );
}

function BoardActions({
  scene,
  reveal,
}: {
  scene: WhiteboardPlayerScene;
  reveal: number;
}) {
  const actions = (scene.boardActions ?? []).slice(0, 8);
  const state = boardActionProgressAt(actions, reveal);
  return (
    <g aria-label="Synchronized board actions">
      {actions.slice(0, state.visibleCount).map((action, index) => {
        const from = action.from ?? { x: 0.15, y: 0.48 };
        const to = action.to ?? { x: 0.78, y: 0.48 };
        const x = 80 + clamp(from.x) * 650;
        const y = 112 + clamp(from.y) * 290;
        const tx = 80 + clamp(to.x) * 650;
        const ty = 112 + clamp(to.y) * 290;
        const progress = index === state.activeIndex ? state.activeProgress : 1;
        const label = boardActionText(action);
        const shown = label.slice(
          0,
          Math.max(1, Math.ceil(label.length * progress))
        );
        const color =
          action.emphasis === "warning"
            ? "#c94d3d"
            : action.emphasis === "accent"
              ? "#2b8b73"
              : "#173f55";
        if (action.type === "draw" || action.type === "link") {
          return (
            <g
              key={`action-${index}`}
              opacity={
                Math.max(0.12, progress) *
                boardActionOpacity(actions, index, reveal)
              }
            >
              <path
                d={boardDrawingPath(action)}
                pathLength={100}
                fill="none"
                stroke={color}
                strokeWidth={action.type === "link" ? 4 : 5}
                strokeDasharray={100}
                strokeDashoffset={(1 - progress) * 100}
                markerEnd={action.type === "link" ? "url(#wbArrow)" : undefined}
              />
              {shown ? (
                <text
                  x={tx}
                  y={ty - 10}
                  fill={color}
                  className="text-[18px] font-semibold"
                >
                  {shown}
                </text>
              ) : null}
            </g>
          );
        }
        if (action.type === "erase") {
          return (
            <path
              key={`action-${index}`}
              d={`M ${x} ${y} L ${tx} ${ty}`}
              fill="none"
              stroke="#d39b2a"
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray="18 10"
              strokeDashoffset={(1 - progress) * 140}
              opacity={Math.max(0.12, progress)}
            />
          );
        }
        if (action.type === "highlight") {
          return (
            <g
              key={`action-${index}`}
              opacity={
                Math.max(0.12, progress) *
                boardActionOpacity(actions, index, reveal)
              }
            >
              <rect
                x={x - 10}
                y={y - 29}
                width={Math.max(86, Math.min(420, (label.length + 4) * 12))}
                height="42"
                rx="9"
                fill="#f4c95d"
                stroke="#d39b2a"
                strokeWidth="2"
                opacity=".72"
              />
              <text
                x={x}
                y={y}
                fill={color}
                className="text-[18px] font-semibold"
              >
                {shown}
              </text>
            </g>
          );
        }
        return (
          <text
            key={`action-${index}`}
            x={x}
            y={y}
            fill={color}
            opacity={
              Math.max(0.12, progress) *
              boardActionOpacity(actions, index, reveal)
            }
            className="text-[18px] font-semibold"
          >
            {shown}
          </text>
        );
      })}
    </g>
  );
}

function WhiteboardSvg({
  scene,
  progress,
  cues,
  sceneIndex,
  sceneCount,
  previousScene,
}: {
  scene: WhiteboardPlayerScene;
  progress: number;
  cues: LessonPhraseCue[];
  sceneIndex: number;
  sceneCount: number;
  previousScene?: WhiteboardPlayerScene;
}) {
  const p = clamp(progress);
  const erasePhase = whiteboardErasePhase(cues);
  const erasing = p < erasePhase;
  // Phrase cues are proportional estimates, not word-exact timestamps. They
  // still keep board changes attached to the narration's actual audio clock.
  const reveal = whiteboardRevealAt(cues, p);
  const labels = scene.boardActions?.length ? [] : sceneLabels(scene);
  const comparison = scene.visual?.kind === "comparison";
  const process = scene.visual?.kind === "process";
  const displayLabels = comparison ? labels.slice(0, 2) : labels;
  const titleLines = wrapText(scene.title, 30).slice(0, 2);
  const titleOpacity = clamp(p * 3.2);
  const visibleCount = Math.min(
    displayLabels.length,
    Math.max(0, Math.ceil(reveal * Math.max(1, displayLabels.length)))
  );
  const nodeWidth = comparison ? 288 : 126;
  const gap = comparison ? 78 : 20;
  const startX = comparison ? 78 : 78;
  const boardY = 232;
  const markerX = erasing
    ? 92 + 630 * clamp(p / erasePhase)
    : 122 + 552 * reveal;
  const markerY = erasing
    ? boardY
    : boardY + 58 + Math.sin(reveal * Math.PI * 3) * 48;

  return (
    <svg
      viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
      role="img"
      aria-label={`Animated whiteboard scene: ${scene.title}`}
      className="h-auto w-full"
    >
      <defs>
        <linearGradient id="wbPaper" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#fffef7" />
          <stop offset="1" stopColor="#e8f2ed" />
        </linearGradient>
        <marker
          id="wbArrow"
          markerWidth="10"
          markerHeight="10"
          refX="8"
          refY="5"
          orient="auto"
        >
          <path d="M0 0 L10 5 L0 10 z" fill="#e45e47" />
        </marker>
      </defs>
      <rect width={WIDTH} height={HEIGHT} fill="#132a3a" />
      <rect
        x="42"
        y="30"
        width="770"
        height="450"
        rx="20"
        fill="url(#wbPaper)"
        stroke="#b9d4cc"
        strokeWidth="5"
      />
      <path d="M42 82 H812" stroke="#d6e6df" strokeWidth="2" />
      <text
        x="72"
        y="62"
        className="fill-[#4b706c] text-[13px] font-bold tracking-[2px]"
      >
        WHITEBOARD · SCENE {sceneIndex + 1}/{sceneCount}
      </text>
      <g opacity={titleOpacity}>
        {titleLines.map((line, index) => (
          <text
            key={`${line}-${index}`}
            x="72"
            y={110 + index * 38}
            className="fill-[#173f55] text-[34px] font-bold"
          >
            {line.slice(
              0,
              Math.ceil(line.length * clamp(reveal * 4 - index * 0.4))
            )}
          </text>
        ))}
      </g>
      <text
        x="72"
        y="188"
        opacity={titleOpacity}
        className="fill-[#5b8d88] text-[12px] font-bold tracking-[2px]"
      >
        {comparison ? "COMPARE" : "CONNECT THE IDEAS"}
      </text>
      <g opacity={erasing ? 1 - p / erasePhase : 1}>
        {visibleCount > 1 &&
          process &&
          Array.from({ length: visibleCount - 1 }, (_, index) => {
            const x1 = startX + index * (nodeWidth + gap) + nodeWidth + 5;
            const x2 = x1 + gap - 8;
            return (
              <path
                key={`arrow-${index}`}
                d={`M ${x1} ${boardY + 58} L ${x2} ${boardY + 58}`}
                fill="none"
                stroke="#e45e47"
                strokeWidth="4"
                strokeDasharray="8 5"
                markerEnd="url(#wbArrow)"
              />
            );
          })}
        {displayLabels.slice(0, visibleCount).map((label, index) => {
          const x = startX + index * (nodeWidth + gap);
          const writeProgress = clamp(reveal * displayLabels.length - index);
          return (
            <g key={`${label}-${index}`}>
              <rect
                x={x}
                y={boardY}
                width={nodeWidth}
                height="118"
                rx="12"
                fill="#f9fbef"
                stroke="#e45e47"
                strokeWidth="3"
              />
              <text
                x={x + 18}
                y={boardY + 27}
                className="fill-[#e45e47] text-[14px] font-bold"
              >
                {index + 1}
              </text>
              {wrapText(label, comparison ? 23 : 13)
                .slice(0, 3)
                .map((line, lineIndex) => (
                  <text
                    key={`${line}-${lineIndex}`}
                    x={x + nodeWidth / 2}
                    y={boardY + 51 + lineIndex * 23}
                    textAnchor="middle"
                    className="fill-[#183f51] text-[17px] font-semibold"
                  >
                    {line.slice(
                      0,
                      Math.ceil(
                        line.length * clamp(writeProgress * 3 - lineIndex * 0.3)
                      )
                    )}
                  </text>
                ))}
            </g>
          );
        })}
        {comparison && visibleCount > 1 ? (
          <text
            x="480"
            y="305"
            textAnchor="middle"
            className="fill-[#e45e47] text-[24px] font-bold"
          >
            VS
          </text>
        ) : null}
        {scene.bullets.slice(0, 4).map((bullet, i) => (
          <text
            key={i}
            x="72"
            y={393 + i * 20}
            opacity={clamp(reveal * 3 - i * 0.4)}
            className="fill-[#376b62] text-[13px] font-semibold"
          >
            {normalizeStandaloneMathText(bullet)
              .slice(
                0,
                Math.ceil(bullet.length * clamp(reveal * 2.5 - i * 0.3))
              )
              .slice(0, 95)}
          </text>
        ))}
        <BoardActions scene={scene} reveal={reveal} />
      </g>
      {erasing && previousScene ? (
        <g opacity={clamp(1 - p / erasePhase)}>
          <text x="72" y="120" className="fill-[#173f55] text-[28px] font-bold">
            {normalizeStandaloneMathText(previousScene.title)}
          </text>
          {previousScene.bullets.slice(0, 5).map((b, i) => (
            <text
              key={i}
              x="72"
              y={190 + i * 42}
              className="fill-[#376b62] text-[18px]"
            >
              {normalizeStandaloneMathText(b).slice(0, 72)}
            </text>
          ))}
        </g>
      ) : null}
      {erasing ? (
        <path
          d={`M 72 210 L ${markerX} 210`}
          stroke="#f4c95d"
          strokeWidth="13"
          strokeLinecap="round"
          opacity=".75"
        />
      ) : null}
      {/* The marker hand is intentionally stylized, not photoreal footage. */}
      <g>
        <circle
          cx="852"
          cy="148"
          r="27"
          fill="#f8c9a6"
          stroke="#7c4939"
          strokeWidth="3"
        />
        <path
          d="M820 149 Q852 109 884 149"
          fill="none"
          stroke="#3e2c35"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path
          d="M820 180 C786 182 780 221 782 280 L884 280 C884 220 876 182 852 180Z"
          fill="#6c8cff"
          stroke="#2c477b"
          strokeWidth="3"
        />
        <path
          d={`M 820 214 Q ${markerX} ${markerY} ${markerX - 10} ${markerY + 8}`}
          fill="none"
          stroke="#f8c9a6"
          strokeWidth="16"
          strokeLinecap="round"
        />
        <circle
          cx={markerX}
          cy={markerY}
          r="12"
          fill="#f8c9a6"
          stroke="#7c4939"
          strokeWidth="2"
        />
        <rect
          x={markerX - 4}
          y={markerY - 25}
          width="8"
          height="30"
          rx="3"
          fill="#e45e47"
          stroke="#8f3324"
          strokeWidth="2"
          transform={`rotate(-24 ${markerX} ${markerY})`}
        />
      </g>
      <text x="72" y="512" className="fill-[#a7c4c5] text-[15px] font-semibold">
        {normalizeStandaloneMathText(scene.title)}
      </text>
    </svg>
  );
}

export function WhiteboardPlayer({
  scenes,
  language,
  audioURL,
  className,
}: WhiteboardPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const frameRef = useRef<number | null>(null);
  const lastFrameRef = useRef<number | null>(null);
  const clockRef = useRef(0);
  const playingRef = useRef(false);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [audioDuration, setAudioDuration] = useState<number | undefined>();
  const [audioReady, setAudioReady] = useState(false);
  const [audioError, setAudioError] = useState("");
  const [playbackRate, setPlaybackRate] = useState(1);

  const timeline = useMemo(
    () => buildWhiteboardTimeline(scenes, audioDuration),
    [scenes, audioDuration]
  );
  const duration = timeline.at(-1)?.end ?? 0;
  const active = findLessonScene(timeline, currentTime);

  useEffect(() => {
    clockRef.current = Math.min(clockRef.current, duration);
    setCurrentTime(clockRef.current);
  }, [duration]);

  const stopFrameLoop = useCallback(() => {
    if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    frameRef.current = null;
    lastFrameRef.current = null;
  }, []);

  const syncFromAudio = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || !Number.isFinite(audio.currentTime)) return;
    const next = Math.max(0, Math.min(duration, audio.currentTime));
    clockRef.current = next;
    setCurrentTime(next);
  }, [duration]);

  const tick = useCallback(
    (now: number) => {
      if (!playingRef.current) return;
      const last = lastFrameRef.current ?? now;
      lastFrameRef.current = now;
      const audio = audioRef.current;
      const next =
        audioURL && audio
          ? Number.isFinite(audio.currentTime)
            ? audio.currentTime
            : clockRef.current
          : clockRef.current + ((now - last) / 1000) * playbackRate;
      const bounded = Math.min(duration, Math.max(0, next));
      clockRef.current = bounded;
      setCurrentTime(bounded);
      if (bounded >= duration || (audioURL && audio?.ended)) {
        playingRef.current = false;
        setPlaying(false);
        stopFrameLoop();
        return;
      }
      frameRef.current = requestAnimationFrame(tick);
    },
    [audioURL, duration, playbackRate, stopFrameLoop]
  );

  const beginFrameLoop = useCallback(() => {
    stopFrameLoop();
    lastFrameRef.current = null;
    frameRef.current = requestAnimationFrame(tick);
  }, [stopFrameLoop, tick]);

  const play = useCallback(async () => {
    if (!duration) return;
    if (clockRef.current >= duration) {
      clockRef.current = 0;
      setCurrentTime(0);
      if (audioRef.current) audioRef.current.currentTime = 0;
    }
    const audio = audioRef.current;
    if (audioURL && audio) {
      try {
        setAudioError("");
        if (audio.ended || audio.currentTime >= duration) {
          audio.currentTime = 0;
          clockRef.current = 0;
          setCurrentTime(0);
        }
        audio.playbackRate = playbackRate;
        await audio.play();
      } catch {
        setAudioError(
          "Your browser blocked audio playback. Tap Play again, or open this page in Safari/Chrome."
        );
        return;
      }
    }
    playingRef.current = true;
    setPlaying(true);
    beginFrameLoop();
  }, [audioURL, beginFrameLoop, duration, playbackRate]);

  const pause = useCallback(() => {
    playingRef.current = false;
    setPlaying(false);
    audioRef.current?.pause();
    stopFrameLoop();
  }, [stopFrameLoop]);

  const replay = useCallback(() => {
    pause();
    clockRef.current = 0;
    setCurrentTime(0);
    if (audioRef.current) audioRef.current.currentTime = 0;
    void play();
  }, [pause, play]);

  const seek = useCallback(
    (value: number) => {
      const next = Math.max(0, Math.min(duration, value));
      clockRef.current = next;
      setCurrentTime(next);
      const audio = audioRef.current;
      if (audio && Number.isFinite(audio.duration)) audio.currentTime = next;
    },
    [duration]
  );

  const setRate = useCallback((value: number) => {
    const next = Number.isFinite(value) && value > 0 ? value : 1;
    setPlaybackRate(next);
    if (audioRef.current) audioRef.current.playbackRate = next;
  }, []);

  useEffect(() => () => stopFrameLoop(), [stopFrameLoop]);

  const onAudioMetadata = useCallback(() => {
    const value = audioRef.current?.duration;
    if (value && Number.isFinite(value) && value > 0) {
      setAudioDuration(value);
      setAudioReady(true);
      syncFromAudio();
    }
  }, [syncFromAudio]);

  const onAudioPlay = useCallback(() => {
    playingRef.current = true;
    setPlaying(true);
    beginFrameLoop();
  }, [beginFrameLoop]);

  const onAudioPause = useCallback(() => {
    syncFromAudio();
    playingRef.current = false;
    setPlaying(false);
    stopFrameLoop();
  }, [stopFrameLoop, syncFromAudio]);

  const onAudioEnded = useCallback(() => {
    clockRef.current = duration;
    setCurrentTime(duration);
    playingRef.current = false;
    setPlaying(false);
    stopFrameLoop();
  }, [duration, stopFrameLoop]);

  const percent = duration ? (currentTime / duration) * 100 : 0;
  return (
    <section
      className={`overflow-hidden rounded-2xl border border-slate-700 bg-slate-950 shadow-2xl ${className ?? ""}`}
      aria-label="Animated whiteboard lesson"
    >
      {audioURL ? (
        <audio
          ref={audioRef}
          src={audioURL}
          preload="metadata"
          onLoadedMetadata={onAudioMetadata}
          onDurationChange={onAudioMetadata}
          onPlay={onAudioPlay}
          onPause={onAudioPause}
          onSeeking={syncFromAudio}
          onRateChange={event =>
            setPlaybackRate(event.currentTarget.playbackRate)
          }
          onEnded={onAudioEnded}
          onError={() =>
            setAudioError(
              "Narration could not load. Check your connection and retry this chapter."
            )
          }
        />
      ) : null}
      <div className="relative border-b border-slate-800 bg-[#102b3a]">
        <WhiteboardSvg
          scene={
            active.scene ??
            scenes[0] ?? {
              title: "Whiteboard lesson",
              bullets: [],
              narration: "",
            }
          }
          progress={active.local}
          cues={active.scene?.cues ?? []}
          sceneIndex={active.index}
          sceneCount={scenes.length}
          previousScene={
            active.index > 0 ? scenes[active.index - 1] : undefined
          }
        />
        <div
          className="absolute bottom-3 left-5 right-5 h-1.5 overflow-hidden rounded-full bg-slate-700/70"
          aria-hidden="true"
        >
          <div
            className="h-full rounded-full bg-amber-300 transition-[width] duration-75"
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>
      {audioError && (
        <p role="alert" className="p-3 text-sm text-amber-200">
          {audioError}
        </p>
      )}
      <div className="flex flex-wrap items-center gap-3 p-4 text-sm text-slate-200">
        <button
          type="button"
          onClick={playing ? pause : () => void play()}
          className="rounded-lg bg-cyan-300 px-4 py-2 font-bold text-slate-950 hover:bg-cyan-200"
          aria-label={
            playing ? "Pause whiteboard lesson" : "Play whiteboard lesson"
          }
        >
          {playing ? "Pause" : "Play"}
        </button>
        <button
          type="button"
          onClick={replay}
          className="rounded-lg border border-slate-600 px-4 py-2 hover:bg-slate-800"
          aria-label="Replay whiteboard lesson"
        >
          Replay
        </button>
        <label className="flex min-w-[10rem] flex-1 items-center gap-2 text-xs text-slate-400">
          <span className="sr-only">Seek narration</span>
          <input
            type="range"
            min={0}
            max={duration || 0.1}
            step={0.01}
            value={Math.min(currentTime, duration || 0.1)}
            onChange={event => seek(Number(event.currentTarget.value))}
            className="w-full accent-amber-300"
            aria-label="Seek narration"
          />
        </label>
        {audioURL ? (
          <label className="flex items-center gap-2 text-xs text-slate-400">
            <span>Speed</span>
            <select
              value={playbackRate}
              onChange={event => setRate(Number(event.currentTarget.value))}
              className="rounded border border-slate-600 bg-slate-900 px-1.5 py-1 text-slate-200"
              aria-label="Narration playback speed"
            >
              {[0.75, 1, 1.25, 1.5].map(rate => (
                <option key={rate} value={rate}>
                  {rate}×
                </option>
              ))}
            </select>
          </label>
        ) : null}
        <span className="text-slate-400">
          {languageLabel(language)} · Scene {active.index + 1} of{" "}
          {scenes.length}
        </span>
        {audioURL ? (
          <span className="text-emerald-300">
            {audioReady ? "Neural narration ready" : "Loading narration…"}
          </span>
        ) : (
          <span className="text-amber-300">
            Visual preview · narration audio unavailable
          </span>
        )}
        <span className="ml-auto tabular-nums text-slate-400">
          {Math.floor(currentTime)}s / {Math.ceil(duration)}s
        </span>
      </div>
      <details className="border-t border-slate-800 p-4 text-sm text-slate-300">
        <summary>Teacher transcript — current scene</summary>
        <p dir={isRtl(language) ? "rtl" : "ltr"} className="mt-2 leading-7">
          {normalizeStandaloneMathText(active.scene?.narration ?? "")}
        </p>
      </details>
    </section>
  );
}

export default WhiteboardPlayer;
