import { useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import {
  studyTaskManager,
  subscribeStudyTasks,
  type StudyTaskMode,
  type StudyTaskRequest,
} from "@/lib/studyTaskManager";
import {
  getWorkspaceAccount,
  subscribeWorkspaceAccount,
} from "@/lib/workspaceAccount";

type Chapter = { index: number; audioURL?: string };
type Course = {
  id: string;
  language: StudyTaskRequest["language"];
  units: Array<{ label: string }>;
  chapters: Chapter[];
};

/** Mounted once: navigation does not own the request lifecycle. Closing the browser pauses work until resumption. */
export default function StudyTaskRunner() {
  const create = trpc.adus.study.createCourse.useMutation({
    meta: { handledError: true },
  });
  const analyze = trpc.adus.study.analyzeChapter.useMutation({
    meta: { handledError: true },
  });
  const voice = trpc.adus.study.prepareChapterVoice.useMutation({
    meta: { handledError: true },
  });
  const pdf = trpc.adus.study.summaryPdf.useMutation({
    meta: { handledError: true },
  });
  const utils = trpc.useUtils();
  const api = useRef({ create, analyze, voice, pdf, utils });
  api.current = { create, analyze, voice, pdf, utils };
  useEffect(() => {
    let disposed = false;
    const running = new Set<string>();
    const run = async (mode: StudyTaskMode, request: StudyTaskRequest) => {
      const account = getWorkspaceAccount();
      if (!account) return;
      const slot = `${account}:${mode}`;
      if (running.has(slot)) return;
      running.add(slot);
      const isCurrent = () =>
        !disposed &&
        getWorkspaceAccount() === account &&
        studyTaskManager.getRequest(mode)?.taskId === request.taskId &&
        studyTaskManager.get(mode)?.state === "running";
      try {
        let courseId = request.courseId;
        if (!courseId) {
          if (!request.files?.length)
            throw Error(
              "Choose the original source files again to resume this upload."
            );
          const created = await api.current.create.mutateAsync({
            files: request.files,
            language: request.language,
            mode,
            generateIllustrations: false,
          });
          if (!isCurrent()) return;
          courseId = created.id;
          studyTaskManager.updateRequest(mode, { courseId, files: undefined });
          studyTaskManager.update(mode, { courseId, progress: 0 });
        }
        const course = (await api.current.utils.adus.study.getCourse.fetch({
          id: courseId,
        })) as Course;
        if (!isCurrent()) return;
        const chapters = new Map(course.chapters.map(ch => [ch.index, ch]));
        for (let index = 0; index < course.units.length; index++) {
          if (!isCurrent()) return;
          let chapter = chapters.get(index);
          if (!chapter) {
            studyTaskManager.update(mode, {
              courseId,
              phase: `Reading ${course.units[index].label} (${index + 1}/${course.units.length})`,
            });
            chapter = (await api.current.analyze.mutateAsync({
              id: courseId,
              index,
            })) as Chapter;
            if (!isCurrent()) return;
            chapters.set(index, chapter);
          }
          if (mode === "video" && !chapter.audioURL) {
            studyTaskManager.update(mode, {
              courseId,
              phase: `Preparing narration ${index + 1}/${course.units.length}`,
            });
            const result = await api.current.voice.mutateAsync({
              id: courseId,
              index,
            });
            if (!isCurrent()) return;
            chapters.set(index, { ...chapter, ...result });
          }
          studyTaskManager.update(mode, {
            courseId,
            progress: (index + 1) / Math.max(1, course.units.length),
            phase: `Prepared ${index + 1}/${course.units.length} chapters`,
          });
        }
        if (mode === "summary") {
          studyTaskManager.update(mode, { phase: "Preparing summary PDF…" });
          const result = await api.current.pdf.mutateAsync({ id: courseId });
          if (!isCurrent()) return;
          studyTaskManager.update(mode, { pdfUrl: result.url, progress: 1 });
        }
        if (isCurrent()) {
          studyTaskManager.complete(
            mode,
            mode === "summary"
              ? "Your summary and PDF are ready."
              : "Your narrated chapters are ready. Press Play."
          );
          void api.current.utils.adus.study.courses.invalidate();
        }
      } catch (error) {
        if (isCurrent())
          studyTaskManager.fail(
            mode,
            error instanceof Error
              ? error.message
              : "Resume this task to retry the failed step."
          );
      } finally {
        running.delete(slot);
        if (!disposed) queueMicrotask(startPending);
      }
    };
    const startPending = () => {
      if (disposed) return;
      for (const mode of ["summary", "video"] as const) {
        const request = studyTaskManager.getRequest(mode);
        if (request && studyTaskManager.get(mode)?.state === "running")
          void run(mode, request);
      }
    };
    const stopTasks = subscribeStudyTasks(startPending);
    const stopAccounts = subscribeWorkspaceAccount(startPending);
    startPending();
    return () => {
      disposed = true;
      stopTasks();
      stopAccounts();
    };
  }, []);
  return null;
}
