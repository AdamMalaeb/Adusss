import {
  CAMERA_STANDALONE_URL,
  cameraCapabilityMessage,
  type CameraCapabilities,
} from "@/lib/cameraCall";

type CameraAccessHelpProps = {
  capabilities?: CameraCapabilities;
  message?: string;
  className?: string;
};

/**
 * Recovery copy for camera failures. This is deliberately an ordinary link:
 * embedded iOS browsers may block camera access, but the app must not redirect
 * or claim that a permission denial was granted.
 */
export default function CameraAccessHelp({
  capabilities,
  message,
  className = "",
}: CameraAccessHelpProps) {
  return (
    <div
      className={`rounded-xl border border-amber-200/20 bg-amber-200/[0.06] px-3 py-3 text-xs leading-5 text-amber-100 ${className}`}
      role="alert"
    >
      <p>
        {message ??
          (capabilities
            ? cameraCapabilityMessage(capabilities)
            : "Camera access is unavailable in this browser. Open the full Adus page in Safari and try again.")}
      </p>
      <a
        href={CAMERA_STANDALONE_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-2 inline-block font-semibold underline underline-offset-2"
      >
        Open the full Adus page in Safari
      </a>
      <p className="mt-1 text-amber-100/70">
        In Safari, review camera permission for this site and choose Allow when
        prompted. Your voice call can continue without video.
      </p>
    </div>
  );
}
