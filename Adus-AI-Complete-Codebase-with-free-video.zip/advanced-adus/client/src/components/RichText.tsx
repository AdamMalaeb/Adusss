import type { ReactNode } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import rehypeKatex from "rehype-katex";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import "katex/dist/katex.min.css";
import { normalizeMathMarkdown } from "@shared/mathFormat";
import { stripProviderCitationTokens } from "@shared/chatCitations";
import { cn } from "@/lib/utils";

export type RichTextProps = {
  /** Markdown source. `children` is also accepted for easy component use. */
  content?: string;
  children?: ReactNode;
  className?: string;
  dir?: "ltr" | "rtl" | "auto";
};

/**
 * Keep wide markdown structures inside the message surface. Tables get an
 * accessible scroll region, while fenced code keeps its whitespace and gets
 * its own horizontal scroller. Inline code is allowed to wrap instead.
 */
const markdownComponents: Components = {
  table({ children, className, node: _node, ...props }) {
    return (
      <div
        className="rich-text-table-wrap"
        role="region"
        aria-label="Scrollable table"
        tabIndex={0}
      >
        <table {...props} className={cn("rich-text-table", className)}>
          {children}
        </table>
      </div>
    );
  },
  pre({ children, className, node: _node, ...props }) {
    return (
      <pre {...props} className={cn("rich-text-code-block", className)}>
        {children}
      </pre>
    );
  },
  code({ children, className, node: _node, ...props }) {
    return (
      <code {...props} className={cn("rich-text-code", className)}>
        {children}
      </code>
    );
  },
};

/**
 * Safe Markdown for AI/source material.
 *
 * Raw HTML is deliberately not enabled: react-markdown leaves HTML nodes out
 * unless `rehype-raw` is supplied, so scripts, event attributes and arbitrary
 * embeds never become DOM. The shared normalizer protects code/currency,
 * repairs common double-escaped delimiters, and turns standalone arrow
 * commands into Unicode before KaTeX renders inline `$...$` and display
 * `$$...$$`/`\\[...\\]` math. remark-gfm keeps saved equation/chemistry tables
 * intact.
 */
export function RichText({
  content,
  children,
  className,
  dir = "auto",
}: RichTextProps) {
  const source =
    typeof content === "string"
      ? content
      : typeof children === "string"
        ? children
        : "";
  return (
    <div
      className={cn("rich-text-content min-w-0", className)}
      dir={dir}
      data-rich-text="true"
      data-math-renderer="katex"
    >
      <ReactMarkdown
        skipHtml
        remarkPlugins={[
          remarkGfm,
          [remarkMath, { singleDollarTextMath: true }],
        ]}
        rehypePlugins={[rehypeKatex]}
        components={markdownComponents}
      >
        {normalizeMathMarkdown(stripProviderCitationTokens(source))}
      </ReactMarkdown>
    </div>
  );
}

export default RichText;
