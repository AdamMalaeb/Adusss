import { LANGUAGE_OPTIONS, type VoiceLanguage } from "@shared/languages";
export function LanguageSelect({
  value,
  onChange,
  includeAuto = false,
  label = "Language",
  className = "",
}: {
  value: string;
  onChange: (value: VoiceLanguage) => void;
  includeAuto?: boolean;
  label?: string;
  className?: string;
}) {
  return (
    <select
      value={value}
      onChange={e => onChange(e.target.value as VoiceLanguage)}
      aria-label={label}
      className={`block w-full min-w-0 max-w-full ${className}`}
    >
      {includeAuto && (
        <option className="bg-[#0b1019]" value="auto">
          Auto detect · follow your language
        </option>
      )}
      <option className="bg-[#0b1019]" value="english">
        English
      </option>
      <option className="bg-[#0b1019]" value="french">
        Français
      </option>
      <option className="bg-[#0b1019]" value="arabic">
        العربية
      </option>
      {LANGUAGE_OPTIONS.filter(x => !["en", "fr", "ar"].includes(x.code)).map(
        x => (
          <option className="bg-[#0b1019]" key={x.code} value={x.code}>
            {x.nativeLabel} · {x.label}
          </option>
        )
      )}
    </select>
  );
}
