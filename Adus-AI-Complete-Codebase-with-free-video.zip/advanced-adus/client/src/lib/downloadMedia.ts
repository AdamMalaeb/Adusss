/** Shared cap for image and chapter-video downloads. */
export const MAX_DOWNLOAD_BYTES = 64 * 1024 * 1024;
/** Image previews use the smaller cap requested by the image workspace. */
export const MAX_IMAGE_DOWNLOAD_BYTES = 20 * 1024 * 1024;

/**
 * Convert an older absolute app URL into the canonical relative storage URL.
 * Only same-origin `/manus-storage/` paths are normalized; arbitrary remote
 * URLs remain untouched and cannot be turned into an ownership ticket.
 */
export function normalizeStoredMediaUrl(url: string): string {
  const value = url.trim();
  if (!value || typeof window === "undefined") return value;
  try {
    const parsed = new URL(value, window.location.origin);
    if (
      parsed.origin === window.location.origin &&
      parsed.pathname.startsWith("/manus-storage/") &&
      !parsed.search &&
      !parsed.hash
    ) {
      return parsed.pathname;
    }
  } catch {
    // Leave malformed/remote legacy values to the normal fetch error path.
  }
  return value;
}

/** Start an attachment download from the current deployed app. */
export function downloadUrl(url: string, filename: string): void {
  if (typeof document === "undefined") {
    throw new Error("Downloads are only available in a browser.");
  }
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.rel = "noopener";
  anchor.style.display = "none";
  document.body?.appendChild(anchor);
  anchor.click();
  if (typeof anchor.remove === "function") anchor.remove();
  else if (document.body) document.body.removeChild(anchor);
}

type SupportedMedia = {
  type:
    | "image/png"
    | "image/jpeg"
    | "image/webp"
    | "image/gif"
    | "video/mp4"
    | "application/pdf"
    | "application/vnd.openxmlformats-officedocument.presentationml.presentation";
  extension: "png" | "jpg" | "webp" | "gif" | "mp4" | "pdf" | "pptx";
};

const PNG_SIGNATURE = new Uint8Array([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
]);
const JPEG_SIGNATURE = new Uint8Array([0xff, 0xd8, 0xff]);
const PDF_SIGNATURE = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d]);

function startsWithBytes(bytes: Uint8Array, signature: Uint8Array): boolean {
  if (bytes.length < signature.length) return false;
  for (let index = 0; index < signature.length; index += 1) {
    if (bytes[index] !== signature[index]) return false;
  }
  return true;
}

function ascii(bytes: Uint8Array, start: number, length: number): string {
  let value = "";
  for (
    let index = start;
    index < start + length && index < bytes.length;
    index += 1
  ) {
    value += String.fromCharCode(bytes[index] ?? 0);
  }
  return value;
}

/** Reject common HTML error/login pages even when storage lies about its type. */
function looksLikeHtml(bytes: Uint8Array): boolean {
  const text = new TextDecoder().decode(bytes.slice(0, 1024));
  const start = text
    .replace(/^\uFEFF/, "")
    .trimStart()
    .toLowerCase();
  return /^(?:<!doctype\s+html\b|<html(?:\s|>)|<head(?:\s|>)|<body(?:\s|>)|<script(?:\s|>)|<iframe(?:\s|>)|<frameset(?:\s|>)|<!--)/.test(
    start
  );
}

/**
 * Detect only formats that this app can safely hand to the browser. The
 * response MIME type is deliberately not trusted: signed storage responses
 * have been observed to return application/octet-stream or a misleading type.
 */
export function sniffMediaType(bytes: Uint8Array): SupportedMedia | null {
  if (startsWithBytes(bytes, PNG_SIGNATURE)) {
    return { type: "image/png", extension: "png" };
  }
  if (startsWithBytes(bytes, JPEG_SIGNATURE)) {
    return { type: "image/jpeg", extension: "jpg" };
  }
  if (
    bytes.length >= 12 &&
    ascii(bytes, 0, 4) === "RIFF" &&
    ascii(bytes, 8, 4) === "WEBP"
  ) {
    return { type: "image/webp", extension: "webp" };
  }
  if (
    bytes.length >= 6 &&
    (ascii(bytes, 0, 6) === "GIF87a" || ascii(bytes, 0, 6) === "GIF89a")
  ) {
    return { type: "image/gif", extension: "gif" };
  }
  // ISO Base Media File Format files identify themselves with an ftyp box at
  // byte 4. Restrict brands to MP4 families so HEIC/M4A/etc. are not
  // mislabeled as video/mp4 and handed to a browser unexpectedly.
  if (bytes.length >= 12 && ascii(bytes, 4, 4) === "ftyp") {
    const majorBrand = ascii(bytes, 8, 4).toLowerCase();
    const compatibleBrands = ascii(
      bytes,
      16,
      Math.max(0, bytes.length - 16)
    ).toLowerCase();
    const mp4Brand =
      majorBrand === "isom" ||
      majorBrand === "iso2" ||
      majorBrand === "iso3" ||
      majorBrand === "iso4" ||
      majorBrand === "iso5" ||
      majorBrand === "iso6" ||
      majorBrand === "mp41" ||
      majorBrand === "mp42" ||
      majorBrand === "avc1" ||
      compatibleBrands.includes("isom") ||
      compatibleBrands.includes("mp41") ||
      compatibleBrands.includes("mp42");
    if (mp4Brand) return { type: "video/mp4", extension: "mp4" };
  }
  if (startsWithBytes(bytes, PDF_SIGNATURE)) {
    return { type: "application/pdf", extension: "pdf" };
  }
  return null;
}

/** Keep the caller's useful name while ensuring it has the detected extension. */
function filenameForType(
  filename: string,
  extension: SupportedMedia["extension"]
): string {
  const safeName = filename
    .trim()
    .replace(/[\\/]/g, "-")
    .replace(/[\u0000-\u001f\u007f]/g, "-");
  const name = safeName || "download";
  const lastDot = name.lastIndexOf(".");
  const stem = lastDot > 0 ? name.slice(0, lastDot) : name;
  return `${stem || "download"}.${extension}`;
}

function getDownloadLimitLabel(maxBytes: number): string {
  return `${Math.round(maxBytes / 1024 / 1024)} MB`;
}

async function readResponseBytes(
  response: Response,
  maxBytes: number
): Promise<Uint8Array> {
  const limitError = () =>
    new Error(
      `This file is larger than the ${getDownloadLimitLabel(maxBytes)} download limit.`
    );
  const reader = response.body?.getReader();
  if (!reader) {
    const blob = await response.blob();
    if (blob.size > maxBytes) throw limitError();
    return new Uint8Array(await blob.arrayBuffer());
  }

  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      total += value.byteLength;
      if (total > maxBytes) {
        void reader.cancel().catch(() => undefined);
        throw limitError();
      }
      chunks.push(value);
    }
  } catch (error) {
    try {
      await reader.cancel();
    } catch {
      // The stream may already have closed; preserve the original error.
    }
    throw error;
  }

  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    for (let index = 0; index < chunk.byteLength; index += 1) {
      bytes[offset + index] = chunk[index] ?? 0;
    }
    offset += chunk.byteLength;
  }
  return bytes;
}

/**
 * Fetch a storage object into a validated File. This intentionally runs in the
 * browser; it is not a server-side URL proxy and never trusts a remote URL's
 * download attribute or content type.
 */
export async function fetchDownloadFile(
  url: string,
  filename: string,
  maxBytes = MAX_DOWNLOAD_BYTES
): Promise<File> {
  if (!url.trim()) throw new Error("The media URL is empty.");
  if (!filename.trim()) throw new Error("A download filename is required.");
  if (!Number.isFinite(maxBytes) || maxBytes <= 0) {
    throw new Error("A positive download limit is required.");
  }

  let response: Response;
  try {
    response = await fetch(url);
  } catch {
    throw new Error(
      "The file could not be downloaded. Your browser may not allow access to this storage URL."
    );
  }

  if (!response.ok) {
    throw new Error(
      `The file could not be downloaded (HTTP ${response.status}).`
    );
  }

  const contentLength = response.headers.get("content-length");
  if (contentLength) {
    const parsedLength = Number(contentLength);
    if (Number.isFinite(parsedLength) && parsedLength > maxBytes) {
      throw new Error(
        `This file is larger than the ${getDownloadLimitLabel(maxBytes)} download limit.`
      );
    }
  }

  let bytes: Uint8Array;
  try {
    bytes = await readResponseBytes(response, maxBytes);
  } catch (error) {
    if (error instanceof Error && error.message.includes("download limit")) {
      throw error;
    }
    throw new Error("The storage response could not be read as a file.");
  }
  if (looksLikeHtml(bytes)) {
    throw new Error(
      "The storage response was HTML, not a supported media file."
    );
  }

  const detected: SupportedMedia | null =
    /\.pptx$/i.test(filename) && bytes[0] === 0x50 && bytes[1] === 0x4b
      ? {
          type: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          extension: "pptx",
        }
      : sniffMediaType(bytes);
  if (!detected) {
    throw new Error(
      "The storage response was not a supported PNG, JPEG, WEBP, GIF, MP4, PDF, or PPTX file."
    );
  }

  const correctedFilename = filenameForType(filename, detected.extension);
  const validatedBuffer = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(validatedBuffer).set(bytes);
  const validatedBlob = new Blob([validatedBuffer], { type: detected.type });
  return new File([validatedBlob], correctedFilename, { type: detected.type });
}

/** Start a browser download from local bytes, never from the remote URL. */
export function saveFile(file: File): void {
  if (typeof document === "undefined") {
    throw new Error("Downloads are only available in a browser.");
  }
  if (typeof URL.createObjectURL !== "function") {
    throw new Error("This browser cannot create a local download.");
  }

  const objectUrl = URL.createObjectURL(file);
  downloadUrl(objectUrl, file.name);

  // Keep the object URL alive through the browser's download dispatch.
  globalThis.setTimeout(() => URL.revokeObjectURL(objectUrl), 30_000);
}

/**
 * Ask the platform share sheet to handle the already-downloaded file.
 * Resolves false when file sharing is unavailable or was canceled.
 */
export async function shareFile(file: File): Promise<boolean> {
  if (
    typeof navigator === "undefined" ||
    typeof navigator.share !== "function" ||
    typeof navigator.canShare !== "function"
  ) {
    return false;
  }

  try {
    if (!navigator.canShare({ files: [file] })) return false;
    await navigator.share({ files: [file] });
    return true;
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError")
      return false;
    throw error;
  }
}
