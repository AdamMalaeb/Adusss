export const CAMERA_FRAME_NAME = "Live camera frame" as const;
export const CAMERA_FRAME_MIME_TYPE = "image/jpeg" as const;
export const CAMERA_MAX_LONG_EDGE = 960;
export const CAMERA_JPEG_QUALITY = 0.75;

export type CameraFacingMode = "user" | "environment";

export type CameraFrame = {
  dataUrl: string;
  mimeType: typeof CAMERA_FRAME_MIME_TYPE;
  name: typeof CAMERA_FRAME_NAME;
};

export type CameraState = {
  active: boolean;
  pending: boolean;
  facingMode: CameraFacingMode;
  status: string;
  error?: string;
};

export type CameraCanvas = {
  width: number;
  height: number;
  drawImage: (
    image: HTMLVideoElement,
    dx: number,
    dy: number,
    dWidth: number,
    dHeight: number
  ) => void;
  toDataURL: (type?: string, quality?: number) => string;
};

export type CameraRuntime = {
  getUserMedia: (constraints: MediaStreamConstraints) => Promise<MediaStream>;
  createCanvas: () => CameraCanvas;
  getCapabilities?: () => CameraCapabilities;
};

export const CAMERA_STANDALONE_URL =
  "https://aiworkspace-dyq23yap.manus.space/" as const;

export type CameraCapabilities = {
  supported: boolean;
  secureContext: boolean;
  embedded: boolean;
  policyAllowsCamera?: boolean;
  canRequest: boolean;
  standaloneUrl: typeof CAMERA_STANDALONE_URL;
  reason?: "embedded" | "policy" | "insecure-context" | "unsupported";
};

type CameraPolicy = {
  allows?: (feature: string) => boolean;
  allowsFeature?: (feature: string) => boolean;
};

/** Read capability signals without requesting permission or opening a prompt. */
export function getCameraCapabilities(): CameraCapabilities {
  const browserWindow = typeof window === "undefined" ? undefined : window;
  const browserNavigator =
    typeof navigator === "undefined" ? undefined : navigator;
  const browserDocument =
    typeof document === "undefined" ? undefined : document;
  const supported =
    typeof browserNavigator?.mediaDevices?.getUserMedia === "function";
  const secureContext = browserWindow?.isSecureContext !== false;
  let embedded = false;
  if (browserWindow) {
    try {
      embedded = browserWindow.top !== browserWindow.self;
    } catch {
      // Cross-origin access to top can throw; that still means this is embedded.
      embedded = true;
    }
  }
  const policy =
    (
      browserDocument as
        | (Document & {
            permissionsPolicy?: CameraPolicy;
            featurePolicy?: CameraPolicy;
          })
        | undefined
    )?.permissionsPolicy ??
    (
      browserDocument as
        | (Document & { featurePolicy?: CameraPolicy })
        | undefined
    )?.featurePolicy;
  let policyAllowsCamera: boolean | undefined;
  if (policy && typeof policy.allowsFeature === "function") {
    try {
      policyAllowsCamera = policy.allowsFeature("camera");
    } catch {
      policyAllowsCamera = undefined;
    }
  } else if (policy && typeof policy.allows === "function") {
    // Older browser implementations and unit-test doubles exposed `allows`.
    try {
      policyAllowsCamera = policy.allows("camera");
    } catch {
      policyAllowsCamera = undefined;
    }
  }
  const canRequest = supported && secureContext && policyAllowsCamera !== false;
  const reason = !secureContext
    ? "insecure-context"
    : policyAllowsCamera === false
      ? embedded
        ? "embedded"
        : "policy"
      : !supported
        ? "unsupported"
        : undefined;
  return {
    supported,
    secureContext,
    embedded,
    policyAllowsCamera,
    canRequest,
    standaloneUrl: CAMERA_STANDALONE_URL,
    reason,
  };
}

export function cameraCapabilityMessage(capabilities: CameraCapabilities) {
  if (capabilities.reason === "embedded") {
    return "This embedded browser does not allow camera access. Open the full page in Safari, then choose Allow when prompted.";
  }
  if (capabilities.reason === "policy") {
    return "This page's host has disabled camera access. Open the full page in Safari, or ask the embedding host to allow camera access.";
  }
  if (capabilities.reason === "insecure-context") {
    return "Camera access requires a secure HTTPS page. Open the full page in Safari and try again.";
  }
  if (capabilities.reason === "unsupported") {
    return "This browser cannot request a camera. Open the full page in Safari and try again.";
  }
  return "Camera access is unavailable in this browser. Check camera permission and try again.";
}

export const initialCameraState: CameraState = {
  active: false,
  pending: false,
  facingMode: "user",
  status: "Camera off",
};

export function browserCameraRuntime(): CameraRuntime {
  return {
    getCapabilities: getCameraCapabilities,
    getUserMedia: constraints => {
      if (!navigator.mediaDevices?.getUserMedia) {
        return Promise.reject(
          new Error("Camera access is not supported in this browser.")
        );
      }
      return navigator.mediaDevices.getUserMedia(constraints);
    },
    createCanvas: () => {
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");
      if (!context)
        throw new Error("Camera snapshots are not supported in this browser.");
      return {
        get width() {
          return canvas.width;
        },
        set width(value: number) {
          canvas.width = value;
        },
        get height() {
          return canvas.height;
        },
        set height(value: number) {
          canvas.height = value;
        },
        drawImage: (
          image: HTMLVideoElement,
          dx: number,
          dy: number,
          dWidth: number,
          dHeight: number
        ) => context.drawImage(image, dx, dy, dWidth, dHeight),
        toDataURL: (type?: string, quality?: number) =>
          canvas.toDataURL(type, quality),
      } satisfies CameraCanvas;
    },
  };
}

export function cameraConstraints(
  facingMode: CameraFacingMode
): MediaStreamConstraints {
  return {
    video: {
      facingMode,
      width: { ideal: 1280 },
      height: { ideal: 720 },
    },
    audio: false,
  };
}

export const basicCameraConstraints: MediaStreamConstraints = {
  video: true,
  audio: false,
};

function cameraErrorName(error: unknown) {
  return (typeof DOMException !== "undefined" &&
    error instanceof DOMException) ||
    (typeof error === "object" && error !== null && "name" in error)
    ? String((error as { name?: unknown }).name ?? "")
    : "";
}

function canRetryWithBasicConstraints(error: unknown) {
  const name = cameraErrorName(error);
  return name === "NotFoundError" || name === "OverconstrainedError";
}

async function requestCameraStream(
  runtime: CameraRuntime,
  facingMode: CameraFacingMode
) {
  try {
    return await runtime.getUserMedia(cameraConstraints(facingMode));
  } catch (error) {
    // Only device/constraint failures get a less restrictive retry. Never
    // retry NotAllowedError: it cannot bypass a real permission denial and can
    // create repeated prompts in iOS embedded browsers.
    if (!canRetryWithBasicConstraints(error)) throw error;
    return runtime.getUserMedia(basicCameraConstraints);
  }
}

async function requestSwitchCameraStream(
  runtime: CameraRuntime,
  facingMode: CameraFacingMode,
  previousStream: MediaStream,
  onPreviousStreamStopped: () => void
) {
  try {
    return {
      stream: await requestCameraStream(runtime, facingMode),
      previousStreamStopped: false,
    };
  } catch (error) {
    // Some iOS camera stacks report NotReadable while the previous lens is
    // still held. Reacquire only for this device-busy error; NotAllowedError
    // is never retried here and cannot be bypassed.
    if (cameraErrorName(error) !== "NotReadableError") throw error;
    stopStream(previousStream);
    onPreviousStreamStopped();
    return {
      stream: await requestCameraStream(runtime, facingMode),
      previousStreamStopped: true,
    };
  }
}

export function cameraDimensions(
  videoWidth: number,
  videoHeight: number,
  maxLongEdge = CAMERA_MAX_LONG_EDGE
) {
  if (
    !Number.isFinite(videoWidth) ||
    !Number.isFinite(videoHeight) ||
    videoWidth <= 0 ||
    videoHeight <= 0
  ) {
    return null;
  }
  const scale = Math.min(1, maxLongEdge / Math.max(videoWidth, videoHeight));
  return {
    width: Math.max(1, Math.round(videoWidth * scale)),
    height: Math.max(1, Math.round(videoHeight * scale)),
  };
}

/** Capture only the current video element view; this never starts a recorder or uploads anything. */
export function captureCameraFrame(
  video: Pick<HTMLVideoElement, "videoWidth" | "videoHeight" | "readyState">,
  createCanvas: () => CameraCanvas
): CameraFrame | null {
  if (typeof video.readyState === "number" && video.readyState < 2) return null;
  const dimensions = cameraDimensions(video.videoWidth, video.videoHeight);
  if (!dimensions) return null;

  const canvas = createCanvas();
  canvas.width = dimensions.width;
  canvas.height = dimensions.height;
  canvas.drawImage(
    video as HTMLVideoElement,
    0,
    0,
    dimensions.width,
    dimensions.height
  );
  return {
    dataUrl: canvas.toDataURL(CAMERA_FRAME_MIME_TYPE, CAMERA_JPEG_QUALITY),
    mimeType: CAMERA_FRAME_MIME_TYPE,
    name: CAMERA_FRAME_NAME,
  };
}

function stopStream(stream: MediaStream | null) {
  stream?.getTracks().forEach(track => track.stop());
}

function cameraError(error: unknown, switching = false) {
  const name = cameraErrorName(error);
  if (name === "NotAllowedError" || name === "SecurityError") {
    return switching
      ? "Camera permission was denied while switching. Allow camera access in your browser settings, then try again."
      : "Camera permission was denied. Allow camera access in your browser settings, then try Open video call again. Your voice call can continue.";
  }
  if (name === "NotFoundError" || name === "DevicesNotFoundError") {
    return "No camera was found. Connect a camera, then try Open video call again. Your voice call can continue.";
  }
  return switching
    ? "The camera could not switch. Check your camera connection and try again."
    : error instanceof Error
      ? error.message
      : "The camera could not start. Check camera permission and try again. Your voice call can continue.";
}

function cameraErrorWithCapabilities(
  error: unknown,
  capabilities: CameraCapabilities | undefined,
  switching = false
) {
  const name = cameraErrorName(error);
  if (
    !switching &&
    (name === "NotAllowedError" || name === "SecurityError") &&
    capabilities?.embedded
  ) {
    return "This embedded browser denied camera access. Open the full Adus page in Safari, review camera permissions for the site, then try again. Your voice call can continue.";
  }
  return cameraError(error, switching);
}

export class CameraCallController {
  private state: CameraState = { ...initialCameraState };
  private request = 0;
  private stream: MediaStream | null = null;
  private preview: HTMLVideoElement | null = null;

  constructor(
    private options: {
      runtime: CameraRuntime;
      onChange: (state: CameraState) => void;
    }
  ) {}

  get snapshot() {
    return { ...this.state };
  }

  attachPreview(video: HTMLVideoElement | null) {
    this.preview = video;
    if (!video) return;
    // Re-apply these as properties because iOS may attach the ref before the
    // stream arrives and ignore a later attribute-only update.
    video.muted = true;
    video.playsInline = true;
    video.autoplay = true;
    video.srcObject = this.stream;
    if (this.stream) void video.play().catch(() => undefined);
  }

  private update(patch: Partial<CameraState>) {
    this.state = { ...this.state, ...patch };
    this.options.onChange(this.snapshot);
    if (this.preview) {
      this.preview.muted = true;
      this.preview.playsInline = true;
      this.preview.autoplay = true;
      this.preview.srcObject = this.stream;
      if (this.stream) void this.preview.play().catch(() => undefined);
    }
  }

  async start(facingMode: CameraFacingMode = this.state.facingMode) {
    if (this.state.active || this.state.pending) {
      if (this.state.active) this.attachPreview(this.preview);
      return;
    }
    const token = ++this.request;
    this.update({
      pending: true,
      error: undefined,
      status: "Requesting camera access…",
      facingMode,
    });
    const capabilities = this.options.runtime.getCapabilities?.();
    if (capabilities && !capabilities.canRequest) {
      this.update({
        active: false,
        pending: false,
        status: "Camera unavailable",
        error: cameraCapabilityMessage(capabilities),
      });
      return;
    }
    try {
      // Camera and microphone are intentionally separate: this request is video-only.
      const nextStream = await requestCameraStream(
        this.options.runtime,
        facingMode
      );
      if (token !== this.request) {
        stopStream(nextStream);
        return;
      }
      this.stream = nextStream;
      this.update({
        active: true,
        pending: false,
        facingMode,
        status: "Camera on",
        error: undefined,
      });
    } catch (error) {
      if (token !== this.request) return;
      this.update({
        active: false,
        pending: false,
        status: "Camera off",
        error: cameraErrorWithCapabilities(error, capabilities),
      });
    }
  }

  async switchCamera() {
    if (!this.state.active || this.state.pending) return;
    const currentStream = this.stream;
    if (!currentStream) return;
    const nextFacingMode: CameraFacingMode =
      this.state.facingMode === "user" ? "environment" : "user";
    const token = ++this.request;
    const previousStream = currentStream;
    this.update({
      pending: true,
      error: undefined,
      status: "Switching camera…",
    });
    const capabilities = this.options.runtime.getCapabilities?.();
    if (capabilities && !capabilities.canRequest) {
      this.update({
        pending: false,
        status: "Camera on",
        error: cameraCapabilityMessage(capabilities),
      });
      return;
    }
    let previousStreamStopped = false;
    try {
      const switched = await requestSwitchCameraStream(
        this.options.runtime,
        nextFacingMode,
        previousStream,
        () => {
          previousStreamStopped = true;
        }
      );
      previousStreamStopped = switched.previousStreamStopped;
      const nextStream = switched.stream;
      if (token !== this.request) {
        stopStream(nextStream);
        return;
      }
      this.stream = nextStream;
      if (!previousStreamStopped) stopStream(previousStream);
      this.update({
        active: true,
        pending: false,
        facingMode: nextFacingMode,
        status: "Camera on",
        error: undefined,
      });
    } catch (error) {
      if (token !== this.request) return;
      if (previousStreamStopped) this.stream = null;
      // Keep the working camera stream if only the alternate lens was denied.
      this.update({
        active: Boolean(this.stream),
        pending: false,
        status: this.stream ? "Camera on" : "Camera off",
        error: cameraErrorWithCapabilities(error, capabilities, true),
      });
    }
  }

  captureFrame() {
    if (!this.state.active || !this.preview) return null;
    return captureCameraFrame(this.preview, this.options.runtime.createCanvas);
  }

  stop() {
    ++this.request;
    stopStream(this.stream);
    this.stream = null;
    if (this.preview) this.preview.srcObject = null;
    this.state = {
      ...this.state,
      active: false,
      pending: false,
      status: "Camera off",
      error: undefined,
    };
    this.options.onChange(this.snapshot);
  }
}
