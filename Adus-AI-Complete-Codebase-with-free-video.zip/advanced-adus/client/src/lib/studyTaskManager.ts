import { useSyncExternalStore } from "react";
import { accountStorageKey } from "./workspaceAccount";
import type { Attachment } from "./attachments";
import type { LanguageSelection } from "@shared/languages";

export type StudyTaskMode = "summary" | "video";
export type StudyTaskState =
  | "idle"
  | "running"
  | "paused"
  | "completed"
  | "failed";

export type StudyTask = {
  mode: StudyTaskMode;
  state: StudyTaskState;
  phase: string;
  progress: number;
  courseId?: string;
  pdfUrl?: string;
  error?: string;
  updatedAt: number;
};

export type StudyTaskRequest = {
  mode: StudyTaskMode;
  taskId?: string;
  language: LanguageSelection;
  files?: Attachment[];
  courseId?: string;
};

type Listener = () => void;
const listeners = new Set<Listener>();
const memory = new Map<string, StudyTask>();
const requests = new Map<StudyTaskMode, StudyTaskRequest>();

function key(mode: StudyTaskMode) {
  return accountStorageKey(`study-task:${mode}`);
}

function requestKey(mode: StudyTaskMode) {
  return accountStorageKey(`study-request:${mode}`);
}

function notify() {
  listeners.forEach(listener => listener());
}

function read(mode: StudyTaskMode): StudyTask | null {
  const storageKey = key(mode);
  if (!storageKey) return memory.get(mode) ?? null;
  const cached = memory.get(storageKey);
  if (cached) return cached;
  try {
    const raw = window.localStorage.getItem(storageKey);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<StudyTask>;
    if (
      parsed.mode !== mode ||
      typeof parsed.phase !== "string" ||
      typeof parsed.progress !== "number" ||
      typeof parsed.updatedAt !== "number"
    )
      return null;
    const task = parsed as StudyTask;
    memory.set(storageKey, task);
    return task;
  } catch {
    return null;
  }
}

function write(mode: StudyTaskMode, task: StudyTask) {
  const storageKey = key(mode);
  if (storageKey) {
    memory.set(storageKey, task);
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(task));
    } catch {
      // Progress remains in memory when a browser blocks or fills localStorage.
    }
  } else memory.set(mode, task);
  notify();
}

function readRequest(mode: StudyTaskMode) {
  const cached = requests.get(mode);
  if (cached) return cached;
  const storageKey = requestKey(mode);
  if (!storageKey) return undefined;
  try {
    const raw = window.localStorage.getItem(storageKey);
    if (!raw) return undefined;
    const parsed = JSON.parse(raw) as StudyTaskRequest;
    if (parsed.mode !== mode || typeof parsed.language !== "string")
      return undefined;
    parsed.taskId ??= `restored-${parsed.courseId ?? mode}`;
    requests.set(mode, parsed);
    return parsed;
  } catch {
    return undefined;
  }
}

function persistRequest(request: StudyTaskRequest) {
  requests.set(request.mode, request);
  const storageKey = requestKey(request.mode);
  if (!storageKey) return;
  try {
    window.localStorage.setItem(storageKey, JSON.stringify(request));
  } catch {
    // Large source files may exceed browser storage; server-saved courses still recover.
  }
}

function removeRequest(mode: StudyTaskMode) {
  requests.delete(mode);
  const storageKey = requestKey(mode);
  if (storageKey) {
    try {
      window.localStorage.removeItem(storageKey);
    } catch {}
  }
}

export const studyTaskManager = {
  get(mode: StudyTaskMode) {
    return read(mode);
  },
  getRequest(mode: StudyTaskMode) {
    return readRequest(mode);
  },
  updateRequest(mode: StudyTaskMode, patch: Partial<StudyTaskRequest>) {
    const current = readRequest(mode);
    if (!current) return;
    persistRequest({ ...current, ...patch, mode });
  },
  enqueue(request: StudyTaskRequest) {
    request = {
      ...request,
      taskId:
        globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`,
    };
    persistRequest(request);
    write(request.mode, {
      mode: request.mode,
      state: "running",
      phase: request.courseId
        ? "Resuming saved work…"
        : "Opening your uploads…",
      progress: 0,
      ...(request.courseId ? { courseId: request.courseId } : {}),
      updatedAt: Date.now(),
    });
  },
  start(mode: StudyTaskMode, courseId?: string) {
    studyTaskManager.enqueue({
      mode,
      language: "english",
      ...(courseId ? { courseId } : {}),
    });
  },
  update(
    mode: StudyTaskMode,
    patch: Partial<Omit<StudyTask, "mode" | "updatedAt">>
  ) {
    const previous = read(mode);
    write(mode, {
      mode,
      state: previous?.state ?? "running",
      phase: previous?.phase ?? "Working…",
      progress: previous?.progress ?? 0,
      ...previous,
      ...patch,
      updatedAt: Date.now(),
    });
  },
  pause(mode: StudyTaskMode, phase = "Paused. Completed work is saved.") {
    studyTaskManager.update(mode, { state: "paused", phase });
  },
  complete(mode: StudyTaskMode, phase = "Complete") {
    removeRequest(mode);
    studyTaskManager.update(mode, { state: "completed", phase, progress: 1 });
  },
  fail(
    mode: StudyTaskMode,
    error: string,
    phase = "Paused at the failed step."
  ) {
    removeRequest(mode);
    studyTaskManager.update(mode, { state: "failed", phase, error });
  },
  clear(mode?: StudyTaskMode) {
    const modes: StudyTaskMode[] = mode ? [mode] : ["summary", "video"];
    modes.forEach(current => {
      removeRequest(current);
      const storageKey = key(current);
      if (storageKey) {
        memory.delete(storageKey);
        try {
          window.localStorage.removeItem(storageKey);
        } catch {}
      } else memory.delete(current);
    });
    notify();
  },
};

export function subscribeStudyTasks(listener: Listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function useStudyTask(mode: StudyTaskMode) {
  return useSyncExternalStore(
    subscribeStudyTasks,
    () => studyTaskManager.get(mode),
    () => null
  );
}

if (typeof window !== "undefined") {
  window.addEventListener("adus:account", () => {
    memory.clear();
    requests.clear();
    notify();
  });
}
