import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  areaForPath,
  getNavigationState,
  publishNavigation,
  subscribeNavigation,
} from "./navigationLifecycle";
import { studyTaskManager } from "./studyTaskManager";

beforeEach(() => {
  studyTaskManager.clear();
  publishNavigation("/");
  vi.restoreAllMocks();
});

describe("workspace navigation lifecycle", () => {
  it("maps chat, study, media, build, and dynamic extension routes", () => {
    expect(areaForPath("/")).toBe("home");
    expect(areaForPath("/chat")).toBe("home");
    expect(areaForPath("/studying")).toBe("studying");
    expect(areaForPath("/videos")).toBe("videos");
    expect(areaForPath("/build?brief=hello")).toBe("build");
    expect(areaForPath("/workspace/my-notes")).toBe("workspace");
    expect(areaForPath("/unknown")).toBe("not-found");
  });

  it("publishes active route changes without requiring page remounts", () => {
    const listener = vi.fn();
    const unsubscribe = subscribeNavigation(listener);
    publishNavigation("/studying");
    publishNavigation("/chat");
    unsubscribe();
    publishNavigation("/videos");

    expect(listener).toHaveBeenCalledTimes(2);
    expect(getNavigationState()).toMatchObject({
      path: "/videos",
      area: "videos",
      active: true,
    });
  });
});

describe("app-scoped study task lifecycle", () => {
  it("retains progress while the study page is hidden and completes later", () => {
    studyTaskManager.enqueue({ mode: "summary", language: "english", courseId: "course-1" });
    studyTaskManager.update("summary", {
      phase: "Reading section 2/4",
      progress: 0.5,
    });

    expect(studyTaskManager.get("summary")).toMatchObject({
      state: "running",
      courseId: "course-1",
      progress: 0.5,
    });

    studyTaskManager.complete("summary", "Your summary and PDF are ready.");
    expect(studyTaskManager.get("summary")).toMatchObject({
      state: "completed",
      progress: 1,
      phase: "Your summary and PDF are ready.",
    });
    expect(studyTaskManager.getRequest("summary")).toBeUndefined();
  });

  it("pauses without losing the saved course id so return can resume", () => {
    studyTaskManager.enqueue({ mode: "video", language: "french", courseId: "course-2" });
    studyTaskManager.update("video", { progress: 0.25, phase: "Narrating 1/4" });
    studyTaskManager.pause("video");

    expect(studyTaskManager.get("video")).toMatchObject({
      state: "paused",
      progress: 0.25,
      courseId: "course-2",
    });
    expect(studyTaskManager.getRequest("video")).toMatchObject({
      mode: "video",
      courseId: "course-2",
    });
  });
});
