import { beforeEach, describe, expect, it } from "vitest";
import {
  clearLegacyWebsiteBrief,
  initialWebsiteBrief,
  LEGACY_SEEDED_WEBSITE_BRIEF,
  websiteArtifactStore,
} from "./websiteArtifactStore";
import { setWorkspaceAccount } from "./workspaceAccount";

function installLocalStorage() {
  const values = new Map<string, string>();
  const localStorage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
    clear: () => values.clear(),
    key: (index: number) => Array.from(values.keys())[index] ?? null,
    get length() {
      return values.size;
    },
  };
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: {
      localStorage,
      dispatchEvent: () => true,
      addEventListener: () => undefined,
    },
  });
  return localStorage;
}

describe("website brief initialization and persistence", () => {
  beforeEach(() => {
    installLocalStorage();
    setWorkspaceAccount(null);
  });

  it("starts blank for a new workspace instead of using a brand seed", () => {
    expect(initialWebsiteBrief(null, {})).toBe("");
  });

  it("keeps an explicit routed brief, including an explicitly empty query", () => {
    expect(initialWebsiteBrief("Build a bakery site", {})).toBe(
      "Build a bakery site"
    );
    expect(initialWebsiteBrief("", { brief: "My saved site" })).toBe("");
  });

  it("keeps a user's custom persisted brief", () => {
    expect(initialWebsiteBrief(null, { brief: "My saved site" })).toBe(
      "My saved site"
    );
  });

  it("removes only the exact legacy seed and preserves previews and published drafts", () => {
    const artifact = {
      id: "artifact-1",
      title: "My site",
      summary: "A custom site",
      html: "<html></html>",
    };
    const deployment = {
      id: "deployment-1",
      host: "netlify" as const,
      state: "published" as const,
      url: "https://example.test",
    };
    expect(
      clearLegacyWebsiteBrief({
        brief: LEGACY_SEEDED_WEBSITE_BRIEF,
        artifact,
        deployment,
      })
    ).toEqual({ artifact, deployment });
    expect(clearLegacyWebsiteBrief({ brief: "A user-created brief" })).toEqual({
      brief: "A user-created brief",
    });
  });

  it("clears the legacy seed from one account without leaking data to another", () => {
    const localStorage = installLocalStorage();
    setWorkspaceAccount("account-a");
    localStorage.setItem(
      "adus:website-workspace:account-a",
      JSON.stringify({
        brief: LEGACY_SEEDED_WEBSITE_BRIEF,
        artifact: {
          id: "a-artifact",
          title: "Account A",
          summary: "A",
          html: "<html></html>",
        },
        deployment: { id: "a-deployment", state: "published" },
      })
    );
    expect(websiteArtifactStore.get()).toMatchObject({
      artifact: { id: "a-artifact" },
      deployment: { id: "a-deployment" },
    });
    expect(websiteArtifactStore.get().brief).toBeUndefined();
    expect(
      JSON.parse(localStorage.getItem("adus:website-workspace:account-a")!)
    ).toEqual(expect.objectContaining({ artifact: expect.any(Object) }));

    setWorkspaceAccount("account-b");
    expect(websiteArtifactStore.get()).toEqual({});
    websiteArtifactStore.patch({ brief: "Account B's site" });
    setWorkspaceAccount("account-a");
    expect(websiteArtifactStore.get()).toMatchObject({
      artifact: { id: "a-artifact" },
    });
    expect(websiteArtifactStore.get().brief).toBeUndefined();
    setWorkspaceAccount("account-b");
    expect(websiteArtifactStore.get()).toEqual({ brief: "Account B's site" });
  });
});
