export type Attachment = {
  name: string;
  mimeType: string;
  dataUrl: string;
  textContent?: string;
};
export const MAX_FILES = 5;
export const MAX_TOTAL_BYTES = 18 * 1024 * 1024;
export async function readFiles(files: File[]): Promise<Attachment[]> {
  if (files.length > MAX_FILES)
    throw new Error("Choose up to 5 files at a time.");
  if (files.some(file => file.size > 8 * 1024 * 1024))
    throw new Error("Each file must be smaller than 8 MB.");
  if (files.reduce((sum, file) => sum + file.size, 0) > MAX_TOTAL_BYTES)
    throw new Error("Combined uploads must be smaller than 18 MB.");
  const extensions: Record<string, string> = {
    pdf: "application/pdf",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    txt: "text/plain",
    md: "text/markdown",
    csv: "text/csv",
    json: "application/json",
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    webp: "image/webp",
    gif: "image/gif",
    mp3: "audio/mpeg",
    wav: "audio/wav",
    mp4: "video/mp4",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    xls: "application/vnd.ms-excel",
  };
  return Promise.all(
    files.map(async file => {
      const mimeType =
        file.type ||
        extensions[file.name.split(".").at(-1)?.toLowerCase() ?? ""] ||
        "application/octet-stream";
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () =>
          reject(new Error(`Could not read ${file.name}.`));
        reader.readAsDataURL(file);
      });
      return {
        name: file.name,
        mimeType,
        dataUrl,
        textContent:
          mimeType.startsWith("text/") ||
          /\.(json|csv|md|txt)$/i.test(file.name)
            ? (await file.text()).slice(0, 200000)
            : undefined,
      };
    })
  );
}
