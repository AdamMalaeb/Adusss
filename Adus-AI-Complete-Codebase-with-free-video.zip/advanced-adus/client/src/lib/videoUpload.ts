import { COOKIE_NAME } from "@shared/const";

export const MAX_SOURCE_BYTES = 80 * 1024 * 1024;

const VIDEO_MIME_TYPES = new Set([
  "video/mp4",
  "video/quicktime",
  "video/webm",
  "video/x-m4v",
  "video/m4v",
  "video/mov",
  "video/x-webm",
]);
const VIDEO_EXTENSIONS = /\.(mp4|mov|m4v|webm)$/i;

export function isLikelyVideoFile(file: File): boolean {
  const mime = file.type.split(";", 1)[0].trim().toLowerCase();
  return !mime || mime.startsWith("video/") || VIDEO_MIME_TYPES.has(mime) || VIDEO_EXTENSIONS.test(file.name);
}

export function validateVideoFileSelection(file: File): string | null {
  if (!file.size) return "Choose a non-empty MP4, MOV, M4V, or WEBM video.";
  if (file.size > MAX_SOURCE_BYTES) return "Source videos must be 80 MB or smaller.";
  if (!isLikelyVideoFile(file)) return "Choose an MP4, MOV, M4V, or WEBM video.";
  return null;
}

function previewAuthorization(): Record<string, string> {
  try {
    const raw = sessionStorage.getItem("manus-cookie");
    const prefix = `${COOKIE_NAME}=`;
    const pair = raw?.split(";").find(value => value.trim().startsWith(prefix));
    const token = pair?.trim().slice(prefix.length);
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
}

export async function uploadVideoFile(file: File): Promise<unknown> {
  const selectedError = validateVideoFileSelection(file);
  if (selectedError) throw new Error(selectedError);
  const body = new FormData();
  body.append("file", file, file.name);
  const response = await fetch("/api/videos/upload", {
    method: "POST",
    body,
    credentials: "include",
    headers: previewAuthorization(),
  });
  const payload = (await response.json().catch(() => ({}))) as {
    error?: string;
  };
  if (!response.ok)
    throw new Error(payload.error || `Video upload failed (HTTP ${response.status}).`);
  return payload;
}
