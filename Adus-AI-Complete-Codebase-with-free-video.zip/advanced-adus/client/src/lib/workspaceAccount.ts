import { useSyncExternalStore } from "react";

export const WORKSPACE_ACCOUNT_EVENT = "adus:account" as const;

type Listener = () => void;

let accountId: string | null = null;
const listeners = new Set<Listener>();

function notify() {
  listeners.forEach(listener => listener());
}

export function setWorkspaceAccount(next: string | null) {
  const normalized = next?.trim() || null;
  if (normalized === accountId) return;
  accountId = normalized;
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent(WORKSPACE_ACCOUNT_EVENT, { detail: normalized })
    );
  }
  notify();
}

export function getWorkspaceAccount() {
  return accountId;
}

export function subscribeWorkspaceAccount(listener: Listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function useWorkspaceAccount() {
  return useSyncExternalStore(
    subscribeWorkspaceAccount,
    getWorkspaceAccount,
    getWorkspaceAccount
  );
}

/** Local storage keys are deliberately namespaced by the authenticated account. */
export function accountStorageKey(namespace: string, id = accountId) {
  return id ? `adus:${namespace}:${id}` : null;
}
