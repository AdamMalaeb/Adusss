import { browserVoiceRuntime } from "./voiceCall";
import { baseAudioMimeType } from "@shared/speechCapture";
export class DictationController {
  private recorder: MediaRecorder | null = null;
  private stream: MediaStream | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private token = 0;
  private busy = false;
  constructor(
    private options: {
      transcribe: (
        blob: Blob,
        recognitionContext?: string
      ) => Promise<{ text: string; error?: string }>;
      onText: (text: string) => void;
      onStatus: (status: string) => void;
      /** Non-authoritative vocabulary hint; never a transcript replacement. */
      recognitionContext?: () => string | undefined;
    }
  ) {}
  get recording() {
    return this.recorder?.state === "recording";
  }
  async toggle() {
    if (this.recording) {
      this.recorder?.stop();
      return;
    }
    if (this.busy) return;
    const token = ++this.token;
    this.busy = true;
    this.options.onStatus("Allow microphone access for dictation…");
    try {
      const runtime = browserVoiceRuntime();
      const stream = await runtime.getUserMedia();
      if (token !== this.token) {
        stream.getTracks().forEach(t => t.stop());
        return;
      }
      this.stream = stream;
      const recorder = runtime.makeRecorder(stream);
      this.recorder = recorder;
      const chunks: Blob[] = [];
      recorder.ondataavailable = e => {
        if (e.data.size) chunks.push(e.data);
      };
      recorder.onerror = () => {
        this.stop();
        this.options.onStatus(
          "Dictation failed. Check microphone access or type your message."
        );
      };
      recorder.onstop = async () => {
        this.releaseStream();
        this.recorder = null;
        if (token !== this.token) return;
        this.options.onStatus("Transcribing in your original language…");
        try {
          const result = await this.options.transcribe(
            new Blob(chunks, {
              // Preserve the recorder's actual container and codec metadata.
              // The server separately normalizes codec parameters for upload.
              type: recorder.mimeType || baseAudioMimeType("audio/webm"),
            }),
            this.options.recognitionContext?.()
          );
          if (token !== this.token) return;
          if (result.error) throw new Error(result.error);
          if (result.text.trim()) this.options.onText(result.text.trim());
          this.options.onStatus(
            result.text.trim() ? "" : "No speech detected. Try again."
          );
        } catch (e) {
          if (token === this.token)
            this.options.onStatus(
              e instanceof Error
                ? e.message
                : "Dictation could not finish. Try again."
            );
        } finally {
          if (token === this.token) this.busy = false;
        }
      };
      // Small timeslices make the first/last audio chunk observable on iOS
      // while onstop still emits the final complete container header.
      recorder.start(250);
      this.options.onStatus(
        "Listening in any supported language… tap the microphone to finish."
      );
      this.timer = setTimeout(() => {
        if (recorder.state === "recording") recorder.stop();
      }, 12000);
    } catch (e) {
      if (token !== this.token) return;
      this.releaseStream();
      this.busy = false;
      this.options.onStatus(
        e instanceof Error
          ? e.message
          : "Allow microphone access and try again."
      );
    }
  }
  private releaseStream() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.stream?.getTracks().forEach(t => t.stop());
    this.stream = null;
  }
  stop() {
    ++this.token;
    if (this.recorder) {
      this.recorder.onstop = null;
      this.recorder.ondataavailable = null;
      if (this.recorder.state === "recording") this.recorder.stop();
    }
    this.recorder = null;
    this.busy = false;
    this.releaseStream();
  }
}
