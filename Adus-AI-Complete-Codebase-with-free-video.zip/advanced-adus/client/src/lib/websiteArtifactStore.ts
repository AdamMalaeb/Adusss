import { useSyncExternalStore } from "react";
import { accountStorageKey } from "./workspaceAccount";

export type SavedWebsiteArtifact = {
  id: string;
  title: string;
  summary: string;
  html: string;
};

export type SavedDeployment = {
  id: string;
  host?: "netlify" | "github" | "vercel" | "other";
  state: "processing" | "published" | "failed";
  url?: string;
};

export type WebsiteWorkspaceState = {
  brief?: string;
  artifact?: SavedWebsiteArtifact | null;
  deployment?: SavedDeployment | null;
};

type Listener = () => void;
const listeners = new Set<Listener>();
const EMPTY_STATE: WebsiteWorkspaceState = {};
const memory = new Map<string, WebsiteWorkspaceState>();

/**
 * The only brand-specific brief ever seeded by the builder. This remains an
 * exact-match migration value, not a new default.
 */
export const LEGACY_SEEDED_WEBSITE_BRIEF =
  "Create a premium, mobile-first website for Safferni Tours. Use deep navy, royal blue, white, and gold. Include a hero section, visa assistance services, travel offers, trust points, contact CTA, and phone numbers 81 97 70 98 and 81 01 87 37 with email Saffernitours@gmail.com.";

/** Remove only the legacy seeded brief; saved previews and deployments remain intact. */
export function clearLegacyWebsiteBrief(
  state: WebsiteWorkspaceState
): WebsiteWorkspaceState {
  if (state.brief !== LEGACY_SEEDED_WEBSITE_BRIEF) return state;
  const { brief: _legacyBrief, ...preserved } = state;
  return preserved;
}

/** Resolve a first brief without inventing a brand or overwriting a routed query. */
export function initialWebsiteBrief(
  queryBrief: string | null,
  workspace: WebsiteWorkspaceState
): string {
  if (queryBrief !== null) return queryBrief;
  return clearLegacyWebsiteBrief(workspace).brief ?? "";
}

function storageKey() {
  return accountStorageKey("website-workspace");
}

function notify() {
  listeners.forEach(listener => listener());
}

function readState(): WebsiteWorkspaceState {
  const key = storageKey();
  if (!key) return memory.get("anonymous") ?? EMPTY_STATE;
  const cached = memory.get(key);
  if (cached) return cached;
  try {
    const raw = window.localStorage.getItem(key);
    const parsed = raw ? (JSON.parse(raw) as WebsiteWorkspaceState) : {};
    const migrated = clearLegacyWebsiteBrief(parsed);
    memory.set(key, migrated);
    if (migrated !== parsed) {
      try {
        window.localStorage.setItem(key, JSON.stringify(migrated));
      } catch {
        // The in-memory migration still prevents the legacy brief from rendering.
      }
    }
    return migrated;
  } catch {
    return EMPTY_STATE;
  }
}

function persist(next: WebsiteWorkspaceState) {
  const key = storageKey() ?? "anonymous";
  const migrated = clearLegacyWebsiteBrief(next);
  memory.set(key, migrated);
  if (storageKey()) {
    try {
      window.localStorage.setItem(key, JSON.stringify(migrated));
    } catch {
      // HTML remains available in memory if a browser blocks or fills storage.
    }
  }
  notify();
}

export const websiteArtifactStore = {
  get() {
    return readState();
  },
  patch(patch: WebsiteWorkspaceState) {
    persist({ ...readState(), ...patch });
  },
  clear() {
    const key = storageKey();
    memory.delete(key ?? "anonymous");
    if (key) {
      try {
        window.localStorage.removeItem(key);
      } catch {}
    }
    notify();
  },
};

export function subscribeWebsiteArtifact(listener: Listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function useWebsiteWorkspace() {
  return useSyncExternalStore<WebsiteWorkspaceState>(
    subscribeWebsiteArtifact,
    () => websiteArtifactStore.get(),
    () => EMPTY_STATE
  );
}

if (typeof window !== "undefined") {
  window.addEventListener("adus:account", () => {
    memory.clear();
    notify();
  });
}
