import {
  matchDetectedLanguage,
  type LanguageSelection,
} from "@shared/languages";
import { selectSpeechRecordingMimeType } from "@shared/speechCapture";

export type VoicePhase =
  | "idle"
  | "starting"
  | "listening"
  | "transcribing"
  | "thinking"
  | "speaking"
  | "muted"
  | "error";
export type VoiceTurn = { role: "user" | "assistant"; content: string };
export type VoiceState = {
  active: boolean;
  muted: boolean;
  phase: VoicePhase;
  status: string;
  canReplay: boolean;
};
export type VoiceLanguage = "auto" | LanguageSelection;
export type VoiceTranscriptionResult = {
  text: string;
  error?: string;
  /** Whisper may return either an ISO code or a full name such as "french". */
  language?: string;
};
export type VoiceAudio = {
  currentTime: number;
  onplay: ((event: Event) => unknown) | null;
  onended: ((event: Event) => unknown) | null;
  onerror: ((event: Event) => unknown) | null;
  play: () => Promise<void> | void;
  pause: () => void;
};
export type NeuralSpeechResponse = {
  url: string;
  key?: string;
  duration?: number;
};
type Timer = ReturnType<typeof globalThis.setTimeout>;

export const VOICE_VAD = {
  rmsThreshold: 0.018,
  // Keep the recorder open through clipped consonants and short pauses.
  minimumSpeechMs: 320,
  trailingSilenceMs: 1_200,
  maximumTurnMs: 30_000,
  /** Poll more responsively; the conservative trailing pause avoids clipping words. */
  pollIntervalMs: 80,
  /** Avoid an unnecessary quarter-second before the next turn. */
  nextTurnDelayMs: 120,
} as const;

/** Conservative client-side hint; unknown automatic text remains provider-detected. */
export function detectVoiceLanguage(
  text: string
): LanguageSelection | undefined {
  if (/[\u0600-\u06ff]/.test(text)) return "arabic";
  if (
    /\b(bonjour|bonsoir|merci|pourquoi|comment|avec|sans|français|française|est-ce|aider)\b/i.test(
      text
    ) ||
    /(francais|français|bonjour|bonsoir)/i.test(text)
  )
    return "french";
  return undefined;
}

export class SilenceDetector {
  private firstSpeech: number | null = null;
  private lastSpeech: number | null = null;
  constructor(private startedAt: number) {}
  sample(level: number, now: number) {
    if (level > VOICE_VAD.rmsThreshold) {
      this.firstSpeech ??= now;
      this.lastSpeech = now;
    }
    return (
      this.lastSpeech !== null &&
      now - this.lastSpeech >= VOICE_VAD.trailingSilenceMs &&
      now - (this.firstSpeech ?? now) >= VOICE_VAD.minimumSpeechMs
    );
  }
  get heardSpeech() {
    return this.firstSpeech !== null;
  }
  expired(now: number) {
    return now - this.startedAt >= VOICE_VAD.maximumTurnMs;
  }
}

export type VoiceRuntime = {
  getUserMedia: () => Promise<MediaStream>;
  makeRecorder: (stream: MediaStream) => MediaRecorder;
  createAudioContext: () => AudioContext | null;
  synthesis: SpeechSynthesis | null;
  makeUtterance: (text: string) => SpeechSynthesisUtterance;
  createAudio?: (url: string) => VoiceAudio;
  unlockAudio?: () => Promise<void>;
  now: () => number;
};

export function browserVoiceRuntime(): VoiceRuntime {
  // Reuse the element unlocked by the user's gesture. A fresh Audio element
  // per answer loses playback permission on mobile Safari.
  let playback: HTMLAudioElement | null = null;
  const audioElement = () => (playback ??= new Audio());
  return {
    getUserMedia: () => {
      if (!navigator.mediaDevices?.getUserMedia)
        return Promise.reject(
          new Error("Microphone recording is not supported in this browser.")
        );
      return navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    },
    makeRecorder: stream => {
      if (typeof MediaRecorder === "undefined")
        throw new Error("Audio recording is not supported in this browser.");
      const mimeType = selectSpeechRecordingMimeType(type =>
        MediaRecorder.isTypeSupported(type)
      );
      if (mimeType) {
        try {
          return new MediaRecorder(stream, { mimeType });
        } catch {
          // Some Safari builds report a format as supported but reject the
          // constructor. Let the browser choose its native format instead.
        }
      }
      return new MediaRecorder(stream);
    },
    createAudioContext: () => {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      return AudioContextClass ? new AudioContextClass() : null;
    },
    synthesis: window.speechSynthesis ?? null,
    makeUtterance: text => new SpeechSynthesisUtterance(text),
    createAudio: url => {
      const audio = audioElement();
      audio.src = url;
      audio.volume = 1;
      audio.preload = "auto";
      return audio;
    },
    unlockAudio: async () => {
      // A short silent WAV played from the Start Call click makes later fetched
      // neural audio eligible for playback on browsers with strict autoplay.
      const bytes = new Uint8Array(44 + 4800);
      const view = new DataView(bytes.buffer);
      for (const [offset, text] of [
        [0, "RIFF"],
        [8, "WAVE"],
        [12, "fmt "],
        [36, "data"],
      ] as const) {
        text
          .split("")
          .forEach(
            (character, i) => (bytes[offset + i] = character.charCodeAt(0))
          );
      }
      view.setUint32(4, bytes.length - 8, true);
      view.setUint32(16, 16, true);
      view.setUint16(20, 1, true);
      view.setUint16(22, 1, true);
      view.setUint32(24, 24000, true);
      view.setUint32(28, 48000, true);
      view.setUint16(32, 2, true);
      view.setUint16(34, 16, true);
      view.setUint32(40, 4800, true);
      const audio = audioElement();
      audio.src =
        "data:audio/wav;base64," +
        btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join(""));
      audio.volume = 1;
      try {
        await audio.play();
        audio.pause();
        audio.currentTime = 0;
      } catch {
        // The later natural-audio play path reports a precise recovery action.
      }
    },
    now: () => Date.now(),
  };
}

export class VoiceCallController {
  private state: VoiceState = {
    active: false,
    muted: false,
    phase: "idle",
    status: "Ready to call",
    canReplay: false,
  };
  private session = 0;
  private stream: MediaStream | null = null;
  private recorder: MediaRecorder | null = null;
  private detector: SilenceDetector | null = null;
  private context: AudioContext | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private analyser: AnalyserNode | null = null;
  private captureTimer: Timer | null = null;
  private nextTimer: Timer | null = null;
  private speechTimer: Timer | null = null;
  private keepAlive: Timer | null = null;
  private utterance: SpeechSynthesisUtterance | null = null;
  private audio: VoiceAudio | null = null;
  private responsePlaybackPending = false;
  private audioStartTimer: Timer | null = null;
  private pending = false;
  private lastAnswer = "";
  private lastAudioUrl = "";
  private history: VoiceTurn[] = [];
  private gender: "man" | "woman" = "woman";
  private detectedLanguage: LanguageSelection | undefined;
  private waits = new Map<ReturnType<typeof setTimeout>, () => void>();

  constructor(
    private options: {
      runtime: VoiceRuntime;
      onChange: (state: VoiceState) => void;
      transcribe: (
        blob: Blob,
        recognitionContext?: string
      ) => Promise<VoiceTranscriptionResult>;
      reply: (text: string, history: VoiceTurn[]) => Promise<string>;
      synthesize?: (
        text: string,
        gender: "man" | "woman",
        language: VoiceLanguage
      ) => Promise<NeuralSpeechResponse>;
      language?: VoiceLanguage | (() => VoiceLanguage);
      /** False by default: never silently replace a neural voice with browser TTS. */
      allowBrowserFallback?: boolean;
    }
  ) {}

  private bounded<T>(operation: Promise<T>, milliseconds: number): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.waits.delete(timer);
        reject(
          new Error("This call stage timed out. Retry listening to continue.")
        );
      }, milliseconds);
      this.waits.set(timer, () => reject(new Error("Call ended.")));
      operation.then(
        value => {
          clearTimeout(timer);
          this.waits.delete(timer);
          resolve(value);
        },
        error => {
          clearTimeout(timer);
          this.waits.delete(timer);
          reject(error);
        }
      );
    });
  }

  get snapshot() {
    return { ...this.state };
  }
  setGender(gender: "man" | "woman") {
    this.gender = gender;
  }
  private current(token: number) {
    return this.state.active && token === this.session;
  }
  private update(patch: Partial<VoiceState>) {
    this.state = { ...this.state, ...patch };
    this.options.onChange(this.snapshot);
  }
  private microphone(enabled: boolean) {
    this.stream?.getAudioTracks().forEach(track => {
      track.enabled = enabled && !this.state.muted;
    });
  }
  private clearTimer(
    key: "captureTimer" | "nextTimer" | "speechTimer" | "keepAlive"
  ) {
    if (this[key] !== null) globalThis.clearTimeout(this[key]!);
    this[key] = null;
  }
  /** Unlock neural audio from a user gesture without requesting microphone access. */
  preparePlayback() {
    void this.options.runtime.unlockAudio?.();
    void this.context?.resume().catch(() => undefined);
  }
  private disconnectCapture() {
    this.clearTimer("captureTimer");
    this.source?.disconnect();
    this.source = null;
    this.analyser = null;
  }

  async start(initialHistory: VoiceTurn[] = []) {
    if (this.state.active) return;
    const token = ++this.session;
    this.history = initialHistory.slice(-20);
    this.detectedLanguage = undefined;
    this.lastAnswer = "";
    this.lastAudioUrl = "";
    this.update({
      active: true,
      muted: false,
      phase: "starting",
      status: "Starting microphone…",
      canReplay: false,
    });
    // Unlock playback during the user's Start Call gesture, without cancelling later replies.
    const synthesis = this.options.runtime.synthesis;
    if (synthesis) {
      synthesis.cancel();
      const primer = this.options.runtime.makeUtterance("ready");
      primer.volume = 0;
      primer.rate = 8;
      synthesis.speak(primer);
      synthesis.resume();
    }
    void this.options.runtime.unlockAudio?.();
    try {
      this.context = this.options.runtime.createAudioContext();
      void this.context?.resume().catch(() => undefined);
    } catch {
      this.context = null;
    }
    try {
      const stream = await this.options.runtime.getUserMedia();
      if (!this.current(token)) {
        stream.getTracks().forEach(track => track.stop());
        return;
      }
      this.stream = stream;
      this.microphone(!this.state.muted);
      this.listen(token);
    } catch (error) {
      if (!this.current(token)) return;
      this.stop();
      this.update({
        phase: "error",
        status:
          error instanceof Error
            ? error.message
            : "Allow microphone access, then start the call again.",
      });
    }
  }

  setMuted(muted: boolean) {
    if (!this.state.active) return;
    this.update({ muted });
    this.microphone(!muted && this.state.phase === "listening");
    if (muted) {
      this.clearTimer("nextTimer");
      // Finish speech already captured, but never cancel a pending or spoken bot response.
      if (this.recorder?.state === "recording") this.finishTurn(false);
      if (
        !this.pending &&
        !this.responsePlaybackPending &&
        !this.utterance &&
        !this.audio &&
        this.state.phase !== "error"
      )
        this.update({
          phase: "muted",
          status: "Your microphone is muted. You can still hear Adus.",
        });
    } else if (
      !this.pending &&
      !this.responsePlaybackPending &&
      !this.utterance &&
      !this.audio &&
      this.state.phase !== "error"
    ) {
      this.listen(this.session);
    }
  }

  private queueListening(
    token: number,
    delay: number = VOICE_VAD.nextTurnDelayMs
  ) {
    if (!this.current(token)) return;
    if (this.state.muted) {
      this.update({
        phase: "muted",
        status: "Your microphone is muted. You can still hear Adus.",
      });
      return;
    }
    this.clearTimer("nextTimer");
    this.nextTimer = globalThis.setTimeout(() => {
      this.nextTimer = null;
      this.listen(token);
    }, delay);
  }

  private listen(token: number) {
    if (!this.current(token) || this.pending || this.utterance || this.recorder)
      return;
    if (this.state.muted) {
      this.queueListening(token);
      return;
    }
    if (!this.stream) return;
    this.microphone(true);
    this.update({
      phase: "listening",
      status: "Listening… speak naturally",
      canReplay: false,
    });
    const chunks: Blob[] = [];
    let forceSubmit = false;
    let monitored = false;
    let recorder: MediaRecorder;
    try {
      recorder = this.options.runtime.makeRecorder(this.stream);
    } catch {
      this.update({
        phase: "error",
        status:
          "Audio recording could not start. End the call and try another browser.",
      });
      return;
    }
    this.recorder = recorder;
    const detector = new SilenceDetector(this.options.runtime.now());
    this.detector = detector;
    recorder.ondataavailable = event => {
      if (event.data.size > 0) chunks.push(event.data);
    };
    recorder.onerror = () => {
      if (!this.current(token)) return;
      this.disconnectCapture();
      recorder.onstop = null;
      if (recorder.state === "recording") recorder.stop();
      this.recorder = null;
      this.update({
        phase: "error",
        status: "Microphone recording failed. End the call and try again.",
      });
    };
    recorder.onstop = async () => {
      if (this.recorder === recorder) {
        this.recorder = null;
        this.disconnectCapture();
      }
      if (!this.current(token)) return;
      if (
        !chunks.length ||
        (!detector.heardSpeech && !forceSubmit && monitored)
      ) {
        this.queueListening(token);
        return;
      }
      const blob = new Blob(chunks, {
        type: recorder.mimeType || "audio/webm",
      });
      this.pending = true;
      this.microphone(false);
      this.update({ phase: "transcribing", status: "Understanding you…" });
      try {
        const result = await this.bounded(
          this.options.transcribe(blob, this.recognitionContext()),
          60000
        );
        if (!this.current(token)) return;
        if (result.error) {
          this.pending = false;
          // Pause instead of sending endless silent recordings or service retries.
          this.update({ phase: "error", status: result.error });
          return;
        }
        this.detectedLanguage = matchDetectedLanguage(result.language);
        const text = result.text.trim();
        if (!text) {
          this.pending = false;
          this.queueListening(token);
          return;
        }
        // Persist the recognized user turn before waiting on the reply. If the
        // user interrupts thinking or TTS, the next request still remembers
        // exactly what was heard. The router receives only the prior history;
        // it appends `text` once as the current user message.
        const historyForReply = this.history.slice(-28);
        this.history.push({ role: "user", content: text.slice(0, 20000) });
        this.history = this.history.slice(-28);
        this.update({ phase: "thinking", status: "Thinking…" });
        const answer = await this.bounded(
          this.options.reply(text, historyForReply),
          60000
        );
        if (!this.current(token)) return;
        this.history.push({
          role: "assistant",
          content: answer.slice(0, 20000),
        });
        this.history = this.history.slice(-28);
        this.pending = false;
        this.speak(answer, token);
      } catch {
        if (!this.current(token)) return;
        this.pending = false;
        this.update({
          phase: "error",
          status:
            "I couldn’t complete that voice turn. Tap Retry listening to continue.",
        });
      }
    };
    // Store a manual flush on this instance, preserving complete recorder headers.
    this.flush = () => {
      forceSubmit = true;
      if (recorder.state === "recording") recorder.stop();
    };
    try {
      if (this.context) {
        this.source = this.context.createMediaStreamSource(this.stream);
        this.analyser = this.context.createAnalyser();
        this.analyser.fftSize = 512;
        this.source.connect(this.analyser);
        monitored = this.context.state === "running";
      }
    } catch {
      this.disconnectCapture();
    }
    // Periodic chunks reduce the chance that iOS drops a short leading utterance;
    // the final onstop event still contributes the complete container tail.
    recorder.start(250);
    const samples = new Float32Array(512);
    const check = () => {
      if (
        !this.current(token) ||
        this.recorder !== recorder ||
        recorder.state !== "recording"
      )
        return;
      const now = this.options.runtime.now();
      let finished = false;
      if (this.analyser) {
        if (this.context?.state === "running") monitored = true;
        this.analyser.getFloatTimeDomainData(samples);
        const rms = Math.sqrt(
          samples.reduce((total, value) => total + value * value, 0) /
            samples.length
        );
        finished = detector.sample(rms, now);
      }
      if (finished || detector.expired(now)) {
        this.finishTurn(false);
        return;
      }
      this.captureTimer = globalThis.setTimeout(
        check,
        VOICE_VAD.pollIntervalMs
      );
    };
    this.captureTimer = globalThis.setTimeout(check, VOICE_VAD.pollIntervalMs);
  }

  private flush: (() => void) | null = null;
  finishTurn(manual = true) {
    if (this.recorder?.state !== "recording") return;
    this.disconnectCapture();
    if (manual) this.flush?.();
    else this.recorder.stop();
  }
  retryListening() {
    if (
      this.state.active &&
      !this.pending &&
      !this.responsePlaybackPending &&
      !this.utterance &&
      !this.audio
    )
      this.queueListening(this.session, 0);
  }
  replay() {
    if (
      this.state.active &&
      this.lastAnswer &&
      !this.pending &&
      !this.recorder
    ) {
      if (this.lastAudioUrl)
        this.playStoredAudio(this.lastAudioUrl, this.session);
      else void this.speak(this.lastAnswer, this.session);
    }
  }
  /** Explicit opt-in fallback; it is intentionally named so the UI can label it honestly. */
  replayWithBrowserVoice() {
    if (
      this.state.active &&
      this.lastAnswer &&
      !this.pending &&
      !this.recorder
    ) {
      void this.speak(this.lastAnswer, this.session, true);
    }
  }

  private selectedLanguage(text: string): VoiceLanguage {
    const configured =
      typeof this.options.language === "function"
        ? this.options.language()
        : (this.options.language ?? "auto");
    return configured === "auto"
      ? (this.detectedLanguage ?? detectVoiceLanguage(text) ?? "auto")
      : configured;
  }

  /**
   * Non-authoritative spelling context only. The server must never copy this
   * into a transcript unless the words are audible in the recording.
   */
  private recognitionContext() {
    const recentUserTurns = this.history
      .filter(turn => turn.role === "user")
      .slice(-3)
      .map(turn => turn.content.replace(/\s+/g, " ").trim().slice(0, 200))
      .filter(Boolean);
    return recentUserTurns.length
      ? recentUserTurns.join(" | ").slice(0, 600)
      : undefined;
  }

  /**
   * Stop only the current generated response/capture and listen again. The
   * active MediaStream remains open, so this is not an end-call operation.
   * Existing history, language selection, mute state, and camera state are
   * deliberately untouched.
   */
  interrupt() {
    if (!this.state.active) return;

    const nextToken = ++this.session;
    for (const [timer, cancel] of Array.from(this.waits.entries())) {
      clearTimeout(timer);
      cancel();
    }
    this.waits.clear();

    const recorder = this.recorder;
    if (recorder) {
      recorder.onstop = null;
      recorder.onerror = null;
      recorder.ondataavailable = null;
      this.recorder = null;
      if (recorder.state === "recording") recorder.stop();
    }
    this.flush = null;
    this.pending = false;
    this.responsePlaybackPending = false;
    this.utterance = null;
    this.detector = null;
    this.disconnectCapture();
    this.clearTimer("nextTimer");
    this.clearTimer("speechTimer");
    this.clearTimer("keepAlive");
    this.clearAudio();
    this.options.runtime.synthesis?.cancel();

    // microphone() respects the user's mute preference. Camera tracks are not
    // owned by this controller and are never touched by an interruption.
    this.microphone(true);
    if (this.state.muted) {
      this.update({
        phase: "muted",
        status: "Your microphone is muted. You can still hear Adus.",
        canReplay: false,
      });
      return;
    }
    this.update({ phase: "listening", canReplay: false });
    this.listen(nextToken);
  }

  /** Explicit alias for a UI control labelled “Stop response”. */
  stopResponseAndListen() {
    this.interrupt();
  }

  private clearAudio() {
    this.clearTimer("speechTimer");
    if (!this.audio) return;
    this.audio.onplay = null;
    this.audio.onended = null;
    this.audio.onerror = null;
    this.audio.pause();
    this.audio = null;
  }

  private playStoredAudio(url: string, token: number) {
    if (!this.current(token) || !this.options.runtime.createAudio) return;
    this.clearAudio();
    const audio = this.options.runtime.createAudio(url);
    this.audio = audio;
    this.responsePlaybackPending = true;
    this.microphone(false);
    this.update({
      phase: "speaking",
      status: "Adus is answering with a natural voice…",
      canReplay: false,
    });
    const fail = () => {
      if (!this.current(token) || this.audio !== audio) return;
      this.clearAudio();
      this.responsePlaybackPending = false;
      this.update({
        phase: "error",
        status:
          "Natural voice playback was blocked. Replay the answer or choose the clearly labeled browser-voice fallback.",
        canReplay: true,
      });
    };
    audio.onplay = () => {
      if (this.current(token) && this.audio === audio) {
        this.clearTimer("speechTimer");
        this.responsePlaybackPending = false;
        this.update({
          phase: "speaking",
          status: "Adus is answering…",
          canReplay: false,
        });
      }
    };
    audio.onerror = fail;
    audio.onended = () => {
      if (!this.current(token) || this.audio !== audio) return;
      this.clearAudio();
      this.responsePlaybackPending = false;
      this.queueListening(token);
    };
    this.speechTimer = setTimeout(fail, 8000);
    try {
      const result = audio.play();
      if (result && typeof result.catch === "function") void result.catch(fail);
    } catch {
      fail();
    }
  }

  private async speak(text: string, token: number, browserFallback = false) {
    if (!this.current(token)) return;
    const clean = text
      .replace(/[*_`#>\[\]]/g, " ")
      .replace(/https?:\/\/\S+/g, "the linked resource")
      .replace(/\s+/g, " ")
      .trim();
    this.lastAnswer = clean;
    if (!clean) {
      this.update({
        phase: "error",
        status: "The voice service returned an empty answer.",
        canReplay: false,
      });
      return;
    }
    this.microphone(false);
    this.clearAudio();
    this.lastAudioUrl = "";
    const synthesis = this.options.runtime.synthesis;
    if (
      !browserFallback &&
      this.options.synthesize &&
      this.options.runtime.createAudio
    ) {
      this.responsePlaybackPending = true;
      this.update({
        phase: "speaking",
        status: "Preparing a natural voice answer…",
        canReplay: false,
      });
      try {
        const result = await this.bounded(
          this.options.synthesize(
            clean,
            this.gender,
            this.selectedLanguage(clean)
          ),
          135000
        );
        if (!this.current(token)) return;
        if (!result.url)
          throw new Error("Natural speech returned no audio URL.");
        this.lastAudioUrl = result.url;
        this.responsePlaybackPending = false;
        this.playStoredAudio(result.url, token);
      } catch {
        if (!this.current(token)) return;
        this.responsePlaybackPending = false;
        this.update({
          phase: "error",
          status:
            "Natural voice is temporarily unavailable. The answer is ready. Replay to retry natural audio, or explicitly choose browser voice as a fallback.",
          canReplay: true,
        });
      }
      return;
    }
    if (!synthesis) {
      this.update({
        phase: "error",
        status: browserFallback
          ? "Browser voice playback is not supported in this browser."
          : "Natural voice is not configured for this call.",
        canReplay: false,
      });
      return;
    }
    synthesis.cancel();
    synthesis.resume();
    const utterance = this.options.runtime.makeUtterance(clean);
    this.utterance = utterance; // Keep a strong reference until speech finishes.
    const matcher =
      this.gender === "woman"
        ? /female|woman|zira|samantha|victoria|karen|susan|moira|fiona/i
        : /\bmale\b|\bman\b|david|daniel|alex|james|george/i;
    const voices = synthesis.getVoices();
    utterance.voice =
      voices.find(
        voice =>
          voice.lang
            .toLowerCase()
            .startsWith(
              (
                matchDetectedLanguage(this.selectedLanguage(clean)) ??
                navigator.language
              )
                .split("-")[0]
                .toLowerCase()
            ) && matcher.test(voice.name)
      ) ??
      voices.find(voice =>
        voice.lang
          .toLowerCase()
          .startsWith(
            (
              matchDetectedLanguage(this.selectedLanguage(clean)) ??
              navigator.language
            )
              .split("-")[0]
              .toLowerCase()
          )
      ) ??
      null;
    utterance.lang =
      matchDetectedLanguage(this.selectedLanguage(clean)) ?? navigator.language;
    utterance.rate = 0.98;
    utterance.pitch = this.gender === "woman" ? 1.08 : 0.92;
    let started = false;
    const fail = () => {
      if (!this.current(token) || this.utterance !== utterance) return;
      this.utterance = null;
      this.clearTimer("speechTimer");
      this.clearTimer("keepAlive");
      synthesis.cancel();
      this.update({
        phase: "error",
        status: "Browser voice playback was blocked. Try Replay answer again.",
        canReplay: true,
      });
    };
    utterance.onstart = () => {
      if (!this.current(token) || this.utterance !== utterance) return;
      started = true;
      this.clearTimer("speechTimer");
      this.update({
        phase: "speaking",
        status: "Adus is answering…",
        canReplay: false,
      });
    };
    utterance.onerror = fail;
    utterance.onend = () => {
      if (!this.current(token) || this.utterance !== utterance) return;
      this.utterance = null;
      this.clearTimer("speechTimer");
      this.clearTimer("keepAlive");
      this.queueListening(token);
    };
    this.update({
      phase: "speaking",
      status: "Adus is answering…",
      canReplay: false,
    });
    this.speechTimer = globalThis.setTimeout(() => {
      if (!started) fail();
    }, 6000);
    synthesis.speak(utterance);
    const resume = () => {
      if (!this.current(token) || this.utterance !== utterance) return;
      synthesis.resume();
      this.keepAlive = globalThis.setTimeout(resume, 4000);
    };
    this.keepAlive = globalThis.setTimeout(resume, 100);
  }

  stop() {
    ++this.session;
    for (const [timer, cancel] of Array.from(this.waits.entries())) {
      clearTimeout(timer);
      cancel();
    }
    this.waits.clear();
    this.state.active = false;
    this.pending = false;
    this.responsePlaybackPending = false;
    this.utterance = null;
    this.recorder && (this.recorder.onstop = null);
    if (this.recorder?.state === "recording") this.recorder.stop();
    this.recorder = null;
    this.flush = null;
    this.detector = null;
    this.disconnectCapture();
    this.clearTimer("nextTimer");
    this.clearTimer("speechTimer");
    this.clearTimer("keepAlive");
    this.clearAudio();
    this.stream?.getTracks().forEach(track => track.stop());
    this.stream = null;
    void this.context?.close().catch(() => undefined);
    this.context = null;
    this.options.runtime.synthesis?.cancel();
    this.update({
      active: false,
      muted: false,
      phase: "idle",
      status: "Call ended",
      canReplay: false,
    });
  }
}
