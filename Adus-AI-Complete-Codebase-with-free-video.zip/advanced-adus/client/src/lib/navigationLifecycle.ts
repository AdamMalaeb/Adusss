import { useSyncExternalStore } from "react";

export type WorkspaceArea =
  | "home"
  | "studying"
  | "images"
  | "videos"
  | "build"
  | "upgrade"
  | "operations"
  | "workspace"
  | "not-found";

export type NavigationState = {
  path: string;
  area: WorkspaceArea;
  active: boolean;
};

export const NAVIGATION_EVENT = "adus:navigation" as const;

type Listener = () => void;

function initialPath() {
  if (typeof window === "undefined") return "/";
  return `${window.location.pathname}${window.location.search}`;
}

export function areaForPath(path: string): WorkspaceArea {
  const pathname = path.split("?", 1)[0] ?? path;
  if (pathname === "/" || pathname === "/chat") return "home";
  if (pathname === "/studying") return "studying";
  if (pathname === "/images") return "images";
  if (pathname === "/videos") return "videos";
  if (pathname === "/build") return "build";
  if (pathname === "/upgrade") return "upgrade";
  if (pathname === "/operations") return "operations";
  if (pathname.startsWith("/workspace/")) return "workspace";
  return "not-found";
}

function createState(path: string): NavigationState {
  return { path, area: areaForPath(path), active: true };
}

let currentState = createState(initialPath());
const listeners = new Set<Listener>();

function notify() {
  listeners.forEach(listener => listener());
}

export function publishNavigation(path: string) {
  const next = createState(path);
  if (next.path === currentState.path && next.area === currentState.area) return;
  currentState = next;
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent(NAVIGATION_EVENT, { detail: currentState })
    );
  }
  notify();
}

export function getNavigationState() {
  return currentState;
}

export function subscribeNavigation(listener: Listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function useNavigationState() {
  return useSyncExternalStore(
    subscribeNavigation,
    getNavigationState,
    getNavigationState
  );
}

export function usePageActivity(area: WorkspaceArea) {
  return useNavigationState().area === area;
}
