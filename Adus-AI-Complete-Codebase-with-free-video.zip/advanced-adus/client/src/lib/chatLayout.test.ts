import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const css = readFileSync(new URL("../index.css", import.meta.url), "utf8");
const richText = readFileSync(
  new URL("../components/RichText.tsx", import.meta.url),
  "utf8"
);
const conversationHistory = readFileSync(
  new URL("../components/ConversationHistory.tsx", import.meta.url),
  "utf8"
);

describe("chat layout contracts", () => {
  it("keeps hostile-width chat content inside the workspace", () => {
    expect(css).toContain(".adus-chat-workspace");
    expect(css).toContain(".adus-chat-shell");
    expect(css).toContain(".adus-chat-messages");
    expect(css).toContain(".adus-chat-composer");
    expect(css).toContain("overflow-wrap: anywhere");
    expect(css).toContain("word-break: break-word");
    expect(css).toContain("height: calc(100dvh - 170px) !important");
  });

  it("gives markdown wide structures an inner scroll boundary", () => {
    expect(css).toContain(".rich-text-table-wrap");
    expect(css).toContain(".rich-text-code-block");
    expect(css).toContain(".katex-display");
    expect(richText).toContain('className="rich-text-table-wrap"');
    expect(richText).toContain(
      'className={cn("rich-text-code-block", className)}'
    );
  });

  it("keeps the mobile history list collapsed until requested", () => {
    expect(conversationHistory).toContain("aria-expanded={mobileOpen}");
    expect(conversationHistory).toContain('id="mobile-conversation-list"');
    expect(conversationHistory).toContain("hidden lg:block");
  });
});
