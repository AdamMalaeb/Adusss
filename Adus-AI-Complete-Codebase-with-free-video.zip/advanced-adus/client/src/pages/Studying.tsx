import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  BookOpen,
  FileText,
  Film,
  Loader2,
  Pause,
  Play,
  RefreshCw,
  Upload,
  X,
} from "lucide-react";
import WorkspaceShell from "@/components/WorkspaceShell";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  readFiles,
  MAX_FILES,
  MAX_TOTAL_BYTES,
  type Attachment,
} from "@/lib/attachments";
import { trpc } from "@/lib/trpc";
import RichText from "@/components/RichText";
import WhiteboardPlayer from "@/components/WhiteboardPlayer";
import MediaSaveActions from "@/components/MediaSaveActions";
import { LanguageSelect } from "@/components/LanguageSelect";
import { isRtl, type LanguageSelection } from "@shared/languages";
import {
  studyTaskManager,
  useStudyTask,
  type StudyTaskMode,
} from "@/lib/studyTaskManager";

type Language = LanguageSelection;
type Mode = StudyTaskMode;
type Chapter = {
  id: string;
  index: number;
  title: string;
  summary: string;
  sourceLabel: string;
  scenes: Array<{
    title: string;
    bullets: string[];
    narration: string;
    visual?: { kind: string; labels: string[] };
    boardActions?: Array<{
      type: "write" | "draw" | "link" | "highlight" | "erase";
      text?: string;
      target?: string;
      from?: { x: number; y: number };
      to?: { x: number; y: number };
      emphasis?: "normal" | "accent" | "warning";
    }>;
  }>;
  sources: string[];
  warnings: string[];
  audioURL?: string;
  audioDuration?: number;
};
type Course = {
  id: string;
  title: string;
  language: Language;
  mode?: Mode;
  units: Array<{ label: string; source: string; page?: number }>;
  warnings: string[];
  chapters: Chapter[];
};

function StudySection({ mode }: { mode: Mode }) {
  const [files, setFiles] = useState<Attachment[]>([]);
  const [language, setLanguage] = useState<Language>("english");
  const [course, setCourse] = useState<Course | null>(null);
  const [error, setError] = useState("");
  const [active, setActive] = useState(0);
  const [pdfURL, setPdfURL] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const task = useStudyTask(mode);
  const history = trpc.adus.study.courses.useQuery(undefined, {
    retry: false,
    meta: { handledError: true },
  });
  const utils = trpc.useUtils();
  const selected = course?.chapters.find(ch => ch.index === active);
  const covered = course?.chapters.length ?? 0;
  const total = course?.units.length ?? 0;
  const ready = course?.chapters.filter(ch => ch.audioURL).length ?? 0;
  const busy = task?.state === "running";

  useEffect(() => {
    if (!task?.courseId) return;
    let cancelled = false;
    void utils.adus.study.getCourse
      .fetch({ id: task.courseId })
      .then(result => {
        if (!cancelled) {
          setCourse(result as Course);
          setLanguage((result as Course).language);
          setPdfURL(task.pdfUrl ?? "");
          setError("");
        }
      })
      .catch(reason => {
        if (!cancelled)
          setError(
            reason instanceof Error
              ? reason.message
              : "Saved study work could not be loaded yet."
          );
      });
    return () => {
      cancelled = true;
    };
  }, [
    course?.id,
    task?.courseId,
    task?.pdfUrl,
    task?.updatedAt,
    task?.state,
    utils.adus.study.getCourse,
  ]);

  useEffect(() => {
    if (course || !history.data?.length || task?.courseId) return;
    const saved = history.data.find(item => (item.mode ?? "video") === mode);
    if (saved) void open(String(saved.id));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [history.data, mode, task?.courseId]);

  async function choose(picked: File[]) {
    try {
      setError("");
      if (files.length + picked.length > MAX_FILES)
        throw Error("Choose up to five files.");
      if (
        files.reduce(
          (sum, file) => sum + Math.ceil(file.dataUrl.length * 0.75),
          0
        ) +
          picked.reduce((sum, file) => sum + file.size, 0) >
        MAX_TOTAL_BYTES
      )
        throw Error("Combined uploads must be smaller than 18 MB.");
      const added = await readFiles(picked);
      setFiles(old => [...old, ...added]);
    } catch (reason) {
      setError(
        reason instanceof Error ? reason.message : "Could not read the upload."
      );
    }
  }

  async function open(id: string) {
    if (busy) return;
    try {
      const result = (await utils.adus.study.getCourse.fetch({ id })) as Course;
      setCourse(result);
      setLanguage(result.language);
      setPdfURL("");
      setActive(0);
      setError("");
    } catch (reason) {
      setError(
        reason instanceof Error ? reason.message : "Could not load saved work."
      );
    }
  }

  function start() {
    if (busy) return;
    if (files.length) {
      studyTaskManager.enqueue({ mode, language, files });
      setCourse(null);
      setPdfURL("");
      setActive(0);
      setFiles([]);
      return;
    }
    if (course) {
      studyTaskManager.enqueue({
        mode,
        language: course.language,
        courseId: course.id,
      });
      return;
    }
    if (!files.length) return;
    studyTaskManager.enqueue({ mode, language, files });
    setFiles([]);
  }

  function toggleTask() {
    if (busy) {
      studyTaskManager.pause(mode, "Pausing after the current request…");
      return;
    }
    if (task?.courseId) {
      studyTaskManager.enqueue({ mode, language, courseId: task.courseId });
    }
  }

  return (
    <section
      aria-label={
        mode === "summary" ? "Summary workspace" : "Lesson video workspace"
      }
      className="min-w-0 space-y-5"
    >
      <div className="rounded-3xl border border-white/10 bg-[#0e1421] p-4 sm:p-6">
        <h2 className="flex items-center gap-2 text-xl font-bold">
          {mode === "summary" ? (
            <FileText className="text-cyan-200" />
          ) : (
            <Film className="text-violet-200" />
          )}
          {mode === "summary" ? "Generate summary" : "Generate lesson video"}
        </h2>
        <p className="mt-2 text-sm leading-6 text-white/55">
          {mode === "summary"
            ? "Upload material for a detailed summary and PDF. Progress stays active while you visit Chat and returns with your saved output."
            : "Upload lesson material for an animated teacher’s board with natural narration. Chapters appear progressively and remain available after navigation."}
        </p>
        <button
          disabled={busy}
          onClick={() => inputRef.current?.click()}
          onDragOver={event => event.preventDefault()}
          onDrop={event => {
            event.preventDefault();
            if (!busy) void choose(Array.from(event.dataTransfer.files));
          }}
          className="mt-4 flex min-h-28 w-full flex-col items-center justify-center rounded-2xl border border-dashed border-cyan-200/25 bg-[#091424] p-4 disabled:opacity-50"
        >
          <Upload className="mb-2 text-cyan-200" />
          <strong className="text-sm">
            {mode === "summary"
              ? "Add source files for summary"
              : "Add PDF or photos for lesson video"}
          </strong>
          <span className="mt-2 text-xs text-white/45">
            Up to 5 files · 8 MB each · 18 MB total
          </span>
        </button>
        <input
          ref={inputRef}
          type="file"
          hidden
          multiple
          accept={
            mode === "summary"
              ? ".pdf,.docx,.txt,.md,.csv,.json,image/*,video/mp4,audio/mpeg,audio/wav,audio/mp4"
              : ".pdf,.docx,.txt,.md,image/*"
          }
          onChange={event => {
            void choose(Array.from(event.target.files ?? []));
            event.currentTarget.value = "";
          }}
        />
        <div className="mt-3 space-y-2">
          {files.map((file, index) => (
            <div
              key={`${file.name}-${index}`}
              className="flex min-w-0 items-center gap-2 rounded-xl bg-white/5 p-3"
            >
              <span className="min-w-0 flex-1 truncate text-xs">
                {file.name}
              </span>
              <button
                disabled={busy}
                aria-label={`Remove ${file.name}`}
                onClick={() =>
                  setFiles(old => old.filter((_, item) => item !== index))
                }
              >
                <X size={16} />
              </button>
            </div>
          ))}
        </div>
        <label className="mt-4 block text-xs text-white/60">
          {mode === "summary" ? "Summary language" : "Lesson language"}
          <LanguageSelect
            value={language}
            onChange={value => value !== "auto" && setLanguage(value)}
            label="Study language"
            className="mt-2 w-full rounded-xl border border-white/10 bg-[#0b1019] px-3 py-3 text-sm text-white"
          />
        </label>
        <Button
          onClick={start}
          disabled={busy || (!files.length && !task?.courseId && !course)}
          className="mt-4 h-11 w-full rounded-xl bg-cyan-200 font-bold text-slate-950 hover:bg-cyan-100"
        >
          {busy ? (
            <Loader2 size={17} className="mr-2 animate-spin" />
          ) : mode === "summary" ? (
            <BookOpen size={17} className="mr-2" />
          ) : (
            <Film size={17} className="mr-2" />
          )}
          {busy
            ? "Working in the background…"
            : task?.courseId
              ? "Resume saved work"
              : mode === "summary"
                ? "Generate summary"
                : "Generate lesson video"}
        </Button>
      </div>
      {(task || error) && (
        <div
          role="status"
          aria-live="polite"
          className="rounded-2xl border border-cyan-200/20 bg-[#101c2b] p-4"
        >
          <p className="flex gap-2 text-sm leading-6">
            {busy ? (
              <Loader2 size={18} className="mt-1 shrink-0 animate-spin" />
            ) : task?.state === "failed" || error ? (
              <AlertTriangle
                size={18}
                className="mt-1 shrink-0 text-amber-200"
              />
            ) : (
              <Play size={18} className="mt-1 shrink-0 text-cyan-200" />
            )}
            {task?.phase ?? error}
          </p>
          {task?.error && (
            <p className="mt-2 break-words text-xs leading-6 text-amber-200">
              {task.error}
            </p>
          )}
          {error && (
            <p className="mt-2 break-words text-xs leading-6 text-amber-200">
              {error}
            </p>
          )}
          {task?.courseId && (
            <>
              <div
                className="mt-3 h-2 overflow-hidden rounded-full bg-white/10"
                aria-label={`${Math.round(task.progress * 100)} percent complete`}
              >
                <div
                  className="h-full rounded-full bg-cyan-200 transition-[width]"
                  style={{
                    width: `${Math.max(4, Math.min(100, Math.round(task.progress * 100)))}%`,
                  }}
                />
              </div>
              <p className="mt-2 text-xs text-white/50">
                Progress: {Math.round(task.progress * 100)}%
              </p>
              <Button className="mt-3" variant="outline" onClick={toggleTask}>
                {busy ? (
                  <Pause size={14} className="mr-2" />
                ) : (
                  <RefreshCw size={14} className="mr-2" />
                )}
                {busy ? "Pause after this request" : "Resume missing chapters"}
              </Button>
            </>
          )}
        </div>
      )}
      {course && (
        <article
          className="min-w-0 rounded-3xl border border-white/10 bg-[#0e1421] p-4 sm:p-6"
          dir={isRtl(course.language) ? "rtl" : "ltr"}
        >
          <h3 className="text-lg font-semibold">
            {mode === "summary" ? "Your summary" : "Your animated lesson"}
          </h3>
          <p className="mt-2 text-xs leading-6 text-white/50">
            {covered === total
              ? "All source sections read."
              : "Coverage is partial. Resume remaining pages."}{" "}
            {mode === "video"
              ? "The teacher is animated, not filmed. Narration is AI-generated."
              : ""}
          </p>
          {mode === "summary" && covered > 0 && (
            <div className="mt-4">
              {pdfURL || task?.pdfUrl ? (
                <MediaSaveActions
                  src={pdfURL || task?.pdfUrl || ""}
                  filename="adus-study-summary.pdf"
                  openLabel="Open summary PDF"
                />
              ) : (
                <p className="text-xs text-white/50">
                  PDF is prepared automatically when all chapters finish.
                </p>
              )}
            </div>
          )}
          <label className="mt-4 block text-xs text-white/55">
            Chapter
            <select
              aria-label={
                mode === "summary"
                  ? "Select summary chapter"
                  : "Select study chapter"
              }
              value={active}
              onChange={event => setActive(Number(event.target.value))}
              className="mt-2 h-11 w-full min-w-0 rounded-xl border border-white/10 bg-[#151d2c] px-3 text-sm text-white"
            >
              {course.units.map((unit, index) => (
                <option key={index} value={index}>
                  {index + 1}. {unit.label}
                  {course.chapters.some(chapter => chapter.index === index)
                    ? " ✓"
                    : ""}
                </option>
              ))}
            </select>
          </label>
          {selected ? (
            <>
              <h4 className="mt-5 break-words text-xl font-bold text-cyan-100">
                {selected.title}
              </h4>
              <p className="mt-2 break-words text-xs text-white/40">
                {selected.sourceLabel}
              </p>
              {mode === "video" && selected.scenes.length > 0 && (
                <div className="mt-5">
                  <WhiteboardPlayer
                    key={selected.id + selected.audioURL}
                    scenes={selected.scenes}
                    language={course.language}
                    audioURL={selected.audioURL}
                  />
                </div>
              )}
              <div className="prose prose-invert mt-5 max-w-none break-words text-sm leading-7 [&_table]:block [&_table]:overflow-x-auto">
                <RichText>{selected.summary}</RichText>
              </div>
              {selected.warnings.map((warning, index) => (
                <p key={index} className="mt-3 text-xs text-amber-100">
                  {warning}
                </p>
              ))}
            </>
          ) : (
            <p className="py-8 text-sm text-white/45">
              This source chapter has not been read yet.
            </p>
          )}
          {course.warnings.map((warning, index) => (
            <p key={index} className="mt-3 text-xs text-amber-100/70">
              {warning}
            </p>
          ))}
        </article>
      )}
      <div className="rounded-2xl border border-white/10 p-4">
        <h3 className="text-sm font-semibold">
          {mode === "summary" ? "Saved summaries" : "Saved lessons"}
        </h3>
        <div className="mt-3 space-y-2">
          {history.data
            ?.filter(item => (item.mode ?? "video") === mode)
            .map(item => (
              <button
                key={item.id}
                disabled={busy}
                onClick={() => void open(item.id)}
                className="block w-full min-w-0 rounded-xl border border-white/10 bg-white/5 p-3 text-left"
              >
                <span className="block truncate text-xs">{item.title}</span>
                <span className="text-[10px] text-white/40">
                  {item.total} sections ·{" "}
                  {new Date(item.createdAt).toLocaleDateString()}
                </span>
              </button>
            ))}
        </div>
      </div>
    </section>
  );
}

export default function Studying() {
  useAuth({ redirectOnUnauthenticated: true });
  return (
    <WorkspaceShell
      title="Studying"
      subtitle="Summaries and narrated animated lessons continue through navigation. Completed chapters, progress, and PDF output are saved to your account."
    >
      <div className="grid min-w-0 items-start gap-6 xl:grid-cols-2">
        <StudySection mode="summary" />
        <StudySection mode="video" />
      </div>
    </WorkspaceShell>
  );
}
