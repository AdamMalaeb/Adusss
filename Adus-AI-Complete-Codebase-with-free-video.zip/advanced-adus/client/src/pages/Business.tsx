import WorkspaceShell from "@/components/WorkspaceShell";
import { LanguageSelect } from "@/components/LanguageSelect";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ArrowDownToLine,
  BarChart3,
  Check,
  ChevronDown,
  ChevronUp,
  CircleAlert,
  FileText,
  History,
  Loader2,
  RotateCcw,
  Sparkles,
  Target,
  WandSparkles,
} from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import type {
  BusinessInput,
  BusinessPlan,
  BusinessRecord,
} from "@shared/business";
import type { VoiceLanguage } from "@shared/languages";

type BusinessRecordWithId = BusinessRecord & { id: string };

const inputClass =
  "mt-2 min-w-0 w-full rounded-xl border border-white/10 bg-[#0a0d14] px-3 py-2.5 text-sm text-white outline-none transition focus:border-cyan-200/45 focus:ring-2 focus:ring-cyan-200/10 placeholder:text-white/20";
const cardClass =
  "min-w-0 rounded-[1.5rem] border border-white/[0.09] bg-white/[0.035] p-5 sm:p-6";

const emptyInput: BusinessInput = {
  idea: "",
  countryOrMarket: "",
  budget: undefined,
  currency: "USD",
  customer: "",
  experience: "",
  researchLocalMarket: false,
  language: "auto",
};

type UnitAssumptions = {
  pricePerCustomer: string;
  customersPerMonth: string;
  variableCostPerCustomer: string;
  fixedCostsPerMonth: string;
};

const emptyUnitAssumptions: UnitAssumptions = {
  pricePerCustomer: "",
  customersPerMonth: "",
  variableCostPerCustomer: "",
  fixedCostsPerMonth: "",
};

function formatScore(score: number) {
  return Number.isInteger(score) ? String(score) : score.toFixed(1);
}

function planMarkdown(record: BusinessRecord) {
  const { plan, input } = record;
  const section = (
    title: string,
    value: { overview: string; actions: string[] }
  ) =>
    `## ${title}\n\n${value.overview}\n\n${value.actions.map(action => `- ${action}`).join("\n")}`;
  const list = (items: string[]) => items.map(item => `- ${item}`).join("\n");
  return [
    `# ${plan.title}`,
    "",
    `Generated: ${new Date(plan.generatedAt).toUTCString()}`,
    `Readiness rubric score: ${formatScore(record.score)}/100 (not a success probability).`,
    "",
    "## Brief",
    "",
    `- Idea: ${input.idea}`,
    `- Country / market: ${input.countryOrMarket}`,
    `- Customer: ${input.customer}`,
    `- Experience: ${input.experience}`,
    `- Budget: ${input.budget === undefined ? "Not supplied" : `${input.currency} ${input.budget}`}`,
    `- Output language: ${input.language === "auto" ? "Follow the language used in the brief" : input.language}`,
    "",
    "## Executive summary",
    "",
    plan.executiveSummary,
    "",
    "## Known facts",
    "",
    list(plan.knownFacts),
    "",
    section("Strategy", plan.strategy),
    "",
    section("Customer", plan.customer),
    "",
    section("Market", plan.market),
    "",
    "## Competitors / alternatives",
    "",
    plan.competitors
      .map(
        item =>
          `### ${item.name}\n\n${item.positioning}\n\nWatchout: ${item.watchout}`
      )
      .join("\n\n"),
    "",
    "## SWOT",
    "",
    `### Strengths\n${list(plan.swot.strengths)}\n\n### Weaknesses\n${list(plan.swot.weaknesses)}\n\n### Opportunities\n${list(plan.swot.opportunities)}\n\n### Threats\n${list(plan.swot.threats)}`,
    "",
    section("Operating structure", plan.operatingStructure),
    "",
    section("Marketing", plan.marketing),
    "",
    "## Milestones",
    "",
    plan.milestones
      .map(
        milestone =>
          `### ${milestone.horizon}: ${milestone.objective}\n${list(milestone.checks)}`
      )
      .join("\n\n"),
    "",
    "## Risks",
    "",
    plan.risks
      .map(
        risk => `- **${risk.risk}** — ${risk.mitigation} Signal: ${risk.signal}`
      )
      .join("\n"),
    "",
    "## Practical advice",
    "",
    list(plan.practicalAdvice),
    "",
    "## Assumptions and missing information",
    "",
    `### Assumptions\n${list(plan.assumptions)}\n\n### Missing information\n${list(plan.missingInformation)}`,
    "",
    "## Rubric factors",
    "",
    plan.rubricFactors
      .map(
        factor =>
          `- **${factor.label}**: ${formatScore(factor.score)}/100, weight ${factor.weight}%. ${factor.evidence} Missing: ${factor.missingInfo.join("; ")}`
      )
      .join("\n"),
    "",
    "## Sources checked",
    "",
    plan.sources.length
      ? plan.sources
          .map(
            source => `- [${source.title}](${source.url}) — ${source.excerpt}`
          )
          .join("\n")
      : "No live public sources were requested or successfully read.",
    "",
    "Unit economics are intentionally excluded from this export until editable assumptions are supplied in the UI. AI-generated content is a planning aid and offers no guarantee of business outcomes.",
    "",
  ].join("\n");
}

function downloadMarkdown(record: BusinessRecord) {
  const blob = new Blob([planMarkdown(record)], {
    type: "text/markdown;charset=utf-8",
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${
    record.plan.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") || "business-plan"
  }.md`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

function SignInHint() {
  return (
    <div className="rounded-2xl border border-cyan-200/10 bg-cyan-200/[0.04] p-4 text-sm leading-6 text-white/55">
      Sign in to save plans privately to your workspace. Your idea is not sent
      to public research unless you explicitly enable local-market research.
    </div>
  );
}

function SectionCard({
  title,
  icon: Icon,
  overview,
  actions,
}: {
  title: string;
  icon: typeof Target;
  overview: string;
  actions: string[];
}) {
  return (
    <section className={cardClass}>
      <div className="mb-4 flex min-w-0 items-center gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-cyan-300/10 text-cyan-200">
          <Icon size={17} />
        </div>
        <h2 className="min-w-0 break-words text-base font-semibold text-white/90">
          {title}
        </h2>
      </div>
      <p className="break-words text-sm leading-7 text-white/65">{overview}</p>
      <ul className="mt-4 space-y-2 text-sm leading-6 text-white/50">
        {actions.map((action, index) => (
          <li key={`${action}-${index}`} className="flex min-w-0 gap-2">
            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-200/70" />
            <span className="min-w-0 break-words">{action}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function RubricChart({ plan }: { plan: BusinessPlan }) {
  const data = plan.rubricFactors.map(factor => ({
    name: factor.label,
    score: factor.score,
  }));
  return (
    <section className={cardClass}>
      <div className="flex min-w-0 items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-base font-semibold text-white/90">
            <BarChart3 size={17} className="text-violet-200" /> Readiness rubric
          </div>
          <p className="mt-2 text-xs leading-5 text-white/40">
            A weighted 0–100 assessment of evidence and preparedness. It is not
            a probability or promise of success.
          </p>
        </div>
        <div className="shrink-0 rounded-2xl border border-violet-200/15 bg-violet-200/10 px-3 py-2 text-right">
          <div className="text-2xl font-bold text-violet-100">
            {formatScore(plan.feasibilityScore)}
          </div>
          <div className="font-mono text-[9px] uppercase tracking-[.14em] text-violet-200/60">
            score / 100
          </div>
        </div>
      </div>
      <div className="mt-5 h-[250px] min-w-0 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            layout="vertical"
            margin={{ top: 4, right: 8, left: 8, bottom: 4 }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(255,255,255,.08)"
              horizontal={false}
            />
            <XAxis
              type="number"
              domain={[0, 100]}
              tick={{ fill: "rgba(255,255,255,.4)", fontSize: 10 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              type="category"
              dataKey="name"
              width={112}
              tick={{ fill: "rgba(255,255,255,.52)", fontSize: 10 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              cursor={{ fill: "rgba(255,255,255,.04)" }}
              contentStyle={{
                background: "#111827",
                border: "1px solid rgba(255,255,255,.12)",
                borderRadius: 12,
                color: "white",
              }}
              formatter={(value: number) => [
                `${formatScore(value)}/100`,
                "rubric score",
              ]}
            />
            <Bar
              dataKey="score"
              fill="#a78bfa"
              radius={[0, 5, 5, 0]}
              barSize={18}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 grid min-w-0 gap-3 sm:grid-cols-2">
        {plan.rubricFactors.map(factor => (
          <div
            key={factor.key}
            className="min-w-0 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3"
          >
            <div className="flex justify-between gap-2 text-xs">
              <span className="min-w-0 break-words text-white/65">
                {factor.label}
              </span>
              <span className="shrink-0 text-violet-200">
                {formatScore(factor.score)} · {factor.weight}%
              </span>
            </div>
            <p className="mt-2 break-words text-[11px] leading-5 text-white/35">
              {factor.evidence}
            </p>
            {factor.missingInfo.length > 0 && (
              <p className="mt-2 break-words text-[11px] leading-5 text-amber-100/55">
                Missing: {factor.missingInfo.join("; ")}
              </p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

function UnitEconomics({
  currency,
  assumptions,
  setAssumptions,
}: {
  currency: string;
  assumptions: UnitAssumptions;
  setAssumptions: (next: UnitAssumptions) => void;
}) {
  const values = useMemo(() => {
    const parsed = Object.fromEntries(
      Object.entries(assumptions).map(([key, value]) => [
        key,
        value.trim() === "" ? null : Number(value),
      ])
    ) as Record<keyof UnitAssumptions, number | null>;
    if (
      Object.values(parsed).some(
        value => value === null || !Number.isFinite(value) || value < 0
      )
    )
      return null;
    const price = parsed.pricePerCustomer!;
    const customers = parsed.customersPerMonth!;
    const variable = parsed.variableCostPerCustomer!;
    const fixed = parsed.fixedCostsPerMonth!;
    const contributionPerCustomer = price - variable;
    return {
      data: [
        { name: "Revenue", value: price * customers },
        { name: "Variable cost", value: variable * customers },
        { name: "Fixed cost", value: fixed },
        {
          name: "Net after costs",
          value: price * customers - variable * customers - fixed,
        },
      ],
      breakeven:
        contributionPerCustomer > 0 ? fixed / contributionPerCustomer : null,
    };
  }, [assumptions]);
  const field = (
    key: keyof UnitAssumptions,
    label: string,
    placeholder: string
  ) => (
    <label className="block min-w-0 text-xs text-white/45">
      {label}
      <input
        inputMode="decimal"
        value={assumptions[key]}
        onChange={event =>
          setAssumptions({ ...assumptions, [key]: event.target.value })
        }
        placeholder={placeholder}
        className={inputClass}
      />
    </label>
  );
  return (
    <section className={cardClass}>
      <div className="flex min-w-0 items-start gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-300/10 text-emerald-200">
          <BarChart3 size={17} />
        </div>
        <div className="min-w-0">
          <h2 className="break-words text-base font-semibold text-white/90">
            Unit economics sandbox
          </h2>
          <p className="mt-1 break-words text-xs leading-5 text-white/40">
            Editable illustrative assumptions, not sourced facts or a forecast.
            Numbers remain hidden until all four inputs are supplied.
          </p>
        </div>
      </div>
      <div className="mt-5 grid min-w-0 gap-3 sm:grid-cols-2">
        {field(
          "pricePerCustomer",
          `Price / customer / month (${currency})`,
          "e.g. 40"
        )}
        {field("customersPerMonth", "Customers / month", "e.g. 25")}
        {field(
          "variableCostPerCustomer",
          `Variable cost / customer (${currency})`,
          "e.g. 8"
        )}
        {field(
          "fixedCostsPerMonth",
          `Fixed costs / month (${currency})`,
          "e.g. 500"
        )}
      </div>
      {!values ? (
        <div className="mt-5 rounded-xl border border-dashed border-white/10 p-4 text-xs leading-5 text-white/35">
          Add non-negative numeric inputs to see revenue, cost, net
          contribution, and breakeven. These values are your assumptions only.
        </div>
      ) : (
        <>
          <div className="mt-5 h-[220px] min-w-0 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={values.data}
                margin={{ top: 4, right: 8, left: 0, bottom: 4 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(255,255,255,.08)"
                  vertical={false}
                />
                <XAxis
                  dataKey="name"
                  tick={{ fill: "rgba(255,255,255,.4)", fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "rgba(255,255,255,.4)", fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    background: "#111827",
                    border: "1px solid rgba(255,255,255,.12)",
                    borderRadius: 12,
                    color: "white",
                  }}
                  formatter={(value: number) => [
                    `${currency} ${value.toFixed(2)}`,
                    "monthly amount",
                  ]}
                />
                <Bar
                  dataKey="value"
                  fill="#67e8a5"
                  radius={[5, 5, 0, 0]}
                  barSize={28}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 rounded-xl border border-emerald-200/10 bg-emerald-200/[0.04] p-3 text-xs leading-5 text-emerald-100/70">
            Illustrative break-even:{" "}
            {values.breakeven === null
              ? "not reached with these assumptions because contribution per customer is not positive"
              : `${values.breakeven.toFixed(1)} customers / month`}{" "}
            · Formula: fixed costs ÷ (price − variable cost).
          </div>
        </>
      )}
    </section>
  );
}

function PlanView({
  record,
  assumptions,
  setAssumptions,
  revisionLanguage,
  setRevisionLanguage,
  reviseInstruction,
  setReviseInstruction,
  onRevise,
  revising,
}: {
  record: BusinessRecordWithId;
  assumptions: UnitAssumptions;
  setAssumptions: (next: UnitAssumptions) => void;
  revisionLanguage: VoiceLanguage;
  setRevisionLanguage: (value: VoiceLanguage) => void;
  reviseInstruction: string;
  setReviseInstruction: (value: string) => void;
  onRevise: () => void;
  revising: boolean;
}) {
  const plan = record.plan;
  const [openSwot, setOpenSwot] = useState(false);
  return (
    <div className="min-w-0 space-y-5">
      <section className="min-w-0 rounded-[1.75rem] border border-cyan-200/15 bg-gradient-to-br from-cyan-200/[0.08] via-white/[0.035] to-violet-200/[0.08] p-5 sm:p-7">
        <div className="flex min-w-0 flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <div className="mb-3 flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-cyan-100/70">
              <Check size={13} /> Generated plan ·{" "}
              {new Date(plan.generatedAt).toLocaleString()}
            </div>
            <h2 className="break-words text-2xl font-bold tracking-tight text-white sm:text-3xl">
              {plan.title}
            </h2>
            <p className="mt-3 max-w-3xl break-words text-sm leading-7 text-white/65">
              {plan.executiveSummary}
            </p>
          </div>
          <div className="shrink-0 rounded-2xl border border-cyan-200/15 bg-[#0a0d14]/50 px-4 py-3">
            <div className="text-3xl font-bold text-cyan-100">
              {formatScore(record.score)}
            </div>
            <div className="font-mono text-[9px] uppercase tracking-[.15em] text-cyan-200/55">
              readiness score / 100
            </div>
          </div>
        </div>
        <div className="mt-5 flex flex-wrap gap-2 text-[11px] text-white/45">
          <span className="rounded-full border border-white/10 px-3 py-1.5">
            Evidence:{" "}
            {plan.researchStatus === "verified"
              ? "public pages checked"
              : plan.researchStatus === "unavailable"
                ? "not available"
                : "not requested"}
          </span>
          <span className="rounded-full border border-amber-200/10 bg-amber-200/[0.04] px-3 py-1.5 text-amber-100/65">
            Score is a rubric, never a success probability
          </span>
        </div>
      </section>
      <div className="grid min-w-0 gap-5 lg:grid-cols-2">
        <SectionCard title="Strategy" icon={Target} {...plan.strategy} />
        <SectionCard title="Customer" icon={Target} {...plan.customer} />
        <SectionCard title="Market" icon={Target} {...plan.market} />
        <SectionCard
          title="Operating structure"
          icon={Target}
          {...plan.operatingStructure}
        />
        <SectionCard
          title="Marketing"
          icon={WandSparkles}
          {...plan.marketing}
        />
      </div>
      <section className={cardClass}>
        <div className="flex min-w-0 items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="text-base font-semibold text-white/90">
              Competitors / alternatives
            </h2>
            <p className="mt-1 text-xs leading-5 text-white/35">
              Names and claims are hypotheses unless supported by a retrieved
              source below.
            </p>
          </div>
          <CircleAlert className="shrink-0 text-amber-200/70" size={17} />
        </div>
        <div className="mt-4 grid min-w-0 gap-3 md:grid-cols-2">
          {plan.competitors.map(item => (
            <div
              key={item.name}
              className="min-w-0 rounded-xl border border-white/[0.07] bg-white/[0.02] p-4"
            >
              <div className="break-words text-sm font-semibold text-white/80">
                {item.name}
              </div>
              <p className="mt-2 break-words text-xs leading-5 text-white/45">
                {item.positioning}
              </p>
              <p className="mt-2 break-words text-xs leading-5 text-amber-100/50">
                Watchout: {item.watchout}
              </p>
            </div>
          ))}
        </div>
      </section>
      <section className={cardClass}>
        <button
          onClick={() => setOpenSwot(value => !value)}
          className="flex w-full min-w-0 items-center justify-between gap-3 text-left"
        >
          <span className="min-w-0 break-words text-base font-semibold text-white/90">
            SWOT snapshot
          </span>
          {openSwot ? (
            <ChevronUp size={17} className="shrink-0 text-white/45" />
          ) : (
            <ChevronDown size={17} className="shrink-0 text-white/45" />
          )}
        </button>
        {openSwot && (
          <div className="mt-4 grid min-w-0 gap-3 sm:grid-cols-2">
            {(
              ["strengths", "weaknesses", "opportunities", "threats"] as const
            ).map(key => (
              <div
                key={key}
                className="min-w-0 rounded-xl border border-white/[0.07] p-4"
              >
                <div className="font-mono text-[10px] uppercase tracking-[.15em] text-cyan-200/60">
                  {key}
                </div>
                <ul className="mt-3 space-y-2 text-xs leading-5 text-white/50">
                  {plan.swot[key].map(item => (
                    <li key={item} className="break-words">
                      • {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
      </section>
      <section className={cardClass}>
        <h2 className="text-base font-semibold text-white/90">
          Milestones and risks
        </h2>
        <div className="mt-4 grid min-w-0 gap-3 md:grid-cols-2">
          {plan.milestones.map(item => (
            <div
              key={`${item.horizon}-${item.objective}`}
              className="min-w-0 rounded-xl border border-white/[0.07] p-4"
            >
              <div className="font-mono text-[10px] uppercase tracking-[.15em] text-cyan-200/60">
                {item.horizon}
              </div>
              <div className="mt-2 break-words text-sm font-semibold text-white/75">
                {item.objective}
              </div>
              <ul className="mt-2 space-y-1 text-xs leading-5 text-white/45">
                {item.checks.map(check => (
                  <li key={check} className="break-words">
                    • {check}
                  </li>
                ))}
              </ul>
            </div>
          ))}
          {plan.risks.map(item => (
            <div
              key={item.risk}
              className="min-w-0 rounded-xl border border-amber-200/10 bg-amber-200/[0.03] p-4"
            >
              <div className="break-words text-sm font-semibold text-amber-100/75">
                {item.risk}
              </div>
              <p className="mt-2 break-words text-xs leading-5 text-white/45">
                Mitigation: {item.mitigation}
              </p>
              <p className="mt-2 break-words text-xs leading-5 text-amber-100/50">
                Signal: {item.signal}
              </p>
            </div>
          ))}
        </div>
      </section>
      <div className="grid min-w-0 gap-5 lg:grid-cols-2">
        <section className={cardClass}>
          <h2 className="text-base font-semibold text-white/90">
            Practical advice
          </h2>
          <ul className="mt-4 space-y-3 text-sm leading-6 text-white/55">
            {plan.practicalAdvice.map(item => (
              <li key={item} className="flex min-w-0 gap-2">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-200/80" />
                <span className="min-w-0 break-words">{item}</span>
              </li>
            ))}
          </ul>
        </section>
        <section className={cardClass}>
          <h2 className="text-base font-semibold text-white/90">
            Evidence boundaries
          </h2>
          <div className="mt-4 space-y-4 text-xs leading-5">
            <div>
              <div className="font-mono uppercase tracking-[.15em] text-emerald-200/60">
                Known facts
              </div>
              <ul className="mt-2 space-y-1 text-white/50">
                {plan.knownFacts.length ? (
                  plan.knownFacts.map(item => (
                    <li key={item} className="break-words">
                      • {item}
                    </li>
                  ))
                ) : (
                  <li className="break-words">
                    • No verified facts were supplied beyond the brief.
                  </li>
                )}
              </ul>
            </div>
            <div>
              <div className="font-mono uppercase tracking-[.15em] text-cyan-200/60">
                Assumptions
              </div>
              <ul className="mt-2 space-y-1 text-white/50">
                {plan.assumptions.map(item => (
                  <li key={item} className="break-words">
                    • {item}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <div className="font-mono uppercase tracking-[.15em] text-amber-100/60">
                Missing information
              </div>
              <ul className="mt-2 space-y-1 text-amber-100/55">
                {plan.missingInformation.map(item => (
                  <li key={item} className="break-words">
                    • {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      </div>
      <RubricChart plan={plan} />
      <UnitEconomics
        currency={plan.unitEconomics.currency}
        assumptions={assumptions}
        setAssumptions={setAssumptions}
      />
      <section className={cardClass}>
        <div className="flex min-w-0 items-center gap-3">
          <RotateCcw size={17} className="shrink-0 text-violet-200" />
          <h2 className="text-base font-semibold text-white/90">
            Revise this plan
          </h2>
        </div>
        <p className="mt-2 text-xs leading-5 text-white/40">
          Ask for a focused change. The previous version remains in history and
          is not overwritten. You can also choose the language for the new
          version.
        </p>
        <label className="mt-4 block max-w-sm text-xs text-white/45">
          Revision language
          <LanguageSelect
            value={revisionLanguage}
            onChange={setRevisionLanguage}
            includeAuto
            label="Revision language"
            className={`${inputClass} mt-2`}
          />
        </label>
        <textarea
          value={reviseInstruction}
          onChange={event => setReviseInstruction(event.target.value)}
          rows={3}
          className={`${inputClass} resize-y`}
          placeholder="e.g. Make the first 30-day validation plan service-led and lower-cost."
        />
        <Button
          disabled={revising || reviseInstruction.trim().length < 4}
          onClick={onRevise}
          className="mt-3 h-10 rounded-xl bg-violet-200 px-4 text-xs font-bold text-slate-950 hover:bg-violet-100"
        >
          {revising ? (
            <Loader2 size={15} className="mr-2 animate-spin" />
          ) : (
            <RotateCcw size={15} className="mr-2" />
          )}{" "}
          Revise and save new version
        </Button>
      </section>
      <section className="flex min-w-0 flex-col gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-sm font-semibold text-white/75">
            <FileText size={16} className="text-cyan-200" /> Export
          </div>
          <p className="mt-1 break-words text-xs leading-5 text-white/35">
            Download the grounded plan as Markdown. Sources are limited to pages
            actually retrieved.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => downloadMarkdown(record)}
          className="shrink-0 gap-2 border-white/10 bg-transparent text-white/70 hover:bg-white/5"
        >
          <ArrowDownToLine size={15} /> Download .md
        </Button>
      </section>
    </div>
  );
}

export default function Business() {
  const { isAuthenticated } = useAuth();
  const history = trpc.business.history.useQuery(undefined, {
    enabled: isAuthenticated,
    retry: false,
  });
  const utils = trpc.useUtils();
  const [input, setInput] = useState<BusinessInput>(emptyInput);
  const [record, setRecord] = useState<BusinessRecordWithId | null>(null);
  const [revisionLanguage, setRevisionLanguage] =
    useState<VoiceLanguage>("auto");
  const [assumptions, setAssumptions] =
    useState<UnitAssumptions>(emptyUnitAssumptions);
  const [reviseInstruction, setReviseInstruction] = useState("");
  const generate = trpc.business.generate.useMutation({
    meta: { handledError: true },
    onSuccess: data => {
      setRecord(data);
      setRevisionLanguage(data.input.language);
      setAssumptions(emptyUnitAssumptions);
      void utils.business.history.invalidate();
    },
  });
  const restore = trpc.business.restore.useMutation({
    meta: { handledError: true },
    onSuccess: data => {
      setRecord(data);
      setInput(data.input);
      setRevisionLanguage(data.input.language);
      setAssumptions(emptyUnitAssumptions);
    },
  });
  const revise = trpc.business.revise.useMutation({
    meta: { handledError: true },
    onSuccess: data => {
      setRecord(data);
      setRevisionLanguage(data.input.language);
      setReviseInstruction("");
      setAssumptions(emptyUnitAssumptions);
      void utils.business.history.invalidate();
    },
  });

  function submit(event: FormEvent) {
    event.preventDefault();
    const normalized: BusinessInput = {
      ...input,
      idea: input.idea.trim(),
      countryOrMarket: input.countryOrMarket.trim(),
      customer: input.customer.trim(),
      experience: input.experience.trim(),
      budget:
        input.budget === undefined || Number.isNaN(input.budget)
          ? undefined
          : input.budget,
    };
    generate.mutate(normalized);
  }

  return (
    <WorkspaceShell
      title="Business"
      subtitle="Turn an idea into a practical, evidence-aware plan. Private by default; public market research is opt-in and uses only the market/location field."
    >
      {!isAuthenticated && <SignInHint />}
      <div className="grid min-w-0 gap-5 xl:grid-cols-[minmax(0,0.82fr)_minmax(0,1.18fr)]">
        <div className="min-w-0 space-y-5">
          <form onSubmit={submit} className={cardClass}>
            <div className="mb-5 flex min-w-0 items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-300 text-slate-950">
                <Sparkles size={18} />
              </div>
              <div className="min-w-0">
                <h2 className="text-lg font-semibold text-white/90">
                  Start with the brief
                </h2>
                <p className="mt-1 break-words text-xs leading-5 text-white/40">
                  Specific inputs produce more useful gaps and tests. Budget is
                  optional.
                </p>
              </div>
            </div>
            <label className="block min-w-0 text-xs text-white/45">
              Business idea
              <textarea
                required
                minLength={4}
                maxLength={4000}
                value={input.idea}
                onChange={event =>
                  setInput({ ...input, idea: event.target.value })
                }
                rows={4}
                className={`${inputClass} resize-y`}
                placeholder="What will you offer, and what problem will it solve?"
              />
            </label>
            <label className="mt-4 block min-w-0 text-xs text-white/45">
              Country / market
              <textarea
                required
                minLength={2}
                maxLength={160}
                value={input.countryOrMarket}
                onChange={event =>
                  setInput({ ...input, countryOrMarket: event.target.value })
                }
                rows={2}
                className={`${inputClass} resize-y`}
                placeholder="e.g. Beirut, Lebanon or remote B2B in the Gulf"
              />
            </label>
            <label className="mt-4 block min-w-0 text-xs text-white/45">
              Plan language
              <LanguageSelect
                value={input.language}
                onChange={value => setInput({ ...input, language: value })}
                includeAuto
                label="Plan language"
                className={`${inputClass} mt-2`}
              />
              <span className="mt-2 block text-[11px] leading-5 text-white/30">
                Auto follows the language used in your brief; choose a supported
                language when you want the plan written elsewhere.
              </span>
            </label>
            <div className="mt-4 grid min-w-0 gap-3 sm:grid-cols-[minmax(0,1fr)_minmax(0,110px)]">
              <label className="block min-w-0 text-xs text-white/45">
                Budget (optional)
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={input.budget ?? ""}
                  onChange={event =>
                    setInput({
                      ...input,
                      budget:
                        event.target.value === ""
                          ? undefined
                          : Number(event.target.value),
                    })
                  }
                  className={inputClass}
                  placeholder="Not supplied"
                />
              </label>
              <label className="block min-w-0 text-xs text-white/45">
                Currency
                <input
                  value={input.currency}
                  maxLength={3}
                  onChange={event =>
                    setInput({
                      ...input,
                      currency: event.target.value.toUpperCase(),
                    })
                  }
                  className={inputClass}
                  placeholder="USD"
                />
              </label>
            </div>
            <label className="mt-4 block min-w-0 text-xs text-white/45">
              Target customer
              <textarea
                required
                minLength={2}
                maxLength={1200}
                value={input.customer}
                onChange={event =>
                  setInput({ ...input, customer: event.target.value })
                }
                rows={3}
                className={`${inputClass} resize-y`}
                placeholder="Who has this problem and how do they buy?"
              />
            </label>
            <label className="mt-4 block min-w-0 text-xs text-white/45">
              Your experience / resources
              <textarea
                required
                minLength={2}
                maxLength={1200}
                value={input.experience}
                onChange={event =>
                  setInput({ ...input, experience: event.target.value })
                }
                rows={3}
                className={`${inputClass} resize-y`}
                placeholder="Skills, access, team, assets, or constraints"
              />
            </label>
            <label className="mt-4 flex min-w-0 items-start gap-3 rounded-xl border border-white/[0.08] bg-white/[0.02] p-3 text-xs leading-5 text-white/55">
              <input
                type="checkbox"
                checked={input.researchLocalMarket}
                onChange={event =>
                  setInput({
                    ...input,
                    researchLocalMarket: event.target.checked,
                  })
                }
                className="mt-1 h-4 w-4 shrink-0 accent-cyan-300"
              />
              <span className="min-w-0">
                <strong className="font-semibold text-white/75">
                  Research public local market
                </strong>
                <br />
                Off by default. If enabled, only a sanitized public query based
                on country / market is sent; your idea, customer, budget, and
                experience stay private.
              </span>
            </label>
            <Button
              type="submit"
              disabled={!isAuthenticated || generate.isPending}
              className="mt-5 h-11 w-full rounded-xl bg-cyan-300 font-bold text-slate-950 hover:bg-cyan-200"
            >
              {generate.isPending ? (
                <Loader2 size={16} className="mr-2 animate-spin" />
              ) : (
                <Sparkles size={16} className="mr-2" />
              )}{" "}
              Generate plan
            </Button>
            {generate.error && (
              <p
                role="alert"
                className="mt-3 break-words text-xs leading-5 text-rose-200/80"
              >
                {generate.error.message}
              </p>
            )}
          </form>
          <section className={cardClass}>
            <div className="flex min-w-0 items-center gap-3">
              <History size={17} className="shrink-0 text-cyan-200" />
              <h2 className="text-base font-semibold text-white/90">
                Saved plans
              </h2>
            </div>
            <p className="mt-2 text-xs leading-5 text-white/35">
              Only your account can read these versions. Restore opens a saved
              plan without deleting newer versions.
            </p>
            <div className="mt-4 space-y-2">
              {history.isLoading ? (
                <div className="text-xs text-white/35">Loading history…</div>
              ) : history.data?.length ? (
                history.data.map(item => (
                  <div
                    key={item.id}
                    className="flex min-w-0 items-center gap-3 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold text-white/75">
                        {item.title}
                      </div>
                      <div className="truncate text-[10px] text-white/35">
                        {formatScore(item.score)}/100 ·{" "}
                        {new Date(item.generatedAt).toLocaleDateString()} ·{" "}
                        {item.countryOrMarket}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={restore.isPending}
                      onClick={() => restore.mutate({ id: item.id })}
                      className="shrink-0 text-cyan-200 hover:bg-cyan-200/10"
                    >
                      <RotateCcw size={14} className="mr-1" /> Restore
                    </Button>
                  </div>
                ))
              ) : (
                <div className="rounded-xl border border-dashed border-white/10 p-4 text-center text-xs text-white/30">
                  No saved plans yet.
                </div>
              )}
            </div>
          </section>
        </div>
        <div className="min-w-0">
          {record ? (
            <PlanView
              record={record}
              assumptions={assumptions}
              setAssumptions={setAssumptions}
              revisionLanguage={revisionLanguage}
              setRevisionLanguage={setRevisionLanguage}
              reviseInstruction={reviseInstruction}
              setReviseInstruction={setReviseInstruction}
              onRevise={() =>
                revise.mutate({
                  id: record.id,
                  instruction: reviseInstruction.trim(),
                  language: revisionLanguage,
                })
              }
              revising={revise.isPending}
            />
          ) : (
            <div className="flex min-h-[520px] min-w-0 flex-col items-center justify-center rounded-[1.75rem] border border-dashed border-white/10 bg-white/[0.02] p-8 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-300/10 text-violet-200">
                <WandSparkles size={24} />
              </div>
              <h2 className="mt-5 text-xl font-semibold text-white/80">
                Your plan will land here
              </h2>
              <p className="mt-3 max-w-md text-sm leading-7 text-white/40">
                The generated plan keeps evidence separate from assumptions,
                names missing information, and calculates its readiness score
                deterministically.
              </p>
            </div>
          )}
        </div>
      </div>
    </WorkspaceShell>
  );
}
