import WorkspaceShell from "@/components/WorkspaceShell";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { readFiles, type Attachment } from "@/lib/attachments";
import { trpc } from "@/lib/trpc";
import { isRtl, LANGUAGE_OPTIONS, type LanguageSelection } from "@shared/languages";
import { Check, Clipboard, Download, FileText, Languages, Loader2, Upload, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const ACCEPTED_FILES = ".pdf,.docx,.txt,.md,.csv,.json,.png,.jpg,.jpeg,.webp,.gif";

function errorMessage(error: unknown, fallback: string) {
  if (error && typeof error === "object" && "message" in error) {
    const message = String((error as { message?: unknown }).message ?? "");
    if (message) return message;
  }
  return fallback;
}

function formatDate(value: number) {
  return new Date(value).toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

type TranslatorResultView = {
  id: string;
  text: string;
  filename: string;
  sourceNames: string[];
  sourceLanguage: "auto" | LanguageSelection;
  targetLanguage: LanguageSelection;
  sourceLabel: string;
  targetLabel: string;
  model: string;
  warnings: string[];
  downloadUrl?: string;
  createdAt: number;
};

export default function Translator() {
  const [files, setFiles] = useState<Attachment[]>([]);
  const [sourceText, setSourceText] = useState("");
  const [sourceLanguage, setSourceLanguage] = useState("auto");
  const [targetLanguage, setTargetLanguage] = useState<LanguageSelection>("en");
  const [result, setResult] = useState<TranslatorResultView>();
  const [selectedHistoryId, setSelectedHistoryId] = useState<string>();
  const [notice, setNotice] = useState("");
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  const translate = trpc.adus.translator.translate.useMutation({
    meta: { handledError: true },
    onSuccess: value => {
      setResult(value);
      setNotice("");
      setCopied(false);
      void utils.adus.translator.list.invalidate();
    },
    onError: error => setNotice(errorMessage(error, "Translation could not be completed.")),
  });
  const history = trpc.adus.translator.list.useQuery(undefined, {
    meta: { handledError: true },
  });
  const getTranslation = trpc.adus.translator.get.useQuery(
    { id: selectedHistoryId ?? "" },
    { enabled: Boolean(selectedHistoryId), meta: { handledError: true } }
  );

  useEffect(() => {
    const record = getTranslation.data;
    const payload = record?.payload;
    if (!record || !payload || typeof payload !== "object" || !("text" in payload)) return;
    setResult({
      ...(payload as Omit<TranslatorResultView, "id">),
      id: selectedHistoryId ?? record.id,
    });
    setNotice("");
  }, [getTranslation.data, selectedHistoryId]);

  const hasSource = Boolean(sourceText.trim() || files.length);
  const busy = translate.isPending;

  async function chooseFiles(fileList: FileList | null) {
    if (!fileList?.length) return;
    try {
      const picked = await readFiles(Array.from(fileList));
      setFiles(picked);
      setNotice("");
    } catch (error: unknown) {
      setNotice(errorMessage(error, "The selected files could not be read."));
    }
  }

  async function submit() {
    if (!hasSource || busy) return;
    setNotice("");
    try {
      await translate.mutateAsync({
        files,
        text: sourceText.trim() || undefined,
        sourceLanguage: sourceLanguage as "auto" | LanguageSelection,
        targetLanguage,
      });
    } catch {
      // The mutation callback presents the server's safe error message.
    }
  }

  async function copyResult() {
    if (!result?.text) return;
    try {
      await navigator.clipboard.writeText(result.text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setNotice("Copy is unavailable in this browser. Select the result text and copy it manually.");
    }
  }

  function downloadResult() {
    if (!result?.text) return;
    const url = URL.createObjectURL(
      new Blob([result.text], { type: "text/plain;charset=utf-8" })
    );
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = result.filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function openHistory(id: string) {
    setSelectedHistoryId(id);
  }

  return (
    <WorkspaceShell
      title="Translator"
      subtitle="Translate complete documents and photos faithfully. Sections, headings, formatting markers, numbers, and names are preserved; the tool does not summarize your source."
    >
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.3fr)_minmax(320px,.7fr)]">
        <div className="space-y-6">
          <Card className="border-cyan-200/20 bg-card/80 shadow-xl shadow-cyan-950/10">
            <CardHeader className="border-b border-border/70">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <Languages className="h-5 w-5 text-cyan-300" />
                    Translate a source
                  </CardTitle>
                  <CardDescription className="mt-2 max-w-2xl leading-6">
                    Upload up to five PDF, photo, DOCX, or text files, or paste text below. Long sources are translated in ordered bounded sections with no silent truncation.
                  </CardDescription>
                </div>
                <Badge variant="outline" className="shrink-0 border-cyan-300/30 text-cyan-200">
                  Built in
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="translator-source-language">Source language</Label>
                  <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
                    <SelectTrigger id="translator-source-language" className="w-full">
                      <SelectValue placeholder="Auto-detect" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto-detect</SelectItem>
                      {LANGUAGE_OPTIONS.map(option => (
                        <SelectItem key={option.code} value={option.code}>
                          {option.label} ({option.nativeLabel})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="translator-target-language">Translate into</Label>
                  <Select value={targetLanguage} onValueChange={value => setTargetLanguage(value as LanguageSelection)}>
                    <SelectTrigger id="translator-target-language" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LANGUAGE_OPTIONS.map(option => (
                        <SelectItem key={option.code} value={option.code}>
                          {option.label} ({option.nativeLabel})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <Label htmlFor="translator-files">Files</Label>
                  <span className="text-xs text-muted-foreground">8 MB each, 18 MB combined</span>
                </div>
                <input
                  ref={fileInputRef}
                  id="translator-files"
                  type="file"
                  accept={ACCEPTED_FILES}
                  multiple
                  className="sr-only"
                  onChange={event => {
                    void chooseFiles(event.target.files);
                    event.currentTarget.value = "";
                  }}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex min-h-28 w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-cyan-300/35 bg-cyan-300/[.04] px-4 py-5 text-center transition-colors hover:border-cyan-200/60 hover:bg-cyan-300/[.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
                >
                  <Upload className="h-5 w-5 text-cyan-200" />
                  <span className="text-sm font-medium">Choose source files</span>
                  <span className="text-xs text-muted-foreground">PDF, photos, DOCX, TXT, Markdown, CSV, or JSON</span>
                </button>
                {files.length > 0 && (
                  <div className="grid gap-2 sm:grid-cols-2">
                    {files.map(file => (
                      <div key={`${file.name}-${file.dataUrl.length}`} className="flex min-w-0 items-center gap-2 rounded-lg border border-border/70 bg-background/40 px-3 py-2 text-sm">
                        <FileText className="h-4 w-4 shrink-0 text-cyan-200" />
                        <span className="min-w-0 flex-1 truncate" title={file.name}>{file.name}</span>
                        <button
                          type="button"
                          className="rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          onClick={() => setFiles(current => current.filter(item => item !== file))}
                          aria-label={`Remove ${file.name}`}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <Label htmlFor="translator-source-text">Or paste text</Label>
                  <span className="text-xs text-muted-foreground">Optional when files are selected</span>
                </div>
                <Textarea
                  id="translator-source-text"
                  value={sourceText}
                  onChange={event => setSourceText(event.target.value)}
                  placeholder="Paste the source text here…"
                  className="min-h-48 resize-y bg-background/30 leading-7"
                />
              </div>

              {notice && (
                <Alert variant="destructive">
                  <AlertTitle>Translation needs attention</AlertTitle>
                  <AlertDescription>{notice}</AlertDescription>
                </Alert>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border/70 pt-5">
                <p className="max-w-xl text-xs leading-5 text-muted-foreground">
                  Readability limits are reported instead of silently dropping pages or characters. Results are saved to your private translation history.
                </p>
                <Button type="button" size="lg" disabled={!hasSource || busy} onClick={() => void submit()}>
                  {busy ? <Loader2 className="animate-spin" /> : <Languages />}
                  {busy ? "Translating…" : "Translate completely"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {result && (
            <Card className="border-emerald-300/20 bg-card/80 shadow-xl shadow-emerald-950/10">
              <CardHeader className="border-b border-border/70">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <CardTitle className="text-xl">Translation result</CardTitle>
                    <CardDescription className="mt-2">
                      {result.sourceLabel} → {result.targetLabel} · {result.sourceNames.join(", ") || "Pasted text"}
                    </CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button type="button" variant="outline" size="sm" onClick={() => void copyResult()}>
                      {copied ? <Check /> : <Clipboard />}
                      {copied ? "Copied" : "Copy"}
                    </Button>
                    <Button type="button" variant="outline" size="sm" onClick={downloadResult}>
                      <Download />
                      Download .txt
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                {result.warnings?.map(warning => (
                  <Alert key={warning}>
                    <AlertTitle>Coverage note</AlertTitle>
                    <AlertDescription>{warning}</AlertDescription>
                  </Alert>
                ))}
                <div className="max-h-[65vh] min-w-0 overflow-auto rounded-xl border border-border/70 bg-background/35 p-5">
                  <pre
                    dir={isRtl(result.targetLanguage) ? "rtl" : "ltr"}
                    className="whitespace-pre-wrap break-words [overflow-wrap:anywhere] font-sans text-sm leading-7"
                  >
                    {result.text}
                  </pre>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <Card className="h-fit border-border/80 bg-card/60 xl:sticky xl:top-6">
          <CardHeader>
            <CardTitle className="text-lg">Recent translations</CardTitle>
            <CardDescription>Private history for this account. Open a saved result without re-running the model.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {history.isLoading && (
              <div className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading history…
              </div>
            )}
            {!history.isLoading && !history.data?.length && (
              <p className="py-6 text-sm leading-6 text-muted-foreground">Your completed translations will appear here.</p>
            )}
            {history.data?.map(item => (
              <button
                key={item.id}
                type="button"
                className="w-full rounded-lg border border-border/60 bg-background/20 px-3 py-3 text-left transition-colors hover:border-cyan-300/40 hover:bg-cyan-300/[.05] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
                onClick={() => void openHistory(item.id)}
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="truncate text-sm font-medium">{item.filename}</span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">{formatDate(item.createdAt)}</span>
                </div>
                <div className="mt-1 truncate text-xs text-muted-foreground">{item.sourceLabel} → {item.targetLabel}</div>
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </WorkspaceShell>
  );
}
