import WebsitePreview from "@/components/WebsitePreview";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import WorkspaceShell from "@/components/WorkspaceShell";
import { trpc } from "@/lib/trpc";
import { saveFile, shareFile } from "@/lib/downloadMedia";
import { Button } from "@/components/ui/button";
import {
  AlertCircle,
  ArrowLeft,
  Check,
  Download,
  Eye,
  Expand,
  FileUp,
  Globe2,
  Loader2,
  Monitor,
  PanelLeft,
  PanelRight,
  Pencil,
  Rocket,
  Share2,
  Sparkles,
  Smartphone,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import {
  initialWebsiteBrief,
  useWebsiteWorkspace,
  websiteArtifactStore,
  type SavedWebsiteArtifact,
  type SavedDeployment,
} from "@/lib/websiteArtifactStore";
import { useWorkspaceAccount } from "@/lib/workspaceAccount";

function Gate() {
  return (
    <main className="adus-grid flex min-h-screen items-center justify-center px-5">
      <section className="adus-glass w-full max-w-lg rounded-[2rem] border border-white/10 p-8">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-300 text-slate-950">
            <Sparkles size={18} />
          </div>
          <div>
            <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan-200">
              Adus build lab
            </div>
            <div className="text-xs text-white/40">
              Rendered website creation
            </div>
          </div>
        </div>
        <h1 className="text-3xl font-extrabold tracking-[-0.06em] text-white">
          Build the website, not the code.
        </h1>
        <p className="mt-4 text-sm leading-7 text-white/50">
          Sign in to create a rendered website preview and publish it when you
          approve the result.
        </p>
        <Button
          onClick={() => startLogin()}
          className="mt-7 h-12 w-full rounded-xl bg-cyan-300 font-bold text-slate-950 hover:bg-cyan-200"
        >
          Sign in to build
        </Button>
      </section>
    </main>
  );
}

type Host = "netlify" | "github" | "vercel" | "other";
type Artifact = { id: string; title: string; summary: string; html: string };
type Deployment = {
  id: string;
  host?: Host;
  state: "processing" | "published" | "failed";
  url?: string;
};
const hostLabels: Record<Host, string> = {
  netlify: "Netlify",
  github: "GitHub Pages",
  vercel: "Vercel",
  other: "Other",
};

const previewSafetyStyles =
  "<style data-adus-preview-safety>html,body{max-width:100%;overflow-x:hidden}*,*:before,*:after{box-sizing:border-box}img,svg,video,canvas{max-width:100%;height:auto}body{margin:0}</style>";
const previewViewport =
  '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">';

/** Adds only missing preview scaffolding; the generated document's data is never replaced. */
export function normalizePreviewHtml(html: string) {
  const additions = [
    /<meta\b[^>]*name\s*=\s*["']viewport["'][^>]*>/i.test(html)
      ? ""
      : previewViewport,
    /<style\b[^>]*data-adus-preview-safety[^>]*>/i.test(html)
      ? ""
      : previewSafetyStyles,
  ].join("");
  if (!additions) return html;
  const head = /<head\b[^>]*>/i;
  if (head.test(html)) {
    return html.replace(head, opening => `${opening}${additions}`);
  }
  const htmlTag = /<html\b[^>]*>/i;
  if (htmlTag.test(html)) {
    return html.replace(
      htmlTag,
      opening => `${opening}<head>${additions}</head>`
    );
  }
  return `${additions}${html}`;
}

function safeErrorMessage(error: unknown, fallback: string) {
  const message = error instanceof Error ? error.message : "";
  if (/not found|regenerate|draft/i.test(message))
    return "This website draft is no longer available. Regenerate it and try again.";
  if (
    /rejected the token|denied this operation|could not find the requested resource|reported a conflict|rate-limited|permissions|account access|account limits/i.test(
      message
    )
  )
    return message;
  if (/token|netlify|github|verify|site|deploy|repository|pages/i.test(message))
    return "The selected host could not complete this deployment. Check the site name and token, then retry.";
  return fallback;
}

export default function BuildLab() {
  const { loading, isAuthenticated } = useAuth();
  const accountId = useWorkspaceAccount();
  const workspace = useWebsiteWorkspace();
  const urlBrief = new URLSearchParams(window.location.search).get("brief");
  const [brief, setBrief] = useState(() =>
    initialWebsiteBrief(urlBrief, workspace)
  );
  const [artifact, setArtifact] = useState<Artifact | null>(
    (workspace.artifact as Artifact | null | undefined) ?? null
  );
  const [deployment, setDeployment] = useState<Deployment | null>(
    (workspace.deployment as Deployment | null | undefined) ?? null
  );
  const [publishOpen, setPublishOpen] = useState(false);
  const [previewMode, setPreviewMode] = useState<"mobile" | "desktop">(
    window.innerWidth < 768 ? "mobile" : "desktop"
  );
  const [previewFullscreen, setPreviewFullscreen] = useState(false);
  const [host, setHost] = useState<Host | null>(null);
  const [siteName, setSiteName] = useState("");
  const [token, setToken] = useState("");
  const [publishError, setPublishError] = useState("");
  const [buildError, setBuildError] = useState("");
  const [importHtml, setImportHtml] = useState("");
  const [importFilename, setImportFilename] = useState("imported-website.html");
  const [importError, setImportError] = useState("");
  const importFileRef = useRef<HTMLInputElement>(null);
  const exportTicket = trpc.adus.media.websiteTicket.useQuery(
    { id: artifact?.id ?? "" },
    {
      enabled: Boolean(artifact),
      retry: false,
      staleTime: 120000,
      refetchInterval: artifact ? 240000 : false,
      meta: { handledError: true },
    }
  );
  const artifactIdRef = useRef<string | null>(null);
  artifactIdRef.current = artifact?.id ?? null;
  const build = trpc.adus.website.build.useMutation({
    meta: { handledError: true },
    onSuccess: result => {
      setArtifact(result);
      setDeployment(null);
      websiteArtifactStore.patch({
        brief: brief.trim(),
        artifact: result as SavedWebsiteArtifact,
        deployment: null,
      });
      setPublishError("");
      setToken("");
    },
    onError: error =>
      setBuildError(
        safeErrorMessage(
          error,
          "The website preview could not be created. Please try again."
        )
      ),
  });
  const publish = trpc.adus.hosting.publish.useMutation({
    meta: { handledError: true },
  });
  const hostingConfiguration = trpc.adus.hosting.configuration.useQuery(
    undefined,
    { retry: false, staleTime: 120000, meta: { handledError: true } }
  );
  const importWebsite = trpc.adus.websiteImport.importHtml.useMutation({
    meta: { handledError: true },
    onSuccess: result => {
      setArtifact(result);
      setDeployment(null);
      websiteArtifactStore.patch({
        brief: brief.trim(),
        artifact: result as SavedWebsiteArtifact,
        deployment: null,
      });
      setPublishError("");
      setImportError("");
    },
    onError: error =>
      setImportError(
        error instanceof Error
          ? error.message
          : "This HTML file could not be imported."
      ),
  });
  const checkDeployment = trpc.adus.hosting.check.useMutation({
    meta: { handledError: true },
  });

  useEffect(() => {
    // Draft state is isolated by authenticated account. Credentials are never
    // included in this store and remain in component memory only.
    setBrief(initialWebsiteBrief(urlBrief, workspace));
    setArtifact((workspace.artifact as Artifact | null | undefined) ?? null);
    setDeployment(
      (workspace.deployment as Deployment | null | undefined) ?? null
    );
    setPublishOpen(false);
    setHost(null);
    setSiteName("");
    setToken("");
    setPublishError("");
  }, [accountId]);

  useEffect(() => {
    if (workspace.brief && workspace.brief !== brief && !urlBrief)
      setBrief(workspace.brief);
    if (workspace.artifact && workspace.artifact.id !== artifact?.id)
      setArtifact(workspace.artifact as Artifact);
    if (workspace.deployment && workspace.deployment.id !== deployment?.id)
      setDeployment(workspace.deployment as Deployment);
  }, [
    workspace,
    workspace.brief,
    workspace.artifact,
    workspace.deployment,
    brief,
    urlBrief,
    artifact?.id,
    deployment?.id,
  ]);

  useEffect(() => {
    if (!deployment || deployment.state !== "processing" || !token) return;
    let cancelled = false;
    const deadline = Date.now() + 60_000;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const poll = async () => {
      if (cancelled) return;
      if (Date.now() >= deadline) {
        setPublishError(
          `The ${deployment.host === "github" ? "GitHub Pages" : "Netlify"} deployment is still processing. You can check it again with your token.`
        );
        return;
      }
      try {
        const result = await checkDeployment.mutateAsync({
          id: deployment.id,
          token,
        });
        if (cancelled) return;
        setDeployment({ ...result, host: deployment.host });
        websiteArtifactStore.patch({
          deployment: { ...result, host: deployment.host } as SavedDeployment,
        });
        if (result.state === "processing")
          timer = setTimeout(() => void poll(), 2_000);
        else setToken("");
      } catch {
        if (!cancelled)
          setPublishError(
            "The deployment status could not be checked. Your token remains only in this page for a retry."
          );
      }
    };
    timer = setTimeout(() => void poll(), 2_000);
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [deployment?.id, deployment?.state, token, checkDeployment.mutateAsync]);

  if (loading || !isAuthenticated) return <Gate />;

  async function createWebsite() {
    if (!brief.trim() || build.isPending) return;
    setBuildError("");
    setPublishError("");
    websiteArtifactStore.patch({ brief: brief.trim() });
    try {
      await build.mutateAsync({ brief: brief.trim() });
    } catch {
      // The handled mutation error is shown in the page without a global overlay.
    }
  }

  async function readHtmlFile(file: File | undefined) {
    if (!file) return;
    setImportError("");
    if (!/\.html?$/i.test(file.name)) {
      setImportError("Choose a .html or .htm file.");
      return;
    }
    if (file.size > 200_000) {
      setImportError(
        "This HTML file is too large. Keep imported source under 200 KB."
      );
      return;
    }
    try {
      setImportFilename(file.name);
      setImportHtml(await file.text());
    } catch {
      setImportError(
        "The HTML file could not be read. Try pasting the source instead."
      );
    }
  }

  async function importWebsiteArtifact() {
    if (!importHtml.trim() || importWebsite.isPending) return;
    setImportError("");
    try {
      await importWebsite.mutateAsync({
        filename: importFilename.trim() || "imported-website.html",
        html: importHtml,
      });
    } catch {
      // The handled mutation error is displayed beside the import controls.
    }
  }

  function openPublish() {
    if (!artifact || publish.isPending) return;
    setHost(null);
    setSiteName("");
    setToken("");
    setPublishError("");
    setPublishOpen(true);
  }

  function closePublish() {
    if (publish.isPending) return;
    setPublishOpen(false);
    setHost(null);
    setSiteName("");
    setToken("");
  }

  function exportHtml() {
    if (!artifact) return;
    if (exportTicket.data?.url) {
      const a = document.createElement("a");
      a.href = exportTicket.data.url;
      a.download = "adus-website.html";
      a.target = "_blank";
      a.rel = "noopener";
      document.body.appendChild(a);
      a.click();
      a.remove();
      return;
    }
    const fileName =
      (siteName.trim() || artifact.title || "adus-website")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "") || "adus-website";
    saveFile(
      new File([artifact.html], `${fileName}.html`, {
        type: "text/html;charset=utf-8",
      })
    );
  }

  async function shareHtml() {
    if (!artifact) return;
    try {
      const fileName =
        (siteName.trim() || artifact.title || "adus-website")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, "") || "adus-website";
      const shared = await shareFile(
        new File([artifact.html], `${fileName}.html`, {
          type: "text/html;charset=utf-8",
        })
      );
      if (!shared) {
        setPublishError(
          "File sharing is not supported in this browser. Use Export .html instead."
        );
      }
    } catch {
      setPublishError(
        "The HTML file could not be shared. Use Export .html instead."
      );
    }
  }

  async function publishWebsite() {
    if (
      !artifact ||
      (host !== "netlify" && host !== "github") ||
      !siteName.trim() ||
      !token.trim() ||
      publish.isPending
    )
      return;
    setPublishError("");
    const publishingWebsiteId = artifact.id;
    try {
      const result = await publish.mutateAsync({
        websiteId: artifact.id,
        host,
        siteName: siteName.trim(),
        token: token.trim(),
        confirm: true,
      });
      if (artifactIdRef.current !== publishingWebsiteId) return;
      setDeployment({ ...result, host });
      websiteArtifactStore.patch({
        deployment: { ...result, host } as SavedDeployment,
      });
      setPublishOpen(false);
      setHost(null);
      setSiteName("");
      if (result.state !== "processing") setToken("");
    } catch (error) {
      setPublishError(
        safeErrorMessage(
          error,
          "The selected host could not complete this deployment. The draft is still available to retry."
        )
      );
      setToken("");
    }
  }

  async function checkDeploymentNow() {
    if (
      !deployment ||
      deployment.state !== "processing" ||
      !token ||
      checkDeployment.isPending
    )
      return;
    try {
      const result = await checkDeployment.mutateAsync({
        id: deployment.id,
        token,
      });
      setDeployment({ ...result, host: deployment.host });
      websiteArtifactStore.patch({
        deployment: { ...result, host: deployment.host } as SavedDeployment,
      });
      if (result.state !== "processing") setToken("");
      else
        setPublishError(
          `${deployment.host === "github" ? "GitHub Pages" : "Netlify"} is still processing this deployment. You can check again shortly.`
        );
    } catch {
      setPublishError(
        "The deployment status could not be checked. Your token remains only in this page for a retry."
      );
    }
  }

  return (
    <WorkspaceShell
      title="Build lab"
      subtitle="Describe the outcome. Adus creates a rendered website preview, then asks which host you want before anything can go live."
    >
      <div className="min-h-screen bg-[#0a0d14] text-white">
        <header className="sticky top-0 z-10 flex h-[76px] items-center justify-between border-b border-white/[0.08] bg-[#0a0d14]/85 px-5 backdrop-blur-xl sm:px-8">
          <a
            href="/"
            className="flex items-center gap-3 text-sm text-white/60 hover:text-white"
          >
            <ArrowLeft size={17} /> Back to workspace
          </a>
          <div className="flex items-center gap-2 text-xs text-white/45">
            <span
              className={`h-1.5 w-1.5 rounded-full ${deployment?.state === "published" && deployment.url ? "bg-emerald-300" : "bg-cyan-300"}`}
            />
            {deployment?.state === "published" && deployment.url
              ? "Published"
              : deployment?.state === "processing"
                ? "Publishing…"
                : "Build preview"}
          </div>
        </header>
        <main className="adus-grid mx-auto w-full min-w-0 max-w-[1500px] px-0 py-7 sm:px-8 lg:py-10">
          <div className="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-cyan-200/75">
                <span className="h-px w-8 bg-cyan-300/70" /> Build lab /
                rendered output
              </div>
              <h1 className="text-4xl font-extrabold tracking-[-0.07em] sm:text-6xl">
                Make it{" "}
                <span className="bg-gradient-to-r from-cyan-200 via-white to-violet-200 bg-clip-text text-transparent">
                  real.
                </span>
              </h1>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-white/50">
                Review the exact generated HTML in the live preview. Regenerate
                it when needed. Publishing always requires a host choice and a
                separate final approval.
              </p>
            </div>
            <div className="flex items-center gap-2 rounded-2xl border border-white/[0.08] bg-white/[0.035] px-4 py-3 text-xs text-white/50">
              <Eye size={16} className="text-cyan-200" /> Live rendered preview
            </div>
          </div>
          <div className="grid gap-6 xl:grid-cols-[360px_minmax(0,1fr)]">
            <section className="adus-glass h-fit rounded-[1.75rem] border border-white/[0.1] p-4 sm:p-6">
              <div className="mb-5 flex items-center gap-2 text-sm font-semibold">
                <Pencil size={17} className="text-cyan-200" /> Website brief
              </div>
              <label className="block text-xs text-white/45">
                What should Adus create?
                <textarea
                  value={brief}
                  onChange={event => setBrief(event.target.value)}
                  rows={12}
                  className="mt-2 w-full resize-y rounded-2xl border border-white/10 bg-[#080b12]/80 p-3 text-sm leading-6 text-white outline-none placeholder:text-white/20 focus:border-cyan-200/40"
                />
              </label>
              <Button
                onClick={() => void createWebsite()}
                disabled={build.isPending || !brief.trim()}
                className="mt-4 h-12 w-full rounded-xl bg-cyan-300 font-bold text-slate-950 hover:bg-cyan-200"
              >
                {build.isPending ? (
                  <>
                    <Loader2 size={17} className="mr-2 animate-spin" /> Creating
                    preview…
                  </>
                ) : (
                  <>
                    <Sparkles size={17} className="mr-2" /> Create website
                  </>
                )}
              </Button>
              {buildError && (
                <div className="mt-4 flex gap-2 rounded-xl border border-rose-300/15 bg-rose-300/[0.06] p-3 text-xs leading-5 text-rose-100">
                  <AlertCircle size={15} className="mt-0.5 shrink-0" />{" "}
                  {buildError}
                </div>
              )}
              <div className="mt-6 border-t border-white/[0.08] pt-5">
                <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
                  <FileUp size={16} className="text-violet-200" /> Import HTML
                </div>
                <p className="text-xs leading-5 text-white/40">
                  Bring another complete .html/.htm document into your private
                  preview. The original source is preserved for export and
                  publishing; only preview scaffolding is added inside the
                  sandbox.
                </p>
                <input
                  ref={importFileRef}
                  type="file"
                  accept=".html,.htm,text/html"
                  className="sr-only"
                  onChange={event => void readHtmlFile(event.target.files?.[0])}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => importFileRef.current?.click()}
                  className="mt-3 h-10 w-full rounded-xl border-white/15 bg-transparent text-white hover:bg-white/5"
                >
                  <FileUp size={15} className="mr-2" /> Choose .html file
                </Button>
                <input
                  value={importFilename}
                  onChange={event => setImportFilename(event.target.value)}
                  aria-label="Imported HTML filename"
                  placeholder="imported-website.html"
                  className="mt-3 h-10 w-full rounded-xl border border-white/10 bg-[#080b12]/80 px-3 text-xs text-white outline-none placeholder:text-white/20 focus:border-violet-200/40"
                />
                <textarea
                  value={importHtml}
                  onChange={event => setImportHtml(event.target.value)}
                  rows={5}
                  aria-label="Paste complete HTML"
                  placeholder="Or paste a complete <html> document here…"
                  className="mt-3 w-full resize-y rounded-xl border border-white/10 bg-[#080b12]/80 p-3 text-xs leading-5 text-white outline-none placeholder:text-white/20 focus:border-violet-200/40"
                />
                <Button
                  type="button"
                  onClick={() => void importWebsiteArtifact()}
                  disabled={importWebsite.isPending || !importHtml.trim()}
                  className="mt-3 h-10 w-full rounded-xl bg-violet-200 font-bold text-slate-950 hover:bg-violet-100"
                >
                  {importWebsite.isPending ? (
                    <>
                      <Loader2 size={15} className="mr-2 animate-spin" />{" "}
                      Importing…
                    </>
                  ) : (
                    <>
                      <FileUp size={15} className="mr-2" /> Import into preview
                    </>
                  )}
                </Button>
                {importError && (
                  <div className="mt-3 flex gap-2 rounded-xl border border-rose-300/15 bg-rose-300/[0.06] p-3 text-xs leading-5 text-rose-100">
                    <AlertCircle size={15} className="mt-0.5 shrink-0" />{" "}
                    {importError}
                  </div>
                )}
              </div>
              <div className="mt-5 space-y-3 text-xs leading-5 text-white/40">
                <div className="flex gap-2">
                  <PanelLeft
                    size={15}
                    className="mt-0.5 shrink-0 text-cyan-200/70"
                  />{" "}
                  Adus generates a complete self-contained visual page with
                  responsive layout and styling.
                </div>
                <div className="flex gap-2">
                  <PanelRight
                    size={15}
                    className="mt-0.5 shrink-0 text-violet-200/70"
                  />{" "}
                  Publishing is a separate approval step—nothing goes live
                  silently.
                </div>
              </div>
            </section>
            <section className="adus-glass min-h-[720px] min-w-0 max-w-full overflow-hidden rounded-[1.75rem] border border-white/[0.1]">
              <div className="flex items-center justify-between border-b border-white/[0.08] px-4 py-3 sm:px-5">
                <div className="min-w-0">
                  <div className="truncate text-sm font-semibold text-white/80">
                    {artifact?.title ?? "Your website preview"}
                  </div>
                  <div className="truncate text-[10px] text-white/30">
                    {artifact?.summary ??
                      "Create a website to see the rendered result here."}
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {artifact && (
                    <button
                      onClick={() => {
                        setArtifact(null);
                        setDeployment(null);
                        websiteArtifactStore.patch({
                          artifact: null,
                          deployment: null,
                        });
                        setPublishError("");
                        setToken("");
                      }}
                      className="hidden rounded-lg border border-white/10 px-3 py-2 text-[10px] text-white/45 hover:bg-white/5 sm:block"
                    >
                      Start over
                    </button>
                  )}
                  {artifact && (
                    <Button
                      onClick={openPublish}
                      disabled={
                        publish.isPending || deployment?.state === "processing"
                      }
                      className="h-9 rounded-lg bg-emerald-300 px-3 text-[10px] font-bold text-slate-950 hover:bg-emerald-200"
                    >
                      {deployment?.state === "published" && deployment.url ? (
                        <>
                          <Check size={13} className="mr-1.5" /> Published
                        </>
                      ) : deployment?.state === "processing" ? (
                        <>
                          <Loader2 size={13} className="mr-1.5 animate-spin" />{" "}
                          Publishing…
                        </>
                      ) : (
                        <>
                          <Rocket size={13} className="mr-1.5" /> Publish
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
              {artifact && (
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.08] bg-white/[0.02] px-3 py-2 sm:px-4">
                  <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-black/20 p-1 text-[10px] text-white/50">
                    <button
                      type="button"
                      aria-pressed={previewMode === "mobile"}
                      onClick={() => setPreviewMode("mobile")}
                      className={`flex items-center gap-1.5 rounded-md px-2.5 py-1.5 ${previewMode === "mobile" ? "bg-cyan-200/15 text-cyan-100" : "hover:bg-white/5"}`}
                    >
                      <Smartphone size={13} /> Mobile fit-width
                    </button>
                    <button
                      type="button"
                      aria-pressed={previewMode === "desktop"}
                      onClick={() => setPreviewMode("desktop")}
                      className={`flex items-center gap-1.5 rounded-md px-2.5 py-1.5 ${previewMode === "desktop" ? "bg-cyan-200/15 text-cyan-100" : "hover:bg-white/5"}`}
                    >
                      <Monitor size={13} /> Desktop overview
                    </button>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setPreviewFullscreen(true)}
                    className="h-8 rounded-lg border-white/10 bg-transparent px-2.5 text-[10px] text-white/60 hover:bg-white/5"
                  >
                    <Expand size={13} /> Fullscreen
                  </Button>
                </div>
              )}
              {artifact ? (
                <div className="flex min-h-[620px] w-full min-w-0 justify-center overflow-auto bg-slate-100 p-0 sm:p-4">
                  <WebsitePreview
                    html={normalizePreviewHtml(artifact.html)}
                    mode={previewMode}
                  />
                </div>
              ) : (
                <div className="flex min-h-[620px] items-center justify-center p-6 text-center sm:p-8">
                  <div className="max-w-sm">
                    <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-300/10 text-cyan-200">
                      <Globe2 size={28} />
                    </div>
                    <h2 className="text-2xl font-bold tracking-[-0.05em]">
                      No code wall.
                    </h2>
                    <p className="mt-3 text-sm leading-6 text-white/40">
                      Your finished website will appear here as a live preview
                      with a Publish button.
                    </p>
                  </div>
                </div>
              )}
            </section>
          </div>
          {deployment?.state === "published" && deployment.url && (
            <div className="mt-6 flex flex-col gap-2 rounded-2xl border border-emerald-200/15 bg-emerald-200/[0.06] p-4 text-sm text-emerald-50 sm:flex-row sm:items-center sm:justify-between">
              <span>
                <strong className="font-semibold">Published and live.</strong>{" "}
                Your approved static page is available at{" "}
                <a
                  href={deployment.url}
                  target="_blank"
                  rel="noreferrer"
                  className="underline underline-offset-2"
                >
                  {deployment.url}
                </a>
                .
              </span>
              <Check size={18} className="shrink-0 text-emerald-200" />
            </div>
          )}
          {deployment?.state === "processing" && (
            <div className="mt-6 flex flex-col gap-3 rounded-2xl border border-cyan-200/15 bg-cyan-200/[0.05] p-4 text-xs leading-6 text-cyan-50 sm:flex-row sm:items-center">
              <Loader2
                size={15}
                className="shrink-0 animate-spin text-cyan-200"
              />
              <span className="flex-1">
                <strong className="font-semibold">
                  {deployment.host === "github" ? "GitHub Pages" : "Netlify"} is
                  processing the deployment.
                </strong>{" "}
                We will check for a ready HTTPS URL for up to 60 seconds. Your
                draft remains available if it takes longer.
              </span>
              {token && (
                <Button
                  onClick={() => void checkDeploymentNow()}
                  disabled={checkDeployment.isPending}
                  variant="outline"
                  className="h-9 shrink-0 border-cyan-200/20 bg-transparent text-cyan-50 hover:bg-cyan-200/10"
                >
                  {checkDeployment.isPending ? (
                    <Loader2 size={14} className="mr-2 animate-spin" />
                  ) : null}{" "}
                  Check status
                </Button>
              )}
            </div>
          )}
          {publishError && (
            <div className="mt-6 flex items-start gap-3 rounded-2xl border border-rose-200/15 bg-rose-200/[0.05] p-4 text-xs leading-6 text-rose-50">
              <AlertCircle size={15} className="mt-1 shrink-0 text-rose-200" />{" "}
              <span>{publishError}</span>
            </div>
          )}
          <div className="mt-6 flex items-start gap-3 rounded-2xl border border-amber-200/10 bg-amber-200/[0.04] p-4 text-xs leading-6 text-white/45">
            <Rocket size={15} className="mt-1 shrink-0 text-amber-200" />
            <span>
              <strong className="font-semibold text-white/70">
                Publishing note:
              </strong>{" "}
              this builder publishes only the reviewed static HTML. Preview
              scripts may run inside an opaque sandbox for interaction checks;
              they cannot access this workspace, cookies, or submit forms.
            </span>
          </div>
        </main>
        {publishOpen && artifact && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
            <section
              role="dialog"
              aria-modal="true"
              aria-labelledby="publish-title"
              className="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-[1.75rem] border border-white/10 bg-[#111722] p-6 shadow-2xl sm:p-8"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan-200/70">
                    Choose a host
                  </div>
                  <h2
                    id="publish-title"
                    className="mt-2 text-2xl font-bold tracking-[-0.05em]"
                  >
                    Where should this website go?
                  </h2>
                  <p className="mt-2 text-sm leading-6 text-white/50">
                    Review the generated page above, select a host, then confirm
                    the public deployment.
                  </p>
                </div>
                <button
                  onClick={closePublish}
                  aria-label="Close publish dialog"
                  className="rounded-lg p-2 text-white/40 hover:bg-white/5 hover:text-white"
                >
                  <X size={18} />
                </button>
              </div>
              <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {(["netlify", "github", "vercel", "other"] as Host[]).map(
                  option => (
                    <button
                      key={option}
                      onClick={() => {
                        setHost(option);
                        setPublishError("");
                      }}
                      className={`rounded-xl border p-4 text-left transition ${host === option ? "border-cyan-200/60 bg-cyan-200/10" : "border-white/10 bg-white/[0.03] hover:border-white/25"}`}
                    >
                      <div className="text-sm font-semibold">
                        {hostLabels[option]}
                      </div>
                      <div className="mt-1 text-[11px] leading-5 text-white/40">
                        {option === "netlify"
                          ? "Static HTML deployment"
                          : option === "github"
                            ? "New public repository"
                            : option === "vercel"
                              ? "Adapter coming soon"
                              : "Export HTML"}
                      </div>
                    </button>
                  )
                )}
              </div>
              {host && hostingConfiguration.data && (
                <div className="mt-4 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-xs leading-5 text-white/55">
                  {host === "other" ? (
                    <>
                      Export is available now. No provider request will be made.
                    </>
                  ) : host === "vercel" ? (
                    <>
                      Vercel is not connected in this release. Export the
                      reviewed HTML instead.
                    </>
                  ) : (
                    <>
                      {hostLabels[host]} is ready for a per-operation token.
                      {hostingConfiguration.data[host]
                        .serverCredentialConfigured
                        ? " A server-side provider credential is configured, but this screen still uses the token you explicitly enter."
                        : " No server-side provider credential is configured; enter your own short-lived token to continue."}
                    </>
                  )}
                </div>
              )}
              {host === "netlify" && (
                <div className="mt-6 space-y-4">
                  <label className="block text-xs text-white/55">
                    Netlify site name
                    <input
                      value={siteName}
                      onChange={event => setSiteName(event.target.value)}
                      placeholder="my-public-site"
                      autoComplete="off"
                      className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none placeholder:text-white/20 focus:border-cyan-200/50"
                    />
                  </label>
                  <label className="block text-xs text-white/55">
                    Personal access token
                    <input
                      type="password"
                      value={token}
                      onChange={event => setToken(event.target.value)}
                      placeholder="Paste your Netlify token"
                      autoComplete="new-password"
                      className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none placeholder:text-white/20 focus:border-cyan-200/50"
                    />
                  </label>
                  <p className="text-xs leading-5 text-white/40">
                    Create a token in{" "}
                    <a
                      href="https://app.netlify.com/user/applications#personal-access-tokens"
                      target="_blank"
                      rel="noreferrer"
                      className="text-cyan-200 underline underline-offset-2"
                    >
                      Netlify personal access tokens
                    </a>
                    . It is used only for this operation, never saved, logged,
                    or placed in local storage.
                  </p>
                </div>
              )}
              {host === "github" && (
                <div className="mt-6 space-y-4">
                  <div className="rounded-xl border border-amber-200/25 bg-amber-200/[0.08] p-4 text-xs leading-6 text-amber-50">
                    <strong className="font-semibold">
                      This creates a new public repository and never overwrites
                      an existing repository.
                    </strong>{" "}
                    Choose a repository name that does not already exist in the
                    account.
                  </div>
                  <label className="block text-xs text-white/55">
                    New repository name
                    <input
                      value={siteName}
                      onChange={event => setSiteName(event.target.value)}
                      placeholder="my-public-site"
                      autoComplete="off"
                      className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none placeholder:text-white/20 focus:border-cyan-200/50"
                    />
                  </label>
                  <label className="block text-xs text-white/55">
                    GitHub personal access token
                    <input
                      type="password"
                      value={token}
                      onChange={event => setToken(event.target.value)}
                      placeholder="Paste your GitHub token"
                      autoComplete="new-password"
                      className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none placeholder:text-white/20 focus:border-cyan-200/50"
                    />
                  </label>
                  <p className="text-xs leading-5 text-white/40">
                    The token is requested in this app only for this operation;
                    it is never saved, logged, or placed in local storage.
                    GitHub Pages is static hosting, so it cannot run backend
                    code or business transactions. Read the{" "}
                    <a
                      href="https://docs.github.com/en/pages/getting-started-with-github-pages/about-github-pages"
                      target="_blank"
                      rel="noreferrer"
                      className="text-cyan-200 underline underline-offset-2"
                    >
                      GitHub Pages documentation
                    </a>{" "}
                    before publishing.
                  </p>
                </div>
              )}
              {host && host !== "netlify" && host !== "github" && (
                <div className="mt-6 rounded-xl border border-amber-200/15 bg-amber-200/[0.05] p-4 text-xs leading-6 text-amber-50">
                  {hostLabels[host]} publishing is not configured yet. No
                  provider request will be made. You can export the exact
                  reviewed HTML now.
                </div>
              )}
              {host && (
                <div className="mt-6 rounded-xl border border-rose-200/15 bg-rose-200/[0.05] p-4 text-xs leading-6 text-rose-50">
                  <strong className="font-semibold">
                    This publishes to the public internet.
                  </strong>{" "}
                  The page shown above is the exact HTML that will be uploaded.
                  Confirm only after you have reviewed it.
                </div>
              )}
              {publishError && (
                <div className="mt-4 flex gap-2 rounded-xl border border-rose-300/15 bg-rose-300/[0.06] p-3 text-xs leading-5 text-rose-100">
                  <AlertCircle size={15} className="mt-0.5 shrink-0" />{" "}
                  {publishError}
                </div>
              )}
              <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                {host && (
                  <Button
                    onClick={exportHtml}
                    variant="outline"
                    className="h-11 rounded-xl border-white/15 bg-transparent text-white hover:bg-white/5"
                  >
                    <Download size={16} className="mr-2" /> Export .html
                  </Button>
                )}
                {host && (
                  <Button
                    onClick={() => void shareHtml()}
                    variant="outline"
                    className="h-11 rounded-xl border-white/15 bg-transparent text-white hover:bg-white/5"
                  >
                    <Share2 size={16} className="mr-2" /> Share .html
                  </Button>
                )}
                <Button
                  onClick={closePublish}
                  variant="outline"
                  className="h-11 rounded-xl border-white/15 bg-transparent text-white hover:bg-white/5"
                >
                  Cancel
                </Button>
                {(host === "netlify" || host === "github") && (
                  <Button
                    onClick={() => void publishWebsite()}
                    disabled={
                      publish.isPending || !siteName.trim() || !token.trim()
                    }
                    className="h-11 rounded-xl bg-cyan-300 font-bold text-slate-950 hover:bg-cyan-200"
                  >
                    {publish.isPending ? (
                      <>
                        <Loader2 size={16} className="mr-2 animate-spin" />{" "}
                        Publishing…
                      </>
                    ) : (
                      <>
                        Publish this website to{" "}
                        {host === "github" ? "GitHub Pages" : "Netlify"}
                      </>
                    )}
                  </Button>
                )}
              </div>
            </section>
          </div>
        )}
        {previewFullscreen && artifact && (
          <div className="fixed inset-0 z-50 flex flex-col bg-black/85 p-2 backdrop-blur-sm sm:p-4">
            <div className="flex items-center justify-between pb-2 text-white">
              <div className="min-w-0 truncate text-sm font-semibold">
                {artifact.title} · full site preview
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => setPreviewFullscreen(false)}
                className="h-9 shrink-0 border-white/20 bg-transparent text-white hover:bg-white/10"
              >
                <X size={16} /> Close
              </Button>
            </div>
            <div className="min-h-0 flex-1 overflow-auto rounded-xl bg-slate-100 p-2 sm:p-4">
              <div className="mb-2 flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setPreviewMode("mobile")}
                >
                  Mobile fit-width
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setPreviewMode("desktop")}
                >
                  Desktop overview
                </Button>
              </div>
              <WebsitePreview
                html={normalizePreviewHtml(artifact.html)}
                mode={previewMode}
                title="Adus full website preview"
              />
            </div>
          </div>
        )}
      </div>
    </WorkspaceShell>
  );
}
