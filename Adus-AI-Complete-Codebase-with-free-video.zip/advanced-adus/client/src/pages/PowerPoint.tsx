import MediaSaveActions from "@/components/MediaSaveActions";
import WorkspaceShell from "@/components/WorkspaceShell";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Check,
  ImagePlus,
  Loader2,
  Presentation,
  RefreshCw,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { PowerPointPicture, PowerPointTaskRecord } from "@shared/powerpoint";

const MAX_PICTURE_BYTES = 8 * 1024 * 1024;
const MAX_PICTURES = 6;
const MAX_POLL_MS = 10 * 60 * 1000;
const POLL_INTERVAL_MS = 7000;

type HistoryResponse = {
  tasks: Array<{ id: string; payload: PowerPointTaskRecord; updatedAt: number }>;
};

type PicturePreview = PowerPointPicture & { previewUrl: string };

function messageFor(error: unknown, fallback: string) {
  return error instanceof Error && error.message ? error.message : fallback;
}

function statusLabel(task: PowerPointTaskRecord) {
  switch (task.state) {
    case "completed":
      return "Completed";
    case "failed":
      return "Needs attention";
    case "waiting_input":
      return "Awaiting input";
    case "waiting_action":
      return "Awaiting action";
    case "queued":
      return "Queued";
    case "running":
      return "Working";
    default:
      return "Status unknown";
  }
}

function statusClass(task: PowerPointTaskRecord) {
  if (task.state === "completed") return "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-200";
  if (task.state === "failed") return "border-destructive/30 bg-destructive/10 text-destructive";
  if (task.state === "waiting_input" || task.state === "waiting_action") return "border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-200";
  return "border-primary/25 bg-primary/10 text-primary";
}

function promptProhibitsPictures(prompt: string) {
  return /\b(no|without|don't|do not|avoid|exclude|omit|text[- ]only|picture[- ]free|image[- ]free)\b[\s\w-]{0,32}\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b/i.test(prompt) || /\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b[\s\w-]{0,24}\b(no|not|none|without|excluded|omitted)\b/i.test(prompt) || /(?:sin|sans|sem|ohne|bez|بدون|من دون|لا|画像なし|画像は不要|이미지 없이|不要图片|无图片)[\s\w-]{0,10}(?:pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?|imágenes?|fotos?|bilder|صور|画像|イメージ|사진|이미지|图片)/i.test(prompt);
}

function promptRequestsPictures(prompt: string) {
  return /\b(add|include|use|find|search(?: for)?|source|generate|create|illustrate|visuali[sz]e|show|with)\b[\s\w-]{0,48}\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b/i.test(prompt) || /\b(pictures?|images?|photos?|photographs?|visuals?|illustrations?|graphics?)\b[\s\w-]{0,24}\b(for|in|throughout|on|of)\b/i.test(prompt) || /(?:ajouter|inclure|utiliser|chercher|générer|créer|avec des|incluir imágenes|com imagens|mit bildern|صور|画像|이미지|图片)/i.test(prompt);
}

export default function PowerPoint() {
  const { user } = useAuth();
  const [prompt, setPrompt] = useState("");
  const [slideCount, setSlideCount] = useState(8);
  const [effectsPrompt, setEffectsPrompt] = useState("");
  const [allowPictures, setAllowPictures] = useState(false);
  const [pictures, setPictures] = useState<PicturePreview[]>([]);
  const [task, setTask] = useState<PowerPointTaskRecord | null>(null);
  const [notice, setNotice] = useState("");
  const [pollStartedAt, setPollStartedAt] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollTimerRef = useRef<number | null>(null);
  const pollingBusyRef = useRef(false);

  const readiness = trpc.powerpoint.readiness.useQuery(undefined, {
    enabled: Boolean(user), retry: false, staleTime: 25_000, meta: { handledError: true },
  });
  const history = trpc.powerpoint.history.useQuery(undefined, {
    enabled: Boolean(user), retry: false, staleTime: 30_000, meta: { handledError: true },
  });
  const generate = trpc.powerpoint.generate.useMutation({ meta: { handledError: true } });
  const poll = trpc.powerpoint.poll.useMutation({ meta: { handledError: true } });
  const sendMessage = trpc.powerpoint.sendMessage.useMutation({ meta: { handledError: true } });
  const [followup, setFollowup] = useState("");
  const taskRecordId = task?.recordId;
  const pictureProhibited = promptProhibitsPictures(prompt);
  const pictureRequested = promptRequestsPictures(prompt);
  const picturesPermitted = !pictureProhibited && (allowPictures || pictureRequested);
  const canGenerate = prompt.trim().length >= 2 && Boolean(readiness.data?.available) && !generate.isPending;

  useEffect(() => {
    const latest = (history.data as HistoryResponse | undefined)?.tasks?.[0]?.payload;
    if (latest && !task) {
      setTask(latest);
      setPollStartedAt(Date.now());
    }
  }, [history.data, task]);

  const pollKnownTask = useCallback(async (manual = false) => {
    if (pollingBusyRef.current || !taskRecordId) return;
    if (!manual && task && !["queued", "running", "unknown"].includes(task.state)) return;
    if (!manual && pollStartedAt && Date.now() - pollStartedAt > MAX_POLL_MS) {
      setNotice("Polling paused after ten minutes. Check result to resume this saved task without creating a duplicate.");
      return;
    }
    pollingBusyRef.current = true;
    try {
      const result = await poll.mutateAsync({ taskRecordId });
      setTask(result);
      if (result.state === "completed") setNotice(result.statusMessage ?? "The PPTX is saved to your workspace.");
      if (result.state === "waiting_input" || result.state === "waiting_action") setNotice(result.statusMessage ?? "The Slides task is awaiting attention.");
    } catch (error) {
      setNotice(messageFor(error, "Could not refresh this saved Slides task."));
    } finally {
      pollingBusyRef.current = false;
    }
  }, [poll, pollStartedAt, task, taskRecordId]);

  useEffect(() => {
    if (!task || !taskRecordId || !["queued", "running", "unknown"].includes(task.state)) return;
    if (pollTimerRef.current) window.clearInterval(pollTimerRef.current);
    pollTimerRef.current = window.setInterval(() => void pollKnownTask(), POLL_INTERVAL_MS);
    return () => {
      if (pollTimerRef.current) window.clearInterval(pollTimerRef.current);
      pollTimerRef.current = null;
    };
  }, [pollKnownTask, task, taskRecordId]);

  async function onPicturesSelected(files: FileList | null) {
    if (!files?.length) return;
    setNotice("");
    if (!allowPictures) {
      setNotice("Allow pictures before adding them. No picture is used by default.");
      return;
    }
    const available = MAX_PICTURES - pictures.length;
    if (available <= 0) {
      setNotice(`You can attach up to ${MAX_PICTURES} pictures.`);
      return;
    }
    const selected = Array.from(files).slice(0, available);
    try {
      const next = await Promise.all(selected.map(async file => {
        if (!/^image\/(png|jpe?g|webp|gif)$/i.test(file.type)) throw new Error("Choose PNG, JPEG, WebP, or GIF pictures.");
        if (file.size > MAX_PICTURE_BYTES) throw new Error("Each picture must be 8 MB or smaller.");
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result));
          reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
          reader.readAsDataURL(file);
        });
        return { filename: file.name, mimeType: file.type, dataUrl, previewUrl: dataUrl };
      }));
      setPictures(current => [...current, ...next]);
    } catch (error) {
      setNotice(messageFor(error, "Could not add those pictures."));
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setNotice("");
    if (!prompt.trim()) {
      setNotice("Describe the presentation you want to create.");
      return;
    }
    if (!readiness.data?.available) {
      setNotice(readiness.data?.message ?? "Slides generation is not connected yet.");
      return;
    }
    try {
      const result = await generate.mutateAsync({
        prompt: prompt.trim(),
        slideCount,
        effectsPrompt: effectsPrompt.trim(),
        allowPictures: picturesPermitted,
        pictures: picturesPermitted ? pictures.map(({ previewUrl: _previewUrl, ...picture }) => picture) : [],
      });
      setTask(result);
      setPollStartedAt(Date.now());
      setNotice("Request submitted. Slides is preparing an editable PPTX; it is not ready until a real output is saved.");
    } catch (error) {
      setNotice(messageFor(error, "The Slides request could not be created."));
    }
  }

  async function followUp() {
    if (!taskRecordId || !followup.trim()) return;
    try {
      const result = await sendMessage.mutateAsync({ taskRecordId, content: followup.trim() });
      setTask(result);
      setFollowup("");
      setPollStartedAt(Date.now());
      setNotice("Follow-up sent to the saved Slides task.");
    } catch (error) {
      setNotice(messageFor(error, "The follow-up could not be sent."));
    }
  }

  return (
    <WorkspaceShell title="PowerPoint generator" subtitle="Describe the deck you want, choose its size, and optionally request effects or provide pictures. The outline is created internally; you receive a native editable PPTX when Slides returns one.">
      <div className="mx-auto grid max-w-5xl gap-5 pb-10">
        <form onSubmit={submit} className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_300px]">
          <Card className="overflow-hidden border-primary/15 shadow-sm">
            <CardHeader className="border-b bg-primary/[.04]">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="mb-2 flex items-center gap-2 text-primary"><Presentation className="size-4" /><span className="font-mono text-[10px] uppercase tracking-[.2em]">One request</span></div>
                  <CardTitle className="text-2xl">What should this presentation say?</CardTitle>
                  <CardDescription className="mt-2 max-w-xl">Use one clear prompt. Adus shapes the slide story internally, then asks the Manus Slides skill for the actual editable deck.</CardDescription>
                </div>
                <Badge variant="outline" className="shrink-0">4–12 slides</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-5 pt-6">
              <div>
                <Label htmlFor="ppt-prompt">Presentation prompt</Label>
                <Textarea id="ppt-prompt" value={prompt} onChange={event => setPrompt(event.target.value)} placeholder="Example: Create a concise board presentation explaining our three-year sustainability roadmap, the decisions needed this quarter, and the risks we should monitor." rows={7} maxLength={12000} className="mt-2 resize-y text-base leading-7" />
                <div className="mt-1 text-right text-xs text-muted-foreground">{prompt.length.toLocaleString()} / 12,000</div>
              </div>
              <div>
                <div className="flex items-center justify-between"><Label htmlFor="ppt-slide-count">Slide count</Label><span className="text-sm font-medium text-primary">{slideCount} slides</span></div>
                <input id="ppt-slide-count" aria-label="Slide count" type="range" min={4} max={12} value={slideCount} onChange={event => setSlideCount(Number(event.target.value))} className="mt-3 w-full accent-primary" />
                <div className="mt-1 flex justify-between text-xs text-muted-foreground"><span>4 concise</span><span>12 detailed</span></div>
              </div>
              <div>
                <Label htmlFor="ppt-effects">Optional animations or effects</Label>
                <Textarea id="ppt-effects" value={effectsPrompt} onChange={event => setEffectsPrompt(event.target.value)} placeholder="Example: Use a restrained fade between sections and subtle emphasis on the decision slide. Leave blank for no request." rows={3} maxLength={2000} className="mt-2 resize-y" />
                <p className="mt-1 text-xs leading-5 text-muted-foreground">This preference is passed to Slides. Availability depends on the provider and is never promised as supported.</p>
              </div>
              <div className="rounded-xl border border-dashed p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-start gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"><ImagePlus className="size-4" /></span><div><div className="text-sm font-medium">Add pictures</div><p className="mt-1 text-xs leading-5 text-muted-foreground">Optional. A clear picture request in your prompt or this toggle permits relevant pictures. Attached pictures are sent as references; no unrelated imagery is added.</p></div></div>
                  <label className="inline-flex shrink-0 items-center gap-2 text-sm"><input type="checkbox" checked={allowPictures} onChange={event => setAllowPictures(event.target.checked)} className="size-4 accent-primary" />Allow pictures</label>
                </div>
                {pictureProhibited && <p className="mt-3 rounded-lg bg-amber-500/10 px-3 py-2 text-xs leading-5 text-amber-800 dark:text-amber-200">Your prompt prohibits pictures, so that instruction wins. Any attached pictures will be ignored for this request.</p>}
                {!pictureProhibited && pictureRequested && !allowPictures && <p className="mt-3 rounded-lg bg-primary/10 px-3 py-2 text-xs leading-5 text-primary">Your prompt requests pictures, so relevant picture sourcing or generation is permitted for this deck.</p>}
                {allowPictures && <div className="mt-3 flex flex-wrap items-center gap-2"><input ref={fileInputRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple className="sr-only" onChange={event => void onPicturesSelected(event.target.files)} /><Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} disabled={pictures.length >= MAX_PICTURES}><Upload className="size-4" />Choose pictures</Button><span className="text-xs text-muted-foreground">{pictures.length} / {MAX_PICTURES} attached</span></div>}
                {pictures.length > 0 && <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">{pictures.map((picture, index) => <div key={`${picture.filename}-${index}`} className="group relative overflow-hidden rounded-lg border bg-muted"><img src={picture.previewUrl} alt={picture.filename} className="aspect-square w-full object-cover" /><button type="button" aria-label={`Remove ${picture.filename}`} onClick={() => setPictures(current => current.filter((_, itemIndex) => itemIndex !== index))} className="absolute right-1 top-1 rounded-full bg-background/90 p-1 text-foreground shadow"><X className="size-3" /></button></div>)}</div>}
              </div>
              <Button type="submit" size="lg" className="w-full sm:w-auto" disabled={!canGenerate}><Sparkles className="size-4" />{generate.isPending ? "Preparing request…" : "Generate PPTX"}</Button>
            </CardContent>
          </Card>
          <aside className="space-y-5">
            <Card>
              <CardHeader><CardTitle className="text-base">Slides connection</CardTitle><CardDescription>Generation stays truthful: a download appears only after a real PPTX is saved.</CardDescription></CardHeader>
              <CardContent className="space-y-3"><div className="rounded-lg border bg-muted/40 p-3 text-sm leading-6">{readiness.isLoading ? "Checking the Slides connection…" : (readiness.data?.message ?? "Connection status is unavailable.")}</div><Button type="button" variant="outline" size="sm" onClick={() => void readiness.refetch()} disabled={readiness.isFetching}><RefreshCw className={readiness.isFetching ? "size-4 animate-spin" : "size-4"} />Re-check connection</Button></CardContent>
            </Card>
          </aside>
        </form>

        {notice && <Alert className="border-primary/20 bg-primary/[.04]"><AlertDescription>{notice}</AlertDescription></Alert>}

        {task && <Card aria-live="polite" className="border-primary/15"><CardHeader><div className="flex flex-wrap items-start justify-between gap-3"><div><CardTitle className="text-xl">Generation status</CardTitle><CardDescription className="mt-1">This status belongs to your authenticated workspace and can be resumed after a refresh.</CardDescription></div><Badge variant="outline" className={statusClass(task)}>{statusLabel(task)}</Badge></div></CardHeader><CardContent className="space-y-4"><div className="flex flex-col gap-3 rounded-lg border bg-muted/25 p-4 sm:flex-row sm:items-center sm:justify-between"><span className="text-sm leading-6">{task.statusMessage ?? "Slides is working on your deck."}</span><div className="flex flex-wrap items-center gap-2"><a className="text-sm text-primary underline-offset-4 hover:underline" href={task.taskUrl} target="_blank" rel="noreferrer">Open task</a><Button type="button" size="sm" variant="outline" onClick={() => void pollKnownTask(true)} disabled={poll.isPending || !taskRecordId}><RefreshCw className={poll.isPending ? "size-4 animate-spin" : "size-4"} />Check result</Button></div></div>{task.output?.url && <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/[.06] p-4"><div className="flex items-center gap-2 font-medium text-emerald-700 dark:text-emerald-200"><Check className="size-4" />Editable PPTX saved</div><p className="mt-1 text-xs leading-5 text-muted-foreground">{task.output.filename} is stored in your workspace.</p><MediaSaveActions src={task.output.url} filename={task.output.filename} className="mt-3" /></div>}{(task.state === "waiting_input" || task.state === "waiting_action") && <Alert className="border-amber-500/25 bg-amber-500/[.06]"><AlertTitle>{task.state === "waiting_input" ? "Slides is asking for input" : "Slides is awaiting an action"}</AlertTitle><AlertDescription className="mt-1">Review the saved task in Manus before responding. This app does not approve consequential actions automatically.</AlertDescription></Alert>}<div className="grid gap-3 sm:grid-cols-[1fr_auto]"><Textarea aria-label="Follow up with the saved Slides task" value={followup} onChange={event => setFollowup(event.target.value)} placeholder="Optional follow-up for the saved Slides task" rows={2} /><Button type="button" variant="outline" className="self-end" onClick={() => void followUp()} disabled={!taskRecordId || !followup.trim() || sendMessage.isPending}>{sendMessage.isPending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}Send follow-up</Button></div></CardContent></Card>}
      </div>
    </WorkspaceShell>
  );
}
