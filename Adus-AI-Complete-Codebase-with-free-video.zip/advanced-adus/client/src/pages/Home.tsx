import DashboardLayout from "@/components/DashboardLayout";
import ConversationHistory from "@/components/ConversationHistory";
import { readFiles, type Attachment } from "@/lib/attachments";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import RichText from "@/components/RichText";
import { chatFailureMessage } from "@shared/chatErrors";
import { LanguageSelect } from "@/components/LanguageSelect";
import CameraAccessHelp from "@/components/CameraAccessHelp";
import { DictationController } from "@/lib/dictation";
import {
  normalizeLanguage,
  whisperLanguageHint,
  type LanguageSelection,
} from "@shared/languages";
import {
  CameraCallController,
  browserCameraRuntime,
  initialCameraState,
  type CameraState,
} from "@/lib/cameraCall";
import {
  ArrowUpRight,
  Bot,
  CameraOff,
  BrainCircuit,
  Check,
  ChevronRight,
  CircleHelp,
  Compass,
  FileText,
  Image as ImageIcon,
  Infinity,
  KeyRound,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  Menu,
  Mic2,
  MicOff,
  Paperclip,
  Phone,
  PhoneOff,
  PenLine,
  Plus,
  Search,
  Send,
  Settings2,
  Volume2,
  RefreshCw,
  Square,
  Sparkles,
  WandSparkles,
  Video,
  Workflow,
  X,
  Zap,
} from "lucide-react";
import {
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  browserVoiceRuntime,
  VoiceCallController,
  type VoiceLanguage,
  type VoiceState,
} from "@/lib/voiceCall";
import type {
  ConversationAttachment,
  ConversationMessage,
  ConversationSummary,
} from "@shared/conversations";

type Message = Omit<ConversationMessage, "id" | "createdAt"> & {
  id?: string;
  createdAt?: number;
  failed?: boolean;
};

type HomeProps = {
  /** The navigation worker may keep Home mounted; inactive live calls are stopped. */
  active?: boolean;
  params?: Record<string | number, string | undefined>;
};

function clientId() {
  return (
    globalThis.crypto?.randomUUID?.() ??
    `${Date.now()}-${Math.random().toString(36).slice(2)}`
  );
}

function AccessGate() {
  const authError =
    typeof window !== "undefined"
      ? new URLSearchParams(window.location.search).get("authError")
      : null;
  const errorCopy =
    authError === "invalid_state"
      ? "Your sign-in session expired or opened in another browser tab. Start sign-in again."
      : authError === "callback_failed"
        ? "The sign-in service did not complete. Please try again."
        : null;
  return (
    <main className="adus-grid flex min-h-screen items-center justify-center px-5 py-10">
      <section className="adus-glass w-full max-w-lg rounded-[2rem] border border-white/10 p-8 shadow-2xl shadow-cyan-950/30 sm:p-10">
        <div className="mb-8 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-300 text-slate-950 shadow-lg shadow-cyan-300/20">
            <Sparkles size={21} />
          </div>
          <div>
            <div className="font-mono text-[11px] font-medium uppercase tracking-[0.24em] text-cyan-200">
              Adus / AI workspace
            </div>
            <div className="text-sm text-white/45">
              Advanced AI control plane
            </div>
          </div>
        </div>
        <div className="mb-8 space-y-4">
          <div className="text-4xl font-extrabold leading-tight tracking-[-0.06em] text-white">
            Your AI workspace is ready.
          </div>
          <p className="max-w-md text-sm leading-7 text-slate-300/70">
            Sign in to access Adus. Anyone with a supported account can use the
            workspace.
          </p>
        </div>
        {errorCopy && (
          <div className="mb-4 rounded-xl border border-amber-200/15 bg-amber-200/[0.06] px-4 py-3 text-xs leading-5 text-amber-100/80">
            {errorCopy}
          </div>
        )}
        <Button
          onClick={() => startLogin()}
          className="h-12 w-full rounded-xl bg-cyan-300 font-bold text-slate-950 hover:bg-cyan-200"
        >
          {errorCopy ? "Try sign-in again" : "Sign in to Adus"}{" "}
          <ArrowUpRight className="ml-2" size={17} />
        </Button>
        <div className="mt-7 flex items-center gap-2 text-xs text-slate-400/60">
          <LockKeyhole size={13} /> Sign-in required · secure by default
        </div>
      </section>
    </main>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const user = message.role === "user";
  return (
    <div
      className={`flex min-w-0 w-full gap-2 sm:gap-3 ${user ? "justify-end" : "justify-start"}`}
    >
      <div
        className={`adus-chat-bubble min-w-0 max-w-full [overflow-wrap:anywhere] rounded-2xl px-3 py-3 text-[15px] leading-7 sm:px-4 ${user ? "max-w-[92%] rounded-br-md bg-cyan-300 font-medium text-slate-950" : "w-full rounded-bl-md border border-white/[0.08] bg-white/[0.045] text-slate-200"}`}
      >
        {user ? (
          <>
            <div className="min-w-0 whitespace-pre-wrap [overflow-wrap:anywhere]">
              {message.content}
            </div>
            {message.attachmentName && (
              <div className="mt-3 overflow-hidden rounded-xl border border-slate-950/15 bg-slate-950/10 p-2 text-xs">
                <div className="flex items-center gap-2">
                  <Paperclip size={13} /> {message.attachmentName}
                </div>
                {message.attachmentUrl && (
                  <img
                    src={message.attachmentUrl}
                    alt={message.attachmentName}
                    className="mt-2 max-h-48 w-full rounded-lg object-cover"
                  />
                )}
              </div>
            )}
          </>
        ) : (
          <>
            <div className="mb-2 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.14em] text-cyan-200/55">
              <Sparkles size={11} /> {message.agent ?? "Adus Coordinator"}
            </div>
            <RichText>{message.content}</RichText>
            {message.research && (
              <div
                className="mt-3 text-[11px] leading-5 text-white/45"
                aria-label="Research status"
              >
                {message.research.status === "retrieved"
                  ? `Sources retrieved via ${message.research.engine} · ${new Date(message.research.checkedAt).toLocaleString()}`
                  : "Live sources unavailable for this answer; current details are unverified."}
              </div>
            )}
            {message.research?.searchSuggestions && (
              <iframe
                title="Google Search suggestions"
                srcDoc={message.research.searchSuggestions}
                sandbox="allow-popups allow-popups-to-escape-sandbox"
                className="mt-3 h-28 w-full max-w-full rounded-xl border-0"
              />
            )}
            {message.imageUrl && (
              <a
                href={message.imageUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-3 block overflow-hidden rounded-xl border border-white/10"
              >
                <img
                  src={message.imageUrl}
                  alt="Generated by Adus"
                  className="max-h-[480px] w-full object-cover"
                />
              </a>
            )}
            {message.openBuilder && (
              <button
                onClick={() => {
                  window.location.href = `/build?brief=${encodeURIComponent(message.builderBrief ?? "")}`;
                }}
                className="mt-4 flex items-center gap-2 rounded-xl bg-cyan-300 px-4 py-3 text-xs font-bold text-slate-950 hover:bg-cyan-200"
              >
                <WandSparkles size={15} /> Open live website builder
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default function Home({ active = true }: HomeProps = {}) {
  const { loading, isAuthenticated } = useAuth();
  const [draft, setDraft] = useState("");
  const [chatSubmitting, setChatSubmitting] = useState(false);
  const chatBusyRef = useRef(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const lastFilesRef = useRef<Attachment[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);
  const [voiceStatus, setVoiceStatus] = useState("");
  const [modelMode, setModelMode] = useState<"auto" | "fast" | "deep">("auto");
  const [voiceCallOpen, setVoiceCallOpen] = useState(false);
  const [voiceGender, setVoiceGender] = useState<"man" | "woman">("woman");
  const [callLanguage, setCallLanguage] = useState<VoiceLanguage>("auto");
  const [callState, setCallState] = useState<VoiceState>({
    active: false,
    muted: false,
    phase: "idle",
    status: "Ready to call",
    canReplay: false,
  });
  const [cameraState, setCameraState] =
    useState<CameraState>(initialCameraState);
  const [activeConversationId, setActiveConversationId] = useState<string>();
  const [conversationStatus, setConversationStatus] = useState("");
  const [failedRequest, setFailedRequest] = useState<{
    value: string;
    files: Attachment[];
    generation: number;
    threadId?: string;
  }>();
  const [removedConversation, setRemovedConversation] = useState<{
    id: string;
    title: string;
  }>();
  const {
    active: voiceCallActive,
    muted: voiceMuted,
    status: voiceCallStatus,
  } = callState;
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Hello, I’m **Adus**. Ask me anything, or attach PDFs, photos and files so we can explore them together.",
    },
  ]);
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  const dictationRef = useRef<DictationController | null>(null);
  const callLaunchRef = useRef(0);
  const voiceControllerRef = useRef<VoiceCallController | null>(null);
  const cameraControllerRef = useRef<CameraCallController | null>(null);
  const cameraPreviewRef = useRef<HTMLVideoElement>(null);
  const restoredConversationRef = useRef<string | undefined>(undefined);
  const activeConversationRef = useRef<string | undefined>(undefined);
  const archivedConversationIdsRef = useRef(new Set<string>());
  const suppressAutoSelectRef = useRef(false);
  const conversationGenerationRef = useRef(0);
  const attachCameraPreview = useCallback((video: HTMLVideoElement | null) => {
    cameraPreviewRef.current = video;
    cameraControllerRef.current?.attachPreview(video);
  }, []);
  const messagesRef = useRef(messages);
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);
  const sendMessage = trpc.adus.chat.useMutation({
    meta: { handledError: true },
  });
  const transcribeVoice = trpc.adus.transcribeVoice.useMutation({
    meta: { handledError: true },
  });
  const voiceReply = trpc.adus.chat.useMutation({
    meta: { handledError: true },
  });
  const callSpeech = trpc.adus.callSpeech.synthesize.useMutation({
    meta: { handledError: true },
  });
  const callLanguageRef = useRef(callLanguage);
  callLanguageRef.current = callLanguage;
  const callApiRef = useRef({ transcribeVoice, voiceReply, callSpeech });
  callApiRef.current = { transcribeVoice, voiceReply, callSpeech };
  const conversationList = trpc.adus.conversations.list.useQuery(undefined, {
    enabled: Boolean(isAuthenticated),
    meta: { handledError: true },
  });
  const conversation = trpc.adus.conversations.get.useQuery(
    { id: activeConversationId ?? "" },
    {
      enabled: Boolean(isAuthenticated && activeConversationId),
      meta: { handledError: true },
    }
  );
  const createConversation = trpc.adus.conversations.create.useMutation({
    meta: { handledError: true },
  });
  const appendConversation = trpc.adus.conversations.append.useMutation({
    meta: { handledError: true },
  });
  const renameConversation = trpc.adus.conversations.rename.useMutation({
    meta: { handledError: true },
  });
  const archiveConversation = trpc.adus.conversations.archive.useMutation({
    meta: { handledError: true },
  });
  const restoreConversation = trpc.adus.conversations.restore.useMutation({
    meta: { handledError: true },
  });
  useEffect(
    () => () => {
      voiceControllerRef.current?.stop();
      cameraControllerRef.current?.stop();
      cameraControllerRef.current?.attachPreview(null);
      cameraPreviewRef.current = null;
      dictationRef.current?.stop();
      ++callLaunchRef.current;
    },
    []
  );
  useEffect(() => {
    activeConversationRef.current = activeConversationId;
  }, [activeConversationId]);
  useEffect(() => {
    if (active) return;
    ++callLaunchRef.current;
    voiceControllerRef.current?.stop();
    cameraControllerRef.current?.stop();
    cameraControllerRef.current?.attachPreview(null);
    setVoiceCallOpen(false);
  }, [active]);
  useEffect(() => {
    if (
      !activeConversationId &&
      !suppressAutoSelectRef.current &&
      conversationList.data?.length
    ) {
      const first = conversationList.data[0] as ConversationSummary;
      activeConversationRef.current = first.id;
      setActiveConversationId(first.id);
    }
  }, [activeConversationId, conversationList.data]);
  useEffect(() => {
    const id = activeConversationId;
    const loaded = conversation.data as
      | { id: string; messages?: Message[] }
      | undefined;
    if (
      !id ||
      !loaded ||
      loaded.id !== id ||
      activeConversationRef.current !== id ||
      restoredConversationRef.current === id
    )
      return;
    restoredConversationRef.current = id;
    const restored = (loaded.messages ?? []).map(message => ({
      ...message,
      id: message.id ?? clientId(),
      createdAt: message.createdAt ?? Date.now(),
    }));
    setMessages(
      restored.length
        ? restored
        : [
            {
              role: "assistant",
              content: "New conversation. How can I help?",
              id: clientId(),
              createdAt: Date.now(),
            },
          ]
    );
    lastFilesRef.current = [];
    setAttachments([]);
  }, [activeConversationId, conversation.data]);
  useEffect(() => {
    cameraControllerRef.current?.attachPreview(cameraPreviewRef.current);
  }, [cameraState.active, cameraState.pending, voiceCallActive]);
  const quickPrompts = useMemo(
    () => [
      "Explain this simply",
      "Help me understand this exercise",
      "Summarize my files",
    ],
    []
  );

  if (loading) return <AccessGate />;
  if (!isAuthenticated) return <AccessGate />;

  async function ensureConversation(firstMessage?: string) {
    if (activeConversationRef.current) return activeConversationRef.current;
    try {
      const created = await createConversation.mutateAsync(
        firstMessage ? { firstMessage } : {}
      );
      restoredConversationRef.current = created.id;
      activeConversationRef.current = created.id;
      setActiveConversationId(created.id);
      void conversationList.refetch();
      return created.id;
    } catch {
      setConversationStatus(
        "This chat is still open, but history could not be saved. Your input is kept here."
      );
      return undefined;
    }
  }

  async function persistMessage(
    conversationId: string | undefined,
    message: Message,
    files: Attachment[] = [],
    generation?: number
  ) {
    if (
      !conversationId ||
      archivedConversationIdsRef.current.has(conversationId)
    )
      return;
    const persistedAttachmentUrl =
      message.attachmentUrl?.startsWith("/manus-storage/") ||
      message.attachmentUrl?.startsWith("https://")
        ? message.attachmentUrl
        : undefined;
    try {
      await appendConversation.mutateAsync({
        id: conversationId,
        message: {
          id: message.id ?? clientId(),
          requestId: message.requestId ?? message.id ?? clientId(),
          role: message.role,
          content: message.content,
          createdAt: message.createdAt ?? Date.now(),
          imageUrl: message.imageUrl,
          openBuilder: message.openBuilder,
          builderBrief: message.builderBrief,
          attachmentName: message.attachmentName,
          attachmentUrl: persistedAttachmentUrl,
          agent: message.agent,
          research: message.research,
          ...(files.length
            ? {
                attachments: files.map(file => ({
                  name: file.name,
                  mimeType: file.mimeType,
                  dataUrl: file.dataUrl,
                  size:
                    Math.floor(
                      (file.dataUrl.split(",")[1]?.length ?? 0) * 0.75
                    ) -
                    (file.dataUrl.endsWith("==")
                      ? 2
                      : file.dataUrl.endsWith("=")
                        ? 1
                        : 0),
                })),
              }
            : {}),
        },
      });
      setConversationStatus("");
      void conversationList.refetch();
    } catch {
      if (
        generation !== undefined &&
        generation !== conversationGenerationRef.current
      )
        return;
      setConversationStatus(
        "History could not be saved. Your input remains in this chat; try again when ready."
      );
    }
  }

  async function startNewConversation() {
    ++conversationGenerationRef.current;
    suppressAutoSelectRef.current = false;
    activeConversationRef.current = undefined;
    setActiveConversationId(undefined);
    lastFilesRef.current = [];
    setAttachments([]);
    setConversationStatus("");
    setMessages([
      {
        role: "assistant",
        content: "New conversation. How can I help?",
        id: clientId(),
        createdAt: Date.now(),
      },
    ]);
    await ensureConversation();
  }

  function switchConversation(id: string) {
    if (id === activeConversationRef.current) return;
    ++conversationGenerationRef.current;
    suppressAutoSelectRef.current = false;
    restoredConversationRef.current = undefined;
    activeConversationRef.current = id;
    setActiveConversationId(id);
    lastFilesRef.current = [];
    setAttachments([]);
    setConversationStatus("");
    setMessages([]);
  }

  async function renameCurrentConversation(id: string, title: string) {
    try {
      await renameConversation.mutateAsync({ id, title });
      void conversationList.refetch();
    } catch {
      setConversationStatus(
        "That conversation could not be renamed. Try again."
      );
    }
  }

  async function removeConversation(id: string) {
    const item = (conversationList.data ?? []).find(
      conversation => conversation.id === id
    );
    if (!item || !window.confirm(`Remove “${item.title}”? You can undo this.`))
      return;

    const wasActive = activeConversationRef.current === id;
    archivedConversationIdsRef.current.add(id);
    if (wasActive) {
      ++conversationGenerationRef.current;
      suppressAutoSelectRef.current = true;
      activeConversationRef.current = undefined;
      restoredConversationRef.current = undefined;
      setActiveConversationId(undefined);
      lastFilesRef.current = [];
      setAttachments([]);
      setMessages([
        {
          role: "assistant",
          content: "New conversation. How can I help?",
          id: clientId(),
          createdAt: Date.now(),
        },
      ]);
    }
    try {
      await archiveConversation.mutateAsync({ id });
      setRemovedConversation({ id, title: item.title });
      setConversationStatus(
        "Conversation removed. Your saved messages are still recoverable."
      );
      await conversationList.refetch();
    } catch {
      archivedConversationIdsRef.current.delete(id);
      setConversationStatus(
        "That conversation could not be removed. Nothing was deleted."
      );
      if (wasActive) {
        suppressAutoSelectRef.current = false;
        activeConversationRef.current = id;
        restoredConversationRef.current = undefined;
        setActiveConversationId(id);
      }
    }
  }

  async function undoRemoveConversation() {
    if (!removedConversation) return;
    const { id } = removedConversation;
    try {
      const restored = await restoreConversation.mutateAsync({ id });
      archivedConversationIdsRef.current.delete(id);
      setRemovedConversation(undefined);
      setConversationStatus("Conversation restored.");
      await conversationList.refetch();
      if (!activeConversationRef.current) {
        suppressAutoSelectRef.current = false;
        activeConversationRef.current = restored.id;
        restoredConversationRef.current = undefined;
        setActiveConversationId(restored.id);
        setMessages([]);
      }
    } catch {
      setConversationStatus(
        "That conversation could not be restored. Try again."
      );
    }
  }

  async function submitMessage(
    event?: FormEvent,
    retry?: {
      value: string;
      files: Attachment[];
      generation: number;
      threadId?: string;
    }
  ) {
    event?.preventDefault();
    const value =
      retry?.value ||
      draft.trim() ||
      (attachments.length ? "Please analyze this attachment." : "");
    if (!value || chatBusyRef.current || sendMessage.isPending) return;
    const generation = conversationGenerationRef.current;
    if (
      retry &&
      (retry.generation !== generation ||
        retry.threadId !== activeConversationRef.current)
    )
      return;
    chatBusyRef.current = true;
    setChatSubmitting(true);
    setFailedRequest(undefined);
    const currentAttachments = retry ? [] : attachments;
    const contextFiles =
      retry?.files ??
      (currentAttachments.length ? currentAttachments : lastFilesRef.current);
    const currentAttachment = currentAttachments[0];
    if (currentAttachments.length) lastFilesRef.current = currentAttachments;
    const userMessage: Message = {
      id: clientId(),
      requestId: clientId(),
      role: "user",
      content: value,
      attachmentName:
        currentAttachments.map(file => file.name).join(", ") || undefined,
      attachmentUrl: currentAttachments[0]?.mimeType.startsWith("image/")
        ? currentAttachment?.dataUrl
        : undefined,
      attachments: currentAttachments.length
        ? currentAttachments.map(file => ({
            name: file.name,
            mimeType: file.mimeType,
            reference: file.name,
          }))
        : undefined,
      createdAt: Date.now(),
    };
    if (!retry) {
      setDraft("");
      setAttachments([]);
    }
    const priorHistory = messagesRef.current
      .filter(message => !message.failed)
      .slice(-25)
      .map(({ role, content }) => ({ role, content }));
    if (!retry) setMessages(current => [...current, userMessage]);
    else setMessages(current => current.filter(message => !message.failed));
    const threadId = retry?.threadId ?? (await ensureConversation(value));
    if (!retry)
      await persistMessage(
        threadId,
        userMessage,
        currentAttachments,
        generation
      );
    if (
      retry &&
      priorHistory.at(-1)?.role === "user" &&
      priorHistory.at(-1)?.content === value
    )
      priorHistory.pop();
    try {
      const result = await sendMessage.mutateAsync({
        message: value,
        chatOnly: true,
        ...(threadId ? { conversationId: threadId } : {}),
        modelMode,
        history: priorHistory,
        attachments: contextFiles,
      });
      const assistantMessage: Message = {
        id: clientId(),
        requestId: clientId(),
        role: "assistant",
        content: result.content,
        imageUrl: result.imageUrl,
        openBuilder: result.openBuilder,
        builderBrief: result.builderBrief,
        agent: result.agent,
        research: "research" in result ? result.research : undefined,
        createdAt: Date.now(),
      };

      if (
        generation === conversationGenerationRef.current &&
        threadId === activeConversationRef.current
      )
        setMessages(current => [...current, assistantMessage]);
      void persistMessage(threadId, assistantMessage, [], generation);
    } catch (error) {
      if (
        generation !== conversationGenerationRef.current ||
        threadId !== activeConversationRef.current
      )
        return;
      const failureMessage: Message = {
        id: clientId(),
        requestId: clientId(),
        role: "assistant",
        content: chatFailureMessage(error),
        failed: true,
        createdAt: Date.now(),
      };
      setMessages(current => [...current, failureMessage]);
      setFailedRequest({ value, files: contextFiles, generation, threadId });
    } finally {
      chatBusyRef.current = false;
      setChatSubmitting(false);
    }
  }

  async function selectAttachments(files: File[]) {
    try {
      const added = await readFiles(files);
      const all = [...attachments, ...added];
      if (
        all.length > 5 ||
        all.reduce((sum, file) => sum + file.dataUrl.length * 0.75, 0) >
          18 * 1024 * 1024
      )
        throw new Error("Choose up to 5 files, under 18 MB combined.");
      setAttachments(all);
      setVoiceStatus("");
    } catch (error) {
      setVoiceStatus(
        error instanceof Error ? error.message : "Could not read the files."
      );
    }
  }

  function startVoice() {
    if (voiceControllerRef.current?.snapshot.active) {
      setVoiceStatus("End the call before using chat dictation.");
      return;
    }
    if (!dictationRef.current)
      dictationRef.current = new DictationController({
        onStatus: setVoiceStatus,
        recognitionContext: () =>
          messagesRef.current
            .filter(turn => turn.role === "user")
            .slice(-3)
            .map(turn => turn.content.slice(0, 200))
            .join(" | ")
            .slice(0, 600) || undefined,
        onText: text =>
          setDraft(current => `${current}${current ? " " : ""}${text}`),
        transcribe: async (blob, recognitionContext) => {
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
          return callApiRef.current.transcribeVoice.mutateAsync({
            dataUrl,
            mimeType: blob.type || "audio/webm",
            recognitionContext,
            language:
              callLanguageRef.current === "auto"
                ? "auto"
                : (whisperLanguageHint(
                    callLanguageRef.current as LanguageSelection
                  ) ?? "auto"),
          });
        },
      });
    void dictationRef.current.toggle();
  }

  function getVoiceController() {
    if (!voiceControllerRef.current) {
      voiceControllerRef.current = new VoiceCallController({
        runtime: browserVoiceRuntime(),
        onChange: setCallState,
        transcribe: async (blob, recognitionContext) => {
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
          return callApiRef.current.transcribeVoice.mutateAsync({
            dataUrl,
            mimeType: blob.type || "audio/webm",
            recognitionContext,
            language:
              callLanguageRef.current === "auto"
                ? "auto"
                : (whisperLanguageHint(
                    callLanguageRef.current as LanguageSelection
                  ) ?? "auto"),
          });
        },
        synthesize: (text, gender, language) =>
          callApiRef.current.callSpeech.mutateAsync({ text, gender, language }),
        language: () => callLanguageRef.current,
        reply: async (text, history) => {
          const camera = cameraControllerRef.current;
          const cameraFrame = camera?.snapshot.active
            ? camera.captureFrame()
            : null;
          const result = await callApiRef.current.voiceReply.mutateAsync({
            message: text,
            voiceMode: true,
            cameraMode: Boolean(camera?.snapshot.active),
            callLanguage: callLanguageRef.current,
            ...(cameraFrame ? { cameraFrame } : {}),
            history,
          });
          return result.content;
        },
      });
    }
    return voiceControllerRef.current;
  }

  function openVoiceCall() {
    dictationRef.current?.stop();
    setVoiceCallOpen(true);
    const controller = getVoiceController();
    controller.setGender(voiceGender);
    void controller.start(
      messagesRef.current.map(({ role, content }) => ({ role, content }))
    );
  }

  function getCameraController() {
    if (!cameraControllerRef.current) {
      cameraControllerRef.current = new CameraCallController({
        runtime: browserCameraRuntime(),
        onChange: setCameraState,
      });
    }
    return cameraControllerRef.current;
  }

  function openVideoCall() {
    dictationRef.current?.stop();
    const launch = ++callLaunchRef.current;
    setVoiceCallOpen(true);
    const voice = getVoiceController();
    const camera = getCameraController();
    voice.setGender(voiceGender);
    voice.preparePlayback();
    void (async () => {
      await camera.start();
      if (launch !== callLaunchRef.current) {
        camera.stop();
        return;
      }
      await voice.start(
        messagesRef.current.map(({ role, content }) => ({ role, content }))
      );
      if (!voice.snapshot.active) camera.stop();
    })();
  }

  function toggleCamera() {
    const camera = getCameraController();
    if (camera.snapshot.active) {
      camera.stop();
    } else {
      void camera.start();
    }
  }

  function changeVoiceGender(value: "man" | "woman") {
    setVoiceGender(value);
    voiceControllerRef.current?.setGender(value);
  }

  function toggleVoiceMute() {
    voiceControllerRef.current?.setMuted(
      !voiceControllerRef.current.snapshot.muted
    );
  }

  function closeVoiceCall() {
    ++callLaunchRef.current;
    voiceControllerRef.current?.stop();
    cameraControllerRef.current?.stop();
    cameraControllerRef.current?.attachPreview(null);
    cameraPreviewRef.current = null;
  }

  return (
    <>
      <DashboardLayout>
        <div className="adus-chat-workspace mx-auto min-w-0 w-full max-w-[1600px]">
          <header className="mb-4 flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold">Chat Only</h1>
              <p className="mt-1 text-xs text-white/40">
                Conversation, photos and files. Your last uploads stay in
                context for follow-up questions.
              </p>
            </div>
            <button
              onClick={() => void startNewConversation()}
              className="rounded-lg border border-white/10 px-3 py-2 text-xs text-white/65"
            >
              New chat
            </button>
          </header>
          {conversationStatus && (
            <div className="mb-3 flex items-center justify-between gap-3 rounded-xl border border-amber-200/15 bg-amber-200/[0.06] px-3 py-2 text-xs leading-5 text-amber-100/80">
              <span>{conversationStatus}</span>
              {removedConversation && (
                <button
                  type="button"
                  onClick={() => void undoRemoveConversation()}
                  disabled={restoreConversation.isPending}
                  className="shrink-0 rounded-md border border-amber-200/25 px-2 py-1 font-semibold text-amber-100 hover:bg-amber-200/10 disabled:opacity-50"
                >
                  {restoreConversation.isPending ? "Restoring…" : "Undo"}
                </button>
              )}
            </div>
          )}
          <div className="flex flex-col gap-4 lg:flex-row">
            <ConversationHistory
              conversations={
                (conversationList.data ?? []) as ConversationSummary[]
              }
              activeConversationId={activeConversationId}
              isLoading={conversationList.isLoading}
              onNewChat={() => void startNewConversation()}
              onSelect={switchConversation}
              onRename={renameCurrentConversation}
              onRemove={removeConversation}
            />
            <section className="adus-chat-shell adus-glass flex h-[calc(100dvh-170px)] min-h-[420px] min-w-0 flex-1 flex-col overflow-hidden rounded-2xl border border-white/[0.1] shadow-2xl shadow-black/25 sm:h-[calc(100dvh-135px)] sm:rounded-[1.75rem]">
              <div className="flex items-center justify-between border-b border-white/[0.08] px-5 py-4 sm:px-6">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-300/15 text-violet-200">
                    <BrainCircuit size={18} />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">Adus</div>
                    <div className="font-mono text-[9px] uppercase tracking-[0.16em] text-white/35">
                      Adus core · context aware
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <label className="hidden items-center gap-2 rounded-lg border border-white/10 px-2 py-1.5 text-[10px] text-white/45 sm:flex">
                    <span className="sr-only">Answer mode</span>
                    <select
                      value={modelMode}
                      onChange={event =>
                        setModelMode(
                          event.target.value as "auto" | "fast" | "deep"
                        )
                      }
                      className="bg-transparent text-[10px] text-white/70 outline-none"
                      aria-label="Answer mode"
                    >
                      <option className="bg-[#0b1019]" value="auto">
                        Auto · balanced
                      </option>
                      <option className="bg-[#0b1019]" value="fast">
                        Fast · short answers
                      </option>
                      <option className="bg-[#0b1019]" value="deep">
                        Deep · complex study/code
                      </option>
                    </select>
                  </label>
                  <span className="rounded-full border border-emerald-300/20 bg-emerald-300/10 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[0.12em] text-emerald-200">
                    ready
                  </span>
                  <button
                    onClick={() => {
                      if (voiceCallOpen) closeVoiceCall();
                      setVoiceCallOpen(current => !current);
                    }}
                    className={`rounded-lg p-2 transition ${voiceCallActive ? "bg-cyan-300/20 text-cyan-100" : "text-white/35 hover:bg-white/5 hover:text-white"}`}
                    aria-label="Open voice call"
                  >
                    <Phone size={16} />
                  </button>
                  <button
                    onClick={openVideoCall}
                    className={`rounded-lg p-2 transition ${cameraState.active ? "bg-cyan-300/20 text-cyan-100" : "text-white/35 hover:bg-white/5 hover:text-white"}`}
                    aria-label="Open video call"
                    title="Open video call"
                  >
                    <Video size={16} />
                  </button>
                </div>
              </div>
              {voiceCallOpen && (
                <div className="mx-4 mt-4 rounded-2xl border border-cyan-200/15 bg-cyan-200/[0.06] p-4 sm:mx-6">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-sm font-semibold text-cyan-50">
                        <Volume2 size={16} /> Adus voice call
                      </div>
                      <p className="mt-1 text-xs leading-5 text-white/45">
                        Speak naturally. Adus listens, thinks, and answers
                        aloud.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <select
                        value={voiceGender}
                        onChange={event => {
                          const value = event.target.value as "man" | "woman";
                          changeVoiceGender(value);
                        }}
                        className="rounded-lg border border-white/10 bg-[#0b1019] px-2 py-2 text-xs text-white"
                      >
                        <option value="woman">Woman’s voice</option>
                        <option value="man">Man’s voice</option>
                      </select>
                      <LanguageSelect
                        value={callLanguage}
                        onChange={setCallLanguage}
                        includeAuto
                        label="Call language"
                        className="rounded-lg border border-white/10 bg-[#0b1019] px-2 py-2 text-xs text-white"
                      />
                      {voiceCallActive ? (
                        <button
                          onClick={closeVoiceCall}
                          className="flex items-center gap-2 rounded-lg bg-rose-300 px-3 py-2 text-xs font-bold text-rose-950"
                        >
                          <PhoneOff size={14} /> End call
                        </button>
                      ) : (
                        <button
                          onClick={openVoiceCall}
                          className="flex items-center gap-2 rounded-lg bg-cyan-300 px-3 py-2 text-xs font-bold text-slate-950"
                        >
                          <Phone size={14} /> Start call
                        </button>
                      )}
                      <button
                        onClick={openVideoCall}
                        className="flex items-center gap-2 rounded-lg border border-cyan-200/25 bg-cyan-200/10 px-3 py-2 text-xs font-semibold text-cyan-100"
                      >
                        <Video size={14} /> Start video
                      </button>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center gap-2 text-[11px] text-cyan-100/70">
                    <span
                      className={`h-2 w-2 rounded-full ${voiceCallActive ? "animate-pulse bg-emerald-300" : "bg-white/25"}`}
                    />{" "}
                    {voiceCallStatus}
                  </div>
                  {cameraState.error && (
                    <div className="mt-3 rounded-xl border border-amber-200/20 bg-amber-200/[0.06] px-3 py-2 text-xs leading-5 text-amber-100">
                      <CameraAccessHelp message={cameraState.error} />
                      <button
                        type="button"
                        onClick={() => void getCameraController().start()}
                        className="ml-2 font-semibold underline underline-offset-2"
                      >
                        Try camera again
                      </button>
                    </div>
                  )}
                </div>
              )}
              <div className="adus-chat-messages adus-scroll min-w-0 flex-1 space-y-4 overflow-x-hidden overflow-y-auto px-3 py-4 sm:px-6 sm:py-6">
                {messages.map((message, index) => (
                  <MessageBubble
                    key={`${message.role}-${index}`}
                    message={message}
                  />
                ))}
                {(chatSubmitting || sendMessage.isPending) && (
                  <div className="flex items-center gap-2 text-xs text-white/40">
                    <div className="flex gap-1">
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-200" />
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-200 [animation-delay:120ms]" />
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-200 [animation-delay:240ms]" />
                    </div>{" "}
                    Adus is thinking
                  </div>
                )}
                <div ref={bottomRef} />
              </div>
              <div className="adus-chat-composer min-w-0 border-t border-white/[0.08] p-2 sm:p-4">
                {failedRequest &&
                  failedRequest.generation ===
                    conversationGenerationRef.current && (
                    <div className="mb-3 flex items-center justify-between gap-3 rounded-xl border border-amber-200/20 bg-amber-200/5 px-3 py-2 text-xs text-amber-100">
                      <span>Your question and attachments are kept.</span>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={chatSubmitting || sendMessage.isPending}
                        onClick={() =>
                          void submitMessage(undefined, failedRequest)
                        }
                      >
                        <RefreshCw size={13} className="mr-1.5" /> Retry answer
                      </Button>
                    </div>
                  )}
                <input
                  id="adus-file-input"
                  type="file"
                  multiple
                  accept="image/*,.pdf,.txt,.md,.csv,.json,.docx,.mp3,.wav,.mp4,.js,.ts,.py,.html,.css"
                  className="hidden"
                  onChange={event => {
                    void selectAttachments(
                      Array.from(event.target.files ?? [])
                    );
                    event.currentTarget.value = "";
                  }}
                />
                <div className="mb-3 flex gap-2 overflow-x-auto pb-1">
                  {quickPrompts.map(prompt => (
                    <button
                      key={prompt}
                      onClick={() => setDraft(prompt)}
                      className="shrink-0 rounded-full border border-white/10 px-3 py-1.5 text-[11px] text-white/45 hover:border-cyan-200/30 hover:text-cyan-100"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
                <form
                  onSubmit={event => void submitMessage(event)}
                  className="rounded-2xl border border-white/10 bg-[#080b12]/80 p-2 focus-within:border-cyan-200/35"
                >
                  {attachments.map((file, index) => (
                    <div
                      key={`${file.name}-${index}`}
                      className="mb-2 flex items-center justify-between rounded-xl border border-cyan-200/15 bg-cyan-200/[0.06] px-3 py-2 text-xs text-cyan-100"
                    >
                      <span className="flex min-w-0 items-center gap-2">
                        {file.mimeType.startsWith("image/") ? (
                          <img
                            src={file.dataUrl}
                            alt={file.name}
                            className="h-10 w-10 rounded object-cover"
                          />
                        ) : (
                          <Paperclip size={13} />
                        )}
                        <span className="truncate">{file.name}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setAttachments(current =>
                            current.filter((_, i) => i !== index)
                          )
                        }
                        aria-label={`Remove ${file.name}`}
                        className="rounded-md p-1 text-white/50 hover:bg-white/10 hover:text-white"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  {voiceStatus && (
                    <div className="mb-2 text-[11px] text-cyan-100/70">
                      {voiceStatus}
                    </div>
                  )}
                  <textarea
                    value={draft}
                    onChange={event => setDraft(event.target.value)}
                    onKeyDown={event => {
                      if (event.key === "Enter" && !event.shiftKey) {
                        event.preventDefault();
                        void submitMessage();
                      }
                    }}
                    placeholder="Tell Adus what you want to do…"
                    rows={2}
                    className="w-full resize-none bg-transparent px-3 py-2 text-sm leading-6 text-white outline-none placeholder:text-white/25"
                  />
                  <div className="flex items-center justify-between px-2 pb-1">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() =>
                          document.getElementById("adus-file-input")?.click()
                        }
                        className="rounded-lg p-2 text-white/35 hover:bg-white/5 hover:text-white"
                        aria-label="Attach a file"
                      >
                        <Paperclip size={16} />
                      </button>
                      <button
                        type="button"
                        onClick={startVoice}
                        className="rounded-lg p-2 text-white/35 hover:bg-white/5 hover:text-white"
                        aria-label="Voice input"
                      >
                        <Mic2 size={16} />
                      </button>
                      <span className="ml-2 hidden text-[10px] text-white/25 sm:inline">
                        Enter to send · Shift + Enter for a new line
                      </span>
                    </div>
                    <Button
                      type="submit"
                      aria-label="Send message"
                      disabled={
                        (!draft.trim() && !attachments.length) ||
                        chatSubmitting ||
                        sendMessage.isPending
                      }
                      size="icon"
                      className="h-9 w-9 rounded-xl bg-cyan-300 text-slate-950 hover:bg-cyan-200"
                    >
                      <Send size={16} />
                    </Button>
                  </div>
                </form>
              </div>
            </section>
          </div>
        </div>
      </DashboardLayout>
      {voiceCallActive && (
        <div className="fixed inset-0 z-[60] flex h-[100dvh] flex-col overflow-y-auto bg-[#070a12]/95 px-5 py-6 text-white backdrop-blur-2xl sm:px-8">
          <div className="relative z-10 flex shrink-0 items-center justify-between">
            <div>
              <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-cyan-200/70">
                Adus / Live voice
              </div>
              <div className="mt-1 text-sm text-white/45">
                Private voice conversation
              </div>
            </div>
            <button
              onClick={closeVoiceCall}
              className="rounded-xl border border-white/10 p-3 text-white/60 hover:bg-white/10 hover:text-white"
              aria-label="End voice call"
            >
              <PhoneOff size={18} />
            </button>
          </div>
          <div className="flex shrink-0 flex-col items-center justify-center gap-3 py-3 sm:gap-5">
            {cameraState.active ? (
              <div className="relative w-full max-w-6xl overflow-hidden rounded-[1.75rem] border border-cyan-200/25 bg-black shadow-2xl shadow-cyan-950/30 lg:w-[60vw]">
                <video
                  ref={attachCameraPreview}
                  autoPlay
                  muted
                  playsInline
                  className="aspect-video max-h-[55vh] min-h-[30vh] w-full object-cover sm:min-h-[38vh]"
                  aria-label="Live camera preview"
                />
                <div className="absolute left-3 top-3 rounded-full bg-black/55 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-cyan-100">
                  {cameraState.facingMode === "user"
                    ? "Front camera"
                    : "Rear camera"}
                </div>
              </div>
            ) : (
              <div
                className={`relative flex h-44 w-44 items-center justify-center rounded-full border border-cyan-200/30 bg-gradient-to-br from-cyan-200/30 via-violet-300/20 to-transparent shadow-[0_0_90px_rgba(103,232,249,.22)] ${voiceCallStatus.includes("Listening") ? "animate-pulse" : ""}`}
              >
                <div className="absolute inset-5 rounded-full border border-white/15" />
                <div className="absolute inset-10 rounded-full bg-cyan-200/20 blur-xl" />
                <Volume2 size={38} className="relative text-cyan-100" />
              </div>
            )}
            <div className="mt-2 text-center">
              <div className="text-2xl font-semibold tracking-[-0.04em]">
                Adus is here
              </div>
              <div
                className="mt-3 text-sm text-cyan-100/75"
                role="status"
                aria-live="polite"
              >
                {voiceCallStatus}
              </div>
              <div
                className={`mt-3 text-xs ${voiceMuted ? "text-rose-300" : "text-emerald-200/70"}`}
              >
                {voiceMuted
                  ? "Your microphone is muted · Bot audio stays on"
                  : "Your microphone is on · Bot audio stays on"}
              </div>
              <p className="mx-auto mt-3 max-w-sm text-xs leading-6 text-white/40">
                Speak naturally. When you pause, Adus processes your voice and
                answers aloud.
              </p>
              <p className="mx-auto mt-3 max-w-md text-[11px] leading-5 text-cyan-100/55">
                Current camera frame is sent with each spoken turn; no
                continuous video is stored.
              </p>
            </div>
          </div>
          <div className="mx-auto flex w-full max-w-md shrink-0 flex-col gap-3">
            <label className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-3 text-xs text-white/60">
              <span>Voice</span>
              <select
                value={voiceGender}
                onChange={event => {
                  const value = event.target.value as "man" | "woman";
                  changeVoiceGender(value);
                }}
                className="bg-transparent text-right text-sm text-white outline-none"
              >
                <option className="bg-[#0b1019]" value="woman">
                  Woman
                </option>
                <option className="bg-[#0b1019]" value="man">
                  Man
                </option>
              </select>
            </label>
            <label className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-3 text-xs text-white/60">
              <span>Language</span>
              <LanguageSelect
                value={callLanguage}
                onChange={setCallLanguage}
                includeAuto
                label="Call language"
                className="max-w-[70%] bg-transparent text-right text-sm text-white outline-none"
              />
            </label>
            <button
              type="button"
              onClick={() => voiceControllerRef.current?.interrupt()}
              className="flex h-11 items-center justify-center gap-2 rounded-2xl border border-amber-200/25 bg-amber-200/10 text-sm font-semibold text-amber-100"
              aria-label="Stop answer and listen"
              title="Stop Adus’s current answer and listen again without losing the conversation"
            >
              <Square size={16} /> Stop · Listen again
            </button>
            {callState.phase === "listening" && (
              <button
                onClick={() => voiceControllerRef.current?.finishTurn()}
                className="h-11 rounded-2xl border border-cyan-200/20 bg-cyan-200/10 text-sm font-semibold text-cyan-100"
              >
                Done speaking · Answer now
              </button>
            )}
            {callState.phase === "error" && (
              <button
                onClick={() =>
                  callState.canReplay
                    ? voiceControllerRef.current?.replay()
                    : voiceControllerRef.current?.retryListening()
                }
                className="h-11 rounded-2xl border border-amber-200/20 bg-amber-200/10 text-sm font-semibold text-amber-100"
              >
                {callState.canReplay
                  ? "Replay natural answer"
                  : "Retry listening"}
              </button>
            )}
            {callState.canReplay && (
              <button
                onClick={() =>
                  voiceControllerRef.current?.replayWithBrowserVoice()
                }
                className="h-10 rounded-2xl border border-white/10 bg-white/[0.05] text-xs font-semibold text-white/65"
              >
                Use browser voice fallback (optional)
              </button>
            )}
            <button
              onClick={toggleCamera}
              disabled={cameraState.pending}
              className="flex h-11 items-center justify-center gap-2 rounded-2xl border border-cyan-200/20 bg-cyan-200/10 text-sm font-semibold text-cyan-100 disabled:opacity-50"
              aria-pressed={cameraState.active}
              aria-label={cameraState.active ? "Stop camera" : "Start camera"}
            >
              {cameraState.active ? (
                <CameraOff size={17} />
              ) : (
                <Video size={17} />
              )}{" "}
              {cameraState.pending
                ? "Camera…"
                : cameraState.active
                  ? "Stop camera"
                  : "Start camera"}
            </button>
            {cameraState.active && (
              <button
                onClick={() => void getCameraController().switchCamera()}
                disabled={cameraState.pending}
                className="flex h-11 items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.05] text-sm font-semibold text-white/75 disabled:opacity-50"
                aria-label="Switch camera"
              >
                <RefreshCw size={16} /> Switch{" "}
                {cameraState.facingMode === "user" ? "to rear" : "to front"}{" "}
                camera
              </button>
            )}
            {cameraState.error && (
              <div className="rounded-xl border border-amber-200/20 bg-amber-200/[0.06] px-3 py-2 text-center text-xs leading-5 text-amber-100">
                <CameraAccessHelp message={cameraState.error} />
                <button
                  type="button"
                  onClick={() => void getCameraController().start()}
                  className="ml-2 font-semibold underline underline-offset-2"
                >
                  Try again
                </button>
              </div>
            )}
            <button
              onClick={toggleVoiceMute}
              className={`flex h-12 items-center justify-center gap-2 rounded-2xl font-bold ${voiceMuted ? "bg-rose-600 text-white hover:bg-rose-500" : "bg-rose-300 text-rose-950 hover:bg-rose-200"}`}
              aria-pressed={voiceMuted}
              aria-label={voiceMuted ? "Unmute microphone" : "Mute microphone"}
            >
              {voiceMuted ? <MicOff size={17} /> : <Mic2 size={17} />}{" "}
              {voiceMuted ? "Unmute microphone" : "Mute microphone"}
            </button>
            <button
              onClick={closeVoiceCall}
              className="flex h-12 items-center justify-center gap-2 rounded-2xl bg-rose-300 font-bold text-rose-950 hover:bg-rose-200"
            >
              <PhoneOff size={17} /> End call
            </button>
            <div className="text-center text-[10px] text-white/25">
              Mute controls only your microphone. Adus keeps answering aloud.
            </div>
          </div>
        </div>
      )}
    </>
  );
}
