import WorkspaceShell from "@/components/WorkspaceShell";
import MediaSaveActions from "@/components/MediaSaveActions";
import VideoEditPanel from "@/components/VideoEditPanel";
import FlikiShortcut from "@/components/FlikiShortcut";
import FreeVideoPanel from "@/components/FreeVideoPanel";
import { LanguageSelect } from "@/components/LanguageSelect";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { uploadVideoFile, validateVideoFileSelection } from "@/lib/videoUpload";
import { trpc } from "@/lib/trpc";
import type { VoiceLanguage } from "@shared/languages";
import { Film, Loader2, Sparkles, Upload, WandSparkles, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const videos = trpc.adus.videos;
const MAX_PENDING_MS = 10 * 60 * 1000;

type Mode = "generate" | "edit";
type VideoResult = {
  id: string;
  type?: "source" | "result";
  operation?: Mode;
  status?: "pending" | "completed" | "failed";
  name?: string;
  mimeType?: string;
  bytes?: number;
  duration?: number;
  sourceId?: string;
  prompt?: string;
  aspectRatio?: "16:9" | "9:16";
  interactionId?: string;
  provider?: "veo" | "omni";
  url?: string;
  error?: string;
};

function errorMessage(error: unknown): string {
  if (error && typeof error === "object" && "message" in error)
    return String((error as { message?: unknown }).message ?? "");
  return "The video request could not be completed. Please try again.";
}

function formatBytes(bytes?: number): string {
  if (!bytes || !Number.isFinite(bytes)) return "";
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function formatDuration(seconds?: number): string {
  if (!seconds || !Number.isFinite(seconds)) return "";
  return `${Math.round(seconds)}s`;
}

export default function Videos() {
  const [mode, setMode] = useState<Mode>("generate");
  const [editEngine, setEditEngine] = useState<"source" | "generative">(
    "source"
  );
  const sourceToken = useRef(0);
  const [prompt, setPrompt] = useState("");
  const [aspectRatio, setAspectRatio] = useState<"16:9" | "9:16">("16:9");
  const [resolution, setResolution] = useState<"720p" | "1080p">("720p");
  const [durationSeconds, setDurationSeconds] = useState<4 | 6 | 8>(8);
  const [narrationEnabled, setNarrationEnabled] = useState(false);
  const [narrationText, setNarrationText] = useState("");
  const [narrationLanguage, setNarrationLanguage] =
    useState<VoiceLanguage>("en");
  const [narrationGender, setNarrationGender] = useState<"woman" | "man">(
    "woman"
  );
  const [sourceFile, setSourceFile] = useState<File | null>(null);
  const [source, setSource] = useState<VideoResult | null>(null);
  const [result, setResult] = useState<VideoResult | null>(null);
  const [notice, setNotice] = useState("");
  const [pendingSince, setPendingSince] = useState<number | null>(null);
  const [sourceUploading, setSourceUploading] = useState(false);
  const sourceInputRef = useRef<HTMLInputElement>(null);

  const generate = videos.generate.useMutation({
    meta: { handledError: true },
  });
  const edit = videos.edit.useMutation({ meta: { handledError: true } });
  const history = videos.list.useQuery(undefined, {
    retry: false,
    meta: { handledError: true },
  });
  const pendingId = result?.status === "pending" ? result.id : "";
  const status = videos.status.useQuery(
    { id: pendingId },
    {
      enabled: Boolean(pendingId && pendingSince),
      refetchInterval: pendingId && pendingSince ? 10_000 : false,
      meta: { handledError: true },
    }
  );

  useEffect(() => {
    if (result || pendingSince || !history.data) return;
    const pendingResult = (history.data as VideoResult[]).find(
      item => item.type === "result" && item.status === "pending"
    );
    if (pendingResult) {
      setResult(pendingResult);
      setPendingSince(Date.now());
    }
  }, [history.data, pendingSince, result]);

  useEffect(() => {
    const next = status.data as VideoResult | undefined;
    if (!next || next.id !== pendingId) return;
    setResult(next);
    if (next.status === "completed") {
      setPendingSince(null);
      setNotice("");
    } else if (next.status === "failed") {
      setPendingSince(null);
      setNotice(
        next.error ?? "The video provider could not finish this request."
      );
    }
  }, [pendingId, status.data]);

  useEffect(() => {
    if (!pendingSince) return;
    const timer = window.setTimeout(() => {
      setPendingSince(null);
      setNotice(
        "This video is taking longer than the ten-minute workspace wait. Use Check result below to try again without starting a duplicate generation."
      );
    }, MAX_PENDING_MS);
    return () => window.clearTimeout(timer);
  }, [pendingSince]);

  function chooseMode(next: Mode) {
    setMode(next);
    setNotice("");
    if (next === "generate") setSource(null);
  }

  function onSourceChange(file: File | null) {
    setNotice("");
    setSource(null);
    if (!file) {
      setSourceFile(null);
      return;
    }
    const selectionError = validateVideoFileSelection(file);
    if (selectionError) {
      setSourceFile(null);
      setNotice(selectionError);
      return;
    }
    setSourceFile(file);
  }

  async function uploadEditSource(file: File | null) {
    const token = ++sourceToken.current;
    setNotice("");
    setSource(null);
    setSourceFile(null);
    if (!file) return;
    const selectionError = validateVideoFileSelection(file);
    if (selectionError) {
      setNotice(selectionError);
      return;
    }
    setSourceFile(file);
    setSourceUploading(true);
    try {
      const uploaded = (await uploadVideoFile(file)) as VideoResult;
      if (token === sourceToken.current) setSource(uploaded);
    } catch (e) {
      if (token === sourceToken.current) setNotice(errorMessage(e));
    } finally {
      if (token === sourceToken.current) setSourceUploading(false);
    }
  }
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setNotice("");
    setResult(null);
    setPendingSince(null);
    const trimmed = prompt.trim();
    if (trimmed.length < 3) {
      setNotice("Describe the video or the exact change you want.");
      return;
    }
    if (narrationEnabled && !narrationText.trim()) {
      setNotice(
        "Add a narration script or turn narration off. No voice is added when narration is off."
      );
      return;
    }
    if (mode === "edit" && !sourceFile && !source) {
      setNotice("Choose a source video before editing.");
      return;
    }
    try {
      let response: VideoResult;
      if (mode === "edit") {
        let sourceId = source?.id;
        if (!sourceId && sourceFile) {
          setSourceUploading(true);
          try {
            const uploaded = (await uploadVideoFile(sourceFile)) as VideoResult;
            sourceId = uploaded.id;
            setSource(uploaded);
          } finally {
            setSourceUploading(false);
          }
        }
        if (!sourceId)
          throw new Error("The source video upload did not finish.");
        response = (await edit.mutateAsync({
          sourceId,
          prompt: trimmed,
          aspectRatio,
        })) as VideoResult;
      } else {
        response = (await generate.mutateAsync({
          prompt: trimmed,
          aspectRatio,
          resolution,
          durationSeconds,
          narration: {
            enabled: narrationEnabled,
            text: narrationText.trim(),
            language: narrationLanguage,
            gender: narrationGender,
          },
        })) as VideoResult;
      }
      setResult(response);
      if (response.status === "pending") setPendingSince(Date.now());
    } catch (error) {
      setNotice(errorMessage(error));
    }
  }

  const busy = sourceUploading || generate.isPending || edit.isPending;
  const hasPending = result?.status === "pending";
  const pending = hasPending && Boolean(pendingSince);
  const outputFilename = `${result?.operation === "edit" ? "adus-edited" : "adus-generated"}-${result?.id ?? "video"}.mp4`;

  return (
    <WorkspaceShell
      title="Video studio"
      subtitle="Create a cinematic clip or edit source footage. Provider capabilities and limits are shown separately."
    >
      <div className="grid min-w-0 max-w-full grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <section className="min-w-0 max-w-full space-y-5">
          <FlikiShortcut />
          <FreeVideoPanel />
          <div className="min-w-0 max-w-full rounded-2xl border bg-card p-2 shadow-sm">
            <div className="grid min-w-0 max-w-full grid-cols-1 gap-2 sm:grid-cols-2">
              <ModeButton
                active={mode === "generate"}
                icon={Sparkles}
                label="Generate"
                description="Create a new short clip from text"
                onClick={() => chooseMode("generate")}
              />
              <ModeButton
                active={mode === "edit"}
                icon={WandSparkles}
                label="Edit source"
                description="Source Editing for cuts, mute, speed, crop and rotation"
                onClick={() => chooseMode("edit")}
              />
            </div>
          </div>

          {mode === "edit" && (
            <div className="mt-5 grid min-w-0 max-w-full grid-cols-1 gap-2 sm:grid-cols-2">
              <Button
                variant={editEngine === "source" ? "default" : "outline"}
                onClick={() => {
                  setEditEngine("source");
                  setNotice("");
                }}
                className="w-full min-w-0 max-w-full whitespace-normal break-words text-left"
              >
                Source Editing
              </Button>
              <Button
                variant={editEngine === "generative" ? "default" : "outline"}
                onClick={() => {
                  setEditEngine("generative");
                  setNotice("");
                }}
                className="w-full min-w-0 max-w-full whitespace-normal break-words text-left"
              >
                Google Generative Restyling
              </Button>
            </div>
          )}
          {mode === "edit" && editEngine === "source" && (
            <section className="mt-5 min-w-0 max-w-full space-y-4">
              <p className="max-w-full break-words text-sm leading-7 text-white/65">
                Upload a video, describe deterministic cuts, speed, mute, crop
                or rotation changes, then review and apply the local edit plan.
                Source Editing runs on the website server and does not call
                Google’s generative video engine.
              </p>
              <input
                type="file"
                accept="video/*,.mp4,.mov,.m4v,.webm"
                className="hidden"
                ref={sourceInputRef}
                onChange={e => {
                  void uploadEditSource(e.target.files?.[0] ?? null);
                  e.currentTarget.value = "";
                }}
              />
              <Button
                onClick={() => sourceInputRef.current?.click()}
                disabled={sourceUploading}
                variant="outline"
                className="max-w-full whitespace-normal break-words"
              >
                {sourceUploading
                  ? "Uploading source…"
                  : source
                    ? "Replace source video"
                    : "Choose source video"}
              </Button>
              {notice && (
                <p
                  role="alert"
                  className="min-w-0 max-w-full break-words text-sm text-red-300"
                >
                  {notice}
                </p>
              )}
              {source && (
                <VideoEditPanel
                  key={source.id}
                  sourceId={source.id}
                  sourceName={source.name}
                  sourceUrl={source.url}
                  onApplied={() => {
                    void history.refetch();
                  }}
                />
              )}
            </section>
          )}
          {(mode === "generate" || editEngine === "generative") && (
            <form
              onSubmit={submit}
              className="min-w-0 max-w-full rounded-2xl border bg-card p-5 shadow-sm sm:p-6"
            >
              <div className="flex min-w-0 flex-col justify-between gap-4 sm:flex-row sm:items-start">
                <div className="min-w-0 max-w-full">
                  <h2 className="font-semibold">
                    {mode === "edit"
                      ? "What should change?"
                      : "Describe the clip"}
                  </h2>
                  <p className="mt-1 max-w-xl text-xs leading-5 text-muted-foreground">
                    {mode === "edit"
                      ? "Use a simple instruction and add “keep everything else the same” when the change should stay tightly scoped."
                      : "Describe one complete short scene. The provider currently supports landscape 16:9 and portrait 9:16 output."}
                  </p>
                </div>
                <label className="flex min-w-0 max-w-full flex-col items-start gap-1 text-xs text-muted-foreground sm:flex-row sm:items-center">
                  <span>Frame</span>
                  <select
                    value={aspectRatio}
                    onChange={event =>
                      setAspectRatio(event.target.value as "16:9" | "9:16")
                    }
                    className="h-9 w-full min-w-0 max-w-full rounded-lg border bg-background px-2 text-sm text-foreground sm:w-auto"
                    aria-label="Video aspect ratio"
                  >
                    <option value="16:9">16:9 landscape</option>
                    <option value="9:16">9:16 portrait</option>
                  </select>
                </label>
              </div>

              {mode === "generate" && (
                <div className="mt-4 grid min-w-0 max-w-full grid-cols-1 gap-3 sm:grid-cols-2">
                  <label className="flex min-w-0 max-w-full flex-col items-start gap-1 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
                    <span>Resolution</span>
                    <select
                      value={resolution}
                      onChange={event => {
                        const next = event.target.value as "720p" | "1080p";
                        setResolution(next);
                        if (next === "1080p") setDurationSeconds(8);
                      }}
                      className="h-9 w-full min-w-0 max-w-full rounded-lg border bg-background px-2 text-sm text-foreground sm:w-auto"
                      aria-label="Video resolution"
                    >
                      <option value="720p">720p</option>
                      <option value="1080p">1080p · 8s only</option>
                    </select>
                  </label>
                  <label className="flex min-w-0 max-w-full flex-col items-start gap-1 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
                    <span>Duration</span>
                    <select
                      value={durationSeconds}
                      onChange={event =>
                        setDurationSeconds(
                          Number(event.target.value) as 4 | 6 | 8
                        )
                      }
                      className="h-9 w-full min-w-0 max-w-full rounded-lg border bg-background px-2 text-sm text-foreground sm:w-auto"
                      aria-label="Video duration"
                    >
                      <option value={4} disabled={resolution === "1080p"}>
                        4 seconds
                      </option>
                      <option value={6} disabled={resolution === "1080p"}>
                        6 seconds
                      </option>
                      <option value={8}>8 seconds</option>
                    </select>
                  </label>
                </div>
              )}

              <Textarea
                value={prompt}
                onChange={event => setPrompt(event.target.value)}
                placeholder={
                  mode === "edit"
                    ? "Example: remove the red backpack and fill the background naturally. Keep everything else the same."
                    : "Example: a single continuous shot of a ceramicist shaping a vase in warm morning light, with quiet studio ambience"
                }
                rows={5}
                maxLength={12_000}
                className="mt-5 min-w-0 w-full max-w-full resize-y"
              />

              {mode === "edit" && (
                <div className="mt-4 min-w-0 max-w-full rounded-xl border border-dashed border-primary/40 bg-primary/5 p-4">
                  <input
                    ref={sourceInputRef}
                    type="file"
                    accept="video/*,.mp4,.mov,.m4v,.webm"
                    className="hidden"
                    onChange={event => {
                      void onSourceChange(event.target.files?.[0] ?? null);
                      event.currentTarget.value = "";
                    }}
                  />
                  <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        <Film className="h-4 w-4 text-primary" />
                        Source video
                      </div>
                      <p className="mt-1 truncate text-xs text-muted-foreground">
                        {sourceFile
                          ? `${sourceFile.name} · ${formatBytes(sourceFile.size)}`
                          : source
                            ? `${source.name ?? "Uploaded source"} · ${formatDuration(source.duration)}`
                            : "MP4, MOV, M4V, or WEBM · up to 80 MB · up to 120 seconds"}
                      </p>
                    </div>
                    <div className="flex min-w-0 max-w-full flex-wrap items-center gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => sourceInputRef.current?.click()}
                        className="max-w-full gap-2 whitespace-normal break-words"
                      >
                        <Upload className="h-3.5 w-3.5" />
                        {sourceFile || source
                          ? "Replace source"
                          : "Choose source"}
                      </Button>
                      {(sourceFile || source) && (
                        <button
                          type="button"
                          onClick={() => {
                            setSourceFile(null);
                            setSource(null);
                          }}
                          className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground"
                          aria-label="Remove source video"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {mode === "generate" && (
                <div className="mt-4 min-w-0 max-w-full rounded-xl border border-dashed border-primary/30 bg-primary/5 p-4">
                  <label className="flex min-w-0 items-start gap-3 text-sm">
                    <input
                      type="checkbox"
                      checked={narrationEnabled}
                      onChange={event =>
                        setNarrationEnabled(event.target.checked)
                      }
                      className="mt-0.5 h-4 w-4 accent-primary"
                    />
                    <span className="min-w-0 max-w-full break-words">
                      <span className="font-medium">
                        Add natural narration (optional)
                      </span>
                      <span className="mt-1 block text-xs leading-5 text-muted-foreground">
                        Off means the generated clip keeps only provider audio.
                        Turn this on to mix the requested neural voice onto the
                        saved output.
                      </span>
                    </span>
                  </label>
                  {narrationEnabled && (
                    <div className="mt-4 space-y-3">
                      <Textarea
                        value={narrationText}
                        onChange={event => setNarrationText(event.target.value)}
                        rows={3}
                        maxLength={12_000}
                        placeholder="Narration script / transcript to read aloud"
                        aria-label="Generated video narration script"
                      />
                      <div className="grid min-w-0 max-w-full grid-cols-1 gap-3 sm:grid-cols-2">
                        <label className="flex min-w-0 max-w-full flex-col gap-1 text-xs text-muted-foreground">
                          <span>Narration language</span>
                          <LanguageSelect
                            value={narrationLanguage}
                            onChange={setNarrationLanguage}
                            includeAuto
                            label="Narration language"
                            className="h-9 w-full min-w-0 max-w-full rounded-lg border bg-background px-2 text-sm text-foreground"
                          />
                        </label>
                        <label className="flex min-w-0 max-w-full flex-col items-start gap-1 text-xs text-muted-foreground sm:flex-row sm:items-center">
                          <span>Voice</span>
                          <select
                            value={narrationGender}
                            onChange={event =>
                              setNarrationGender(
                                event.target.value as "woman" | "man"
                              )
                            }
                            aria-label="Narration voice"
                            className="h-9 w-full min-w-0 max-w-full rounded-lg border bg-background px-2 text-sm text-foreground sm:w-auto"
                          >
                            <option value="woman">Woman</option>
                            <option value="man">Man</option>
                          </select>
                        </label>
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="mt-5 flex min-w-0 flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="min-w-0 max-w-full break-words text-xs leading-5 text-muted-foreground">
                  {mode === "edit"
                    ? "The source is uploaded privately to your workspace before it is sent to Gemini for editing."
                    : "Generation uses Google Veo. The app needs available video quota; no fake local preview is used."}
                </p>
                <Button
                  type="submit"
                  disabled={busy || hasPending}
                  className="w-full max-w-full gap-2 whitespace-normal break-words sm:w-auto"
                >
                  {busy || pending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Sparkles className="h-4 w-4" />
                  )}
                  {busy
                    ? "Uploading…"
                    : pending
                      ? "Rendering…"
                      : mode === "edit"
                        ? "Edit video"
                        : "Generate video"}
                </Button>
              </div>
              {notice && (
                <div
                  className="mt-4 rounded-xl border border-destructive/25 bg-destructive/5 px-3 py-2.5 text-xs leading-5 text-destructive"
                  role="alert"
                >
                  {notice}
                  {/video-generation quota|quota exceeded/i.test(notice) && (
                    <div className="mt-3 min-w-0 max-w-full break-words text-muted-foreground">
                      <p>
                        This is a Google project quota response, not a failed
                        video download. No video was created. Review the
                        configured project’s limits in Google AI Studio.
                      </p>
                      <a
                        className="mt-2 inline-block font-medium text-primary underline"
                        href="https://aistudio.google.com/usage"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Check your Google AI Studio project limits
                      </a>
                    </div>
                  )}
                </div>
              )}
            </form>
          )}

          {result && (
            <section
              className="min-w-0 max-w-full rounded-2xl border bg-card p-5 shadow-sm sm:p-6"
              aria-live="polite"
            >
              <div className="mb-4 flex min-w-0 flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 max-w-full">
                  <h2 className="font-semibold">
                    {result.status === "completed"
                      ? "Video ready"
                      : result.status === "failed"
                        ? "Video failed"
                        : "Video rendering"}
                  </h2>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {result.status === "pending"
                      ? `Google ${result.provider === "veo" ? "Veo" : "Omni"} returned a pending operation. This page checks every 10 seconds for up to 10 minutes, and the operation can be recovered after a reload.`
                      : result.status === "completed"
                        ? `${result.operation === "edit" ? "Edited" : "Generated"} · ${formatDuration(result.duration) || "short clip"}`
                        : (result.error ??
                          "The provider did not return a playable video.")}
                  </p>
                </div>
                {pending && pendingSince ? (
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                ) : hasPending ? (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="max-w-full whitespace-normal break-words"
                    onClick={() => {
                      setPendingSince(Date.now());
                      void status.refetch();
                    }}
                  >
                    Check result
                  </Button>
                ) : null}
              </div>
              {result.url ? (
                <>
                  <video
                    controls
                    playsInline
                    preload="metadata"
                    src={result.url}
                    className="aspect-video w-full rounded-xl bg-black object-contain"
                  />
                  <MediaSaveActions
                    src={result.url}
                    filename={outputFilename}
                    className="mt-4"
                  />
                </>
              ) : (
                <div className="flex min-h-44 items-center justify-center rounded-xl bg-muted/40 px-5 text-center text-xs leading-5 text-muted-foreground">
                  {hasPending
                    ? "Waiting for Gemini to finish and return the playable file…"
                    : (result.error ?? "No video file was returned.")}
                </div>
              )}
            </section>
          )}
        </section>

        <aside className="min-w-0 max-w-full space-y-5">
          <div className="min-w-0 max-w-full rounded-2xl border bg-card p-5 shadow-sm">
            <div className="flex items-center gap-2 font-semibold">
              <Film className="h-4 w-4 text-primary" />
              Video limits
            </div>
            <ul className="mt-4 space-y-2 text-xs leading-5 text-muted-foreground">
              <li>
                • Source uploads: MP4, MOV, M4V, or WEBM (container-validated)
              </li>
              <li>• Source cap: 80 MB and 120 seconds</li>
              <li>• Outputs are validated and capped at 64 MB</li>
              <li>
                • Generated videos are short clips; arbitrary hour-long
                durations are not supported
              </li>
              <li>
                • Provider output includes Google’s SynthID provenance watermark
              </li>
            </ul>
          </div>
          <div className="min-w-0 max-w-full rounded-2xl border border-primary/20 bg-primary/5 p-5 text-xs leading-5 text-muted-foreground">
            <div className="font-semibold text-foreground">
              Edit prompts that work well
            </div>
            <p className="mt-2">
              Keep the instruction simple: “remove the phone,” “change the
              background to a quiet beach,” or “make this anime.” Add “keep
              everything else the same” when you want the action, framing, and
              untargeted details preserved.
            </p>
          </div>
        </aside>
      </div>
    </WorkspaceShell>
  );
}

function ModeButton({
  active,
  icon: Icon,
  label,
  description,
  onClick,
}: {
  active: boolean;
  icon: typeof Sparkles;
  label: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`w-full min-w-0 max-w-full rounded-xl p-4 text-left whitespace-normal break-words transition ${active ? "bg-primary text-primary-foreground shadow-sm" : "hover:bg-muted"}`}
    >
      <Icon className="mb-3 h-5 w-5" />
      <div className="text-sm font-semibold">{label}</div>
      <div
        className={`mt-1 text-xs leading-5 ${active ? "text-primary-foreground/75" : "text-muted-foreground"}`}
      >
        {description}
      </div>
    </button>
  );
}
