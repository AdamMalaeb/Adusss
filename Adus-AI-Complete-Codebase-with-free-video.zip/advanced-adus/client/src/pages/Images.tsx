import WorkspaceShell from "@/components/WorkspaceShell";
import ImagePreview from "@/components/ImagePreview";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { readFiles, type Attachment } from "@/lib/attachments";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Check,
  FileImage,
  Image as ImageIcon,
  Loader2,
  RefreshCw,
  Scissors,
  Sparkles,
  Upload,
  WandSparkles,
  X,
} from "lucide-react";
import { useMemo, useRef, useState } from "react";

type Mode = "generate" | "edit" | "resize";
type ResultStatus = "queued" | "running" | "success" | "error";

type ImageTask = {
  index: number;
  status: ResultStatus;
  url?: string;
  error?: string;
};

type HistoryPayload = {
  url?: string;
  prompt?: string;
  edited?: boolean;
  createdAt?: number;
  index?: number;
};

type ResizeResult = {
  url: string;
  width: number;
  height: number;
  format: string;
};

export type ImageBatchResult<T> = {
  index: number;
  value?: T;
  error?: unknown;
};

/** Run independent image RPCs with a small provider-friendly concurrency cap. */
export async function runImageBatch<T>(
  indices: number[],
  worker: (index: number) => Promise<T>,
  onResult: (result: ImageBatchResult<T>) => void,
  concurrency = 2
): Promise<void> {
  let cursor = 0;
  const lane = async () => {
    while (true) {
      const position = cursor;
      cursor += 1;
      if (position >= indices.length) return;
      const index = indices[position];
      try {
        onResult({ index, value: await worker(index) });
      } catch (error) {
        onResult({ index, error });
      }
    }
  };
  await Promise.all(
    Array.from(
      { length: Math.min(Math.max(1, concurrency), indices.length) },
      () => lane()
    )
  );
}

const modes: Array<{
  id: Mode;
  label: string;
  description: string;
  icon: typeof Sparkles;
}> = [
  {
    id: "generate",
    label: "Generate",
    description: "Make up to five standalone images",
    icon: Sparkles,
  },
  {
    id: "edit",
    label: "Edit",
    description: "Fix only what you target",
    icon: WandSparkles,
  },
  {
    id: "resize",
    label: "Resize",
    description: "Preserve content with contain by default",
    icon: Scissors,
  },
];

function errorMessage(error: unknown) {
  if (error && typeof error === "object" && "message" in error)
    return String((error as { message?: unknown }).message);
  return "This image task failed. Try it again.";
}

function isImageAttachment(attachment: Attachment | undefined) {
  return Boolean(attachment?.mimeType.toLowerCase().startsWith("image/"));
}

export default function Images() {
  const { user } = useAuth();
  const [mode, setMode] = useState<Mode>("generate");
  const [prompt, setPrompt] = useState("");
  const [count, setCount] = useState(4);
  const [reference, setReference] = useState<Attachment | null>(null);
  const [tasks, setTasks] = useState<ImageTask[]>([]);
  const [resizeResult, setResizeResult] = useState<ResizeResult | null>(null);
  const [resizeWidth, setResizeWidth] = useState("1024");
  const [resizeHeight, setResizeHeight] = useState("1024");
  const [resizeFit, setResizeFit] = useState<"contain" | "cover">("contain");
  const [resizeFormat, setResizeFormat] = useState<"png" | "jpeg" | "webp">(
    "png"
  );
  const [notice, setNotice] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const batchRef = useRef<{
    prompt: string;
    count: number;
    reference: Attachment | null;
  }>({ prompt: "", count: 4, reference: null });
  const batchBusyRef = useRef(false);
  const generateOne = trpc.adus.images.generateOne.useMutation();
  const resizeImage = trpc.adus.images.resize.useMutation();
  const history = trpc.adus.images.list.useQuery(undefined, {
    enabled: Boolean(user),
  });

  const successfulImages = useMemo(
    () =>
      tasks
        .filter(task => task.status === "success" && task.url)
        .map(task => ({ index: task.index, url: task.url! })),
    [tasks]
  );
  const completedCount = tasks.filter(
    task => task.status === "success" || task.status === "error"
  ).length;
  const failedCount = tasks.filter(task => task.status === "error").length;
  const running = tasks.some(task => task.status === "running");

  function updateTask(index: number, update: Partial<ImageTask>) {
    setTasks(current =>
      current.map(task =>
        task.index === index ? { ...task, ...update } : task
      )
    );
  }

  async function runBatch(indices: number[], batchCount = count) {
    if (!indices.length || batchBusyRef.current) return;
    batchBusyRef.current = true;
    const snapshot = batchRef.current;
    try {
      await runImageBatch(
        indices,
        async index => {
          updateTask(index, { status: "running", error: undefined });
          return generateOne.mutateAsync({
            prompt: snapshot.prompt,
            index,
            count: snapshot.count,
            reference: snapshot.reference ?? undefined,
          });
        },
        result => {
          if (result.error)
            updateTask(result.index, {
              status: "error",
              error: errorMessage(result.error),
            });
          else
            updateTask(result.index, {
              status: "success",
              url: result.value?.url,
              error: undefined,
            });
        },
        2
      );
      await history.refetch();
    } finally {
      batchBusyRef.current = false;
    }
  }

  async function submitGeneration(event: React.FormEvent) {
    event.preventDefault();
    if (batchBusyRef.current) return;
    setNotice("");
    setResizeResult(null);
    if (!prompt.trim()) {
      setNotice("Describe the image you want to create.");
      return;
    }
    if (mode === "edit" && !isImageAttachment(reference ?? undefined)) {
      setNotice("Choose an image reference before editing.");
      return;
    }
    batchRef.current = { prompt: prompt.trim(), count, reference };
    const nextTasks = Array.from({ length: count }, (_, index) => ({
      index,
      status: "queued" as const,
    }));
    setTasks(nextTasks);
    await runBatch(
      nextTasks.map(task => task.index),
      count
    );
  }

  async function retry(index: number) {
    setNotice("");
    updateTask(index, { status: "queued", error: undefined });
    await runBatch([index], count);
  }

  async function onReferenceFiles(files: FileList | null) {
    if (!files?.length) return;
    setNotice("");
    try {
      const attachments = await readFiles([files[0]]);
      const picked = attachments[0];
      if (!isImageAttachment(picked))
        throw new Error(
          "Choose an image file (PNG, JPEG, WebP, or another supported image)."
        );
      setReference(picked);
      setResizeResult(null);
    } catch (error) {
      setNotice(errorMessage(error));
    }
  }

  async function useGeneratedAsReference(url: string, index: number) {
    setNotice("");
    try {
      const response = await fetch(new URL(url, window.location.origin).href);
      if (!response.ok)
        throw new Error("The generated image could not be loaded for editing.");
      const blob = await response.blob();
      const file = new File(
        [blob],
        `generated-${index + 1}.${blob.type.split("/")[1] ?? "png"}`,
        { type: blob.type || "image/png" }
      );
      const attachment = (await readFiles([file]))[0];
      if (!isImageAttachment(attachment))
        throw new Error("Only image results can be used as an edit reference.");
      setReference(attachment);
      setMode("edit");
      setNotice("Generated image selected as the edit reference.");
    } catch (error) {
      setNotice(errorMessage(error));
    }
  }

  async function submitResize(event: React.FormEvent) {
    event.preventDefault();
    setNotice("");
    setResizeResult(null);
    if (!isImageAttachment(reference ?? undefined)) {
      setNotice("Choose an image to resize.");
      return;
    }
    const width = Number(resizeWidth);
    const height = Number(resizeHeight);
    if (
      !Number.isInteger(width) ||
      !Number.isInteger(height) ||
      width < 1 ||
      height < 1
    ) {
      setNotice("Width and height must be whole pixels.");
      return;
    }
    try {
      const result = await resizeImage.mutateAsync({
        file: reference!,
        width,
        height,
        fit: resizeFit,
        format: resizeFormat,
      });
      setResizeResult(result);
    } catch (error) {
      setNotice(errorMessage(error));
    }
  }

  const busy = running || generateOne.isPending || resizeImage.isPending;

  return (
    <WorkspaceShell
      title="Image workspace"
      subtitle="Create individual image results, make precise edits, or resize an existing image. Batches run two image tasks at a time and show partial results as they arrive."
    >
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <section className="space-y-5">
          <div className="rounded-2xl border bg-card p-2 shadow-sm">
            <div className="grid gap-2 sm:grid-cols-3">
              {modes.map(({ id, label, description, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    setMode(id);
                    setNotice("");
                    setResizeResult(null);
                  }}
                  className={`rounded-xl p-4 text-left transition ${mode === id ? "bg-primary text-primary-foreground shadow-sm" : "hover:bg-muted"}`}
                  aria-pressed={mode === id}
                >
                  <Icon className="mb-3 h-5 w-5" />
                  <div className="text-sm font-semibold">{label}</div>
                  <div
                    className={`mt-1 text-xs leading-5 ${mode === id ? "text-primary-foreground/75" : "text-muted-foreground"}`}
                  >
                    {description}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <form
            onSubmit={mode === "resize" ? submitResize : submitGeneration}
            className="rounded-2xl border bg-card p-5 shadow-sm sm:p-6"
          >
            {mode !== "resize" ? (
              <>
                <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
                  <div>
                    <h2 className="font-semibold">
                      {mode === "edit"
                        ? "What should change?"
                        : "Describe your image set"}
                    </h2>
                    <p className="mt-1 text-xs leading-5 text-muted-foreground">
                      {mode === "edit"
                        ? "The reference identity and untargeted details stay intact."
                        : "Each result is a complete image, never a collage or contact sheet."}
                    </p>
                  </div>
                  <label className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>Images</span>
                    <select
                      value={count}
                      onChange={event => setCount(Number(event.target.value))}
                      className="h-9 rounded-lg border bg-background px-2 text-sm text-foreground"
                      aria-label="Number of images"
                    >
                      {[1, 2, 3, 4, 5].map(value => (
                        <option key={value} value={value}>
                          {value}
                        </option>
                      ))}
                    </select>
                  </label>
                </div>
                <Textarea
                  value={prompt}
                  onChange={event => setPrompt(event.target.value)}
                  placeholder={
                    mode === "edit"
                      ? "Example: remove the small logo in the bottom-right corner and keep everything else unchanged"
                      : "Example: five distinct editorial images for a quiet coastal hotel, each standalone and ready to download"
                  }
                  rows={5}
                  className="mt-5 resize-y"
                  maxLength={12000}
                />
                <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <ReferencePicker
                    reference={reference}
                    inputRef={fileInputRef}
                    onFiles={onReferenceFiles}
                    onClear={() => setReference(null)}
                    label={
                      mode === "edit"
                        ? "Choose edit reference"
                        : "Optional reference"
                    }
                  />
                  <Button type="submit" disabled={busy} className="gap-2">
                    {busy ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4" />
                    )}
                    {busy
                      ? "Working…"
                      : mode === "edit"
                        ? "Edit image"
                        : `Generate ${count}`}
                  </Button>
                </div>
              </>
            ) : (
              <>
                <div>
                  <h2 className="font-semibold">
                    Resize without losing the original
                  </h2>
                  <p className="mt-1 text-xs leading-5 text-muted-foreground">
                    Contain is the safe default: it preserves the full image
                    with transparent or neutral padding. Cover crops only when
                    you choose it.
                  </p>
                </div>
                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  <label className="text-xs font-medium">
                    Width (px)
                    <input
                      value={resizeWidth}
                      onChange={event => setResizeWidth(event.target.value)}
                      inputMode="numeric"
                      type="number"
                      min={1}
                      max={4096}
                      className="mt-2 h-10 w-full rounded-lg border bg-background px-3 text-sm"
                    />
                  </label>
                  <label className="text-xs font-medium">
                    Height (px)
                    <input
                      value={resizeHeight}
                      onChange={event => setResizeHeight(event.target.value)}
                      inputMode="numeric"
                      type="number"
                      min={1}
                      max={4096}
                      className="mt-2 h-10 w-full rounded-lg border bg-background px-3 text-sm"
                    />
                  </label>
                  <label className="text-xs font-medium">
                    Fit
                    <select
                      value={resizeFit}
                      onChange={event =>
                        setResizeFit(event.target.value as "contain" | "cover")
                      }
                      className="mt-2 h-10 w-full rounded-lg border bg-background px-3 text-sm"
                    >
                      <option value="contain">
                        Contain · keep all content
                      </option>
                      <option value="cover">Cover · crop to fill</option>
                    </select>
                  </label>
                  <label className="text-xs font-medium">
                    Format
                    <select
                      value={resizeFormat}
                      onChange={event =>
                        setResizeFormat(
                          event.target.value as "png" | "jpeg" | "webp"
                        )
                      }
                      className="mt-2 h-10 w-full rounded-lg border bg-background px-3 text-sm"
                    >
                      <option value="png">PNG</option>
                      <option value="jpeg">JPEG</option>
                      <option value="webp">WebP</option>
                    </select>
                  </label>
                </div>
                <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <ReferencePicker
                    reference={reference}
                    inputRef={fileInputRef}
                    onFiles={onReferenceFiles}
                    onClear={() => setReference(null)}
                    label="Choose image"
                  />
                  <Button type="submit" disabled={busy} className="gap-2">
                    {resizeImage.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Scissors className="h-4 w-4" />
                    )}
                    {resizeImage.isPending ? "Resizing…" : "Resize image"}
                  </Button>
                </div>
              </>
            )}
            {notice && (
              <div
                className="mt-4 flex items-start gap-2 rounded-xl border border-destructive/25 bg-destructive/5 px-3 py-2.5 text-xs leading-5 text-destructive"
                role="alert"
              >
                <X className="mt-0.5 h-4 w-4 shrink-0" />
                {notice}
              </div>
            )}
          </form>

          {mode !== "resize" && tasks.length > 0 && (
            <section
              className="rounded-2xl border bg-card p-5 shadow-sm sm:p-6"
              aria-live="polite"
            >
              <div className="mb-5 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h2 className="font-semibold">Results</h2>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {completedCount} of {tasks.length} complete
                    {failedCount ? ` · ${failedCount} failed` : ""}. Results
                    stay available while the rest finish.
                  </p>
                </div>
                {failedCount > 0 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      void runBatch(
                        tasks
                          .filter(task => task.status === "error")
                          .map(task => task.index)
                      )
                    }
                    disabled={busy}
                    className="gap-2"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    Retry failed
                  </Button>
                )}
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {tasks.map(task => (
                  <article
                    key={task.index}
                    className="overflow-hidden rounded-xl border bg-muted/20"
                  >
                    <div className="flex items-center justify-between border-b px-3 py-2 text-xs">
                      <span className="font-medium">
                        Image {task.index + 1}
                      </span>
                      {task.status === "success" ? (
                        <Check className="h-4 w-4 text-emerald-600" />
                      ) : task.status === "running" ? (
                        <Loader2 className="h-4 w-4 animate-spin text-primary" />
                      ) : task.status === "error" ? (
                        <button
                          type="button"
                          onClick={() => void retry(task.index)}
                          className="inline-flex items-center gap-1 text-destructive hover:underline"
                        >
                          <RefreshCw className="h-3.5 w-3.5" />
                          Retry
                        </button>
                      ) : (
                        <span className="text-muted-foreground">Queued</span>
                      )}
                    </div>
                    {task.url ? (
                      <>
                        <ImagePreview
                          src={task.url}
                          alt={`Generated image ${task.index + 1}`}
                          filename={`adus-image-${task.index + 1}.png`}
                          trigger={
                            <button
                              type="button"
                              className="block w-full bg-muted text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset"
                              aria-label={`Preview generated image ${task.index + 1}`}
                            >
                              <img
                                src={task.url}
                                alt=""
                                className="aspect-square w-full object-contain"
                              />
                            </button>
                          }
                        />
                        <div className="flex items-center justify-between gap-2 p-3">
                          <button
                            type="button"
                            onClick={() =>
                              void useGeneratedAsReference(
                                task.url!,
                                task.index
                              )
                            }
                            className="text-xs text-muted-foreground hover:text-foreground"
                          >
                            Use for edit
                          </button>
                          <ImagePreview
                            src={task.url}
                            alt={`Generated image ${task.index + 1}`}
                            filename={`adus-image-${task.index + 1}.png`}
                            trigger={
                              <Button type="button" variant="link" size="sm">
                                Preview & download
                              </Button>
                            }
                          />
                        </div>
                      </>
                    ) : (
                      <div className="flex min-h-40 items-center justify-center px-4 text-center text-xs text-muted-foreground">
                        {task.status === "running"
                          ? "Generating this standalone image…"
                          : task.status === "error"
                            ? task.error
                            : "Waiting to start…"}
                      </div>
                    )}
                  </article>
                ))}
              </div>
            </section>
          )}

          {mode === "resize" && resizeResult && (
            <section className="rounded-2xl border bg-card p-5 shadow-sm sm:p-6">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="font-semibold">Resized image</h2>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {resizeResult.width} × {resizeResult.height} ·{" "}
                    {resizeResult.format.toUpperCase()}
                  </p>
                </div>
                <ImagePreview
                  src={resizeResult.url}
                  alt="Resized result"
                  filename={`adus-resized.${resizeResult.format === "jpeg" ? "jpg" : resizeResult.format}`}
                  trigger={
                    <Button type="button" variant="outline" size="sm">
                      Preview & download
                    </Button>
                  }
                />
              </div>
              <ImagePreview
                src={resizeResult.url}
                alt="Resized result"
                filename={`adus-resized.${resizeResult.format === "jpeg" ? "jpg" : resizeResult.format}`}
                trigger={
                  <button
                    type="button"
                    className="block w-full rounded-xl bg-muted text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset"
                    aria-label="Preview resized result"
                  >
                    <img
                      src={resizeResult.url}
                      alt=""
                      className="max-h-[600px] w-full rounded-xl object-contain"
                    />
                  </button>
                }
              />
            </section>
          )}
        </section>

        <aside className="space-y-5">
          <div className="rounded-2xl border bg-card p-5 shadow-sm">
            <div className="flex items-center gap-2 font-semibold">
              <FileImage className="h-4 w-4 text-primary" />
              Image limits
            </div>
            <ul className="mt-4 space-y-2 text-xs leading-5 text-muted-foreground">
              <li>• Up to 5 generated images per batch</li>
              <li>• Two generation tasks run concurrently</li>
              <li>• Failed items can be retried individually</li>
              <li>• Resize inputs: 8 MB, 40 MP, max 4096 px per side</li>
              <li>• Resize outputs: max 16 MP</li>
            </ul>
          </div>
          <div className="rounded-2xl border bg-card p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold">Recent image history</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  Private to this signed-in workspace
                </div>
              </div>
              <ImageIcon className="h-4 w-4 text-muted-foreground" />
            </div>
            {history.isLoading ? (
              <div className="mt-4 text-xs text-muted-foreground">
                Loading history…
              </div>
            ) : history.data?.length ? (
              <div className="mt-4 grid grid-cols-3 gap-2">
                {history.data.slice(0, 9).map(record => {
                  const payload = record.payload as HistoryPayload;
                  return payload.url ? (
                    <ImagePreview
                      key={record.id}
                      src={payload.url}
                      alt="Previous generated image"
                      filename={`adus-history-${record.id}.png`}
                      trigger={
                        <button
                          type="button"
                          className="block w-full overflow-hidden rounded-lg border bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset"
                          aria-label="Preview previous generated image"
                        >
                          <img
                            src={payload.url}
                            alt=""
                            className="aspect-square w-full object-cover"
                          />
                        </button>
                      }
                    />
                  ) : null;
                })}
              </div>
            ) : (
              <div className="mt-4 rounded-xl bg-muted/40 px-3 py-4 text-xs leading-5 text-muted-foreground">
                No generated images yet. Your successful results will appear
                here.
              </div>
            )}
          </div>
          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-5 text-xs leading-5 text-muted-foreground">
            <div className="font-semibold text-foreground">
              Reference handling
            </div>
            <p className="mt-2">
              Edits use the same image-generation service with the reference
              attached explicitly. The edit instruction is scoped to the
              requested change so identity and untargeted details are preserved.
            </p>
          </div>
        </aside>
      </div>
    </WorkspaceShell>
  );
}

function ReferencePicker({
  reference,
  inputRef,
  onFiles,
  onClear,
  label,
}: {
  reference: Attachment | null;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onFiles: (files: FileList | null) => void;
  onClear: () => void;
  label: string;
}) {
  return (
    <div className="flex min-w-0 items-center gap-2">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={event => {
          onFiles(event.target.files);
          event.currentTarget.value = "";
        }}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="inline-flex min-w-0 items-center gap-2 rounded-lg border px-3 py-2 text-xs font-medium hover:bg-muted"
      >
        <Upload className="h-3.5 w-3.5 shrink-0" />
        {reference ? (
          <span className="max-w-40 truncate">{reference.name}</span>
        ) : (
          label
        )}
      </button>
      {reference && (
        <button
          type="button"
          onClick={onClear}
          className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label="Remove image reference"
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
