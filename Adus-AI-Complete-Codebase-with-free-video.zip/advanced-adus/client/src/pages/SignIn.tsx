import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Check,
  Chrome,
  ExternalLink,
  Loader2,
  LockKeyhole,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { safeReturnRoute, startLegacyLogin } from "@/const";

function returnRouteFromLocation() {
  const params = new URLSearchParams(window.location.search);
  return safeReturnRoute(params.get("returnTo"));
}

export default function SignIn() {
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [statusFailed, setStatusFailed] = useState(false);
  const returnTo = useMemo(returnRouteFromLocation, []);
  const loginError = new URLSearchParams(window.location.search).get(
    "googleError"
  );

  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    fetch("/api/google/status", {
      credentials: "same-origin",
      signal: controller.signal,
    })
      .then(response => {
        if (!response.ok) throw new Error("status unavailable");
        return response.json() as Promise<{ configured?: boolean }>;
      })
      .then(data => {
        if (active) setConfigured(data.configured === true);
      })
      .catch(() => {
        if (active) {
          setConfigured(false);
          setStatusFailed(true);
        }
      })
      .finally(() => clearTimeout(timeout));
    return () => {
      active = false;
      clearTimeout(timeout);
      controller.abort();
    };
  }, []);

  const startGoogle = () => {
    window.location.assign(
      `/api/google/start?returnTo=${encodeURIComponent(returnTo)}`
    );
  };

  return (
    <main className="adus-grid flex min-h-screen items-center justify-center px-5 py-10 text-slate-100">
      <section className="adus-glass w-full max-w-md rounded-[2rem] border border-white/10 p-7 shadow-2xl shadow-cyan-950/20 sm:p-9">
        <a
          href={returnTo}
          className="mb-10 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-white/45 transition-colors hover:text-cyan-200"
        >
          <ArrowLeft size={14} /> Back to workspace
        </a>

        <div className="mb-8 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-300 text-lg font-black text-slate-950">
            A
          </div>
          <div>
            <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-cyan-200">
              Adus workspace
            </div>
            <div className="text-xs text-white/40">
              Ideas into useful systems.
            </div>
          </div>
        </div>

        <h1 className="text-3xl font-extrabold tracking-[-0.06em] text-white sm:text-4xl">
          Welcome back.
        </h1>
        <p className="mt-4 text-sm leading-7 text-white/55">
          Sign in to pick up your workspace, automations, and creative tools.
        </p>
        {loginError && (
          <p
            role="alert"
            className="mt-4 rounded-xl border border-amber-300/20 bg-amber-300/5 p-3 text-sm text-amber-100"
          >
            {loginError === "access_denied"
              ? "Google sign-in was cancelled. You can try again when ready."
              : "Google sign-in did not complete or expired. Please try again."}
          </p>
        )}

        <Button
          type="button"
          onClick={startGoogle}
          disabled={configured !== true}
          className="mt-8 h-12 w-full rounded-xl bg-white font-bold text-slate-950 hover:bg-cyan-50"
        >
          {configured === null ? (
            <Loader2 size={17} className="animate-spin" />
          ) : (
            <Chrome size={17} />
          )}
          {configured === true
            ? "Continue with Google"
            : "Google sign-in setup required"}
        </Button>

        <div className="mt-4 flex items-start gap-2 text-xs leading-5 text-white/40">
          {configured === true ? (
            <Check size={14} className="mt-0.5 shrink-0 text-cyan-300" />
          ) : (
            <LockKeyhole size={14} className="mt-0.5 shrink-0 text-amber-300" />
          )}
          <span>
            {configured === true
              ? "Google will verify your identity securely before Adus creates a local session."
              : statusFailed
                ? "Sign-in configuration could not be checked. Google sign-in is unavailable until the server is configured."
                : "An administrator must set the Google OAuth credentials and HTTPS callback before this option can be used."}
          </span>
        </div>

        <div className="my-8 flex items-center gap-3 text-[10px] font-mono uppercase tracking-[0.2em] text-white/25">
          <span className="h-px flex-1 bg-white/10" />
          <span>Optional legacy access</span>
          <span className="h-px flex-1 bg-white/10" />
        </div>

        <button
          type="button"
          onClick={startLegacyLogin}
          className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] text-sm font-semibold text-white/75 transition-colors hover:border-cyan-300/40 hover:bg-white/[0.08] hover:text-white"
        >
          Use legacy Manus sign-in <ExternalLink size={14} />
        </button>

        <p className="mt-6 text-center text-[11px] leading-5 text-white/30">
          By continuing, you use Adus only with an account you control. Google
          identities are never matched to an existing account by email alone.
        </p>
      </section>
    </main>
  );
}
