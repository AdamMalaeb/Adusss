import WorkspaceShell from "@/components/WorkspaceShell";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import {
  CheckCircle2,
  Code2,
  ExternalLink,
  GitBranch,
  Layers3,
  Loader2,
  RotateCcw,
  ShieldAlert,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";

const defaultWorkspacePrompt = "Add a new tab named Test";
const defaultSourcePrompt =
  "Improve the mobile study view without changing authentication, permissions, billing, or the approved study voice and languages. Add or update a focused regression test.";

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

export default function Upgrade() {
  const [workspacePrompt, setWorkspacePrompt] = useState(
    defaultWorkspacePrompt
  );
  const [sourcePrompt, setSourcePrompt] = useState(defaultSourcePrompt);
  const [workspaceError, setWorkspaceError] = useState("");
  const [sourceError, setSourceError] = useState("");
  const [selectedTabId, setSelectedTabId] = useState("");
  const [customTask, setCustomTask] = useState("");
  const [selectedFunction, setSelectedFunction] = useState<
    "notes" | "summarizer" | "calculator" | "translator" | "aiTool"
  >("notes");
  const utils = trpc.useUtils();

  const workspaceStatus = trpc.adus.workspaceExtensions.status.useQuery(
    undefined,
    { meta: { handledError: true } }
  );
  const workspaceTabs = trpc.adus.workspaceExtensions.list.useQuery(undefined, {
    meta: { handledError: true },
  });
  const workspaceHistory = trpc.adus.workspaceExtensions.history.useQuery(
    undefined,
    { meta: { handledError: true } }
  );
  const workspacePropose = trpc.adus.workspaceExtensions.propose.useMutation({
    meta: { handledError: true },
  });
  const workspaceApply = trpc.adus.workspaceExtensions.activate.useMutation({
    meta: { handledError: true },
    onSuccess: () => {
      void utils.adus.workspaceExtensions.invalidate();
    },
  });
  const workspaceUndo = trpc.adus.workspaceExtensions.undo.useMutation({
    meta: { handledError: true },
    onSuccess: () => {
      void utils.adus.workspaceExtensions.invalidate();
    },
  });

  useEffect(() => {
    const first = workspaceTabs.data?.[0];
    if (!selectedTabId && first) {
      setSelectedTabId(first.id);
      setSelectedFunction(first.functionConfig.type);
      if (first.functionConfig.type === "aiTool") {
        setCustomTask(first.functionConfig.instructions);
      }
    }
  }, [selectedTabId, workspaceTabs.data]);

  useEffect(() => {
    const selected = workspaceTabs.data?.find(tab => tab.id === selectedTabId);
    if (selected) {
      setSelectedFunction(selected.functionConfig.type);
      if (selected.functionConfig.type === "aiTool") {
        setCustomTask(selected.functionConfig.instructions);
      }
    }
  }, [selectedTabId, workspaceTabs.data]);

  const sourceStatus = trpc.adus.upgrade.source.status.useQuery(undefined, {
    meta: { handledError: true },
  });
  const sourceHistory = trpc.adus.upgrade.source.history.useQuery(undefined, {
    enabled: sourceStatus.data?.owner === true,
    meta: { handledError: true },
  });
  const sourcePropose = trpc.adus.upgrade.source.propose.useMutation({
    meta: { handledError: true },
    onSuccess: () => {
      void utils.adus.upgrade.source.history.invalidate();
    },
  });
  const sourceApprove = trpc.adus.upgrade.source.approve.useMutation({
    meta: { handledError: true },
    onSuccess: () => {
      void utils.adus.upgrade.source.history.invalidate();
    },
  });

  async function proposeWorkspaceChange() {
    setWorkspaceError("");
    try {
      await workspacePropose.mutateAsync({ prompt: workspacePrompt });
    } catch (error) {
      setWorkspaceError(
        errorMessage(
          error,
          "The workspace change could not be drafted. No tab was changed."
        )
      );
    }
  }

  async function proposeSelectedTabAction(prompt: string) {
    setWorkspacePrompt(prompt);
    setWorkspaceError("");
    try {
      await workspacePropose.mutateAsync({ prompt });
    } catch (error) {
      setWorkspaceError(
        errorMessage(
          error,
          "The selected tab change could not be drafted. No tab was changed."
        )
      );
    }
  }

  function selectedTabPrompt(operation: "remove" | "edit") {
    if (!selectedTabId) return "";
    return operation === "remove"
      ? `Remove tab ${selectedTabId}`
      : selectedFunction === "aiTool"
        ? `Configure tab ${selectedTabId} to ${customTask.trim()}`
        : `Edit tab ${selectedTabId} to use ${selectedFunction}`;
  }

  async function removeSelectedTab() {
    const prompt = selectedTabPrompt("remove");
    if (prompt) await proposeSelectedTabAction(prompt);
  }

  async function configureSelectedTab() {
    const prompt = selectedTabPrompt("edit");
    if (prompt) await proposeSelectedTabAction(prompt);
  }

  async function applyWorkspaceChange() {
    const proposal = workspacePropose.data;
    if (!proposal) return;
    setWorkspaceError("");
    try {
      await workspaceApply.mutateAsync({ id: proposal.id, confirmed: true });
      workspacePropose.reset();
    } catch (error) {
      setWorkspaceError(
        errorMessage(
          error,
          "The workspace change could not be applied. No tab was changed."
        )
      );
    }
  }

  async function undoWorkspaceChange(id: string) {
    setWorkspaceError("");
    try {
      await workspaceUndo.mutateAsync({ id, confirmed: true });
    } catch (error) {
      setWorkspaceError(
        errorMessage(
          error,
          "The workspace change could not be undone. The tab was not changed."
        )
      );
    }
  }

  async function proposeSourceChange() {
    setSourceError("");
    try {
      await sourcePropose.mutateAsync({ prompt: sourcePrompt });
    } catch (error) {
      setSourceError(
        errorMessage(
          error,
          "The source proposal could not be created. No source change was created."
        )
      );
    }
  }

  async function approveSource(id: string) {
    setSourceError("");
    try {
      await sourceApprove.mutateAsync({ id, confirmed: true });
    } catch (error) {
      setSourceError(
        errorMessage(
          error,
          "The draft PR could not be created. The proposal was not published or merged."
        )
      );
    }
  }

  const workspaceProposal = workspacePropose.data;

  return (
    <WorkspaceShell
      title="Upgrade Adus safely"
      subtitle="Make a reviewed, reversible workspace change first. Repository code remains a separate owner-only draft-PR workflow and never pretends to rewrite the running app."
    >
      <div className="flex flex-col gap-8">
        <section className="rounded-2xl border border-cyan-200/20 bg-cyan-200/[.04] p-6">
          <div className="flex items-start gap-3">
            <Layers3 className="mt-1 text-cyan-200" size={20} />
            <div>
              <h2 className="text-lg font-semibold">Workspace tabs</h2>
              <p className="mt-2 text-sm leading-6 text-white/65">
                Ask for a clear tab change, review the exact declarative action,
                then apply it. Changes are durable and scoped to your account;
                they never evaluate arbitrary code or rewrite repository files.
              </p>
            </div>
          </div>

          {workspaceStatus.data?.owner ? (
            <>
              <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_auto]">
                <textarea
                  aria-label="Workspace tab change prompt"
                  value={workspacePrompt}
                  onChange={event => setWorkspacePrompt(event.target.value)}
                  rows={3}
                  className="w-full rounded-xl border border-white/10 bg-[#080b12] p-4 text-sm leading-7 outline-none focus:border-cyan-200/40"
                  placeholder="Add a new tab named Test"
                />
                <Button
                  onClick={() => void proposeWorkspaceChange()}
                  disabled={
                    workspacePropose.isPending ||
                    workspacePrompt.trim().length < 4
                  }
                  className="h-fit bg-cyan-300 text-slate-950"
                >
                  {workspacePropose.isPending ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    <Layers3 size={16} />
                  )}
                  Review tab change
                </Button>
              </div>
              <p className="mt-3 text-xs leading-5 text-white/45">
                You can write naturally: “Add a tab for generating business
                ideas”, “Rename the long translator tab to Translator”,
                “Configure tab 5 to summarize”, or “Remove tab 5”. New task
                names stay short while the reviewed function keeps the full
                duty. Selected-tab controls below submit the exact durable tab
                ID, so removal never guesses between duplicate labels.
              </p>
            </>
          ) : (
            <div className="mt-5 flex items-start gap-3 rounded-xl border border-white/10 bg-black/20 p-4 text-sm text-white/55">
              <ShieldAlert
                size={18}
                className="mt-0.5 shrink-0 text-white/40"
              />
              <p>
                Workspace tab changes are restricted to the application owner.
                Your existing workspace remains available below and in the
                sidebar.
              </p>
            </div>
          )}

          {workspaceError && (
            <p role="alert" className="mt-4 text-sm text-rose-200">
              {workspaceError}
            </p>
          )}

          {workspaceProposal && (
            <div className="mt-6 rounded-xl border border-amber-200/20 bg-amber-200/[.04] p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-[.18em] text-amber-200/70">
                    Review exact change
                  </p>
                  <h3 className="mt-2 text-xl font-semibold">
                    {workspaceProposal.summary}
                  </h3>
                </div>
                <span className="rounded-full border border-amber-200/20 px-3 py-1 text-xs text-amber-200">
                  Not applied
                </span>
              </div>
              <div className="mt-4 grid gap-3 text-sm text-white/60 sm:grid-cols-2">
                <div className="rounded-lg bg-black/20 p-3">
                  <span className="text-xs text-white/40">Operation</span>
                  <p className="mt-1 font-medium text-white/80">
                    {workspaceProposal.operation}
                  </p>
                </div>
                <div className="rounded-lg bg-black/20 p-3">
                  <span className="text-xs text-white/40">Route result</span>
                  <p className="mt-1 font-mono text-xs text-cyan-100">
                    {workspaceProposal.after?.path ??
                      workspaceProposal.before?.path ??
                      "No route"}
                  </p>
                </div>
              </div>
              <Button
                onClick={() => void applyWorkspaceChange()}
                disabled={workspaceApply.isPending}
                className="mt-5 bg-emerald-300 text-slate-950"
              >
                {workspaceApply.isPending ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <CheckCircle2 size={16} />
                )}
                Apply reviewed change
              </Button>
              <p className="mt-3 text-xs leading-5 text-white/45">
                Applying stores the tab for this account and adds its route to
                the sidebar. You can undo applied changes from history.
              </p>
            </div>
          )}

          <div className="mt-6">
            <h3 className="mb-3 text-sm font-semibold">Your active tabs</h3>
            {workspaceTabs.data?.length ? (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {workspaceTabs.data.map((tab, index) => (
                  <Link
                    key={tab.id}
                    href={tab.path}
                    className="rounded-xl border border-white/10 bg-black/15 p-4 transition-colors hover:border-cyan-200/30"
                  >
                    <p className="font-medium">
                      <span className="mr-2 font-mono text-xs text-cyan-200/70">
                        {index + 1}.
                      </span>
                      {tab.label}
                    </p>
                    <p className="mt-1 font-mono text-xs text-white/40">
                      {tab.path}
                    </p>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="rounded-xl border border-dashed border-white/10 p-4 text-sm text-white/40">
                No declarative tabs yet. Add one above to create a real route.
              </p>
            )}
          </div>

          {workspaceTabs.data?.length && workspaceStatus.data?.owner ? (
            <div className="mt-5 rounded-xl border border-white/10 bg-black/15 p-4">
              <h3 className="text-sm font-semibold">Target an active tab</h3>
              <p className="mt-2 text-xs leading-5 text-white/50">
                Choose a tab by its durable ID, then prepare a reviewed edit or
                removal. Nothing changes until you review and apply the proposal
                above.
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto]">
                <select
                  aria-label="Active tab target"
                  value={selectedTabId}
                  onChange={event => setSelectedTabId(event.target.value)}
                  className="h-10 min-w-0 rounded-md border border-white/10 bg-[#080b12] px-3 text-sm"
                >
                  {workspaceTabs.data.map((tab, index) => (
                    <option key={tab.id} value={tab.id}>
                      {index + 1}. {tab.label} · {tab.id.slice(0, 8)}…
                    </option>
                  ))}
                </select>
                <select
                  aria-label="Selected tab function"
                  value={selectedFunction}
                  onChange={event =>
                    setSelectedFunction(
                      event.target.value as typeof selectedFunction
                    )
                  }
                  className="h-10 min-w-0 rounded-md border border-white/10 bg-[#080b12] px-3 text-sm"
                >
                  <option value="notes">Notes</option>
                  <option value="summarizer">Summarizer</option>
                  <option value="calculator">Calculator</option>
                  <option value="translator">Translator</option>
                  <option value="aiTool">Custom text tool</option>
                </select>
                {selectedFunction === "aiTool" && (
                  <textarea
                    aria-label="Custom text tool duty"
                    value={customTask}
                    onChange={event => setCustomTask(event.target.value)}
                    rows={2}
                    placeholder="Generate practical business ideas for independent cafes"
                    className="min-h-10 rounded-md border border-white/10 bg-[#080b12] px-3 py-2 text-sm sm:col-span-2"
                  />
                )}
                <div className="flex gap-2 sm:justify-end">
                  <Button
                    onClick={() => void configureSelectedTab()}
                    disabled={
                      workspacePropose.isPending ||
                      !selectedTabId ||
                      (selectedFunction === "aiTool" && customTask.trim().length < 8)
                    }
                    className="bg-cyan-300 text-slate-950"
                  >
                    Configure
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => void removeSelectedTab()}
                    disabled={workspacePropose.isPending || !selectedTabId}
                    className="border-rose-200/20 text-rose-100"
                  >
                    Remove
                  </Button>
                </div>
              </div>
            </div>
          ) : null}

          {workspaceHistory.data?.length ? (
            <div className="mt-7">
              <h3 className="mb-3 text-sm font-semibold">Change history</h3>
              <div className="space-y-3">
                {workspaceHistory.data.map(row => (
                  <div
                    key={row.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 p-4"
                  >
                    <div>
                      <p className="text-sm font-medium">{row.summary}</p>
                      <p className="mt-1 text-xs text-white/40">
                        {row.status} ·{" "}
                        {new Date(row.proposedAt).toLocaleString()}
                      </p>
                    </div>
                    {row.status === "applied" &&
                      workspaceStatus.data?.owner && (
                        <button
                          disabled={workspaceUndo.isPending}
                          onClick={() => void undoWorkspaceChange(row.id)}
                          className="flex items-center gap-2 text-xs text-cyan-200"
                        >
                          <RotateCcw size={14} />
                          Undo
                        </button>
                      )}
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </section>

        <section className="rounded-2xl border border-white/10 bg-white/[.03] p-6">
          <div className="flex items-start gap-3">
            <Code2 className="mt-1 text-cyan-200" size={20} />
            <div>
              <h2 className="text-lg font-semibold">Repository code upgrade</h2>
              <p className="mt-2 text-sm leading-6 text-white/60">
                This is the separate owner-only workflow. It reads a bounded
                allowlist, drafts complete file replacements and exact diffs,
                and only creates a private branch and draft PR after review. It
                never executes model-generated scripts, merges, deploys,
                publishes, or changes auth, permissions, billing, secrets, or
                workflows.
              </p>
            </div>
          </div>

          {sourceStatus.data?.owner ? (
            <>
              <div className="mt-5 rounded-xl border border-white/10 bg-black/20 p-4 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <GitBranch size={16} className="text-cyan-200" />
                  <span className="font-medium">
                    {sourceStatus.data.configured
                      ? `Configured${sourceStatus.data.repository ? ` · ${sourceStatus.data.repository}` : ""}`
                      : "Setup required"}
                  </span>
                </div>
                <p className="mt-2 leading-6 text-white/60">
                  {sourceStatus.data.message}
                </p>
                {!sourceStatus.data.configured && (
                  <p className="mt-3 text-xs leading-6 text-amber-200/80">
                    Configure <code>ADUS_SOURCE_REPO</code> with a private
                    <code> owner/repository</code> value and a server-only
                    <code> GITHUB_SOURCE_TOKEN</code>. No source mutation is
                    attempted while setup is missing.
                  </p>
                )}
              </div>

              <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_auto]">
                <textarea
                  aria-label="Source code upgrade prompt"
                  value={sourcePrompt}
                  onChange={event => setSourcePrompt(event.target.value)}
                  rows={4}
                  disabled={!sourceStatus.data.configured}
                  className="w-full rounded-xl border border-white/10 bg-[#080b12] p-4 text-sm leading-7 outline-none focus:border-cyan-200/40 disabled:cursor-not-allowed disabled:opacity-50"
                />
                <Button
                  onClick={() => void proposeSourceChange()}
                  disabled={
                    !sourceStatus.data.configured ||
                    sourcePropose.isPending ||
                    sourcePrompt.trim().length < 4
                  }
                  className="h-fit bg-cyan-300 text-slate-950"
                >
                  {sourcePropose.isPending ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    <Code2 size={16} />
                  )}
                  Propose code diff
                </Button>
              </div>
            </>
          ) : (
            <div className="mt-5 flex items-start gap-3 rounded-xl border border-white/10 bg-black/20 p-4 text-sm text-white/55">
              <ShieldAlert
                size={18}
                className="mt-0.5 shrink-0 text-white/40"
              />
              <p>Source-code upgrades are restricted to the owner.</p>
            </div>
          )}

          {sourceError && (
            <p role="alert" className="mt-4 text-sm text-rose-200">
              {sourceError}
            </p>
          )}

          {sourcePropose.data && (
            <div className="mt-6 rounded-xl border border-emerald-200/15 bg-emerald-200/[.03] p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-xl font-semibold">
                    {sourcePropose.data.title}
                  </h3>
                  <p className="mt-2 max-w-3xl whitespace-pre-wrap text-sm leading-6 text-white/65">
                    {sourcePropose.data.summary}
                  </p>
                </div>
                <span className="rounded-full border border-amber-200/20 px-3 py-1 text-xs text-amber-200">
                  Review required
                </span>
              </div>
              <div className="mt-5 space-y-4">
                {sourcePropose.data.changedFiles.map(file => (
                  <article
                    key={file.path}
                    className="rounded-xl border border-white/10 bg-black/20 p-4"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <code className="text-sm text-cyan-100">{file.path}</code>
                      <span className="text-xs text-white/45">
                        {file.reason}
                      </span>
                    </div>
                    <pre className="mt-3 max-h-72 overflow-auto whitespace-pre-wrap rounded-lg bg-[#05070b] p-3 text-[11px] leading-5 text-white/65">
                      {file.diff}
                    </pre>
                  </article>
                ))}
              </div>
              {sourcePropose.data.tests.length > 0 && (
                <div className="mt-5">
                  <h4 className="text-sm font-semibold">Requested checks</h4>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-xs leading-5 text-white/60">
                    {sourcePropose.data.tests.map((test, index) => (
                      <li key={index}>{test}</li>
                    ))}
                  </ul>
                </div>
              )}
              <Button
                onClick={() => void approveSource(sourcePropose.data.id)}
                disabled={sourceApprove.isPending}
                className="mt-5 bg-emerald-300 text-slate-950"
              >
                {sourceApprove.isPending ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <GitBranch size={16} />
                )}
                Approve branch + draft PR
              </Button>
              <p className="mt-3 text-xs leading-5 text-white/40">
                Approval rechecks the base commit. A changed branch rejects the
                operation and requires a fresh proposal.
              </p>
            </div>
          )}

          {sourceHistory.data && sourceHistory.data.length > 0 && (
            <div className="mt-7">
              <h3 className="mb-3 text-sm font-semibold">
                Source upgrade history
              </h3>
              <div className="space-y-3">
                {sourceHistory.data.map(row => (
                  <div
                    key={row.id}
                    className="rounded-xl border border-white/10 p-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium">
                          {row.payload.title}
                        </p>
                        <p className="mt-1 text-xs text-white/40">
                          {row.payload.status} ·{" "}
                          {new Date(row.createdAt).toLocaleString()}
                        </p>
                      </div>
                      {row.payload.result?.pullRequestUrl && (
                        <a
                          href={row.payload.result.pullRequestUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-cyan-200 hover:underline"
                        >
                          Draft PR <ExternalLink size={13} />
                        </a>
                      )}
                    </div>
                    {row.payload.result?.ci && (
                      <p className="mt-2 text-xs text-white/45">
                        CI: {row.payload.result.ci.status} · commit{" "}
                        {row.payload.result.commitSha?.slice(0, 12)}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      </div>
    </WorkspaceShell>
  );
}
