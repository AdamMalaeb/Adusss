import WorkspaceShell from "@/components/WorkspaceShell";
import RichText from "@/components/RichText";
import { LanguageSelect } from "@/components/LanguageSelect";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { isRtl, type LanguageSelection } from "@shared/languages";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft,
  Calculator,
  Languages,
  Layers3,
  Loader2,
  NotebookPen,
  Sparkles,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";

const toolCopy = {
  notes: {
    label: "Notes",
    icon: NotebookPen,
    description: "A private destination for future reviewed workspace notes.",
  },
  summarizer: {
    label: "Summarizer",
    icon: Sparkles,
    description:
      "Turn pasted material into a concise, faithful Markdown summary.",
  },
  calculator: {
    label: "Calculator",
    icon: Calculator,
    description:
      "Evaluate numbers and basic arithmetic without executing code.",
  },
  translator: {
    label: "Translator",
    icon: Languages,
    description: "Translate text through the server-side Adus LLM helper.",
  },
  aiTool: {
    label: "Custom text tool",
    icon: Sparkles,
    description: "Run the reviewed text-only duty configured for this tab.",
  },
} as const;

type ToolType = keyof typeof toolCopy;
type GenericControl = {
  name: string;
  label: string;
  type: "text" | "textarea";
  required: boolean;
  placeholder?: string;
};

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

export default function WorkspaceExtension() {
  const { slug = "" } = useParams<{ slug: string }>();
  const [, setLocation] = useLocation();
  const tab = trpc.adus.workspaceExtensions.get.useQuery(
    { slug },
    { enabled: Boolean(slug), meta: { handledError: true } }
  );
  const [text, setText] = useState("");
  const [genericValues, setGenericValues] = useState<Record<string, string>>(
    {}
  );
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [sourceLanguage, setSourceLanguage] = useState<
    LanguageSelection | "auto"
  >("auto");
  const [targetLanguage, setTargetLanguage] = useState<LanguageSelection>("en");

  useEffect(() => {
    if (!tab.data) return;
    setSourceLanguage(tab.data.functionConfig.sourceLanguage);
    setTargetLanguage(tab.data.functionConfig.targetLanguage);
    setText("");
    setGenericValues({});
    setResult("");
    setError("");
  }, [
    tab.data?.id,
    tab.data?.updatedAt,
    tab.data?.functionConfig.sourceLanguage,
    tab.data?.functionConfig.targetLanguage,
  ]);

  const translate = trpc.adus.workspaceExtensions.translate.useMutation({
    meta: { handledError: true },
  });
  const summarize = trpc.adus.workspaceExtensions.summarize.useMutation({
    meta: { handledError: true },
  });
  const calculate = trpc.adus.workspaceExtensions.calculate.useMutation({
    meta: { handledError: true },
  });
  const execute = trpc.adus.workspaceExtensions.execute.useMutation({
    meta: { handledError: true },
  });

  if (tab.isLoading) {
    return (
      <WorkspaceShell
        title="Loading workspace tab"
        subtitle="Reading your durable workspace configuration."
      >
        <div className="flex items-center gap-2 text-sm text-white/55">
          <Loader2 size={16} className="animate-spin" /> Loading tab…
        </div>
      </WorkspaceShell>
    );
  }

  if (!tab.data) {
    return (
      <WorkspaceShell
        title="Workspace tab unavailable"
        subtitle="This tab does not exist in your workspace, or it was removed."
      >
        <Button
          onClick={() => setLocation("/upgrade")}
          className="bg-cyan-300 text-slate-950"
        >
          <ArrowLeft size={16} /> Manage workspace tabs
        </Button>
      </WorkspaceShell>
    );
  }

  const currentTab = tab.data;
  const tool = currentTab.functionConfig.type as ToolType;
  const copy = toolCopy[tool];
  const Icon = copy.icon;
  const genericConfig =
    currentTab.functionConfig.type === "aiTool"
      ? currentTab.functionConfig
      : null;
  const busy =
    translate.isPending ||
    summarize.isPending ||
    calculate.isPending ||
    execute.isPending;

  async function runTool() {
    setError("");
    setResult("");
    try {
      if (tool === "aiTool") {
        if (!genericConfig) return;
        const missing = genericConfig.inputControls.find(
          control => control.required && !genericValues[control.name]?.trim()
        );
        if (missing) {
          setError(
            `${missing.label} is required before running ${genericConfig.name}.`
          );
          return;
        }
        const output = await execute.mutateAsync({
          tabId: currentTab.id,
          values: genericValues,
        });
        setResult(output.text);
        return;
      }
      if (!text.trim()) {
        setError(
          tool === "calculator"
            ? "Enter an expression first."
            : "Enter some text first."
        );
        return;
      }
      if (tool === "translator") {
        const output = await translate.mutateAsync({
          tabId: currentTab.id,
          text,
          sourceLanguage,
          targetLanguage,
        });
        setResult(output.text);
      } else if (tool === "summarizer") {
        const output = await summarize.mutateAsync({
          tabId: currentTab.id,
          text,
        });
        setResult(output.text);
      } else if (tool === "calculator") {
        const output = await calculate.mutateAsync({
          tabId: currentTab.id,
          text,
        });
        setResult(`### Result\n\n\`${output.value}\``);
      }
    } catch (caught) {
      setError(
        errorMessage(
          caught,
          "The workspace function could not finish. No tab configuration was changed."
        )
      );
    }
  }

  const genericControls: GenericControl[] = genericConfig?.inputControls ?? [];

  return (
    <WorkspaceShell
      title={currentTab.label}
      subtitle="A durable, account-scoped workspace tab. Its reviewed function is isolated to this tab; it never evaluates arbitrary code or rewrites repository files."
    >
      <div className="grid max-w-5xl gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(260px,360px)]">
        <section className="rounded-2xl border border-cyan-200/15 bg-cyan-200/[.03] p-6">
          <div className="flex items-start gap-3">
            <Icon className="mt-1 text-cyan-200" size={20} />
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-semibold">
                  {genericConfig?.name ?? copy.label}
                </h2>
                <span className="rounded-full border border-cyan-200/20 px-2 py-0.5 text-[10px] uppercase tracking-[.16em] text-cyan-100/70">
                  Active tab
                </span>
              </div>
              <p className="mt-2 text-sm leading-7 text-white/60">
                {copy.description}
              </p>
              {genericConfig && (
                <p className="mt-2 text-xs leading-6 text-white/45">
                  Reviewed duty: {genericConfig.instructions}
                </p>
              )}
              <p className="mt-3 font-mono text-xs text-white/40">
                {currentTab.path} · {currentTab.id}
              </p>
            </div>
          </div>

          {tool === "notes" ? (
            <div className="mt-6 rounded-xl border border-dashed border-white/15 bg-black/15 p-4 text-sm leading-6 text-white/55">
              This tab is configured as a notes destination. Use Upgrade Adus to
              review a different function for this exact tab.
            </div>
          ) : tool === "aiTool" ? (
            <div className="mt-6 space-y-4">
              {genericControls.map(control => {
                const value = genericValues[control.name] ?? "";
                return (
                  <label
                    key={control.name}
                    className="block text-sm text-white/70"
                  >
                    <span className="mb-2 block">
                      {control.label}
                      {control.required ? " *" : ""}
                    </span>
                    {control.type === "text" ? (
                      <input
                        aria-label={control.label}
                        value={value}
                        onChange={event =>
                          setGenericValues(previous => ({
                            ...previous,
                            [control.name]: event.target.value,
                          }))
                        }
                        placeholder={control.placeholder}
                        className="h-11 w-full rounded-md border border-white/10 bg-[#080b12] px-3 text-sm text-white outline-none focus:border-cyan-200/40"
                      />
                    ) : (
                      <Textarea
                        aria-label={control.label}
                        value={value}
                        onChange={event =>
                          setGenericValues(previous => ({
                            ...previous,
                            [control.name]: event.target.value,
                          }))
                        }
                        placeholder={control.placeholder}
                        rows={6}
                        className="border-white/10 bg-[#080b12] leading-7"
                      />
                    )}
                  </label>
                );
              })}
              <Button
                onClick={() => void runTool()}
                disabled={busy}
                className="bg-cyan-300 text-slate-950"
              >
                {busy ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Icon size={16} />
                )}
                Run {genericConfig?.name ?? "tool"}
              </Button>
            </div>
          ) : (
            <div className="mt-6 space-y-4">
              <Textarea
                aria-label={
                  tool === "calculator"
                    ? "Calculator expression"
                    : `${copy.label} input`
                }
                value={text}
                onChange={event => setText(event.target.value)}
                rows={tool === "calculator" ? 2 : 8}
                placeholder={
                  tool === "translator"
                    ? "Paste text to translate…"
                    : tool === "summarizer"
                      ? "Paste notes, an article, or study material…"
                      : "(12 + 4) / 2"
                }
                className="border-white/10 bg-[#080b12] leading-7"
              />
              {tool === "translator" && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <LanguageSelect
                    value={sourceLanguage}
                    onChange={value => setSourceLanguage(value)}
                    includeAuto
                    label="Source language"
                    className="h-10 w-full rounded-md border border-white/10 bg-[#080b12] px-3 text-sm"
                  />
                  <LanguageSelect
                    value={targetLanguage}
                    onChange={value =>
                      value !== "auto" && setTargetLanguage(value)
                    }
                    label="Target language"
                    className="h-10 w-full rounded-md border border-white/10 bg-[#080b12] px-3 text-sm"
                  />
                </div>
              )}
              <Button
                onClick={() => void runTool()}
                disabled={busy || !text.trim()}
                className="bg-cyan-300 text-slate-950"
              >
                {busy ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Icon size={16} />
                )}
                {tool === "translator"
                  ? "Translate"
                  : tool === "summarizer"
                    ? "Summarize"
                    : "Calculate"}
              </Button>
            </div>
          )}

          {error && (
            <p role="alert" className="mt-4 text-sm text-rose-200">
              {error}
            </p>
          )}
          {result && (
            <div className="mt-5 rounded-xl border border-emerald-200/15 bg-emerald-200/[.03] p-5">
              <p className="mb-3 text-xs uppercase tracking-[.16em] text-emerald-200/70">
                Result
              </p>
              <RichText
                content={result}
                dir={
                  tool === "translator" && isRtl(targetLanguage)
                    ? "rtl"
                    : "auto"
                }
                className="prose prose-invert max-w-none text-sm leading-7"
              />
            </div>
          )}
        </section>

        <aside className="h-fit rounded-2xl border border-white/10 bg-white/[.03] p-5">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Layers3 size={16} className="text-cyan-200" /> Tab configuration
          </div>
          <dl className="mt-4 space-y-3 text-sm">
            <div>
              <dt className="text-xs text-white/40">Function</dt>
              <dd className="mt-1 text-white/80">
                {genericConfig?.name ?? copy.label}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-white/40">Scope</dt>
              <dd className="mt-1 text-white/80">
                This account and this tab only
              </dd>
            </div>
            <div>
              <dt className="text-xs text-white/40">Safety</dt>
              <dd className="mt-1 leading-6 text-white/60">
                Text-only execution. No arbitrary eval, live source rewriting,
                integrations, deployment, or account changes.
              </dd>
            </div>
          </dl>
          <Button
            variant="outline"
            onClick={() => setLocation("/upgrade")}
            className="mt-5 w-full"
          >
            <ArrowLeft size={16} /> Manage this tab
          </Button>
        </aside>
      </div>
    </WorkspaceShell>
  );
}
